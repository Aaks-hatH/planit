#!/usr/bin/env bash
# Copies the PlanIt install-guide + check-in UI files into your repo's frontend/ folder.
# Run from anywhere inside your repo:  bash apply.sh
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
# find the frontend folder (the one holding vite.config.js), skipping node_modules
FE="$(find "$ROOT" -type f -name vite.config.js -not -path '*/node_modules/*' -exec dirname {} \; | head -n1)"
if [ -z "$FE" ] || [ ! -d "$FE/src" ]; then echo "Could not find the frontend folder (vite.config.js + src/)."; exit 1; fi
echo "Frontend folder: $FE"
cp -rv "$HERE/frontend/src/." "$FE/src/"
echo "Done. Next: cd \"$FE\" && npm run build"
