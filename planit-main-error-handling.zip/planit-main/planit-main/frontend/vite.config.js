import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      // 'prompt': a new version waits until the person taps Reload (see src/utils/appUpdate.js).
      // It must never swap itself in while check-ins are unsynced or a ticket is on screen.
      registerType: 'prompt',
      includeAssets: ['planit-icon.svg', 'apple-touch-icon.png', 'favicon.ico'],
      manifest: {
        name: 'PlanIt',
        short_name: 'PlanIt',
        description: 'Plan events together with secure chat, polls, and file sharing',
        theme_color: '#000000',
        background_color: '#000000',
        display: 'standalone',
        id: '/',
        start_url: '/',
        scope: '/',
        categories: ['productivity', 'events'],
        shortcuts: [
          {
            name: 'Check-in',
            short_name: 'Check-in',
            description: 'Open PlanIt to the check-in screen',
            url: '/',
            icons: [{ src: 'pwa-192x192.png', sizes: '192x192', type: 'image/png' }]
          }
        ],
        icons: [
          {
            src: 'pwa-192x192.png',
            sizes: '192x192',
            type: 'image/png',
            purpose: 'any'
          },
          {
            src: 'pwa-512x512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'any'
          },
          {
            src: 'pwa-maskable-192x192.png',
            sizes: '192x192',
            type: 'image/png',
            purpose: 'maskable'
          },
          {
            src: 'pwa-maskable-512x512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable'
          }
        ]
      },
      workbox: {
        maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
        // Navigations are fetched fresh (network first); see sw-offline-shell.js for the offline fallback.
        // index.html IS precached now (as the offline app shell). It used to be excluded so Safari would
        // always pick up new deployments. That is still guaranteed: sw-offline-shell.js only serves
        // the cached shell when the network fails, times out or answers 5xx; online users always get
        // the fresh HTML. Without a cached shell, any page not visited before could not open offline.
        globPatterns: ['index.html', '**/*.{js,css,ico,png,svg,woff,woff2}'],
        importScripts: ['sw-offline-shell.js'],
        // Navigations are handled by sw-offline-shell.js (network first, precached shell as fallback)
        // and the NetworkFirst runtime route below, so the built-in precache fallback stays off.
        navigateFallback: null,
        runtimeCaching: [
          {
            // Navigation requests (HTML) — always go to the network first.
            // Falls back to cache only when fully offline. This ensures
            // Safari always receives the latest index.html on every load.
            urlPattern: ({ request }) => request.mode === 'navigate',
            handler: 'NetworkFirst',
            options: {
              cacheName: 'pages-cache',
              networkTimeoutSeconds: 5,
              expiration: {
                maxEntries: 5,
                maxAgeSeconds: 60 * 60 * 24, // 1 day max in offline cache
              },
            },
          },
          {
            // API calls must NEVER be cached or intercepted by the SW.
            // The /resolve endpoint in particular must always hit the network
            // so suspended/cancelled WL sites are blocked immediately.
            urlPattern: /\/api\//i,
            handler: 'NetworkOnly',
          },
          {
            urlPattern: /^https:\/\/fonts\.googleapis\.com\/.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 'google-fonts-cache',
              expiration: {
                maxEntries: 10,
                maxAgeSeconds: 60 * 60 * 24 * 365 // 1 year
              },
              cacheableResponse: {
                statuses: [0, 200]
              }
            }
          },
          {
            urlPattern: /^https:\/\/fonts\.gstatic\.com\/.*/i,
            handler: 'CacheFirst',
            options: {
              cacheName: 'gstatic-fonts-cache',
              expiration: {
                maxEntries: 10,
                maxAgeSeconds: 60 * 60 * 24 * 365 // 1 year
              },
              cacheableResponse: {
                statuses: [0, 200]
              }
            }
          }
        ],
        cleanupOutdatedCaches: true,
        skipWaiting: false,   // wait for the Reload tap (SKIP_WAITING message from registerSW)
        clientsClaim: true
      },
      devOptions: {
        enabled: false
      }
    })
  ],
  publicDir: 'public',
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/uploads': {
        target: 'http://localhost:5000',
        changeOrigin: true
      },
      '/socket.io': {
        target: 'http://localhost:5000',
        changeOrigin: true,
        ws: true
      }
    }
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
    // Target modern browsers — smaller output, no legacy polyfills
    target: 'es2020',
    // Raise the chunk-size warning threshold; our lazy chunks are intentionally large
    chunkSizeWarningLimit: 800,
    rollupOptions: {
      output: {
        // Split vendor code into stable, long-cacheable chunks.
        // Named chunks get deterministic filenames so a CDN/browser can cache
        // them across deploys when the underlying library hasn't changed.
        manualChunks(id) {
          // Core React runtime — almost never changes, should be cached forever
          if (id.includes('node_modules/react/') ||
              id.includes('node_modules/react-dom/') ||
              id.includes('node_modules/react-router-dom/') ||
              id.includes('node_modules/react-router/')) {
            return 'react-vendor';
          }
          // Socket.IO — changes rarely; separate chunk avoids invalidating React cache
          if (id.includes('node_modules/socket.io-client') ||
              id.includes('node_modules/engine.io-client')) {
            return 'socket';
          }
          // Utility libs
          if (id.includes('node_modules/axios') ||
              id.includes('node_modules/crypto-js') ||
              id.includes('node_modules/date-fns')) {
            return 'utils';
          }
          // Shared public UI (nav, footer, modal...) is imported from several lazy
          // chunks. Giving it its own chunk keeps it out of the venue/whitelabel/admin
          // chunks, which would otherwise import each other in a cycle.
          if (id.includes('/src/components/ui/')) {
            return 'ui-shared';
          }
          // Admin panel is large and only ever used by organizers — keep it isolated
          if (id.includes('/src/pages/Admin') ||
              id.includes('/src/pages/SecurityDashboard') ||
              id.includes('/src/components/PlatformAnalyticsDashboard')) {
            return 'admin';
          }
          // Venue and white-label pages are already lazy routes, so Rollup splits them on the dynamic imports.
          // (Manual 'venue' and 'whitelabel' chunks imported each other, which crashed the app with a
          // circular-chunk error: "Cannot access 'Qr' before initialization".)
        },
      },
    },
  }
})
