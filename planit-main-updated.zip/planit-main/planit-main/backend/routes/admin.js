const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { realIp } = require('../middleware/realIp');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const os = require('os');
const mongoose = require('mongoose');
const { body, validationResult } = require('express-validator');
const Event = require('../models/Event');
const Message = require('../models/Message');
const Poll = require('../models/Poll');
const File = require('../models/File');
const EventParticipant = require('../models/EventParticipant');
const Invite = require('../models/Invite');
const Employee = require('../models/Employee');
const { verifyAdmin, requirePermission, requireAnyPermission, requireSuperAdminRole, demoGuard,
        revokeEmployeeSessions, clearEmployeeRevocation, invalidateEmployeeAccess } = require('../middleware/auth');
const OrgNode        = require('../models/OrgNode');
const JobApplication = require('../models/JobApplication');
const perms          = require('../utils/permissions');
const team           = require('../services/teamService');
const { authLimiter } = require('../middleware/rateLimiter');
const { secrets } = require('../keys');
const Blocklist = require('../models/Blocklist');
const redis     = require('../services/redisClient');
const { audit, getAuditLogs } = require('../models/AuditLog');
const speakeasy  = require('speakeasy');
const QRCode     = require('qrcode');
const { verifyTurnstile } = require('../services/captchaService');
const { unbanIp, listActiveBans } = require('../middleware/security');

// ─── TOTP helpers ─────────────────────────────────────────────────────────────
// Encrypt a TOTP secret before storing it so the DB field is not plaintext.
// We derive an encryption key from the license key so there's no extra secret.
//
// SEC FIX: previously AES-128-CBC with no integrity check (ciphertext could be
// tampered with undetected) and a key that was just a raw slice of another
// secret. Now AES-256-GCM (authenticated) with the key derived via SHA-256
// so we always get a full 32-byte key regardless of secrets.db's length/format.
function _totpKey() {
  return crypto.createHash('sha256').update(String(secrets.db)).digest(); // 32-byte AES-256 key
}
function encryptTotpSecret(secret) {
  const iv     = crypto.randomBytes(12); // 96-bit nonce, standard for GCM
  const key    = _totpKey();
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const enc    = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()]);
  const tag    = cipher.getAuthTag();
  return `v2:${iv.toString('hex')}:${tag.toString('hex')}:${enc.toString('hex')}`;
}
function decryptTotpSecret(stored) {
  const parts = stored.split(':');
  if (parts[0] === 'v2') {
    const [, ivHex, tagHex, encHex] = parts;
    const iv  = Buffer.from(ivHex,  'hex');
    const tag = Buffer.from(tagHex, 'hex');
    const enc = Buffer.from(encHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', _totpKey(), iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
  }
  // Legacy format (iv:enc, AES-128-CBC keyed off the raw secrets.db slice) —
  // kept read-only so 2FA secrets stored before this fix still decrypt.
  // New/rotated secrets always use the v2 (GCM) format above.
  const [ivHex, encHex] = parts;
  const iv  = Buffer.from(ivHex,  'hex');
  const enc = Buffer.from(encHex, 'hex');
  const legacyKey = Buffer.from(String(secrets.db).slice(0, 32), 'hex');
  const decipher = crypto.createDecipheriv('aes-128-cbc', legacyKey, iv);
  return Buffer.concat([decipher.update(enc), decipher.final()]).toString('utf8');
}
function verifyTotpCode(encryptedSecret, code) {
  try {
    const secret = decryptTotpSecret(encryptedSecret);
    return speakeasy.totp.verify({ secret, encoding: 'base32', token: code, window: 1 });
  } catch { return false; }
}

// ─── Brute-force lockout constants ────────────────────────────────────────────
// After LOCKOUT_MAX_ATTEMPTS failed logins from the same IP + username combo,
// the account is locked for LOCKOUT_WINDOW_SECS seconds. Subsequent attempts
// return 429 without ever hitting bcrypt, which also prevents timing attacks.
const LOCKOUT_MAX_ATTEMPTS = 5;
const LOCKOUT_WINDOW_SECS  = 15 * 60; // 15 minutes

// Key helpers — scoped to IP + lowercased username so username enumeration is
// harder (an attacker from a new IP gets a fresh counter).
const _lockKey = (ip, user) => `login:lock:${ip}:${user.toLowerCase().slice(0, 50)}`;
const _failKey = (ip, user) => `login:fail:${ip}:${user.toLowerCase().slice(0, 50)}`;

// ─── Validation middleware ────────────────────────────────────────────────────
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

// ─── Global in-memory log ring-buffer (2 000 entries) ────────────────────────
// Patched once at first require; survives hot-reloads because the object lives
// on `global`.  All console.log / warn / error calls on the server are captured
// and broadcast to SSE clients in real time.
if (!global.__adminLogBuffer) {
  global.__adminLogBuffer  = [];
  global.__adminLogClients = [];

  const MAX = 10000;
  const safeStr = (a) => {
    if (typeof a !== 'object' || a === null) return String(a);
    try {
      const seen = new WeakSet();
      return JSON.stringify(a, (_k, v) => {
        if (typeof v === 'object' && v !== null) {
          if (seen.has(v)) return '[Circular]';
          seen.add(v);
        }
        return v;
      }, 0);
    } catch { return String(a); }
  };

  const push = (level, args) => {
    const entry = {
      ts:    new Date().toISOString(),
      level,
      msg:   args.map(safeStr).join(' '),
      pid:   process.pid,
    };
    global.__adminLogBuffer.push(entry);
    if (global.__adminLogBuffer.length > MAX) global.__adminLogBuffer.shift();
    global.__adminLogClients.forEach(send => { try { send(entry); } catch {} });
  };

  const _log   = console.log.bind(console);
  const _warn  = console.warn.bind(console);
  const _error = console.error.bind(console);
  console.log   = (...a) => { push('info',  a); _log(...a);   };
  console.warn  = (...a) => { push('warn',  a); _warn(...a);  };
  console.error = (...a) => { push('error', a); _error(...a); };
}

// ═══════════════════════════════════════════════════════════════════════════════
// AUTHENTICATION
// ═══════════════════════════════════════════════════════════════════════════════

router.post(
  '/login',
  authLimiter,
  [
    body('username').trim().notEmpty().withMessage('Username is required'),
    body('password').notEmpty().withMessage('Password is required'),
    // turnstileToken is optional — validated below only when configured
    body('turnstileToken').optional().isString(),
    validate,
  ],
  async (req, res) => {
    try {
      const { username, password, turnstileToken, totpCode } = req.body;
      const ip = realIp(req);

      // ── Turnstile verification ────────────────────────────────────────────────
      // Checked first, before any credential work, so bots can't even attempt
      // brute-force without solving a challenge. Fails open when router is
      // unreachable (network error) so a router outage never locks admins out.
      const tsResult = await verifyTurnstile(turnstileToken, ip, { failOpen: true, context: 'admin' });
      if (!tsResult.ok) {
        return res.status(400).json({ error: 'Human verification failed. Please try again.' });
      }

      // ── Brute-force lockout check ────────────────────────────────────────────
      const lockKey  = _lockKey(ip, username);
      const isLocked = await redis.get(lockKey);
      if (isLocked) {
        audit('login_locked', {
          req,
          actor: { email: username, role: 'unknown' },
          status: 'blocked',
          details: { username, ip, reason: 'lockout_active' },
        });
        return res.status(429).json({
          error: 'Too many failed login attempts. This account is temporarily locked. Try again in 15 minutes.',
          lockedOut: true,
        });
      }

      // ── Helper: record a failed attempt and potentially lock ─────────────────
      const recordFailure = async (reason = '') => {
        const failKey  = _failKey(ip, username);
        const attempts = await redis.incrWithExpiry(failKey, LOCKOUT_WINDOW_SECS);
        if (attempts >= LOCKOUT_MAX_ATTEMPTS) {
          await redis.set(lockKey, '1', LOCKOUT_WINDOW_SECS);
          await redis.del(failKey);
          audit('login_locked', {
            req,
            actor: { email: username, role: 'unknown' },
            status: 'blocked',
            details: { username, ip, attempts, reason },
          });
          return { locked: true, attempts };
        }
        audit('login_failure', {
          req,
          actor: { email: username, role: 'unknown' },
          status: 'failure',
          details: { username, ip, attempts, remaining: LOCKOUT_MAX_ATTEMPTS - attempts, reason },
        });
        return { locked: false, attempts };
      };

      // ── Helper: clear fail counter after a successful login ───────────────────
      const clearFailCounter = async () => {
        await redis.del(_failKey(ip, username)).catch(() => {});
      };

      const adminUsername = process.env.ADMIN_USERNAME || 'admin';
      const adminPassword = process.env.ADMIN_PASSWORD || 'admin123';

      // ── Demo account check ───────────────────────────────────────────────────
      const demoUsername = process.env.DEMO_USERNAME || '';
      const demoPassword = process.env.DEMO_PASSWORD || '';
      if (demoUsername && demoPassword && username === demoUsername && password === demoPassword) {
        const jti = crypto.randomUUID();
        const demoToken = jwt.sign(
          {
            jti, username: demoUsername, name: 'Demo Account',
            isAdmin: true, isEmployee: true, isDemo: true,
            role: 'demo', permissions: {},
          },
          secrets.jwt,
          { expiresIn: '8h' },
        );
        audit('login_success', {
          req,
          actor: { email: demoUsername, role: 'demo', name: 'Demo Account' },
          details: { type: 'demo', ip },
        });
        return res.json({
          message: 'Demo login successful',
          token: demoToken,
          user: { username: demoUsername, name: 'Demo Account', role: 'demo', isEmployee: true, isDemo: true, permissions: {} },
        });
      }

      if (username !== adminUsername || password !== adminPassword) {
        // ── Employee login ────────────────────────────────────────────────────
        // Fetch with +totpSecret so we can verify TOTP when enabled
        const employee = await Employee.findOne(
          { email: username.toLowerCase().trim(), status: 'active' },
        ).select('+totpSecret');

        if (!employee || !employee.passwordHash) {
          const { locked } = await recordFailure('unknown_user');
          if (locked) return res.status(429).json({ error: 'Too many failed login attempts. Account locked for 15 minutes.', lockedOut: true });
          return res.status(401).json({ error: 'Invalid credentials' });
        }

        const match = await bcrypt.compare(password, employee.passwordHash);
        if (!match) {
          const { locked } = await recordFailure('bad_password');
          if (locked) return res.status(429).json({ error: 'Too many failed login attempts. Account locked for 15 minutes.', lockedOut: true });
          return res.status(401).json({ error: 'Invalid credentials' });
        }

        // ── forcePasswordReset enforcement ─────────────────────────────────────
        if (employee.forcePasswordReset) {
          await clearFailCounter();
          const resetToken = jwt.sign(
            {
              jti: crypto.randomUUID(),
              employeeId: employee._id.toString(),
              email: employee.email,
              role: employee.role,
              isAdmin: true, isEmployee: true,
              forcePasswordReset: true, restricted: true,
            },
            secrets.jwt,
            { expiresIn: '1h' },
          );
          audit('login_failure', {
            req,
            actor: { employeeId: employee._id.toString(), email: employee.email, role: employee.role, name: employee.name },
            status: 'failure',
            details: { reason: 'force_password_reset_required', ip },
          });
          return res.status(403).json({
            error: 'You must change your password before continuing.',
            forcePasswordReset: true, resetToken, employeeId: employee._id.toString(),
          });
        }

        // ── TOTP check ────────────────────────────────────────────────────────
        // If the employee has TOTP enabled, password alone is insufficient.
        // Return requiresTOTP: true so the frontend shows the code input.
        // The totpCode must arrive in the same request (single round-trip after
        // the first challenge response) to prevent a half-authenticated state.
        if (employee.totpEnabled && employee.totpSecret) {
          if (!totpCode) {
            // Password correct but no TOTP code supplied — signal the frontend
            return res.status(200).json({ requiresTOTP: true });
          }
          const validTotp = verifyTotpCode(employee.totpSecret, String(totpCode).replace(/\s/g, ''));
          if (!validTotp) {
            const { locked } = await recordFailure('bad_totp');
            if (locked) return res.status(429).json({ error: 'Too many failed login attempts. Account locked for 15 minutes.', lockedOut: true });
            return res.status(401).json({ error: 'Invalid authenticator code.' });
          }
        }

        // ── Successful employee login ──────────────────────────────────────────
        await clearFailCounter();
        const jti = crypto.randomUUID();
        const empToken = jwt.sign(
          {
            jti,
            employeeId:  employee._id.toString(),
            name:        employee.name,
            email:       employee.email,
            role:        employee.role,
            isAdmin:     true,
            isEmployee:  true,
            isDemo:      employee.isDemo || false,
            permissions: employee.permissions,
          },
          secrets.jwt,
          { expiresIn: '24h' },
        );

        Employee.findByIdAndUpdate(employee._id, {
          $set: { lastLogin: new Date(), previousLogin: employee.lastLogin || null }, $inc: { loginCount: 1 },
        }).catch(() => {});
        team.recordLogin(req, { actorId: employee._id, name: employee.name, email: employee.email, role: employee.role, totp: !!employee.totpEnabled });

        audit('login_success', {
          req,
          actor: { employeeId: employee._id.toString(), email: employee.email, role: employee.role, name: employee.name },
          details: { ip, jti, totp: employee.totpEnabled },
        });

        return res.json({
          message: 'Employee login successful',
          token: empToken,
          user: {
            username:    employee.name,
            email:       employee.email,
            role:        employee.role,
            isEmployee:  true,
            isDemo:      employee.isDemo || false,
            permissions: employee.permissions,
            forcePasswordReset: false,
            totpEnabled: employee.totpEnabled || false,
          },
        });
      }

      // ── Root super-admin login ────────────────────────────────────────────────
      // Root admin TOTP is stored in Redis under key `totp:root:secret` (encrypted,
      // same AES-128 scheme used for employee secrets). If that key exists, TOTP
      // is considered enabled and a valid code must accompany the login.
      const rootTotpEncrypted = await redis.get('totp:root:secret').catch(() => null);
      const rootTotpEnabled   = !!rootTotpEncrypted;

      if (rootTotpEnabled) {
        if (!totpCode) {
          // Password correct but no TOTP code — tell frontend to show the TOTP step
          return res.status(200).json({ requiresTOTP: true });
        }
        const validTotp = verifyTotpCode(rootTotpEncrypted, String(totpCode).replace(/\s/g, ''));
        if (!validTotp) {
          const { locked } = await recordFailure('bad_totp_root');
          if (locked) {
            return res.status(429).json({
              error: 'Too many failed attempts. This account is temporarily locked.',
              lockedOut: true,
            });
          }
          return res.status(401).json({ error: 'Invalid authenticator code.' });
        }
      }

      await clearFailCounter();
      const jti   = crypto.randomUUID();
      const token = jwt.sign(
        { jti, username, isAdmin: true, role: 'super_admin' },
        secrets.jwt,
        { expiresIn: '24h' },
      );

      team.recordLogin(req, { actorId: 'root', actorType: 'root', name: 'Super Admin', email: String(username), role: 'super_admin', totp: rootTotpEnabled });
      audit('login_success', {
        req,
        actor: { email: username, role: 'super_admin', name: 'Root Admin' },
        details: { type: 'root', ip, jti, totp: rootTotpEnabled },
      });

      res.json({
        message: 'Admin login successful',
        token,
        user: { username, role: 'super_admin', totpEnabled: rootTotpEnabled },
      });
    } catch (error) {
      console.error('[admin/login] error:', error);
      res.status(500).json({ error: 'Login failed' });
    }
  }
);

// ═══════════════════════════════════════════════════════════════════════════════
// TOTP SETUP ROUTES  (authenticated — employee must already be logged in)
// ═══════════════════════════════════════════════════════════════════════════════

// GET /admin/totp/status  — returns whether TOTP is enabled for the caller
router.get('/totp/status', verifyAdmin, async (req, res) => {
  try {
    const empId = req.user?.employeeId;
    if (!empId) {
      // Root admin — secret lives in Redis
      const rootSecret = await redis.get('totp:root:secret').catch(() => null);
      return res.json({ totpEnabled: !!rootSecret, isRootAdmin: true });
    }
    const emp = await Employee.findById(empId).select('totpEnabled');
    res.json({ totpEnabled: emp?.totpEnabled || false, isRootAdmin: false });
  } catch { res.status(500).json({ error: 'Failed to fetch TOTP status' }); }
});

// POST /admin/totp/setup  — generate a new TOTP secret, return QR code URI
// Does NOT enable TOTP yet — caller must verify a code first via /totp/enable.
// Works for both employee accounts (secret stored in DB) and the root admin
// (secret stored in Redis under totp:root:secret, same AES-128 encryption).
router.post('/totp/setup', verifyAdmin, async (req, res) => {
  try {
    const empId = req.user?.employeeId;

    // ── Root admin path ───────────────────────────────────────────────────────
    if (!empId) {
      const rawSecret = speakeasy.generateSecret({ length: 20 });
      const encryptedPending = encryptTotpSecret(rawSecret.base32);
      // 10-minute window to scan the QR and verify a code
      await redis.set('totp:root:pending', encryptedPending, 10 * 60);

      const otpauthUrl = speakeasy.otpauthURL({
        secret: rawSecret.ascii,
        label:  encodeURIComponent('PlanIt:root'),
        issuer: 'PlanIt',
      });
      const qrDataUrl = await QRCode.toDataURL(otpauthUrl);
      return res.json({ qr: qrDataUrl, secret: rawSecret.base32, isRootAdmin: true });
    }

    // ── Employee path ─────────────────────────────────────────────────────────
    const emp = await Employee.findById(empId);
    if (!emp) return res.status(404).json({ error: 'Employee not found' });

    const rawSecret = speakeasy.generateSecret({ length: 20 });
    const encryptedPending = encryptTotpSecret(rawSecret.base32);
    await redis.set(`totp:pending:${empId}`, encryptedPending, 10 * 60);

    const otpauthUrl = speakeasy.otpauthURL({
      secret: rawSecret.ascii,
      label:  encodeURIComponent(`PlanIt:${emp.email}`),
      issuer: 'PlanIt',
    });
    const qrDataUrl = await QRCode.toDataURL(otpauthUrl);
    res.json({ qr: qrDataUrl, secret: rawSecret.base32, isRootAdmin: false });
  } catch (err) {
    console.error('[totp/setup]', err);
    res.status(500).json({ error: 'TOTP setup failed' });
  }
});

// POST /admin/totp/enable  — verify the setup code and activate TOTP
router.post('/totp/enable', verifyAdmin, async (req, res) => {
  try {
    const empId = req.user?.employeeId;
    const { code } = req.body;
    if (!code || typeof code !== 'string') return res.status(400).json({ error: 'Verification code required' });

    // ── Root admin path ───────────────────────────────────────────────────────
    if (!empId) {
      const encryptedPending = await redis.get('totp:root:pending');
      if (!encryptedPending) return res.status(400).json({ error: 'TOTP setup session expired. Please start setup again.' });

      const valid = verifyTotpCode(encryptedPending, code.replace(/\s/g, ''));
      if (!valid) return res.status(400).json({ error: 'Invalid code. Please check your authenticator app and try again.' });

      // Promote pending → permanent (no TTL)
      await redis.set('totp:root:secret', encryptedPending);
      await redis.del('totp:root:pending');

      audit('totp_enabled', {
        req,
        actor: { email: req.user?.username, role: 'super_admin', name: 'Root Admin' },
        details: { ip: realIp(req), account: 'root' },
      });
      return res.json({ ok: true, message: 'Two-factor authentication has been enabled for the root admin.' });
    }

    // ── Employee path ─────────────────────────────────────────────────────────
    const pendingKey = `totp:pending:${empId}`;
    const encryptedPending = await redis.get(pendingKey);
    if (!encryptedPending) return res.status(400).json({ error: 'TOTP setup session expired. Please start setup again.' });

    const valid = verifyTotpCode(encryptedPending, code.replace(/\s/g, ''));
    if (!valid) return res.status(400).json({ error: 'Invalid code. Please check your authenticator app and try again.' });

    await Employee.findByIdAndUpdate(empId, {
      $set: { totpSecret: encryptedPending, totpEnabled: true, twoFactorEnabled: true },
    });
    await redis.del(pendingKey);

    audit('totp_enabled', {
      req,
      actor: { employeeId: empId, email: req.user.email, role: req.user.role },
      details: { ip: realIp(req) },
    });

    res.json({ ok: true, message: 'Two-factor authentication has been enabled.' });
  } catch (err) {
    console.error('[totp/enable]', err);
    res.status(500).json({ error: 'Failed to enable TOTP' });
  }
});

// POST /admin/totp/disable  — disable TOTP (requires current password + totp code)
router.post('/totp/disable', verifyAdmin, async (req, res) => {
  try {
    const empId = req.user?.employeeId;
    const { password, code } = req.body;
    if (!password || !code) return res.status(400).json({ error: 'Current password and authenticator code required.' });

    // ── Root admin path ───────────────────────────────────────────────────────
    if (!empId) {
      const rootSecret = await redis.get('totp:root:secret');
      if (!rootSecret) return res.status(400).json({ error: 'TOTP is not enabled on the root account.' });

      // Verify password
      const adminUser = (process.env.ADMIN_USERNAME || '').trim();
      const adminPass = (process.env.ADMIN_PASSWORD || '').trim();
      if (password !== adminPass) return res.status(401).json({ error: 'Incorrect password.' });

      // Verify TOTP code
      const totpOk = verifyTotpCode(rootSecret, String(code).replace(/\s/g, ''));
      if (!totpOk) return res.status(401).json({ error: 'Invalid authenticator code.' });

      await redis.del('totp:root:secret');

      audit('totp_disabled', {
        req,
        actor: { email: adminUser, role: 'super_admin', name: 'Root Admin' },
        details: { ip: realIp(req), account: 'root' },
      });
      return res.json({ ok: true, message: 'Two-factor authentication has been disabled for the root admin.' });
    }

    // ── Employee path ─────────────────────────────────────────────────────────
    const emp = await Employee.findById(empId).select('+totpSecret +passwordHash totpEnabled');
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    if (!emp.totpEnabled || !emp.totpSecret) return res.status(400).json({ error: 'TOTP is not enabled.' });

    const passOk = await bcrypt.compare(password, emp.passwordHash || '');
    if (!passOk) return res.status(401).json({ error: 'Incorrect password.' });

    const totpOk = verifyTotpCode(emp.totpSecret, String(code).replace(/\s/g, ''));
    if (!totpOk) return res.status(401).json({ error: 'Invalid authenticator code.' });

    await Employee.findByIdAndUpdate(empId, {
      $set:   { totpEnabled: false, twoFactorEnabled: false },
      $unset: { totpSecret: '' },
    });

    audit('totp_disabled', {
      req,
      actor: { employeeId: empId, email: req.user.email, role: req.user.role },
      details: { ip: realIp(req) },
    });

    res.json({ ok: true, message: 'Two-factor authentication has been disabled.' });
  } catch (err) {
    console.error('[totp/disable]', err);
    res.status(500).json({ error: 'Failed to disable TOTP' });
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// DEMO GUARD  —  router-level write intercept for demo accounts
// ═══════════════════════════════════════════════════════════════════════════════
// Mounted here so it covers ALL routes below.  The login route above is exempt
// (no auth required there).  demoGuard is a no-op when req.admin is not yet set
// (the individual route's verifyAdmin will run first, but demoGuard only acts
// on demo tokens anyway — and requirePermission ALSO blocks demo accounts on
// any permissioned route, giving us defence-in-depth).
router.use(demoGuard);

// ═══════════════════════════════════════════════════════════════════════════════
// DASHBOARD & STATISTICS
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/stats', verifyAdmin, requireAnyPermission('canViewDashboard', 'canViewAnalytics'), async (req, res, next) => {
  try {
    const [
      totalEvents,
      activeEvents,
      totalMessages,
      totalPolls,
      totalFiles,
    ] = await Promise.all([
      Event.countDocuments(),
      Event.countDocuments({ status: 'active' }),
      Message.countDocuments({ isDeleted: false }),
      Poll.countDocuments(),
      File.countDocuments({ isDeleted: false }),
    ]);

    const yesterday   = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentEvents = await Event.countDocuments({ createdAt: { $gte: yesterday } });

    const events = await Event.find({}, 'participants');
    const totalParticipants = events.reduce((sum, e) => sum + e.participants.length, 0);

    const fileStats   = await File.aggregate([
      { $match: { isDeleted: false } },
      { $group: { _id: null, totalSize: { $sum: '$size' } } },
    ]);
    const totalStorage = fileStats.length > 0 ? fileStats[0].totalSize : 0;

    res.json({
      totalEvents,
      activeEvents,
      totalMessages,
      totalPolls,
      totalFiles,
      totalParticipants,
      recentEvents,
      totalStorage,
      averageParticipantsPerEvent:
        totalEvents > 0 ? Math.round(totalParticipants / totalEvents) : 0,
    });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// SYSTEM INFO  —  GET /admin/system
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/system', verifyAdmin, requirePermission('canViewSystem'), async (req, res, next) => {
  try {
    const mem      = process.memoryUsage();
    const load     = os.loadavg();
    const totalMem = os.totalmem();
    const freeMem  = os.freemem();

    const [evCount, msgCount, partCount, pollCount, fileCount, incCount, empCount] =
      await Promise.all([
        Event.countDocuments(),
        Message.countDocuments(),
        EventParticipant.countDocuments(),
        Poll.countDocuments(),
        File.countDocuments(),
        mongoose.connection.db
          ?.collection('incidents')
          .countDocuments()
          .catch(() => 0) ?? Promise.resolve(0),
        Employee.countDocuments(),
      ]);

    res.json({
      process: {
        pid:         process.pid,
        nodeVersion: process.version,
        platform:    process.platform,
        arch:        process.arch,
        uptime:      Math.floor(process.uptime()),
        env:         process.env.NODE_ENV || 'production',
        memoryMB: {
          rss:       +(mem.rss       / 1024 / 1024).toFixed(1),
          heapUsed:  +(mem.heapUsed  / 1024 / 1024).toFixed(1),
          heapTotal: +(mem.heapTotal / 1024 / 1024).toFixed(1),
          external:  +(mem.external  / 1024 / 1024).toFixed(1),
        },
      },
      os: {
        hostname:   os.hostname(),
        type:       os.type(),
        release:    os.release(),
        cpus:       os.cpus().length,
        loadAvg:    load.map(l => +l.toFixed(2)),
        totalMemMB: +(totalMem / 1024 / 1024).toFixed(0),
        freeMemMB:  +(freeMem  / 1024 / 1024).toFixed(0),
        usedMemPct: +(((totalMem - freeMem) / totalMem) * 100).toFixed(1),
      },
      db: {
        state:     mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
        stateCode: mongoose.connection.readyState,
        host:      mongoose.connection.host,
        name:      mongoose.connection.name,
      },
      collections: {
        events:       evCount,
        messages:     msgCount,
        participants: partCount,
        polls:        pollCount,
        files:        fileCount,
        incidents:    incCount,
        employees:    empCount,
      },
      serverTime: new Date().toISOString(),
    });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// LIVE LOGS
// ═══════════════════════════════════════════════════════════════════════════════

// GET /admin/logs/fleet — fetches logs from every fleet service via the router.
// The router fans out to itself, every known backend, and the watchdog, then
// returns everything merged by timestamp. Only ROUTER_URL needs to be set here —
// WATCHDOG_URL and backend URLs are all managed on the router side.
router.get('/logs/fleet', verifyAdmin, requirePermission('canViewLogs'), requirePermission('canViewLogs'), async (req, res) => {
  const { meshGet } = require('../middleware/mesh');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = process.env.ROUTER_URL    || '';

  if (!routerUrl) {
    // No router configured — return this backend's logs only as fallback
    const name = CALLER;
    const logs = (global.__adminLogBuffer || []).slice().map(e => ({ ...e, source: name.toLowerCase(), sourceName: name }));
    return res.json({
      logs,
      total:     logs.length,
      sources:   [{ source: name.toLowerCase(), name, ok: true, count: logs.length }],
      fetchedAt: new Date().toISOString(),
      note:      'ROUTER_URL not set — showing this backend only',
    });
  }

  const result = await meshGet(CALLER, `${routerUrl}/mesh/fleet-logs`, { timeout: 15000 });

  if (result.ok && result.data) {
    return res.json(result.data);
  }

  // Router unreachable — fall back to local logs only
  console.warn(`[admin] Fleet logs: router fetch failed — ${result.error}`);
  const name = CALLER;
  const logs = (global.__adminLogBuffer || []).slice().map(e => ({ ...e, source: name.toLowerCase(), sourceName: name }));
  res.json({
    logs,
    total:     logs.length,
    sources:   [
      { source: name.toLowerCase(), name, ok: true,  count: logs.length },
      { source: 'router',           name: 'Router',  ok: false, error: result.error },
    ],
    fetchedAt: new Date().toISOString(),
    note:      'Router unreachable — showing this backend only',
  });
});

// GET /admin/logs  — last N log lines (n=all returns everything)
router.get('/logs', verifyAdmin, requirePermission('canViewLogs'), (req, res) => {
  const raw = req.query.n;
  const n   = raw === 'all' ? Infinity : (parseInt(raw) || 500);
  const lvl = req.query.level;
  let entries = n === Infinity ? global.__adminLogBuffer.slice() : global.__adminLogBuffer.slice(-n);
  if (lvl) entries = entries.filter(e => e.level === lvl);
  res.json({ logs: entries, total: global.__adminLogBuffer.length });
});

// GET /admin/logs/stream  — Server-Sent Events real-time log stream
router.get('/logs/stream', verifyAdmin, requirePermission('canViewLogs'), (req, res) => {
  res.setHeader('Content-Type',  'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection',    'keep-alive');
  res.flushHeaders();

  // Send the last 50 lines immediately so the client sees context
  global.__adminLogBuffer.slice(-50).forEach(entry =>
    res.write(`data: ${JSON.stringify(entry)}\n\n`)
  );

  const send = entry => res.write(`data: ${JSON.stringify(entry)}\n\n`);
  global.__adminLogClients.push(send);

  const hb = setInterval(() => res.write(': heartbeat\n\n'), 20000);

  req.on('close', () => {
    clearInterval(hb);
    const idx = global.__adminLogClients.indexOf(send);
    if (idx !== -1) global.__adminLogClients.splice(idx, 1);
  });
});

// GET /admin/logs/full — complete system snapshot: ALL logs + full system state
// No pagination, no limits. Intended for debugging and incident investigation.
router.get('/logs/full', verifyAdmin, requirePermission('canViewLogs'), async (req, res, next) => {
  try {
    const mem      = process.memoryUsage();
    const load     = os.loadavg();
    const totalMem = os.totalmem();
    const freeMem  = os.freemem();
    const cpus     = os.cpus();

    const [evCount, msgCount, partCount, pollCount, fileCount, empCount] =
      await Promise.all([
        Event.countDocuments(),
        Message.countDocuments(),
        EventParticipant.countDocuments(),
        Poll.countDocuments(),
        File.countDocuments(),
        Employee.countDocuments(),
      ]);

    const errorCount = global.__adminLogBuffer.filter(e => e.level === 'error').length;
    const warnCount  = global.__adminLogBuffer.filter(e => e.level === 'warn').length;

    res.json({
      generatedAt: new Date().toISOString(),
      summary: {
        totalLogs:     global.__adminLogBuffer.length,
        errors:        errorCount,
        warnings:      warnCount,
        liveClients:   global.__adminLogClients.length,
      },
      process: {
        pid:         process.pid,
        nodeVersion: process.version,
        platform:    process.platform,
        arch:        process.arch,
        uptime:      Math.floor(process.uptime()),
        uptimeHuman: `${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m ${Math.floor(process.uptime() % 60)}s`,
        env:         process.env.NODE_ENV || 'production',
        memory: {
          rss:        `${(mem.rss       / 1024 / 1024).toFixed(1)} MB`,
          heapUsed:   `${(mem.heapUsed  / 1024 / 1024).toFixed(1)} MB`,
          heapTotal:  `${(mem.heapTotal / 1024 / 1024).toFixed(1)} MB`,
          external:   `${(mem.external  / 1024 / 1024).toFixed(1)} MB`,
        },
      },
      os: {
        hostname:    os.hostname(),
        type:        os.type(),
        release:     os.release(),
        cpuCount:    cpus.length,
        cpuModel:    cpus[0]?.model || 'unknown',
        loadAvg1m:   os.loadavg()[0].toFixed(2),
        loadAvg5m:   os.loadavg()[1].toFixed(2),
        loadAvg15m:  os.loadavg()[2].toFixed(2),
        totalMemMB:  (totalMem / 1024 / 1024).toFixed(0),
        freeMemMB:   (freeMem  / 1024 / 1024).toFixed(0),
        usedMemPct:  (((totalMem - freeMem) / totalMem) * 100).toFixed(1) + '%',
      },
      database: {
        state:       mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
        host:        mongoose.connection.host,
        name:        mongoose.connection.name,
        port:        mongoose.connection.port,
      },
      collections: {
        events:       evCount,
        messages:     msgCount,
        participants: partCount,
        polls:        pollCount,
        files:        fileCount,
        employees:    empCount,
      },
      config: {
        corsOrigin:      process.env.CORS_ORIGIN || 'not set',
        cloudinarySet:   !!(process.env.CLOUDINARY_CLOUD_NAME),
        licenseSet:      !!(process.env.PLANIT_LICENSE_KEY),
        adminUserSet:    !!(process.env.ADMIN_USERNAME),
      },
      // ALL log entries — no limit
      logs: global.__adminLogBuffer.slice(),
    });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// EVENT MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

// Get all events (paginated + filterable)
router.get('/events', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const page  = parseInt(req.query.page)  || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip  = (page - 1) * limit;

    const filter = {};
    if (req.query.status && req.query.status !== 'all') {
      filter.status = req.query.status;
    }
    if (req.query.search) {
      filter.$or = [
        { title:          { $regex: req.query.search, $options: 'i' } },
        { subdomain:      { $regex: req.query.search, $options: 'i' } },
        { organizerEmail: { $regex: req.query.search, $options: 'i' } },
        { organizerName:  { $regex: req.query.search, $options: 'i' } },
      ];
    }
    // Spam verdict filter — allows the admin events list to be scoped to flagged events
    if (req.query.spamVerdict && req.query.spamVerdict !== 'all') {
      filter.spamVerdict = req.query.spamVerdict;
    }

    const selectFields = req.query.spamVerdict
      ? '+spamScore +spamFlags +spamVerdict'
      : '';

    const query = Event.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit);
    if (selectFields) query.select(selectFields);

    const [events, total] = await Promise.all([
      query.lean(),
      Event.countDocuments(filter),
    ]);

    res.json({
      events,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    next(error);
  }
});

// Get single event details
router.get('/events/:eventId', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    const [messageCount, pollCount, fileCount, participantCount] = await Promise.all([
      Message.countDocuments({ eventId: event._id, isDeleted: false }),
      Poll.countDocuments({ eventId: event._id }),
      File.countDocuments({ eventId: event._id, isDeleted: false }),
      EventParticipant.countDocuments({ eventId: event._id }),
    ]);

    res.json({ event, stats: { messages: messageCount, polls: pollCount, files: fileCount, participants: participantCount } });
  } catch (error) {
    next(error);
  }
});

// Update event (full edit)
router.patch('/events/:eventId', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const allowed = [
      'title', 'description', 'date', 'location',
      'organizerName', 'organizerEmail', 'maxParticipants',
      'isPasswordProtected', 'isEnterpriseMode', 'subdomain', 'status',
      'themeColor', 'tags', 'coverImage', 'timezone',
    ];
    const updates = {};
    for (const field of allowed) {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    }
    if (updates.date === '') delete updates.date;
    if (updates.timezone !== undefined) {
      try { new Intl.DateTimeFormat('en-US', { timeZone: updates.timezone }); }
      catch { return res.status(400).json({ error: 'Invalid timezone' }); }
    }
    if (updates.date !== undefined && updates.date !== null && updates.date !== '' && isNaN(new Date(updates.date).getTime())) {
      return res.status(400).json({ error: 'Invalid date' });
    }
    // Allow patching nested settings fields
    // SEC FIX: keys came straight from req.body with no denylist, so a request
    // body like {"settings": {"__proto__": {...}}} or a "$"-prefixed key could
    // reach Mongoose's update path unfiltered. Block dangerous key shapes.
    const DANGEROUS_KEY = /^(__proto__|constructor|prototype)$/i;
    if (req.body.settings && typeof req.body.settings === 'object') {
      for (const [k, v] of Object.entries(req.body.settings)) {
        if (DANGEROUS_KEY.test(k) || k.startsWith('$') || k.includes('.')) continue;
        updates[`settings.${k}`] = v;
      }
    }

    // If the date is changing, remember the old one so RSVP hero/countdown blocks
    // that were seeded from it can follow the new time (otherwise they go stale).
    let oldDateMs = null;
    if (updates.date) {
      const prev = await Event.findById(req.params.eventId).select('date').lean();
      oldDateMs = prev?.date ? new Date(prev.date).getTime() : null;
    }

    const event = await Event.findByIdAndUpdate(
      req.params.eventId,
      updates,
      { new: true, runValidators: true }
    );
    if (!event) return res.status(404).json({ error: 'Event not found' });

    if (updates.date && oldDateMs !== null && Array.isArray(event.rsvpPageConfig?.sections)) {
      let touched = false;
      for (const sec of event.rsvpPageConfig.sections) {
        const c = sec?.content;
        if (!c) continue;
        if (sec.type === 'hero' && c.dateTime && new Date(c.dateTime).getTime() === oldDateMs) { c.dateTime = event.date; touched = true; }
        if (sec.type === 'countdown' && c.targetDateTime && new Date(c.targetDateTime).getTime() === oldDateMs) { c.targetDateTime = event.date; touched = true; }
      }
      if (touched) { event.markModified('rsvpPageConfig'); await event.save(); }
    }

    res.json({ message: 'Event updated successfully', event });
  } catch (error) {
    if (error.code === 11000) return res.status(400).json({ error: 'Subdomain already taken' });
    next(error);
  }
});

// Update event status
router.patch(
  '/events/:eventId/status',
  verifyAdmin,
  requirePermission('canEditEvents'),
  [
    body('status')
      .isIn(['draft', 'active', 'completed', 'cancelled'])
      .withMessage('Invalid status'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const event = await Event.findByIdAndUpdate(
        req.params.eventId,
        { status: req.body.status },
        { new: true }
      );
      if (!event) return res.status(404).json({ error: 'Event not found' });
      res.json({ message: 'Event status updated', event });
    } catch (error) {
      next(error);
    }
  }
);

// Delete event + all related data
router.delete('/events/:eventId', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    // Delete all File attachments from Cloudinary before wiping DB records
    const files = await File.find({ eventId: event._id });
    for (const file of files) {
      try { await file.deleteFromCloudinary(); } catch (_) {}
    }

    // Delete cover image from Cloudinary (stored as planit-covers/cover-{eventId})
    if (event.coverImage) {
      try {
        const cloudinary = require('cloudinary').v2;
        cloudinary.config({
          cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
          api_key:    process.env.CLOUDINARY_API_KEY,
          api_secret: process.env.CLOUDINARY_API_SECRET,
        });
        await cloudinary.uploader.destroy(`planit-covers/cover-${event._id}`, { resource_type: 'image' });
      } catch (_) {}
    }

    await Promise.all([
      Message.deleteMany({ eventId: event._id }),
      Poll.deleteMany({ eventId: event._id }),
      EventParticipant.deleteMany({ eventId: event._id }),
      Invite ? Invite.deleteMany({ eventId: event._id }) : Promise.resolve(),
      File.deleteMany({ eventId: event._id }),
      Event.findByIdAndDelete(event._id),
    ]);

    res.json({ message: 'Event and all related data deleted successfully' });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// MESSAGES MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/events/:eventId/messages', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const messages = await Message.find({ eventId: req.params.eventId, isDeleted: false })
      .sort({ createdAt: 1 })
      .lean();
    res.json({ messages });
  } catch (error) { next(error); }
});

router.delete('/events/:eventId/messages/:messageId', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    await Message.findByIdAndUpdate(req.params.messageId, { isDeleted: true, deletedAt: new Date() });
    res.json({ message: 'Message deleted' });
  } catch (error) { next(error); }
});

router.post('/events/:eventId/messages/bulk-delete', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    const { messageIds } = req.body;
    await Message.updateMany(
      { _id: { $in: messageIds }, eventId: req.params.eventId },
      { isDeleted: true, deletedAt: new Date() }
    );
    res.json({ message: `${messageIds.length} messages deleted` });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// PARTICIPANTS MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/events/:eventId/participants', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const participants = await EventParticipant.find({ eventId: req.params.eventId })
      .select('-password')
      .sort({ joinedAt: 1 })
      .lean();
    res.json({ participants });
  } catch (error) { next(error); }
});

router.delete('/events/:eventId/participants/:username', verifyAdmin, requirePermission('canManageUsers'), async (req, res, next) => {
  try {
    await EventParticipant.deleteOne({ eventId: req.params.eventId, username: req.params.username });
    await Event.findByIdAndUpdate(req.params.eventId, {
      $pull: { participants: { username: req.params.username } },
    });
    res.json({ message: 'Participant removed' });
  } catch (error) { next(error); }
});

router.delete('/events/:eventId/participants/:username/password', verifyAdmin, requirePermission('canManageUsers'), async (req, res, next) => {
  try {
    await EventParticipant.findOneAndUpdate(
      { eventId: req.params.eventId, username: req.params.username },
      { $unset: { password: '' }, hasPassword: false }
    );
    res.json({ message: 'Password reset successfully' });
  } catch (error) { next(error); }
});

router.post('/events/:eventId/participants/bulk-remove', verifyAdmin, requirePermission('canManageUsers'), async (req, res, next) => {
  try {
    const { usernames } = req.body;
    await EventParticipant.deleteMany({
      eventId: req.params.eventId,
      username: { $in: usernames },
    });
    await Event.findByIdAndUpdate(req.params.eventId, {
      $pull: { participants: { username: { $in: usernames } } },
    });
    res.json({ message: `${usernames.length} participants removed` });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// POLLS MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/events/:eventId/polls', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const polls = await Poll.find({ eventId: req.params.eventId }).sort({ createdAt: -1 }).lean();
    res.json({ polls });
  } catch (error) { next(error); }
});

router.delete('/events/:eventId/polls/:pollId', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    await Poll.findByIdAndDelete(req.params.pollId);
    res.json({ message: 'Poll deleted' });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// FILES MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/events/:eventId/files', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const files = await File.find({ eventId: req.params.eventId, isDeleted: false })
      .sort({ uploadedAt: -1 })
      .lean();
    res.json({ files });
  } catch (error) { next(error); }
});

router.delete('/events/:eventId/files/:fileId', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    await File.findByIdAndUpdate(req.params.fileId, { isDeleted: true, deletedAt: new Date() });
    res.json({ message: 'File deleted' });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// INVITES MANAGEMENT (Enterprise Mode)
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/events/:eventId/invites', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    if (!Invite) return res.json({ invites: [] });
    const invites = await Invite.find({ eventId: req.params.eventId })
      .sort({ createdAt: -1 })
      .lean();
    res.json({ invites });
  } catch (error) { next(error); }
});

router.post('/events/:eventId/invites/:inviteCode/checkin', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    if (!Invite) return res.status(404).json({ error: 'Invite system not available' });
    const invite = await Invite.findOneAndUpdate(
      { eventId: req.params.eventId, inviteCode: req.params.inviteCode },
      { checkedIn: true, checkedInAt: new Date(), actualAttendees: req.body.actualAttendees, status: 'checked-in' },
      { new: true }
    );
    if (!invite) return res.status(404).json({ error: 'Invite not found' });
    res.json({ message: 'Guest checked in', invite });
  } catch (error) { next(error); }
});

router.delete('/events/:eventId/invites/:inviteId', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    if (!Invite) return res.status(404).json({ error: 'Invite system not available' });
    await Invite.findByIdAndDelete(req.params.inviteId);
    res.json({ message: 'Invite deleted' });
  } catch (error) { next(error); }
});

// ─── RSVP Page Submissions (new guest-facing RSVP page system) ────────────────
// Separate from the legacy `event.rsvps[]` embedded array (which only tracks
// in-app participant yes/maybe/no). These are collected via the public RSVP
// page builder and can carry plus-ones, custom answers, seating selections,
// approval status, and check-in state.
router.get('/events/:eventId/rsvp-submissions', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    const submissions = await RSVPSubmission.find({ eventId: req.params.eventId, deletedAt: null })
      .sort({ submittedAt: -1 })
      .lean();
    res.json({ submissions });
  } catch (error) { next(error); }
});

router.patch('/events/:eventId/rsvp-submissions/:submissionId', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    const ALLOWED = ['status', 'organizerNotes', 'starred', 'tags'];
    const update = {};
    ALLOWED.forEach(key => { if (req.body[key] !== undefined) update[key] = req.body[key]; });
    update.updatedAt = new Date();

    const submission = await RSVPSubmission.findOneAndUpdate(
      { _id: req.params.submissionId, eventId: req.params.eventId },
      update,
      { new: true }
    ).lean();
    if (!submission) return res.status(404).json({ error: 'Submission not found' });
    res.json({ message: 'Submission updated', submission });
  } catch (error) { next(error); }
});

router.post('/events/:eventId/rsvp-submissions/:submissionId/checkin', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    const submission = await RSVPSubmission.findOneAndUpdate(
      { _id: req.params.submissionId, eventId: req.params.eventId },
      { checkedIn: true, checkedInAt: new Date() },
      { new: true }
    ).lean();
    if (!submission) return res.status(404).json({ error: 'Submission not found' });
    res.json({ message: 'Guest checked in', submission });
  } catch (error) { next(error); }
});

router.post('/events/:eventId/rsvp-submissions/:submissionId/undo-checkin', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    const submission = await RSVPSubmission.findOneAndUpdate(
      { _id: req.params.submissionId, eventId: req.params.eventId },
      { checkedIn: false, checkedInAt: null },
      { new: true }
    ).lean();
    if (!submission) return res.status(404).json({ error: 'Submission not found' });
    res.json({ message: 'Check-in undone', submission });
  } catch (error) { next(error); }
});

router.delete('/events/:eventId/rsvp-submissions/:submissionId', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    await RSVPSubmission.findOneAndUpdate(
      { _id: req.params.submissionId, eventId: req.params.eventId },
      { deletedAt: new Date() }
    );
    res.json({ message: 'Submission deleted' });
  } catch (error) { next(error); }
});

// ─── GET /events/:eventId/full ─────────────────────────────────────────────────
// Returns all event data in a single round-trip for the admin event detail panel.
router.get('/events/:eventId/full', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const { getModel: getAnalyticsModel } = require('../models/PlatformAnalytics');
    const { eventId } = req.params;

    // Fetch event with admin-only fields explicitly included
    const event = await Event.findById(eventId)
      .select('+adminNotes +spamScore +spamFlags +spamVerdict +creatorIp +creatorUserAgent +creatorFingerprint')
      .lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });

    // Analytics summary
    let analytics = null;
    try {
      const AM = getAnalyticsModel();
      if (AM) {
        const [byEventType, uniqueVisitorIds, suspectedCount] = await Promise.all([
          AM.aggregate([
            { $match: { linkedEventId: String(event._id) } },
            { $group: { _id: '$eventType', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
          ]),
          AM.distinct('visitorId', { linkedEventId: String(event._id) }),
          AM.countDocuments({ linkedEventId: String(event._id), isSuspected: true }),
        ]);
        analytics = { byEventType, uniqueVisitors: uniqueVisitorIds.length, suspectedCount };
      }
    } catch { /* analytics unavailable */ }

    // Live connection count
    let liveConnections = 0;
    try {
      const { io } = require('../server');
      if (io) {
        const rooms = io.sockets.adapter.rooms;
        const room = rooms?.get(`event_${event._id}`);
        liveConnections = room ? room.size : 0;
      }
    } catch { /* socket unavailable */ }

    // RSVP breakdown from embedded array
    const rsvpBreakdown = { yes: 0, maybe: 0, no: 0 };
    (event.rsvps || []).forEach(r => { if (rsvpBreakdown[r.status] !== undefined) rsvpBreakdown[r.status]++; });

    const RSVPSubmission = require('../models/RSVPSubmission');

    const [participants, invites, polls, files, messages, auditLogs, rsvpSubmissions] = await Promise.all([
      EventParticipant.find({ eventId: event._id })
        .select('username role joinedAt lastSeenAt hasPassword recoveryCodeGeneratedAt')
        .lean(),
      Invite ? Invite.find({ eventId: event._id })
        .select('guestName guestEmail inviteCode checkedIn checkedInAt blocked blockedReason securityFlags trustScore')
        .lean() : Promise.resolve([]),
      Poll.find({ eventId: event._id }).lean(),
      File.find({ eventId: event._id, isDeleted: false }).lean(),
      Message.find({ eventId: event._id, isDeleted: false }).sort({ createdAt: -1 }).limit(50).lean(),
      getAuditLogs({ targetId: String(event._id), limit: 100 }),
      RSVPSubmission.find({ eventId: event._id, deletedAt: null }).sort({ submittedAt: -1 }).lean(),
    ]);

    // ── New RSVP page system: stats + sanitized settings ─────────────────────
    // rsvpSubmissions come from the public RSVP page builder (plus-ones, custom
    // questions, seating selections, approval workflow, check-in) — distinct
    // from the legacy `event.rsvps[]` array used above for rsvpBreakdown.
    const rsvpStats = {
      total:          rsvpSubmissions.length,
      byResponse:     { yes: 0, maybe: 0, no: 0 },
      byStatus:       { pending: 0, confirmed: 0, waitlisted: 0, declined: 0 },
      totalAttendees: 0,
      checkedIn:      0,
      withPlusOnes:   0,
      withSeatSelected: 0,
    };
    rsvpSubmissions.forEach(s => {
      if (rsvpStats.byResponse[s.response] !== undefined) rsvpStats.byResponse[s.response]++;
      if (rsvpStats.byStatus[s.status] !== undefined) rsvpStats.byStatus[s.status]++;
      rsvpStats.totalAttendees += 1 + (s.plusOnes || 0);
      if (s.checkedIn) rsvpStats.checkedIn++;
      if (s.plusOnes > 0) rsvpStats.withPlusOnes++;
      if (s.selectedTableId) rsvpStats.withSeatSelected++;
    });

    // Strip secrets (rsvpPassword, Gmail OAuth tokens) before this reaches the
    // admin frontend — replace with booleans so the UI can still show state.
    let rsvpPage = null;
    if (event.rsvpPage) {
      const { rsvpPassword, gmailAuth, ...rest } = event.rsvpPage;
      rsvpPage = { ...rest, hasPassword: !!rsvpPassword, gmailConnected: !!gmailAuth?.connected, gmailEmail: gmailAuth?.connected ? gmailAuth.email : '' };
      event.rsvpPage = rsvpPage; // keep the embedded `event` object consistent with the sanitized copy
    }

    res.json({
      event,
      participants,
      invites,
      polls,
      files,
      messages: messages.reverse(),
      auditLogs,
      rsvpBreakdown,
      analytics,
      liveConnections,
      // New RSVP page system (page builder submissions) — separate from the
      // legacy embedded rsvpBreakdown above.
      rsvpSubmissions,
      rsvpStats,
      rsvpPage,
      rsvpPageConfig: event.rsvpPageConfig || null,
    });
  } catch (err) {
    next(err);
  }
});

// ─── PATCH /events/:eventId/admin-notes ───────────────────────────────────────
router.patch('/events/:eventId/admin-notes', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const { adminNotes } = req.body || {};
    if (typeof adminNotes !== 'string') return res.status(400).json({ error: 'adminNotes must be a string' });
    if (adminNotes.length > 5000) return res.status(400).json({ error: 'adminNotes exceeds 5000 characters' });

    const event = await Event.findByIdAndUpdate(
      req.params.eventId,
      { $set: { adminNotes } },
      { new: true, select: '+adminNotes' }
    ).lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });

    await audit({
      action:   'admin_notes_updated',
      actorId:  req.admin?.id,
      actorName: req.admin?.username,
      targetId: String(event._id),
      details:  { length: adminNotes.length },
    });

    res.json({ adminNotes: event.adminNotes, updatedAt: new Date() });
  } catch (err) {
    next(err);
  }
});

// ─── PATCH /events/:eventId/event-type ─────────────────────────────────────────
// Admin-only: convert an event between Standard and RSVP-only. Keeps
// event.rsvpPage.enabled in sync — turning it on when converting TO rsvpOnly,
// and just disabling (not deleting) it when converting back to standard, so
// nothing is lost if the event is flipped back later.
router.patch('/events/:eventId/event-type', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const { eventType } = req.body || {};
    const ALLOWED = ['standard', 'rsvpOnly'];
    if (!ALLOWED.includes(eventType)) {
      return res.status(400).json({ error: `eventType must be one of: ${ALLOWED.join(', ')}` });
    }

    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    if (event.eventType === eventType) {
      return res.json({ message: 'No change', eventType: event.eventType, rsvpPageEnabled: event.rsvpPage?.enabled || false });
    }

    const previousType = event.eventType;
    const wasRsvpOnly = previousType === 'rsvpOnly';
    event.eventType = eventType;

    if (eventType === 'rsvpOnly') {
      if (!event.rsvpPage) event.rsvpPage = {};
      event.rsvpPage.enabled = true;
    } else if (wasRsvpOnly && event.rsvpPage) {
      event.rsvpPage.enabled = false;
    }

    await event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${event._id}`).emit('event_settings_updated', { eventType: event.eventType });

    await audit({
      action:    'admin_event_type_changed',
      actorId:   req.admin?.id,
      actorName: req.admin?.username,
      targetId:  String(event._id),
      details:   { from: previousType, to: eventType },
    });

    res.json({
      message: 'Event type updated',
      eventType: event.eventType,
      rsvpPageEnabled: event.rsvpPage?.enabled || false,
    });
  } catch (err) {
    next(err);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// SPAM DETECTION & MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════════

// ─── GET /admin/spam/events ────────────────────────────────────────────────────
// List events flagged by the spam detector.
// Query params:
//   verdict   'review' | 'block' | 'all'  (default: 'all' flagged)
//   page      int  (default 1)
//   limit     int  (default 25)
//   sort      'score_desc' | 'score_asc' | 'newest' | 'oldest'
router.get('/spam/events', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const { analyzeEvent: _ae, reAnalyzeEvent: _rae } = require('../services/spamDetector');
    const page    = Math.max(1, parseInt(req.query.page)  || 1);
    const limit   = Math.min(100, parseInt(req.query.limit) || 25);
    const skip    = (page - 1) * limit;
    const verdict = req.query.verdict || 'all';

    const filter = {};
    if (verdict === 'review')      filter.spamVerdict = 'review';
    else if (verdict === 'block')  filter.spamVerdict = 'block';
    else                           filter.spamVerdict = { $in: ['review', 'block'] };

    const sortMap = {
      score_desc: { spamScore: -1 },
      score_asc:  { spamScore:  1 },
      oldest:     { createdAt:  1 },
      newest:     { createdAt: -1 },
    };
    const sort = sortMap[req.query.sort] || { spamScore: -1 };

    const [events, total] = await Promise.all([
      Event.find(filter)
        .select('+spamScore +spamFlags +spamVerdict +adminNotes +creatorIp +creatorUserAgent +creatorFingerprint')
        .sort(sort)
        .skip(skip)
        .limit(limit)
        .lean(),
      Event.countDocuments(filter),
    ]);

    // Aggregate summary counts
    const [reviewCount, blockCount] = await Promise.all([
      Event.countDocuments({ spamVerdict: 'review' }),
      Event.countDocuments({ spamVerdict: 'block'  }),
    ]);

    res.json({
      events,
      summary: { review: reviewCount, block: blockCount, total: reviewCount + blockCount },
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) { next(err); }
});

// ─── GET /admin/spam/events/:eventId ──────────────────────────────────────────
// Full spam detail for a single event (flags, score breakdown, creator metadata).
router.get('/spam/events/:eventId', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId)
      .select('+spamScore +spamFlags +spamVerdict +adminNotes +creatorIp +creatorUserAgent +creatorFingerprint')
      .lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });

    // Count other events from same IP or fingerprint
    const [ipEventCount, fpEventCount] = await Promise.all([
      event.creatorIp
        ? Event.countDocuments({ creatorIp: event.creatorIp, _id: { $ne: event._id } })
        : Promise.resolve(0),
      event.creatorFingerprint
        ? Event.countDocuments({ creatorFingerprint: event.creatorFingerprint, _id: { $ne: event._id } })
        : Promise.resolve(0),
    ]);

    res.json({
      event,
      creatorHistory: {
        eventsFromSameIp:          ipEventCount,
        eventsFromSameFingerprint: fpEventCount,
      },
    });
  } catch (err) { next(err); }
});

// ─── POST /admin/spam/events/:eventId/reanalyze ────────────────────────────────
// Re-run spam analysis on an existing event (useful after content edits).
router.post('/spam/events/:eventId/reanalyze', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const { reAnalyzeEvent } = require('../services/spamDetector');
    const result = await reAnalyzeEvent(req.params.eventId);

    await audit({
      action:    'spam_reanalyzed',
      actorId:   req.admin?.id,
      actorName: req.admin?.username,
      targetId:  req.params.eventId,
      details:   { score: result.score, verdict: result.verdict, flags: result.flags },
    });

    res.json({ ok: true, ...result });
  } catch (err) {
    if (err.message === 'Event not found') return res.status(404).json({ error: 'Event not found' });
    next(err);
  }
});

// ─── PATCH /admin/spam/events/:eventId/verdict ────────────────────────────────
// Manually override the spam verdict for an event.
// body: { verdict: 'clean' | 'review' | 'block', reason?: string }
router.patch('/spam/events/:eventId/verdict', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    const { verdict, reason = '' } = req.body;
    if (!['clean', 'review', 'block'].includes(verdict)) {
      return res.status(400).json({ error: 'verdict must be clean, review, or block' });
    }

    const event = await Event.findByIdAndUpdate(
      req.params.eventId,
      { $set: { spamVerdict: verdict } },
      { new: true, select: '+spamScore +spamFlags +spamVerdict +adminNotes' }
    ).lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });

    await audit({
      action:    'spam_verdict_override',
      actorId:   req.admin?.id,
      actorName: req.admin?.username,
      targetId:  String(event._id),
      details:   { verdict, reason, previousVerdict: event.spamVerdict },
    });

    res.json({ ok: true, eventId: event._id, verdict, spamScore: event.spamScore, spamFlags: event.spamFlags });
  } catch (err) { next(err); }
});

// ─── POST /admin/spam/events/bulk-action ──────────────────────────────────────
// Apply a bulk action to multiple spam-flagged events.
// body: { eventIds: string[], action: 'clear' | 'block' | 'delete' | 'block-and-ban-ip' }
router.post('/spam/events/bulk-action', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    const { eventIds, action } = req.body;
    if (!Array.isArray(eventIds) || eventIds.length === 0) {
      return res.status(400).json({ error: 'eventIds must be a non-empty array' });
    }
    if (eventIds.length > 100) {
      return res.status(400).json({ error: 'Maximum 100 events per bulk action' });
    }
    if (!['clear', 'block', 'delete', 'block-and-ban-ip'].includes(action)) {
      return res.status(400).json({ error: 'action must be clear, block, delete, or block-and-ban-ip' });
    }

    const events = await Event.find({ _id: { $in: eventIds } })
      .select('+spamVerdict +creatorIp')
      .lean();

    let result = {};

    if (action === 'clear') {
      const r = await Event.updateMany(
        { _id: { $in: eventIds } },
        { $set: { spamVerdict: 'clean', spamScore: 0, spamFlags: [] } }
      );
      result = { modified: r.modifiedCount };
    } else if (action === 'block') {
      const r = await Event.updateMany(
        { _id: { $in: eventIds } },
        { $set: { spamVerdict: 'block', status: 'cancelled' } }
      );
      result = { modified: r.modifiedCount };
    } else if (action === 'delete') {
      const ids = events.map(e => e._id);
      await Promise.all([
        Event.deleteMany({ _id: { $in: ids } }),
        Message.deleteMany({ eventId: { $in: ids } }),
        Poll.deleteMany({ eventId: { $in: ids } }),
        File.deleteMany({ eventId: { $in: ids } }),
        EventParticipant.deleteMany({ eventId: { $in: ids } }),
      ]);
      result = { deleted: ids.length };
    } else if (action === 'block-and-ban-ip') {
      // Block the events
      await Event.updateMany(
        { _id: { $in: eventIds } },
        { $set: { spamVerdict: 'block', status: 'cancelled' } }
      );
      // Ban unique IPs
      const ips = [...new Set(events.map(e => e.creatorIp).filter(Boolean))];
      const banResults = [];
      for (const ip of ips) {
        try {
          const { ban } = require('../middleware/security');
          await ban(ip, 'Spam event bulk action', 24 * 60); // 24-hour ban
          // Also write to Blocklist for persistence
          const existing = await Blocklist.findOne({ type: 'ip', value: ip });
          if (!existing) {
            await Blocklist.create({
              type: 'ip', value: ip, reason: 'Spam event bulk ban',
              permanent: false, expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
              addedBy: req.admin?.username || 'admin',
            });
          }
          banResults.push(ip);
        } catch { /* best-effort per IP */ }
      }
      result = { eventsBocked: eventIds.length, ipsBanned: banResults.length, ips: banResults };
    }

    await audit({
      action:    'spam_bulk_action',
      actorId:   req.admin?.id,
      actorName: req.admin?.username,
      details:   { action, eventCount: eventIds.length, result },
    });

    res.json({ ok: true, action, result });
  } catch (err) { next(err); }
});

// ─── GET /admin/spam/rsvps ─────────────────────────────────────────────────────
// List RSVP submissions that were auto-flagged as spam suspects
// (identified by the presence of "[Auto-flagged]" in organizerNotes).
router.get('/spam/rsvps', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    const page  = Math.max(1, parseInt(req.query.page)  || 1);
    const limit = Math.min(100, parseInt(req.query.limit) || 25);
    const skip  = (page - 1) * limit;

    const filter = { organizerNotes: /^\[Auto-flagged\]/, deletedAt: null };
    if (req.query.eventId) filter.eventId = req.query.eventId;

    const [submissions, total] = await Promise.all([
      RSVPSubmission.find(filter)
        .sort({ submittedAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      RSVPSubmission.countDocuments(filter),
    ]);

    res.json({ submissions, pagination: { page, limit, total, pages: Math.ceil(total / limit) } });
  } catch (err) { next(err); }
});

// ─── POST /admin/spam/rsvps/bulk-action ────────────────────────────────────────
// Bulk action on flagged RSVP submissions.
// body: { submissionIds: string[], action: 'approve' | 'decline' | 'delete' | 'ban-ip' }
router.post('/spam/rsvps/bulk-action', verifyAdmin, requirePermission('canDeleteEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    const { submissionIds, action } = req.body;
    if (!Array.isArray(submissionIds) || submissionIds.length === 0) {
      return res.status(400).json({ error: 'submissionIds must be a non-empty array' });
    }
    if (submissionIds.length > 200) {
      return res.status(400).json({ error: 'Maximum 200 submissions per bulk action' });
    }
    if (!['approve', 'decline', 'delete', 'ban-ip'].includes(action)) {
      return res.status(400).json({ error: 'action must be approve, decline, delete, or ban-ip' });
    }

    let result = {};

    if (action === 'approve') {
      const r = await RSVPSubmission.updateMany(
        { _id: { $in: submissionIds } },
        { $set: { status: 'confirmed' } }
      );
      result = { modified: r.modifiedCount };
    } else if (action === 'decline') {
      const r = await RSVPSubmission.updateMany(
        { _id: { $in: submissionIds } },
        { $set: { status: 'declined' } }
      );
      result = { modified: r.modifiedCount };
    } else if (action === 'delete') {
      const r = await RSVPSubmission.updateMany(
        { _id: { $in: submissionIds } },
        { $set: { deletedAt: new Date() } }
      );
      result = { deleted: r.modifiedCount };
    } else if (action === 'ban-ip') {
      const subs = await RSVPSubmission.find({ _id: { $in: submissionIds } })
        .select('ipAddress')
        .lean();
      const ips = [...new Set(subs.map(s => s.ipAddress).filter(Boolean))];
      const banned = [];
      for (const ip of ips) {
        try {
          const existing = await Blocklist.findOne({ type: 'ip', value: ip });
          if (!existing) {
            await Blocklist.create({
              type: 'ip', value: ip,
              reason: 'Spam RSVP bulk ban',
              permanent: false,
              expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
              addedBy: req.admin?.username || 'admin',
            });
          }
          banned.push(ip);
        } catch { /* best-effort */ }
      }
      // Decline the submissions too
      await RSVPSubmission.updateMany(
        { _id: { $in: submissionIds } },
        { $set: { status: 'declined' } }
      );
      result = { ipsBanned: banned.length, submissionsDeclined: submissionIds.length };
    }

    await audit({
      action:    'spam_rsvp_bulk_action',
      actorId:   req.admin?.id,
      actorName: req.admin?.username,
      details:   { action, count: submissionIds.length, result },
    });

    res.json({ ok: true, action, result });
  } catch (err) { next(err); }
});

// ─── GET /admin/spam/stats ────────────────────────────────────────────────────
// Platform-wide spam statistics for the admin dashboard.
router.get('/spam/stats', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const RSVPSubmission = require('../models/RSVPSubmission');
    const since7d  = new Date(Date.now() - 7  * 24 * 60 * 60 * 1000);
    const since30d = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    const [
      totalEvents,
      eventsReview,
      eventsBlock,
      eventsClean,
      eventsReview7d,
      eventsBlock7d,
      topSpamFlags,
      rsvpFlagged,
      rsvpFlagged7d,
      topSpamIPs,
    ] = await Promise.all([
      Event.countDocuments({}),
      Event.countDocuments({ spamVerdict: 'review' }),
      Event.countDocuments({ spamVerdict: 'block' }),
      Event.countDocuments({ spamVerdict: 'clean' }),
      Event.countDocuments({ spamVerdict: 'review', createdAt: { $gte: since7d } }),
      Event.countDocuments({ spamVerdict: 'block',  createdAt: { $gte: since7d } }),
      // Top spam flags across all flagged events
      Event.aggregate([
        { $match: { spamVerdict: { $in: ['review', 'block'] } } },
        { $unwind: '$spamFlags' },
        { $group: { _id: '$spamFlags', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 15 },
      ]).allowDiskUse(false).exec().catch(() => []),
      // RSVP spam counts
      RSVPSubmission.countDocuments({ organizerNotes: /^\[Auto-flagged\]/, deletedAt: null }),
      RSVPSubmission.countDocuments({ organizerNotes: /^\[Auto-flagged\]/, deletedAt: null, submittedAt: { $gte: since7d } }),
      // Top IPs creating spam events
      Event.aggregate([
        { $match: { spamVerdict: { $in: ['review', 'block'] }, creatorIp: { $exists: true, $ne: null } } },
        { $group: { _id: '$creatorIp', count: { $sum: 1 }, avgScore: { $avg: '$spamScore' } } },
        { $sort: { count: -1 } },
        { $limit: 10 },
      ]).allowDiskUse(false).exec().catch(() => []),
    ]);

    res.json({
      events: {
        total: totalEvents,
        clean:  eventsClean,
        review: eventsReview,
        block:  eventsBlock,
        flaggedPercent: totalEvents > 0 ? +(((eventsReview + eventsBlock) / totalEvents) * 100).toFixed(2) : 0,
        last7d: { review: eventsReview7d, block: eventsBlock7d },
      },
      rsvps: {
        flagged:  rsvpFlagged,
        last7d:   rsvpFlagged7d,
      },
      topFlags: topSpamFlags.map(f => ({ flag: f._id, count: f.count })),
      topIPs:   topSpamIPs.map(r => ({ ip: r._id, count: r.count, avgScore: Math.round(r.avgScore) })),
    });
  } catch (err) { next(err); }
});

// ─── POST /admin/spam/analyze-text ────────────────────────────────────────────
// Dry-run spam analysis on arbitrary text (for admin testing/investigation).
// body: { title?, description?, email?, subdomain?, name? }
router.post('/spam/analyze-text', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const { analyzeEvent } = require('../services/spamDetector');
    const result = await analyzeEvent({
      title:          req.body.title          || '',
      description:    req.body.description    || '',
      subdomain:      req.body.subdomain      || '',
      organizerEmail: req.body.email          || '',
      organizerName:  req.body.name           || '',
      ip:             '',
      userAgent:      req.body.userAgent      || '',
      fingerprint:    '',
      honeypot:       '',
    });
    res.json(result);
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// SEARCH & ACTIVITY
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/search', verifyAdmin, requirePermission('canViewEvents'), async (req, res, next) => {
  try {
    const query = req.query.q;
    if (!query || query.length < 2) {
      return res.status(400).json({ error: 'Search query must be at least 2 characters' });
    }

    const regex = { $regex: query, $options: 'i' };

    const [events, messages, polls, participants] = await Promise.all([
      Event.find({
        $or: [
          { title: regex }, { subdomain: regex }, { description: regex },
          { organizerName: regex }, { organizerEmail: regex },
        ],
      }).limit(20).lean(),
      Message.find({ content: regex, isDeleted: false })
        .limit(20)
        .populate('eventId', 'title subdomain')
        .lean(),
      Poll.find({ question: regex })
        .limit(20)
        .populate('eventId', 'title subdomain')
        .lean(),
      EventParticipant.find({ username: regex })
        .limit(20)
        .select('-password')
        .lean(),
    ]);

    res.json({
      results: { events, messages, polls, participants },
      total: events.length + messages.length + polls.length + participants.length,
    });
  } catch (error) {
    next(error);
  }
});

router.get('/activity', verifyAdmin, requirePermission('canViewDashboard'), async (req, res, next) => {
  try {
    const since = new Date(Date.now() - 48 * 60 * 60 * 1000);
    const [recentEvents, recentMessages, recentParticipants] = await Promise.all([
      Event.find({ createdAt: { $gte: since } }).sort({ createdAt: -1 }).limit(10).lean(),
      Message.find({ createdAt: { $gte: since }, isDeleted: false }).sort({ createdAt: -1 }).limit(20).lean(),
      EventParticipant.find({ joinedAt: { $gte: since } }).select('-password').sort({ joinedAt: -1 }).limit(20).lean(),
    ]);
    res.json({ recentEvents, recentMessages, recentParticipants });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// ORGANIZERS  —  GET /admin/organizers
// Aggregates unique organizers from the events collection.
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/organizers', verifyAdmin, requirePermission('canViewUserProfiles'), async (req, res, next) => {
  try {
    const organizers = await Event.aggregate([
      {
        $group: {
          _id:               '$organizerEmail',
          name:              { $last: '$organizerName' },
          email:             { $first: '$organizerEmail' },
          totalEvents:       { $sum: 1 },
          activeEvents:      { $sum: { $cond: [{ $eq: ['$status', 'active'] }, 1, 0] } },
          firstEvent:        { $min: '$createdAt' },
          lastEvent:         { $max: '$createdAt' },
          totalParticipants: { $sum: { $size: { $ifNull: ['$participants', []] } } },
          isEnterprise:      { $max: { $cond: ['$isEnterpriseMode', 1, 0] } },
        },
      },
      { $sort: { totalEvents: -1 } },
      { $limit: 500 },
    ]);
    res.json({ organizers, total: organizers.length });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// ALL STAFF  —  GET /admin/staff
// Returns every staff-role EventParticipant enriched with event title.
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/staff', verifyAdmin, requirePermission('canViewUserProfiles'), async (req, res, next) => {
  try {
    const staff = await EventParticipant.find({ role: 'staff' })
      .select('-password')
      .sort({ createdAt: -1 })
      .lean();

    const eventIds = [...new Set(staff.map(s => s.eventId?.toString()))];
    const events   = await Event.find({ _id: { $in: eventIds } }).select('title subdomain').lean();
    const evMap    = Object.fromEntries(events.map(e => [e._id.toString(), e]));

    const enriched = staff.map(s => ({
      ...s,
      eventTitle:     evMap[s.eventId?.toString()]?.title     || 'Unknown Event',
      eventSubdomain: evMap[s.eventId?.toString()]?.subdomain || '',
    }));

    res.json({ staff: enriched, total: enriched.length });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// ALL PARTICIPANTS  —  GET /admin/all-participants
// Every participant (non-staff) across all events, paginated.
// ═══════════════════════════════════════════════════════════════════════════════

router.get('/all-participants', verifyAdmin, requirePermission('canViewUserProfiles'), async (req, res, next) => {
  try {
    const page   = parseInt(req.query.page  || '1');
    const limit  = parseInt(req.query.limit || '50');
    const skip   = (page - 1) * limit;
    const search = req.query.search;

    const filter = { role: { $ne: 'staff' } };
    if (search) filter.username = { $regex: search, $options: 'i' };

    const [participants, total] = await Promise.all([
      EventParticipant.find(filter)
        .select('-password')
        .sort({ joinedAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      EventParticipant.countDocuments(filter),
    ]);

    const eventIds = [...new Set(participants.map(p => p.eventId?.toString()))];
    const events   = await Event.find({ _id: { $in: eventIds } }).select('title subdomain').lean();
    const evMap    = Object.fromEntries(events.map(e => [e._id.toString(), e]));

    const enriched = participants.map(p => ({
      ...p,
      eventTitle:     evMap[p.eventId?.toString()]?.title     || '',
      eventSubdomain: evMap[p.eventId?.toString()]?.subdomain || '',
    }));

    res.json({ participants: enriched, total, pages: Math.ceil(total / limit), page });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// EMPLOYEE MANAGEMENT  —  /admin/employees
// ═══════════════════════════════════════════════════════════════════════════════

// GET /admin/me — returns the current admin's own profile and permission set.
// Useful for the frontend to know which UI sections to show/hide.
router.get('/me', verifyAdmin, async (req, res) => {
  const admin = req.admin;
  const rootLogin = !admin.isEmployee && admin.isAdmin === true;
  let login = { lastLogin: null, previousLogin: null, loginCount: 0 };
  try {
    if (admin.employeeId) {
      const e = await Employee.findById(admin.employeeId).select('lastLogin previousLogin loginCount').lean();
      if (e) login = { lastLogin: e.lastLogin || null, previousLogin: e.previousLogin || null, loginCount: e.loginCount || 0 };
    } else if (rootLogin) {
      login = await team.rootLoginStats();
    }
  } catch (_) { /* login info is a nicety, never block /me */ }
  res.json({
    _id:         admin.employeeId  || null,  // MongoDB _id for employee accounts; null for root
    name:        admin.name        || admin.username || 'Admin',
    email:       admin.email       || null,
    role:        admin.role        || 'super_admin',
    isEmployee:  admin.isEmployee  || false,
    isDemo:      admin.isDemo      || false,
    permissions: admin.permissions || null, // null = root admin (all access)
    sections:    perms.sectionsFor(admin),  // admin pages this person may open (server-side source of truth)
    ...login,
  });
});

// GET /admin/me/full — full self-profile (all safe fields, no passwordHash/totpSecret)
router.get('/me/full', verifyAdmin, async (req, res, next) => {
  try {
    const empId = req.admin?.employeeId;
    if (!empId) {
      // Root admin — return synthetic profile
      const rootStats = await team.rootLoginStats().catch(() => ({ lastLogin: null, previousLogin: null, loginCount: 0 }));
      return res.json({
        name:             req.admin.username || 'Root Admin',
        email:            null,
        role:             'super_admin',
        isEmployee:       false,
        department:       null,
        phone:            null,
        timezone:         null,
        location:         null,
        emergencyContact: null,
        employeeId:       null,
        startDate:        null,
        lastLogin:        rootStats.lastLogin,
        previousLogin:    rootStats.previousLogin,
        loginCount:       rootStats.loginCount,
        createdAt:        null,
        twoFactorEnabled: !!(await redis.get('totp:root:secret').catch(() => null)),
        permissions:      null,
        status:           'active',
        notes:            null,
      });
    }
    const emp = await Employee.findById(empId)
      .select('-passwordHash -totpSecret')
      .lean();
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    res.json(emp);
  } catch (error) { next(error); }
});

// PATCH /admin/me — self-service profile update
// Employees can update their own display name, phone, timezone, location, and
// emergency contact. Role, permissions, and all security fields are immutable
// from this endpoint — those require a super_admin.
router.patch(
  '/me',
  verifyAdmin,
  [
    body('name').optional().trim().isLength({ min: 1, max: 100 }).withMessage('Name must be 1–100 characters'),
    body('phone').optional({ nullable: true }).trim().isLength({ max: 30 }).withMessage('Phone too long'),
    body('timezone').optional({ nullable: true }).trim().isLength({ max: 60 }).withMessage('Timezone too long'),
    body('location').optional({ nullable: true }).trim().isLength({ max: 100 }).withMessage('Location too long'),
    body('emergencyContact').optional({ nullable: true }).trim().isLength({ max: 200 }).withMessage('Emergency contact too long'),
  ],
  async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ error: errors.array()[0].msg });
    try {
      const empId = req.admin?.employeeId;
      if (!empId) return res.status(403).json({ error: 'Root admin profile is not editable via this endpoint.' });

      // Whitelist — only these fields may be self-edited
      const allowed = ['name', 'phone', 'timezone', 'location', 'emergencyContact'];
      const update  = {};
      for (const field of allowed) {
        if (req.body[field] !== undefined) update[field] = req.body[field] || null;
      }
      if (Object.keys(update).length === 0) return res.status(400).json({ error: 'No updatable fields provided.' });

      const emp = await Employee.findByIdAndUpdate(
        empId,
        { $set: update },
        { new: true, runValidators: true }
      ).select('-passwordHash -totpSecret');

      if (!emp) return res.status(404).json({ error: 'Employee not found' });

      audit('employee_updated', {
        req, actor: req.admin,
        targetId: emp._id.toString(), targetType: 'employee',
        details: { selfUpdate: true, updatedFields: Object.keys(update), email: emp.email },
      });

      res.json({ employee: emp, message: 'Profile updated' });
    } catch (error) { next(error); }
  }
);

// GET /admin/me/audit — own audit log (last 100 entries for this employee)
// No extra permission required — employees are always allowed to see their own activity.
router.get('/me/audit', verifyAdmin, async (req, res, next) => {
  try {
    const empId = req.admin?.employeeId || 'root';
    const limit = Math.min(parseInt(req.query.limit || '50', 10), 100);
    const skip  = parseInt(req.query.skip || '0', 10);
    const logs  = await getAuditLogs({ actorId: empId, limit, skip });
    res.json({ logs, count: logs.length });
  } catch (error) { next(error); }
});

// ─── Shared helpers for the Team routes ───────────────────────────────────────
const SAFE_EMPLOYEE_STRIP = ['passwordHash', 'totpSecret'];
const stripSecrets = (doc) => {
  const o = typeof doc?.toObject === 'function' ? doc.toObject() : { ...doc };
  for (const k of SAFE_EMPLOYEE_STRIP) delete o[k];
  return o;
};
const sanitizePerms = (obj) => Object.fromEntries(perms.PERMISSION_KEYS.map((k) => [k, obj?.[k] === true]));
const PW_RULE = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{10,}$/;
const PW_MSG  = 'Password must be at least 10 characters with an uppercase letter, a number and a special character.';
const isEmail = (e) => /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(String(e || ''));

// Who the viewer is on the org chart, and which boxes sit under them (their reports, direct and indirect).
async function orgView(req) {
  const docs = await OrgNode.find().select('title parentId employeeId personName personEmail status owner level').lean();
  const t = team.treeOf(docs);
  const mine = team.nodeOfAdmin(docs, req.admin);
  const visible = new Set(mine ? [String(mine._id), ...t.subtree(mine._id)] : []);
  return { docs, t, mine, visible };
}

// GET /admin/team/catalog - every role, permission group and admin section that exists. The Team page renders
// from this, so a permission added in utils/permissions.js can never be "missing" from the UI.
router.get('/team/catalog', verifyAdmin, (req, res) => {
  res.json(perms.publicCatalog());
});

// GET /admin/team/logins/:actorId - sign-in history. Allowed for: super admins (anyone), yourself, and your managers
// (anyone above you on the org chart). IP addresses are only shown to super admins and to the person themselves.
router.get('/team/logins/:actorId', verifyAdmin, async (req, res, next) => {
  try {
    const sup = perms.isSuperAdmin(req.admin);
    const target = String(req.params.actorId);
    const rootLogin = !req.admin.isEmployee && req.admin.isAdmin === true;
    const meId = req.admin.employeeId ? String(req.admin.employeeId) : (rootLogin ? 'root' : null);
    let allowed = sup || (meId && meId === target);
    if (!allowed && target !== 'root' && meId) {
      const ov = await orgView(req);
      const targetNode = ov.docs.find((d) => d.employeeId && String(d.employeeId) === target);
      allowed = !!(ov.mine && targetNode && ov.visible.has(String(targetNode._id)));
    }
    if (!allowed) return res.status(403).json({ error: 'You can only see sign-in activity for yourself and the people you manage.' });
    res.json({ logins: await team.recentLogins(target, 25, sup || meId === target) });
  } catch (error) { next(error); }
});

// POST /admin/team/sync-permissions - older accounts were created before newer permission flags existed, so those flags
// are simply absent. This fills every missing flag from the person's ROLE defaults (never changes a flag that is already set).
router.post('/team/sync-permissions', verifyAdmin, requireSuperAdminRole, async (req, res, next) => {
  try {
    const raw = await Employee.find().lean();
    const details = [];
    for (const e of raw) {
      const preset = perms.presetFor(e.role);
      const set = {};
      for (const k of perms.PERMISSION_KEYS) {
        if (e.permissions?.[k] === undefined) set[`permissions.${k}`] = e.role === 'super_admin' ? true : preset[k];
      }
      if (!Object.keys(set).length) continue;
      await Employee.updateOne({ _id: e._id }, { $set: set });
      invalidateEmployeeAccess(e._id);
      details.push({ _id: String(e._id), name: e.name, role: e.role, added: Object.keys(set).map((k) => k.replace('permissions.', '')), granted: Object.entries(set).filter(([, v]) => v).length });
    }
    audit('permissions_synced', { req, actor: req.admin, targetType: 'employee', details: { accounts: details.length } });
    res.json({ checked: raw.length, updated: details.length, details, message: details.length ? `Filled in missing permissions on ${details.length} account${details.length === 1 ? '' : 's'}` : 'Every account already has every permission flag' });
  } catch (error) { next(error); }
});

// GET /admin/employees - the team directory. Needs canViewEmployees (super admins always). Everyone else uses /careers/admin/org/me.
router.get('/employees', verifyAdmin, requirePermission('canViewEmployees'), async (req, res, next) => {
  try {
    const sup = perms.isSuperAdmin(req.admin);
    const [raw, ov] = await Promise.all([Employee.find().sort({ createdAt: -1 }).lean(), orgView(req)]);
    const nodeByEmp = new Map(ov.docs.filter((d) => d.employeeId).map((d) => [String(d.employeeId), d]));
    const meId = req.admin.employeeId ? String(req.admin.employeeId) : null;

    const employees = raw.map((e) => {
      const safe = { ...e };
      for (const k of SAFE_EMPLOYEE_STRIP) delete safe[k];

      const node = nodeByEmp.get(String(e._id)) || null;
      const parent = node?.parentId ? ov.t.byId.get(String(node.parentId)) : null;
      safe.position = node ? { _id: String(node._id), title: node.title, level: node.level } : null;
      safe.manager = parent ? { nodeId: String(parent._id), name: parent.status === 'open' ? null : parent.personName, title: parent.title, open: parent.status === 'open', employeeId: parent.employeeId ? String(parent.employeeId) : null } : null;
      safe.reportCount = node ? ov.t.direct(node._id).length : 0;

      // Sign-in activity: yourself, the people under you, or everyone if you are a super admin.
      const canSeeLogin = sup || String(e._id) === meId || (node && ov.visible.has(String(node._id)));
      if (!canSeeLogin) { delete safe.lastLogin; delete safe.previousLogin; delete safe.loginCount; safe.loginHidden = true; }

      if (sup) {
        safe.missingPermissions = perms.PERMISSION_KEYS.filter((k) => e.permissions?.[k] === undefined);
      } else {
        for (const k of ['permissions', 'isDemo', 'phone', 'emergencyContact', 'notes', 'twoFactorEnabled', 'totpEnabled', 'forcePasswordReset', 'accessibleEvents', 'githubUsername', 'githubAccess']) delete safe[k];
      }
      return safe;
    });

    const root = sup ? { name: 'Super Admin', ...(await team.rootLoginStats()) } : null;
    res.json({ employees, root });
  } catch (error) { next(error); }
});

// POST /admin/employees - add a person. One call does everything:
//   role -> default permissions, a strong one-time password, the org-chart box (fill an open position or sit under a
//   manager), and marking the hiring application accepted when they came from Careers.
router.post('/employees', verifyAdmin, requireSuperAdminRole, async (req, res, next) => {
  try {
    const {
      name, email, role, department, phone, notes, permissions, startDate, status, isDemo,
      timezone, location, emergencyContact, employeeId, twoFactorEnabled, forcePasswordReset, accessibleEvents,
      orgNodeId, managerNodeId, positionTitle, applicationId, githubUsername, githubAccess,
    } = req.body;
    const cleanName  = String(name || '').trim();
    const cleanEmail = String(email || '').trim().toLowerCase();
    if (!cleanName || !cleanEmail) return res.status(400).json({ error: 'Name and email required' });
    if (!isEmail(cleanEmail)) return res.status(400).json({ error: 'That email address does not look right.' });

    const roleId = role || 'volunteer';
    if (!perms.ROLE_IDS.includes(roleId)) return res.status(400).json({ error: `Unknown role "${roleId}".` });

    if (await Employee.findOne({ email: cleanEmail })) return res.status(400).json({ error: 'Email already registered' });

    const empData = {
      name: cleanName, email: cleanEmail, role: roleId, department, phone, notes, status,
      timezone, location, emergencyContact, employeeId,
      // Role decides the starting access. Explicit flags (the "customise" step) win when sent.
      permissions: roleId === 'super_admin' ? perms.allPermissions() : (permissions && typeof permissions === 'object' ? sanitizePerms(permissions) : perms.presetFor(roleId)),
      isDemo: typeof isDemo === 'boolean' ? isDemo : roleId === 'demo',
    };
    if (typeof twoFactorEnabled === 'boolean') empData.twoFactorEnabled = twoFactorEnabled;
    if (Array.isArray(accessibleEvents)) empData.accessibleEvents = accessibleEvents;
    if (githubUsername) empData.githubUsername = String(githubUsername).trim().slice(0, 39);
    if (['none', 'read', 'write'].includes(githubAccess)) empData.githubAccess = githubAccess;
    if (startDate && String(startDate).trim()) {
      const d = new Date(startDate);
      if (!isNaN(d.getTime())) empData.startDate = d;
    }

    // Password: use the one supplied, otherwise generate a strong one-time password. Either way the person
    // is forced to choose their own on first login unless the caller explicitly says otherwise.
    let tempPassword = null;
    const supplied = req.body.password && String(req.body.password).trim();
    if (supplied) {
      if (!PW_RULE.test(supplied)) return res.status(400).json({ error: PW_MSG });
      empData.passwordHash = await bcrypt.hash(supplied, 10);
    } else {
      tempPassword = team.generatePassword();
      empData.passwordHash = await bcrypt.hash(tempPassword, 10);
    }
    empData.forcePasswordReset = typeof forcePasswordReset === 'boolean' ? forcePasswordReset : true;

    const emp = await Employee.create(empData);
    audit('employee_created', {
      req, actor: req.admin,
      targetId: emp._id.toString(), targetType: 'employee',
      details: { name: emp.name, email: emp.email, role: emp.role, createdBy: req.admin.email || req.admin.username },
    });

    // Put them on the org chart so their manager / reports exist from day one.
    let node = null; let chartError = null;
    try {
      node = await team.placeOnChart({ emp, orgNodeId, managerNodeId, title: String(positionTitle || '').trim().slice(0, 120), department: String(department || '').trim().slice(0, 80), by: req.admin.email || req.admin.username || 'super admin' });
    } catch (e) { chartError = e.message || 'Could not place them on the org chart'; console.error('[team] placeOnChart failed:', e.message); }

    // Came from a hiring application? Mark it accepted (and keep the history).
    let application = null;
    if (applicationId && mongoose.isValidObjectId(String(applicationId))) {
      try {
        const app = await JobApplication.findById(applicationId);
        if (app) {
          if (app.status !== 'accepted') { app.status = 'accepted'; app.statusHistory.push({ status: 'accepted', by: req.admin.email || req.admin.username || 'super admin' }); await app.save(); }
          application = { _id: String(app._id), status: app.status };
        }
      } catch (e) { console.error('[team] application update failed:', e.message); }
    }

    audit('employee_onboarded', {
      req, actor: req.admin, targetId: emp._id.toString(), targetType: 'employee',
      details: { role: emp.role, onChart: !!node, fromApplication: !!application, generatedPassword: !!tempPassword },
    });

    res.status(201).json({
      employee: stripSecrets(emp), node: node ? { _id: String(node._id), title: node.title, parentId: node.parentId ? String(node.parentId) : null } : null,
      application, chartError, ...(tempPassword ? { tempPassword } : {}), message: 'Employee created',
    });
  } catch (error) { next(error); }
});

const EDITABLE_EMPLOYEE_FIELDS = ['name', 'email', 'role', 'department', 'phone', 'notes', 'status', 'isDemo', 'timezone', 'location',
  'emergencyContact', 'employeeId', 'twoFactorEnabled', 'forcePasswordReset', 'accessibleEvents', 'githubUsername', 'githubAccess', 'avatar'];

router.patch('/employees/:id', verifyAdmin, requireSuperAdminRole, async (req, res, next) => {
  try {
    const { password, startDate, permissions, applyRoleDefaults } = req.body;
    const updateData = {};
    for (const f of EDITABLE_EMPLOYEE_FIELDS) if (req.body[f] !== undefined) updateData[f] = req.body[f];

    const before = await Employee.findById(req.params.id).select('role status email name department').lean();
    if (!before) return res.status(404).json({ error: 'Employee not found' });

    if (updateData.role !== undefined && !perms.ROLE_IDS.includes(updateData.role)) return res.status(400).json({ error: `Unknown role "${updateData.role}".` });
    if (updateData.email !== undefined) {
      updateData.email = String(updateData.email).trim().toLowerCase();
      if (!isEmail(updateData.email)) return res.status(400).json({ error: 'That email address does not look right.' });
      if (updateData.email !== before.email && await Employee.findOne({ email: updateData.email, _id: { $ne: req.params.id } })) return res.status(400).json({ error: 'Email already registered' });
    }
    // Nobody can lock themselves out or strip their own access from this screen.
    const isSelf = req.admin.employeeId && String(req.admin.employeeId) === String(req.params.id);
    if (isSelf && ((updateData.role && updateData.role !== before.role) || (updateData.status && updateData.status !== 'active'))) {
      return res.status(400).json({ error: 'You cannot change your own role or suspend yourself. Ask another super admin.' });
    }

    // Permissions: a role change can re-apply that role's defaults; otherwise explicit flags replace the set.
    const roleFinal = updateData.role || before.role;
    if (roleFinal === 'super_admin') updateData.permissions = perms.allPermissions();
    else if (applyRoleDefaults === true) updateData.permissions = perms.presetFor(roleFinal);
    else if (permissions && typeof permissions === 'object') updateData.permissions = sanitizePerms(permissions);
    if (roleFinal === 'demo') updateData.isDemo = true;

    if (password && String(password).trim()) {
      if (!PW_RULE.test(String(password).trim())) return res.status(400).json({ error: PW_MSG });
      updateData.passwordHash = await bcrypt.hash(String(password).trim(), 10);
      updateData.forcePasswordReset = false; // clear force-reset flag on manual set
    }
    if (startDate && String(startDate).trim()) {
      updateData.startDate = new Date(startDate);
      if (isNaN(updateData.startDate.getTime())) return res.status(400).json({ error: 'Invalid start date format.' });
    }

    const emp = await Employee.findByIdAndUpdate(req.params.id, { $set: updateData }, { new: true, runValidators: true });
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    invalidateEmployeeAccess(emp._id.toString());   // new role / flags apply on their very next request

    // Keep their org-chart box in step with their account.
    const nodeSync = {};
    if (updateData.name !== undefined) nodeSync.personName = emp.name;
    if (updateData.email !== undefined) nodeSync.personEmail = emp.email;
    if (updateData.department !== undefined && updateData.department !== before.department) nodeSync.department = emp.department || '';
    if (Object.keys(nodeSync).length) OrgNode.updateMany({ employeeId: emp._id }, { $set: nodeSync }).catch(() => {});

    const fields = Object.keys(updateData).filter((k) => k !== 'passwordHash');
    audit('employee_updated', {
      req, actor: req.admin,
      targetId: emp._id.toString(), targetType: 'employee',
      details: { name: emp.name, email: emp.email, updatedFields: fields, updatedBy: req.admin.email || req.admin.username },
    });
    if (updateData.role && updateData.role !== before.role) {
      audit('employee_role_changed', { req, actor: req.admin, targetId: emp._id.toString(), targetType: 'employee', details: { name: emp.name, from: before.role, to: emp.role } });
    }
    res.json({ employee: stripSecrets(emp), message: 'Employee updated' });
  } catch (error) { next(error); }
});

router.delete('/employees/:id', verifyAdmin, requireSuperAdminRole, async (req, res, next) => {
  try {
    const emp = await Employee.findById(req.params.id).lean();
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    if (req.admin.employeeId && String(req.admin.employeeId) === String(req.params.id)) return res.status(400).json({ error: 'You cannot delete your own account.' });
    await Employee.findByIdAndDelete(req.params.id);
    // Revoke all active sessions immediately — the employee no longer exists
    // so any lingering JWT would otherwise grant ghost access for up to 24h.
    await revokeEmployeeSessions(req.params.id);
    invalidateEmployeeAccess(req.params.id);
    // Their box stays on the chart (so reporting lines don't break) but no longer points at a login account.
    await OrgNode.updateMany({ employeeId: emp._id }, { $set: { employeeId: null } });
    audit('employee_deleted', {
      req, actor: req.admin,
      targetId: req.params.id, targetType: 'employee',
      details: { name: emp.name, email: emp.email, role: emp.role, deletedBy: req.admin.email || req.admin.username },
    });
    res.json({ message: 'Employee deleted' });
  } catch (error) { next(error); }
});

// POST /admin/employees/:id/force-reset — flag the employee to reset pw on next login
router.post('/employees/:id/force-reset', verifyAdmin, requireSuperAdminRole, async (req, res, next) => {
  try {
    const emp = await Employee.findByIdAndUpdate(
      req.params.id,
      { $set: { forcePasswordReset: true } },
      { new: true }
    );
    if (!emp) return res.status(404).json({ error: 'Employee not found' });

    // Revoke all active sessions immediately so the employee MUST re-login.
    // On re-login the forcePasswordReset flag is checked and a restricted
    // reset-token is issued — they cannot reach any route until they change it.
    await revokeEmployeeSessions(req.params.id);

    audit('force_password_reset_set', {
      req, actor: req.admin,
      targetId: req.params.id, targetType: 'employee',
      details: { name: emp.name, email: emp.email, setBy: req.admin.email || req.admin.username },
    });

    res.json({ message: 'Password reset flag set — employee sessions revoked', employee: stripSecrets(emp) });
  } catch (error) { next(error); }
});

// POST /admin/employees/:id/suspend — suspend / unsuspend. Send { suspend: true|false } to be explicit; with no
// body it toggles (the old behaviour).
router.post('/employees/:id/suspend', verifyAdmin, requireSuperAdminRole, async (req, res, next) => {
  try {
    const emp = await Employee.findById(req.params.id);
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    if (req.admin.employeeId && String(req.admin.employeeId) === String(req.params.id)) return res.status(400).json({ error: 'You cannot suspend your own account.' });
    const next_status = typeof req.body?.suspend === 'boolean'
      ? (req.body.suspend ? 'suspended' : 'active')
      : (emp.status === 'suspended' ? 'active' : 'suspended');
    emp.status = next_status;
    await emp.save();
    invalidateEmployeeAccess(emp._id.toString());
    const reason = String(req.body?.reason || '').slice(0, 300);

    if (next_status === 'suspended') {
      // Immediately invalidate all active JWT sessions for this employee.
      await revokeEmployeeSessions(emp._id.toString());
      audit('employee_suspended', {
        req, actor: req.admin,
        targetId: emp._id.toString(), targetType: 'employee',
        details: { name: emp.name, email: emp.email, reason, suspendedBy: req.admin.email || req.admin.username },
      });
    } else {
      // Unsuspending: clear the revocation flag so new logins work normally.
      await clearEmployeeRevocation(emp._id.toString());
      audit('employee_unsuspended', {
        req, actor: req.admin,
        targetId: emp._id.toString(), targetType: 'employee',
        details: { name: emp.name, email: emp.email, unsuspendedBy: req.admin.email || req.admin.username },
      });
    }

    res.json({ message: `Employee ${next_status}`, status: next_status });
  } catch (error) { next(error); }
});

// GET /admin/employees/:id/activity — lightweight activity summary
router.get('/employees/:id/activity', verifyAdmin, requireSuperAdminRole, async (req, res, next) => {
  try {
    const emp = await Employee.findById(req.params.id).lean();
    if (!emp) return res.status(404).json({ error: 'Employee not found' });
    res.json({
      lastLogin:    emp.lastLogin   || null,
      previousLogin: emp.previousLogin || null,
      loginCount:   emp.loginCount  || 0,
      createdAt:    emp.createdAt,
      updatedAt:    emp.updatedAt,
      startDate:    emp.startDate   || null,
    });
  } catch (error) { next(error); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /admin/employees/:id/change-password
// ─────────────────────────────────────────────────────────────────────────────
// Dual-purpose endpoint:
//   1. Forced-reset flow: called by the employee themselves using the restricted
//      resetToken issued at login when forcePasswordReset is true.  The token is
//      short-lived (1h), carries `restricted: true`, and is accepted here only.
//   2. Admin-initiated: a super_admin can set any employee's password directly.
//
// In both cases a new full-access token is issued and the forcePasswordReset flag
// is cleared, so the employee can immediately continue working.
// ─────────────────────────────────────────────────────────────────────────────
router.post(
  '/employees/:id/change-password',
  // Accept either a restricted reset-token (employee self-service) or a full admin token
  async (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1] || req.cookies.adminToken;
    if (!token) return res.status(401).json({ error: 'Authentication required.' });
    try {
      const decoded = require('jsonwebtoken').verify(token, secrets.jwt);
      // Allow if: (a) caller is a super_admin or root admin, OR
      //           (b) caller is the employee themselves with a restricted reset-token
      const isSelf      = decoded.restricted && decoded.isEmployee &&
                          decoded.employeeId?.toString() === req.params.id;
      const isAdminCall = decoded.isAdmin && !decoded.restricted &&
                          (decoded.role === 'super_admin' || (!decoded.isEmployee && decoded.isAdmin));
      if (!isSelf && !isAdminCall) {
        return res.status(403).json({ error: 'Not authorised to change this password.' });
      }
      req._pwChangeDecoded   = decoded;
      req._pwChangeSelf      = isSelf;
      next();
    } catch {
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
  },
  [
    body('newPassword')
      .isLength({ min: 10 }).withMessage('Password must be at least 10 characters')
      .matches(/[A-Z]/).withMessage('Password must contain at least one uppercase letter')
      .matches(/[0-9]/).withMessage('Password must contain at least one number')
      .matches(/[^A-Za-z0-9]/).withMessage('Password must contain at least one special character'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const emp = await Employee.findById(req.params.id);
      if (!emp) return res.status(404).json({ error: 'Employee not found.' });

      const newHash = await bcrypt.hash(req.body.newPassword, 12);
      emp.passwordHash      = newHash;
      emp.forcePasswordReset = false;
      await emp.save();

      // Revoke old sessions (including the restricted reset-token), then issue
      // a fresh full-access token so the employee can continue without re-logging in.
      await revokeEmployeeSessions(emp._id.toString());

      const jti      = crypto.randomUUID();
      const newToken = jwt.sign(
        {
          jti,
          employeeId:  emp._id.toString(),
          name:        emp.name,
          email:       emp.email,
          role:        emp.role,
          isAdmin:     true,
          isEmployee:  true,
          isDemo:      emp.isDemo || false,
          permissions: emp.permissions,
        },
        secrets.jwt,
        { expiresIn: '24h' },
      );

      audit('password_changed', {
        req,
        actor: req._pwChangeDecoded,
        targetId:   emp._id.toString(),
        targetType: 'employee',
        details: {
          name:       emp.name,
          email:      emp.email,
          selfChange: req._pwChangeSelf,
          changedBy:  req._pwChangeDecoded.email || req._pwChangeDecoded.username,
        },
      });

      res.json({
        message: 'Password changed successfully.',
        token:   newToken, // fresh full-access token (no forcePasswordReset)
        user: {
          username:           emp.name,
          email:              emp.email,
          role:               emp.role,
          isEmployee:         true,
          isDemo:             emp.isDemo || false,
          permissions:        emp.permissions,
          forcePasswordReset: false,
        },
      });
    } catch (error) { next(error); }
  }
);

// ═══════════════════════════════════════════════════════════════════════════════
// AUDIT LOG VIEWER
// ═══════════════════════════════════════════════════════════════════════════════
// GET /admin/audit-logs
// Returns the decrypted audit trail. Restricted to employees with canViewSecurityLogs
// or any super_admin / root admin.
//
// Query params:
//   limit    — max records (default 100, max 500)
//   skip     — pagination offset
//   action   — filter by action string (e.g. 'login_failure')
//   actorId  — filter by employee ID
//   targetId — filter by affected resource ID
// ─────────────────────────────────────────────────────────────────────────────
router.get('/audit-logs', verifyAdmin, requirePermission('canViewSecurityLogs'), async (req, res, next) => {
  try {
    const limit    = Math.min(parseInt(req.query.limit  || '100', 10), 500);
    const skip     = parseInt(req.query.skip   || '0',   10);
    const { action, actorId, targetId } = req.query;

    const logs = await getAuditLogs({ limit, skip, action, actorId, targetId });
    res.json({ logs, count: logs.length, limit, skip });
  } catch (error) { next(error); }
});



router.get('/export', verifyAdmin, requirePermission('canExportData'), async (req, res, next) => {
  try {
    const type    = req.query.type || 'events';
    const eventId = req.query.eventId;
    const filter  = eventId ? { eventId } : {};
    let data;

    switch (type) {
      case 'events':
        data = await Event.find(filter).lean();
        break;
      case 'messages':
        data = await Message.find({ ...filter, isDeleted: false }).lean();
        break;
      case 'polls':
        data = await Poll.find(filter).lean();
        break;
      case 'files':
        data = await File.find({ ...filter, isDeleted: false }).lean();
        break;
      case 'participants':
        data = await EventParticipant.find(filter).select('-password').lean();
        break;
      case 'invites':
        data = Invite ? await Invite.find(filter).lean() : [];
        break;
      case 'all': {
        if (!eventId) return res.status(400).json({ error: 'Event ID required for full export' });
        const [ev, msgs, pls, fls, parts, invs] = await Promise.all([
          Event.findById(eventId).lean(),
          Message.find({ eventId, isDeleted: false }).lean(),
          Poll.find({ eventId }).lean(),
          File.find({ eventId, isDeleted: false }).lean(),
          EventParticipant.find({ eventId }).select('-password').lean(),
          Invite ? Invite.find({ eventId }).lean() : Promise.resolve([]),
        ]);
        data = { event: ev, messages: msgs, polls: pls, files: fls, participants: parts, invites: invs };
        break;
      }
      default:
        return res.status(400).json({ error: 'Invalid export type' });
    }

    res.json({ data, exportedAt: new Date(), type });
  } catch (error) {
    next(error);
  }
});

router.get('/export/stats', verifyAdmin, requirePermission('canExportData'), async (req, res, next) => {
  try {
    const [eventsByStatus, eventsByMonth, messagesByDay] = await Promise.all([
      Event.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
      Event.aggregate([
        { $group: { _id: { $dateToString: { format: '%Y-%m', date: '$createdAt' } }, count: { $sum: 1 } } },
        { $sort: { _id: -1 } },
        { $limit: 12 },
      ]),
      Message.aggregate([
        { $match: { isDeleted: false } },
        { $group: { _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } }, count: { $sum: 1 } } },
        { $sort: { _id: -1 } },
        { $limit: 30 },
      ]),
    ]);

    res.json({ eventsByStatus, eventsByMonth, messagesByDay, generatedAt: new Date() });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// ADMIN EVENT ACCESS — bypass password
// ═══════════════════════════════════════════════════════════════════════════════

router.post('/events/:eventId/access', verifyAdmin, requirePermission('canEditEvents'), async (req, res, next) => {
  try {
    // Demo accounts are read-only guests and must never mint organizer-level tokens.
    if (req.admin?.isDemo) {
      return res.status(403).json({ error: 'Demo accounts cannot open events as admin.', demo: true });
    }

    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    // Act as the event's real organizer so every organizer check (RSVP, enterprise
    // check-in, table service, standard events, sockets) passes without a 401/403.
    const organizer = (event.participants || []).find(p => p.role === 'organizer');
    const username  = organizer?.username || event.organizerName || 'ADMIN';

    const token = jwt.sign(
      {
        eventId:           event._id.toString(),
        username,
        role:              'organizer',
        isAdminAccess:     true,
        canBypassPassword: true,
        adminName:         req.admin?.name || req.admin?.email || req.admin?.username || 'admin',
      },
      secrets.jwt,
      { expiresIn: '24h' }
    );

    audit('admin_event_access', {
      req, actor: req.admin,
      targetId: event._id.toString(), targetType: 'event',
      details: { title: event.title },
    });

    res.json({
      token,
      username,
      eventType: event.eventType,
      isEnterpriseMode: event.isEnterpriseMode,
      event: {
        _id:                 event._id,
        title:               event.title,
        subdomain:           event.subdomain,
        date:                event.date,
        location:            event.location,
        description:         event.description,
        organizerName:       event.organizerName,
        organizerEmail:      event.organizerEmail,
        isPasswordProtected: event.isPasswordProtected,
        isEnterpriseMode:    event.isEnterpriseMode,
        eventType:           event.eventType,
        status:              event.status,
        participants:        event.participants,
        createdAt:           event.createdAt,
      },
    });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// MANUAL CLEANUP — run the 7-day cleanup job on demand
// ═══════════════════════════════════════════════════════════════════════════════

router.post('/cleanup', verifyAdmin, requirePermission('canRunCleanup'), async (req, res, next) => {
  try {
    const { manualCleanup, cleanupOrphanedCloudinaryAssets } = require('../jobs/cleanupJob');

    const logs        = [];
    const originalLog  = console.log;
    const originalError = console.error;

    console.log   = (...args) => { logs.push({ level: 'info',  message: args.join(' ') }); originalLog(...args);   };
    console.error = (...args) => { logs.push({ level: 'error', message: args.join(' ') }); originalError(...args); };

    await manualCleanup();

    console.log   = originalLog;
    console.error = originalError;

    const successLine  = logs.find(l => l.message.includes('Successfully deleted:'));
    const failLine     = logs.find(l => l.message.includes('Failed to delete:'));
    const successCount = successLine ? parseInt(successLine.message.match(/\d+/)?.[0] || '0') : 0;
    const failCount    = failLine    ? parseInt(failLine.message.match(/\d+/)?.[0]    || '0') : 0;

    // Run Cloudinary orphan sweep
    const cloudinaryResult = await cleanupOrphanedCloudinaryAssets();

    res.json({
      success: true,
      message: 'Manual cleanup completed',
      results: { deleted: successCount, failed: failCount, total: successCount + failCount },
      cloudinary: cloudinaryResult,
      logs: logs.map(l => l.message).filter(m => !m.includes('===')),
    });
  } catch (error) {
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// MARKETING EMAIL
// ═══════════════════════════════════════════════════════════════════════════════

// GET /admin/marketing/templates
// Returns the list of available marketing email templates.
router.get('/marketing/templates', verifyAdmin, requirePermission('canViewMarketing'), (_req, res) => {
  const { listTemplates } = require('../services/marketingService');
  res.json({ templates: listTemplates() });
});

// GET /admin/marketing/preview/:templateId
// Returns the rendered HTML of a template for previewing in an iframe.
router.get('/marketing/preview/:templateId', verifyAdmin, requirePermission('canViewMarketing'), (req, res) => {
  const { previewTemplate } = require('../services/marketingService');
  const { ctaUrl, recipientName, recipientCompany, recipientRole } = req.query;
  const recipient = {
    name:    recipientName    || '',
    company: recipientCompany || '',
    role:    recipientRole    || '',
  };
  const html = previewTemplate(req.params.templateId, ctaUrl, recipient);
  if (!html) return res.status(404).json({ error: 'Template not found' });
  res.setHeader('Content-Type', 'text/html');
  res.send(html);
});

// POST /admin/marketing/send is defined after the discovery routes below.

// ═══════════════════════════════════════════════════════════════════════════════
// COMMAND CENTER  —  super_admin only
// ═══════════════════════════════════════════════════════════════════════════════

// requireSuperAdmin is imported from auth.js as requireSuperAdminRole.
// Keep local alias for backward compatibility with all /cc/* route definitions.
const requireSuperAdmin = requireSuperAdminRole;

// GET /admin/cc/fleet — full fleet metrics from all services
router.get('/cc/fleet', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { meshGet, meshPost } = require('../middleware/mesh');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = process.env.ROUTER_URL    || '';

  const localMem  = process.memoryUsage();
  const localSnap = {
    service:  CALLER,
    type:     'backend',
    pid:      process.pid,
    uptime:   Math.floor(process.uptime()),
    node:     process.version,
    memMB: {
      rss:       +(localMem.rss       / 1048576).toFixed(1),
      heapUsed:  +(localMem.heapUsed  / 1048576).toFixed(1),
      heapTotal: +(localMem.heapTotal / 1048576).toFixed(1),
    },
    logEntries:   global.__adminLogBuffer?.length || 0,
    liveClients:  global.__adminLogClients?.length || 0,
    errors24h:    (global.__adminLogBuffer || []).filter(e => e.level === 'error' && new Date(e.ts) > new Date(Date.now() - 86400000)).length,
    warns24h:     (global.__adminLogBuffer || []).filter(e => e.level === 'warn'  && new Date(e.ts) > new Date(Date.now() - 86400000)).length,
    ok: true,
  };

  if (!routerUrl) {
    return res.json({ services: [localSnap], fetchedAt: new Date().toISOString(), note: 'ROUTER_URL not set' });
  }

  const [routerR, watchdogR] = await Promise.all([
    meshPost(CALLER, `${routerUrl}/mesh/exec`, { command: 'stats' }, { timeout: 8000 })
      .catch(() => ({ ok: false })),
    meshGet(CALLER, `${(process.env.WATCHDOG_URL || '').replace(/\/$/, '')}/mesh/status`, { timeout: 8000 })
      .catch(() => ({ ok: false })),
  ]);

  const services = [localSnap];

  if (routerR.ok && routerR.data?.result) {
    const r = routerR.data.result;
    services.push({ service: 'Router', type: 'router', pid: r.pid, uptime: r.uptime, node: r.nodeVersion, memMB: r.memMB, logEntries: r.logBufferLen, backends: r.backends, emailPool: r.emailPool, ok: true });
  } else {
    services.push({ service: 'Router', type: 'router', ok: false, error: 'unreachable' });
  }

  if (watchdogR.ok && watchdogR.data) {
    const d = watchdogR.data;
    services.push({ service: 'Watchdog', type: 'watchdog', pid: d.pid, uptime: d.uptime, node: d.nodeVersion || d.version, ok: true, monitoredServices: d.services?.length || 0 });
  } else {
    services.push({ service: 'Watchdog', type: 'watchdog', ok: false, error: 'unreachable' });
  }

  res.json({ services, fetchedAt: new Date().toISOString() });
});

// POST /admin/cc/command — dispatch a command to a specific service
router.post('/cc/command', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { target, command, params = {} } = req.body || {};
  if (!target || !command) return res.status(400).json({ error: 'target and command required' });

  const { meshPost, meshGet } = require('../middleware/mesh');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = (process.env.ROUTER_URL || '').replace(/\/$/, '');
  const watchdogUrl = (process.env.WATCHDOG_URL || '').replace(/\/$/, '');

  const BACKEND_COMMANDS = ['flush-logs', 'gc', 'ping', 'stats', 'cache-clear'];
  const ROUTER_COMMANDS  = ['flush-logs', 'gc', 'ping', 'stats', 'clear-key-suspension', 'list-backends'];

  if (target === 'backend') {
    switch (command) {
      case 'ping':
        return res.json({ ok: true, result: { pong: true, ts: new Date().toISOString(), pid: process.pid } });
      case 'stats': {
        const m = process.memoryUsage();
        return res.json({ ok: true, result: { pid: process.pid, uptime: Math.floor(process.uptime()), memMB: { rss: +(m.rss/1048576).toFixed(1), heapUsed: +(m.heapUsed/1048576).toFixed(1), heapTotal: +(m.heapTotal/1048576).toFixed(1) }, logBuffer: global.__adminLogBuffer?.length || 0, node: process.version } });
      }
      case 'flush-logs': {
        const count = global.__adminLogBuffer?.length || 0;
        if (global.__adminLogBuffer) global.__adminLogBuffer.length = 0;
        console.log(`[cc] Backend log buffer flushed (${count} entries)`);
        return res.json({ ok: true, result: { flushed: count } });
      }
      case 'gc': {
        let ran = false;
        if (global.gc) { global.gc(); ran = true; }
        return res.json({ ok: true, result: { gcRan: ran } });
      }
      case 'cache-clear': {
        console.log('[cc] Cache clear requested via command center — use flush-logs for log buffer or clear-key-suspension for email keys');
        return res.json({ ok: true, result: { note: 'Cache clear acknowledged. Use clear-key-suspension on the router to unsuspend rate-limited email keys.' } });
      }
      default:
        if (!BACKEND_COMMANDS.includes(command)) return res.status(400).json({ error: `Unknown backend command: ${command}` });
    }
  }

  if (target === 'router') {
    if (!routerUrl) return res.status(503).json({ error: 'ROUTER_URL not set' });
    if (!ROUTER_COMMANDS.includes(command)) return res.status(400).json({ error: `Unknown router command: ${command}` });
    const r = await meshPost(CALLER, `${routerUrl}/mesh/exec`, { command, params }, { timeout: 10000 });
    if (r.ok) return res.json({ ok: true, result: r.data?.result });
    return res.status(502).json({ ok: false, error: r.error || 'Router unreachable' });
  }

  if (target === 'watchdog') {
    if (!watchdogUrl) return res.status(503).json({ error: 'WATCHDOG_URL not set' });
    if (command === 'ping') {
      const r = await meshGet(CALLER, `${watchdogUrl}/watchdog/ping`, { timeout: 8000 });
      return res.json({ ok: r.ok, result: r.data || { error: r.error } });
    }
    if (command === 'status') {
      const r = await meshGet(CALLER, `${watchdogUrl}/watchdog/status`, { timeout: 8000 });
      return res.json({ ok: r.ok, result: r.data || { error: r.error } });
    }
    if (command === 'stats') {
      const r = await meshGet(CALLER, `${watchdogUrl}/mesh/status`, { timeout: 8000 });
      return res.json({ ok: r.ok, result: r.data || { error: r.error } });
    }
    return res.status(400).json({ error: `Unknown watchdog command: ${command}` });
  }

  res.status(400).json({ error: `Unknown target: ${target}. Must be backend, router, or watchdog.` });
});

// GET /admin/cc/email-pool — Brevo and Mailjet key pool from router
router.get('/cc/email-pool', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { meshGet } = require('../middleware/mesh');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = (process.env.ROUTER_URL || '').replace(/\/$/, '');
  if (!routerUrl) return res.status(503).json({ error: 'ROUTER_URL not set' });
  const r = await meshGet(CALLER, `${routerUrl}/mesh/email/pool`, { timeout: 8000 });
  if (r.ok) return res.json(r.data);
  res.status(502).json({ ok: false, error: r.error || 'Router unreachable' });
});

// ─── Router proxy routes ──────────────────────────────────────────────────────
// These replace the old frontend-direct mesh calls. The admin JWT (verifyAdmin)
// is the only credential needed — no VITE_MESH_SECRET in the browser.

// GET /admin/cc/router/status
router.get('/cc/router/status', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { meshGet } = require('../middleware/mesh');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = (process.env.ROUTER_URL || '').replace(/\/$/, '');
  if (!routerUrl) return res.status(503).json({ error: 'ROUTER_URL not set' });
  const r = await meshGet(CALLER, `${routerUrl}/mesh/status`, { timeout: 8000 });
  if (r.ok) return res.json(r.data);
  res.status(502).json({ ok: false, error: r.error || 'Router unreachable' });
});

// POST /admin/cc/router/boost
router.post('/cc/router/boost', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { verifyTurnstile } = require('../services/captchaService');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = (process.env.ROUTER_URL || '').replace(/\/$/, '');
  if (!routerUrl) return res.status(503).json({ error: 'ROUTER_URL not set' });
  const r = await meshPost(CALLER, `${routerUrl}/mesh/boost`, req.body, { timeout: 8000 });
  if (r.ok) return res.json(r.data);
  res.status(502).json({ ok: false, error: r.error || 'Router unreachable' });
});

// DELETE /admin/cc/router/boost
router.delete('/cc/router/boost', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { meshDelete } = require('../middleware/mesh');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = (process.env.ROUTER_URL || '').replace(/\/$/, '');
  if (!routerUrl) return res.status(503).json({ error: 'ROUTER_URL not set' });
  const r = await meshDelete(CALLER, `${routerUrl}/mesh/boost`, { timeout: 8000 });
  if (r.ok) return res.json(r.data);
  res.status(502).json({ ok: false, error: r.error || 'Router unreachable' });
});

// POST /admin/cc/router/scale
router.post('/cc/router/scale', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { verifyTurnstile } = require('../services/captchaService');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = (process.env.ROUTER_URL || '').replace(/\/$/, '');
  if (!routerUrl) return res.status(503).json({ error: 'ROUTER_URL not set' });
  const r = await meshPost(CALLER, `${routerUrl}/mesh/scale`, req.body, { timeout: 8000 });
  if (r.ok) return res.json(r.data);
  res.status(502).json({ ok: false, error: r.error || 'Router unreachable' });
});

// POST /admin/cc/router/email/test
router.post('/cc/router/email/test', verifyAdmin, requireSuperAdmin, async (req, res) => {
  const { verifyTurnstile } = require('../services/captchaService');
  const CALLER    = process.env.BACKEND_LABEL || 'Backend';
  const routerUrl = (process.env.ROUTER_URL || '').replace(/\/$/, '');
  if (!routerUrl) return res.status(503).json({ error: 'ROUTER_URL not set' });
  const r = await meshPost(CALLER, `${routerUrl}/mesh/email/test`, req.body, { timeout: 10000 });
  if (r.ok) return res.json(r.data);
  res.status(502).json({ ok: false, error: r.error || 'Router unreachable' });
});

// GET /admin/cc/db — live database collection sizes and index info
router.get('/cc/db', verifyAdmin, requireSuperAdmin, async (req, res, next) => {
  try {
    const db = mongoose.connection.db;
    if (!db) return res.status(503).json({ error: 'Database not connected' });
    const collections = await db.listCollections().toArray();
    const stats = await Promise.all(
      collections.map(async (col) => {
        try {
          const s = await db.collection(col.name).stats();
          return { name: col.name, count: s.count, sizeMB: +(s.size / 1048576).toFixed(3), indexSizeMB: +(s.totalIndexSize / 1048576).toFixed(3), avgObjSize: s.avgObjSize || 0 };
        } catch { return { name: col.name, count: 0, sizeMB: 0, error: true }; }
      })
    );
    res.json({ collections: stats.sort((a, b) => b.sizeMB - a.sizeMB), dbName: mongoose.connection.name, state: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected', fetchedAt: new Date().toISOString() });
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// MARKETING — SCHEDULING
// ═══════════════════════════════════════════════════════════════════════════════

router.post('/marketing/schedule', verifyAdmin, requirePermission('canSendMarketing'), async (req, res, next) => {
  try {
    const redis = require('../services/redisClient');
    const { templateId, recipients, subject, ctaUrl, sendAt, label } = req.body || {};
    if (!templateId || !Array.isArray(recipients) || recipients.length === 0 || !sendAt)
      return res.status(400).json({ error: 'templateId, recipients, and sendAt required' });

    const id  = `sched:${Date.now()}:${Math.random().toString(36).slice(2, 8)}`;
    const job = { id, templateId, recipients, subject: subject || '', ctaUrl: ctaUrl || '', sendAt, label: label || templateId, createdAt: new Date().toISOString(), status: 'pending' };
    const ttl = Math.max(86400, Math.ceil((new Date(sendAt) - Date.now()) / 1000) + 3600);
    await redis.set(id, JSON.stringify(job), ttl);

    const listRaw = await redis.get('mktschedlist').catch(() => null);
    const list    = listRaw ? JSON.parse(listRaw) : [];
    list.push(id);
    await redis.set('mktschedlist', JSON.stringify(list), 7 * 86400);

    console.log(`[marketing] Scheduled campaign "${id}" (${recipients.length} recipients) for ${sendAt}`);
    res.status(201).json({ ok: true, id, job });
  } catch (err) { next(err); }
});

router.get('/marketing/scheduled', verifyAdmin, requirePermission('canViewMarketing'), async (req, res, next) => {
  try {
    const redis = require('../services/redisClient');
    const listRaw = await redis.get('mktschedlist').catch(() => null);
    const ids     = listRaw ? JSON.parse(listRaw) : [];
    const jobs    = (await Promise.all(ids.map(id => redis.get(id).then(r => r ? JSON.parse(r) : null).catch(() => null)))).filter(Boolean);
    res.json({ scheduled: jobs, total: jobs.length });
  } catch (err) { next(err); }
});

router.delete('/marketing/schedule/:id', verifyAdmin, requirePermission('canSendMarketing'), async (req, res, next) => {
  try {
    const redis = require('../services/redisClient');
    const id    = req.params.id;
    await redis.del(id).catch(() => {});
    const listRaw = await redis.get('mktschedlist').catch(() => null);
    if (listRaw) {
      const list = JSON.parse(listRaw).filter(x => x !== id);
      await redis.set('mktschedlist', JSON.stringify(list), 7 * 86400);
    }
    console.log(`[marketing] Cancelled scheduled campaign ${id}`);
    res.json({ ok: true, cancelled: id });
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// MARKETING — CONTACT DISCOVERY  (live, SSE-streamed)
// ═══════════════════════════════════════════════════════════════════════════════

// POST /admin/marketing/discover  — start a discovery run, streams results via SSE
router.get('/marketing/discover', verifyAdmin, requirePermission('canViewMarketing'), async (req, res) => {
  const { query, industry, location, limit } = req.query;
  if (!query && !industry) return res.status(400).json({ error: 'query or industry required' });

  const { discoverLeads } = require('../services/discoveryService');

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const send = (type, data) => {
    try { res.write(`data: ${JSON.stringify({ type, ...data })}\n\n`); } catch {}
  };

  const redis = require('../services/redisClient');
  const contactedRaw = await redis.get('mkt:contacted').catch(() => null);
  const contacted = new Set(contactedRaw ? JSON.parse(contactedRaw) : []);

  let stopped = false;
  req.on('close', () => { stopped = true; });

  try {
    await discoverLeads({
      query: query || '',
      industry: industry || '',
      location: location || '',
      limit: Math.min(parseInt(limit) || 30, 100),
      contacted,
      onProgress: (msg) => { if (!stopped) send('progress', { msg }); },
      onLead: (lead) => {
        if (!stopped) {
          const alreadyContacted = contacted.has((lead.email || '').toLowerCase());
          send('lead', { lead: { ...lead, alreadyContacted } });
        }
      },
      isStopped: () => stopped,
    });
  } catch (err) {
    send('error', { msg: err.message });
  }

  send('done', { msg: 'Discovery complete' });
  res.end();
});

// GET /admin/marketing/contacted  — list of already-emailed addresses
router.get('/marketing/contacted', verifyAdmin, requirePermission('canViewMarketing'), async (req, res, next) => {
  try {
    const redis = require('../services/redisClient');
    const raw = await redis.get('mkt:contacted').catch(() => null);
    const list = raw ? JSON.parse(raw) : [];
    res.json({ contacted: list, total: list.length });
  } catch (err) { next(err); }
});

// POST /admin/marketing/contacted/add  — manually mark emails as contacted
router.post('/marketing/contacted/add', verifyAdmin, requirePermission('canSendMarketing'), async (req, res, next) => {
  try {
    const redis = require('../services/redisClient');
    const { emails } = req.body;
    if (!Array.isArray(emails)) return res.status(400).json({ error: 'emails array required' });
    const raw = await redis.get('mkt:contacted').catch(() => null);
    const set = new Set(raw ? JSON.parse(raw) : []);
    emails.forEach(e => { if (e) set.add(e.toLowerCase().trim()); });
    await redis.set('mkt:contacted', JSON.stringify([...set]), 365 * 86400);
    res.json({ ok: true, total: set.size });
  } catch (err) { next(err); }
});

// DELETE /admin/marketing/contacted/:email  — remove from contacted list
router.delete('/marketing/contacted/:email', verifyAdmin, requirePermission('canSendMarketing'), async (req, res, next) => {
  try {
    const redis = require('../services/redisClient');
    const email = decodeURIComponent(req.params.email).toLowerCase();
    const raw = await redis.get('mkt:contacted').catch(() => null);
    const arr = (raw ? JSON.parse(raw) : []).filter(e => e !== email);
    await redis.set('mkt:contacted', JSON.stringify(arr), 365 * 86400);
    res.json({ ok: true, total: arr.length });
  } catch (err) { next(err); }
});

// Override sendCampaign to auto-track sent emails
const _origSend = router.stack; // just a reference; we patch via middleware below
router.post('/marketing/send', verifyAdmin, requirePermission('canSendMarketing'), async (req, res, next) => {
  try {
    const { templateId, recipients, subject, ctaUrl } = req.body || {};

    if (!templateId) return res.status(400).json({ error: 'templateId is required' });
    if (!Array.isArray(recipients) || recipients.length === 0)
      return res.status(400).json({ error: 'recipients must be a non-empty array' });
    if (recipients.length > 1000)
      return res.status(400).json({ error: 'Maximum 1,000 recipients per send.' });

    const { sendCampaign } = require('../services/marketingService');

    // Normalise: accept both plain strings and {email,name,company,role} objects
    const normalised = recipients.map(r =>
      typeof r === 'string' ? { email: r.trim().toLowerCase(), name: '', company: '', role: '' } :
      { email: (r.email || '').trim().toLowerCase(), name: r.name || '', company: r.company || '', role: r.role || '', website: r.website || '' }
    );

    const results = await sendCampaign({ templateId, recipients: normalised, subject, ctaUrl });

    // Track every successfully sent address
    try {
      const redis = require('../services/redisClient');
      const raw = await redis.get('mkt:contacted').catch(() => null);
      const set = new Set(raw ? JSON.parse(raw) : []);
      normalised.forEach(r => { if (r.email) set.add(r.email); });
      await redis.set('mkt:contacted', JSON.stringify([...set]), 365 * 86400);
    } catch {}

    res.json({ ok: true, results });
  } catch (err) {
    if (err.message?.startsWith('Unknown template')) return res.status(400).json({ error: err.message });
    if (err.message?.includes('ROUTER_URL not set')) return res.status(503).json({ error: 'Email delivery not configured. Set ROUTER_URL.' });
    next(err);
  }
});

// ═══════════════════════════════════════════════════════════════════════════════
// COMMAND CENTER — PLATFORM INTELLIGENCE
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/cc/platform-metrics', verifyAdmin, requireSuperAdmin, async (req, res, next) => {
  try {
    const now = new Date(), d30 = new Date(now - 30*86400000), d7 = new Date(now - 7*86400000);

    const [eventsPerDay, messagesPerDay, eventsByStatus, withPolls, withFiles, withEnterprise, withSeating] = await Promise.all([
      Event.aggregate([{ $match:{ createdAt:{ $gte:d30 } } },{ $group:{ _id:{ $dateToString:{ format:'%Y-%m-%d', date:'$createdAt' } }, count:{ $sum:1 } } },{ $sort:{ _id:1 } }]),
      Message.aggregate([{ $match:{ createdAt:{ $gte:d7 }, isDeleted:false } },{ $group:{ _id:{ $dateToString:{ format:'%Y-%m-%d', date:'$createdAt' } }, count:{ $sum:1 } } },{ $sort:{ _id:1 } }]),
      Event.aggregate([{ $group:{ _id:'$status', count:{ $sum:1 } } }]),
      Poll.distinct('eventId').then(ids => ids.length).catch(() => 0),
      File.distinct('eventId').then(ids => ids.length).catch(() => 0),
      Event.countDocuments({ isEnterpriseMode:true }),
      Event.countDocuments({ 'settings.seatingEnabled':true }),
    ]);

    const totalEvents = await Event.countDocuments();
    const mao         = await Event.distinct('organizerEmail', { createdAt:{ $gte:d30 } });
    const newOrgsThisWeek = await Event.distinct('organizerEmail', { createdAt:{ $gte:d7 } });
    const newOrgsLastWeek = await Event.distinct('organizerEmail', { createdAt:{ $gte:new Date(now-14*86400000), $lt:d7 } });

    const eventsWithParticipants = await Event.countDocuments({ 'participants.0':{ $exists:true } });
    const checkedInEvents = await EventParticipant.distinct('eventId', { checkedIn:true }).then(ids => ids.length).catch(() => 0);
    const completedEvents = await Event.countDocuments({ status:'completed' });

    const powerUsers = await Event.aggregate([
      { $group:{ _id:'$organizerEmail', name:{ $last:'$organizerName' }, events:{ $sum:1 }, lastActive:{ $max:'$createdAt' } } },
      { $sort:{ events:-1 } },{ $limit:10 },
    ]);

    const adopt = n => totalEvents > 0 ? Math.round((n/totalEvents)*100) : 0;
    res.json({
      eventsPerDay, messagesPerDay, eventsByStatus,
      maoCount: mao.length,
      newOrgsThisWeek: newOrgsThisWeek.length,
      newOrgsLastWeek: newOrgsLastWeek.length,
      featureAdoption: {
        polls:      { count:withPolls,      pct:adopt(withPolls) },
        files:      { count:withFiles,      pct:adopt(withFiles) },
        enterprise: { count:withEnterprise, pct:adopt(withEnterprise) },
        seating:    { count:withSeating,    pct:adopt(withSeating) },
      },
      conversionFunnel: { created:totalEvents, hasParticipants:eventsWithParticipants, hadCheckin:checkedInEvents, completed:completedEvents },
      powerUsers,
      generatedAt: new Date().toISOString(),
    });
  } catch(err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// COMMAND CENTER — SECURITY INTELLIGENCE
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/cc/security-intel', verifyAdmin, requireSuperAdmin, async (req, res, next) => {
  try {
    const logs = global.__adminLogBuffer || [];
    const now  = Date.now();

    const failedLogins = logs.filter(e => e.level==='error' && (e.msg.includes('Invalid credentials')||e.msg.includes('401'))).slice(-50).map(e => ({ ts:e.ts, msg:e.msg.slice(0,120) }));
    const rateLimitHits = logs.filter(e => e.msg.toLowerCase().includes('rate')||e.msg.includes('429')).slice(-30).map(e => ({ ts:e.ts, msg:e.msg.slice(0,120) }));
    const errLast1h  = logs.filter(e => e.level==='error' && new Date(e.ts) > new Date(now-3600000)).length;
    const errLast24h = logs.filter(e => e.level==='error' && new Date(e.ts) > new Date(now-86400000)).length;
    const errSpike   = errLast1h > (errLast24h/24)*3;

    const suspiciousParticipants = await EventParticipant.aggregate([
      { $match:{ joinedAt:{ $gte:new Date(now-86400000) }, role:{ $ne:'staff' } } },
      { $group:{ _id:'$username', count:{ $sum:1 } } },
      { $match:{ count:{ $gte:5 } } },
      { $sort:{ count:-1 } },{ $limit:20 },
    ]);

    const largeFiles = await File.find({ isDeleted:false }).sort({ size:-1 }).limit(10).select('name size eventId uploadedAt').lean();

    const busyEvents = await Event.find({ 'participants.10':{ $exists:true } })
      .select('title subdomain participants status createdAt organizerEmail').sort({ createdAt:-1 }).limit(10).lean()
      .then(evs => evs.map(e => ({ ...e, participantCount:e.participants?.length||0, participants:undefined })));

    const errorPatterns = {};
    logs.filter(e => e.level==='error').slice(-300).forEach(e => {
      const k = e.msg.slice(0,60); errorPatterns[k] = (errorPatterns[k]||0)+1;
    });
    const topErrors = Object.entries(errorPatterns).map(([msg,count]) => ({ msg,count })).sort((a,b) => b.count-a.count).slice(0,10);

    res.json({ failedLogins, rateLimitHits, errLast1h, errLast24h, errSpike, suspiciousParticipants, largeFiles, busyEvents, topErrors, generatedAt:new Date().toISOString() });
  } catch(err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// COMMAND CENTER — RUNTIME / WS / REDIS / CONFIG
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/cc/ws-stats', verifyAdmin, requireSuperAdmin, async (req, res, next) => {
  try {
    let wsStats = { connected:0, rooms:0, note:'socket not accessible' };
    try {
      const { io } = require('../server');
      if (io) {
        const sockets = await io.fetchSockets();
        const rooms   = io.sockets.adapter.rooms;
        wsStats = { connected:sockets.length, rooms:rooms?rooms.size:0, note:'live' };
      }
    } catch {}

    const redis = require('../services/redisClient');
    let redisHealth = { mode:redis.isRedis?'upstash':'in-memory', connected:redis.isRedis };
    if (redis.isRedis) {
      const t0 = Date.now();
      try { await redis.set('cc:ping','1',10); redisHealth.pingMs = Date.now()-t0; redisHealth.pingOk = (await redis.get('cc:ping'))==='1'; }
      catch { redisHealth.pingOk = false; }
    }

    const config = [
      { label:'MongoDB URI',          set:!!process.env.MONGODB_URI },
      { label:'JWT / License Key',    set:!!(process.env.JWT_SECRET||process.env.PLANIT_LICENSE_KEY) },
      { label:'Router URL',           set:!!process.env.ROUTER_URL },
      { label:'Cloudinary',           set:!!process.env.CLOUDINARY_CLOUD_NAME },
      { label:'Upstash Redis',        set:!!(process.env.UPSTASH_REDIS_URL&&process.env.UPSTASH_REDIS_TOKEN) },
      { label:'Admin Credentials',    set:!!process.env.ADMIN_USERNAME },
      { label:'CORS Origin',          set:!!process.env.CORS_ORIGIN },
      { label:'Frontend URL',         set:!!process.env.FRONTEND_URL },
      { label:'Hunter.io',            set:!!process.env.HUNTER_API_KEY },
      { label:'Google CSE',           set:!!(process.env.GOOGLE_CSE_KEY&&process.env.GOOGLE_CSE_CX) },
      { label:'Watchdog URL',         set:!!process.env.WATCHDOG_URL },
    ];
    const configScore = Math.round((config.filter(c=>c.set).length/config.length)*100);

    const mem = process.memoryUsage();
    res.json({
      wsStats, redisHealth, config, configScore,
      process: {
        uptime:   Math.floor(process.uptime()), pid:process.pid, node:process.version,
        memMB:    { rss:+(mem.rss/1048576).toFixed(1), heapUsed:+(mem.heapUsed/1048576).toFixed(1), heapTotal:+(mem.heapTotal/1048576).toFixed(1) },
        cpuCount: os.cpus().length, loadAvg:os.loadavg().map(l=>+l.toFixed(2)),
        freeMemMB:+(os.freemem()/1048576).toFixed(0), totalMemMB:+(os.totalmem()/1048576).toFixed(0),
      },
      generatedAt: new Date().toISOString(),
    });
  } catch(err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// COMMAND CENTER — EVENT INTELLIGENCE
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/cc/event-intel', verifyAdmin, requireSuperAdmin, async (req, res, next) => {
  try {
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const pastEvents = await Event.find({ date:{ $lt:now }, status:{ $nin:['completed','cancelled'] } })
      .select('title subdomain organizerEmail date participants status createdAt').limit(50).lean();
    const pastIds = pastEvents.map(e => e._id);
    const checkedInIds = await EventParticipant.distinct('eventId', { eventId:{ $in:pastIds }, checkedIn:true }).catch(() => []);
    const checkedSet   = new Set(checkedInIds.map(String));
    const abandonedEvents = pastEvents.filter(e => !checkedSet.has(String(e._id)))
      .map(e => ({ ...e, participantCount:e.participants?.length||0, participants:undefined }));

    const activeEvents = await Event.find({ status:'active' }).select('title subdomain date participants').limit(20).lean();
    const activeVelocity = await Promise.all(activeEvents.map(async evt => {
      const last5  = new Date(now-5*60000);
      const [total, recent] = await Promise.all([
        EventParticipant.countDocuments({ eventId:evt._id, checkedIn:true }).catch(() => 0),
        EventParticipant.countDocuments({ eventId:evt._id, checkedIn:true, checkedInAt:{ $gte:last5 } }).catch(() => 0),
      ]);
      return { id:evt._id, title:evt.title, subdomain:evt.subdomain, total:evt.participants?.length||0, checkedIn:total, last5min:recent, pct:evt.participants?.length>0?Math.round((total/evt.participants.length)*100):0 };
    }));

    const cleanupTarget = new Date(now-7*86400000);
    const cleanupCandidates = await Event.find({ status:'completed', updatedAt:{ $lt:cleanupTarget } })
      .select('title subdomain date organizerEmail updatedAt').limit(30).lean();

    const [todayCount, ystdCount] = await Promise.all([
      Event.countDocuments({ createdAt:{ $gte:todayStart } }),
      Event.countDocuments({ createdAt:{ $gte:new Date(todayStart-86400000), $lt:todayStart } }),
    ]);

    res.json({ abandonedEvents, activeVelocity, cleanupCandidates, todayCount, ystdCount, generatedAt:new Date().toISOString() });
  } catch(err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// COMMAND CENTER — GLOBAL SEARCH
// ═══════════════════════════════════════════════════════════════════════════════
router.get('/cc/global-search', verifyAdmin, requireSuperAdmin, async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) return res.status(400).json({ error: 'Query must be at least 2 characters' });
    const rx = { $regex:q, $options:'i' };
    const [participants, events, organizers] = await Promise.all([
      EventParticipant.find({ $or:[{ username:rx }] }).select('-password').sort({ joinedAt:-1 }).limit(30).lean(),
      Event.find({ $or:[{ title:rx },{ subdomain:rx },{ organizerEmail:rx },{ organizerName:rx }] })
        .select('title subdomain organizerName organizerEmail status date participants').limit(20).lean(),
      Event.aggregate([{ $match:{ organizerEmail:rx } },{ $group:{ _id:'$organizerEmail', name:{ $last:'$organizerName' }, events:{ $sum:1 } } },{ $limit:10 }]),
    ]);
    const eIds = [...new Set(participants.map(p => p.eventId?.toString()))];
    const eMap = await Event.find({ _id:{ $in:eIds } }).select('title subdomain').lean()
      .then(evs => Object.fromEntries(evs.map(e => [e._id.toString(), e])));
    const enriched = participants.map(p => ({ ...p, eventTitle:eMap[p.eventId?.toString()]?.title||'', eventSubdomain:eMap[p.eventId?.toString()]?.subdomain||'' }));
    res.json({
      participants: enriched,
      events: events.map(e => ({ ...e, participantCount:e.participants?.length||0, participants:undefined })),
      organizers,
      total: enriched.length+events.length+organizers.length,
    });
  } catch(err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// COMMAND CENTER — BULK EVENT OPS
// ═══════════════════════════════════════════════════════════════════════════════
router.post('/cc/bulk-events', verifyAdmin, requireSuperAdmin, async (req, res, next) => {
  try {
    const { action, filter = {} } = req.body;
    if (!action) return res.status(400).json({ error: 'action required' });
    let result = {};
    if (action === 'force-complete-old') {
      const cutoff = new Date(Date.now()-(parseInt(filter.days)||7)*86400000);
      const r = await Event.updateMany({ date:{ $lt:cutoff }, status:{ $in:['active','draft'] } }, { $set:{ status:'completed' } });
      result = { modified:r.modifiedCount };
    } else if (action === 'delete-empty-drafts') {
      const cutoff = new Date(Date.now()-(parseInt(filter.days)||3)*86400000);
      const targets = await Event.find({ status:'draft', createdAt:{ $lt:cutoff }, 'participants.0':{ $exists:false } }).select('_id').lean();
      const ids = targets.map(e => e._id);
      if (ids.length) await Promise.all([Event.deleteMany({ _id:{ $in:ids } }), Message.deleteMany({ eventId:{ $in:ids } }), Poll.deleteMany({ eventId:{ $in:ids } }), EventParticipant.deleteMany({ eventId:{ $in:ids } })]);
      result = { deleted:ids.length };
    } else if (action === 'cancel-abandoned') {
      const cutoff = new Date(Date.now()-86400000);
      const past   = await Event.find({ date:{ $lt:cutoff }, status:'active' }).select('_id').lean();
      const ids    = past.map(e => e._id);
      const withCI = await EventParticipant.distinct('eventId', { eventId:{ $in:ids }, checkedIn:true });
      const toCancel = ids.filter(id => !withCI.map(String).includes(String(id)));
      if (toCancel.length) await Event.updateMany({ _id:{ $in:toCancel } }, { $set:{ status:'cancelled' } });
      result = { cancelled:toCancel.length };
    } else { return res.status(400).json({ error:`Unknown action: ${action}` }); }
    res.json({ ok:true, result:{ ...result, action } });
  } catch(err) { next(err); }
});

// ─── Blocklist routes ──────────────────────────────────────────────────────────

// GET /admin/blocklist — list all entries, optional ?type= filter
router.get('/blocklist', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.type) filter.type = req.query.type;
    const entries = await Blocklist.find(filter).sort({ createdAt: -1 }).lean();
    res.json({ entries });
  } catch (err) { next(err); }
});

// POST /admin/blocklist — add an entry
// body: { type, value, reason?, permanent?, expiresAt? }
router.post('/blocklist', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const { type, value, reason = '', permanent = true, expiresAt = null } = req.body;
    if (!type || !['ip', 'event', 'name'].includes(type))
      return res.status(400).json({ error: 'type must be ip, event, or name' });
    if (!value || !value.trim())
      return res.status(400).json({ error: 'value is required' });

    // Prevent duplicates
    const existing = await Blocklist.findOne({ type, value: value.trim() });
    if (existing) return res.status(409).json({ error: 'Entry already exists', entry: existing });

    const entry = await Blocklist.create({
      type,
      value:     value.trim(),
      reason:    reason.trim(),
      permanent: permanent && !expiresAt,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
      addedBy:   req.admin?.username || 'admin',
    });

    // Also write to Redis so the in-memory / Redis ban check catches it immediately
    // without waiting for the next DB query (which has a try/catch that can fail)
    if (type === 'ip') {
      const ttl = expiresAt ? Math.floor((new Date(expiresAt) - Date.now()) / 1000) : 0;
      if (ttl > 0) {
        await redis.set(`sec:ban:${value.trim()}`, '1', ttl);
      } else if (!expiresAt) {
        // Permanent — write with very long TTL (10 years) so Redis also catches it
        await redis.set(`sec:ban:${value.trim()}`, '1', 60 * 60 * 24 * 365 * 10);
      }
    }

    res.status(201).json({ entry });
  } catch (err) { next(err); }
});

// DELETE /admin/blocklist/:id — remove an entry
router.delete('/blocklist/:id', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const entry = await Blocklist.findByIdAndDelete(req.params.id).lean();
    if (!entry) return res.status(404).json({ error: 'Not found' });
    // Also remove from Redis if it was an IP ban
    if (entry.type === 'ip') {
      await redis.del(`sec:ban:${entry.value}`);
    }
    res.json({ ok: true, entry });
  } catch (err) { next(err); }
});

// GET /admin/security/bans — list all IPs currently banned by trafficGuard
// Returns bans from Redis (sec:ban:*) plus the in-memory fallback map.
// Does NOT include permanent MongoDB blocklist entries — those live under /blocklist.
router.get('/security/bans', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const bans = await listActiveBans();
    res.json({ bans, total: bans.length });
  } catch (err) { next(err); }
});

// POST /admin/security/unban — instantly clear a trafficGuard ban + warn counter
// for an IP without waiting for the Redis TTL. Useful when a watchdog IP or
// a legitimate admin accidentally gets banned.
router.post('/security/unban', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const { ip } = req.body;
    if (!ip || typeof ip !== 'string' || ip.length > 100) {
      return res.status(400).json({ error: 'ip required' });
    }
    const result = await unbanIp(ip.trim());
    audit('security_unban', {
      req,
      actor: { employeeId: req.user?.employeeId, email: req.user?.email, role: req.user?.role },
      details: { ip: ip.trim(), operator: realIp(req) },
    });
    res.json(result);
  } catch (err) { next(err); }
});

// PATCH /admin/blocklist/:id — update reason or expiry
router.patch('/blocklist/:id', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const allowed = ['reason', 'expiresAt', 'permanent'];
    const updates = {};
    for (const key of allowed) {
      if (req.body[key] !== undefined) updates[key] = req.body[key];
    }
    if (updates.expiresAt !== undefined) {
      updates.expiresAt = updates.expiresAt ? new Date(updates.expiresAt) : null;
      updates.permanent = !updates.expiresAt;
    }
    const entry = await Blocklist.findByIdAndUpdate(req.params.id, { $set: updates }, { new: true }).lean();
    if (!entry) return res.status(404).json({ error: 'Not found' });
    res.json({ entry });
  } catch (err) { next(err); }
});

// ─── Maintenance mode ─────────────────────────────────────────────────────────
// Persists to the `mnt` collection (compressed schema) so state survives
// router/backend restarts without relying on env vars.
//
// t  types:   's' = scheduled | 'i' = incident | 'd' = degraded
// s  statuses:'upcoming' | 'active' | 'resolved'
//
// GET  /admin/maintenance         — current state (router + latest DB record)
// POST /admin/maintenance         — create/activate/resolve
// GET  /admin/maintenance/history — last 20 records

const Mnt = require('../models/Mnt');
const { meshPost: _meshPost } = require('../middleware/mesh');

// Helper: parse datetime-local string as local time (not UTC)
// datetime-local inputs return "YYYY-MM-DDTHH:mm" without timezone
// new Date() treats this as UTC, but we want local time interpretation
function parseLocalDateTime(str) {
  if (!str) return null;
  const match = str.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
  if (!match) return new Date(str); // fallback
  const [, y, m, d, hh, mm] = match;
  // Month is 0-indexed in JS Date
  return new Date(parseInt(y), parseInt(m) - 1, parseInt(d), parseInt(hh), parseInt(mm));
}

// Helper: push state to router in-memory cache via mesh
async function _syncRouter(payload) {
  const routerUrl = process.env.ROUTER_URL;
  if (!routerUrl) {
    console.warn('[maintenance] ROUTER_URL not set — router state not updated. Set ROUTER_URL on the backend to enable live sync.');
    return;
  }
  try {
    const result = await _meshPost(
      process.env.BACKEND_LABEL || 'Backend',
      `${routerUrl}/mesh/maintenance`,
      payload,
    );
    if (result?.ok === false) {
      console.warn('[maintenance] Router sync returned error:', result.error || result.status);
    } else {
      console.log(`[maintenance] Router synced → active=${payload.active}`);
    }
  } catch (err) {
    console.warn('[maintenance] Router sync failed (non-fatal):', err.message);
  }
}

// GET /admin/maintenance
router.get('/maintenance', verifyAdmin, async (req, res) => {
  try {
    const rec = await Mnt.findOne({ s: { $in: ['upcoming', 'active'] } }).sort({ ca: -1 }).lean();
    if (!rec) return res.json({ active: false, upcoming: false, type: null, message: '', eta: null, routerConfigured: !!process.env.ROUTER_URL });

    const active   = rec.s === 'active';
    const upcoming = rec.s === 'upcoming';
    res.json({
      active,
      upcoming,
      type:    rec.t,
      message: rec.msg  || '',
      eta:     rec.eta  || null,
      start:   rec.start || null,
      by:      rec.by   || 'admin',
      id:      rec._id,
      routerConfigured: !!process.env.ROUTER_URL,
    });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /admin/maintenance
// body: { action, type, message, eta, start }
//   action = 'activate'  — create + go live immediately
//   action = 'schedule'  — create as upcoming (banner only, no lockout)
//   action = 'resolve'   — mark current record resolved, clear router
router.post('/maintenance', verifyAdmin, requirePermission('canToggleMaintenance'), async (req, res) => {
  try {
    const { action, type = 's', message = '', eta, start } = req.body;
    const by = req.admin?.username || req.admin?.name || 'admin';

    if (action === 'resolve') {
      const result = await Mnt.updateMany({ s: { $in: ['upcoming','active'] } }, { $set: { s: 'resolved', end: new Date() } });
      console.log(`[maintenance] Resolve: updated ${result.modifiedCount} DB record(s) to resolved`);
      await _syncRouter({ active: false, upcoming: false, message: '', eta: null, type: null });
      return res.json({ ok: true, active: false, upcoming: false });
    }

    if (action === 'activate' || action === 'schedule') {
      // Resolve any existing active/upcoming first
      await Mnt.updateMany({ s: { $in: ['upcoming','active'] } }, { $set: { s: 'resolved', end: new Date() } });

      const status = action === 'schedule' ? 'upcoming' : 'active';
      const rec = await Mnt.create({
        t:     type,
        s:     status,
        msg:   (message || '').slice(0, 280),
        eta:   eta   ? parseLocalDateTime(eta)   : null,
        start: start ? parseLocalDateTime(start) : (action === 'activate' ? new Date() : null),
        by:    (by || 'admin').slice(0, 40),
        ca:    new Date(),
      });

      // Sync router: lock down on 'active', banner-only on 'upcoming'
      await _syncRouter({
        active:   status === 'active',
        upcoming: status === 'upcoming',
        message:  rec.msg,
        eta:      rec.eta ? rec.eta.toISOString() : null,
        type:     rec.t,
      });

      return res.json({
        ok: true,
        active:   status === 'active',
        upcoming: status === 'upcoming',
        type:     rec.t,
        message:  rec.msg,
        eta:      rec.eta || null,
        start:    rec.start || null,
        id:       rec._id,
      });
    }

    res.status(400).json({ error: 'action must be activate | schedule | resolve' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /admin/maintenance/history — last 20 records
router.get('/maintenance/history', verifyAdmin, async (req, res) => {
  try {
    const recs = await Mnt.find({}).sort({ ca: -1 }).limit(20).lean();
    res.json({ records: recs });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// ═══════════════════════════════════════════════════════════════════════════════
// SECURITY OPERATIONS CENTER
// ═══════════════════════════════════════════════════════════════════════════════

// SOC SSE client registry — receives security-filtered log events only.
// Set up once per process; idempotent via global flag.
if (!global.__socClients) {
  global.__socClients = [];
  // Tap into the main log broadcast pipe with a security filter so new events
  // are forwarded to connected SOC SSE clients with zero polling overhead.
  global.__adminLogClients.push((entry) => {
    const m = entry.msg || '';
    const relevant =
      m.includes('[honeypot]') || m.includes('[tarpit]') ||
      m.includes('[abuseipdb]') || m.includes('[trafficGuard]') ||
      (entry.level !== 'info' && (
        m.includes('bad UA') || m.includes('path fuzz') || m.includes('rapid:') ||
        m.includes('oversized') || m.includes('pre-ban') || m.includes('sec:ban')
      ));
    if (relevant) {
      global.__socClients.forEach(fn => { try { fn(entry); } catch {} });
    }
  });
}

function _isSecurityEntry(e) {
  const m = e.msg || '';
  return (
    m.includes('[honeypot]') || m.includes('[tarpit]') ||
    m.includes('[abuseipdb]') || m.includes('[trafficGuard]') ||
    (e.level !== 'info' && (
      m.includes('bad UA') || m.includes('path fuzz') || m.includes('rapid:') ||
      m.includes('oversized') || m.includes('pre-ban') || m.includes('sec:ban')
    ))
  );
}

function _tagEntry(e) {
  const m = e.msg || '';
  if (m.includes('[honeypot]'))     return 'honeypot';
  if (m.includes('[tarpit]'))       return 'tarpit';
  if (m.includes('[abuseipdb]'))    return 'abuseipdb';
  if (m.includes('[trafficGuard]')) return 'trafficguard';
  return 'security';
}

// GET /admin/security/soc  —  aggregated SOC snapshot
router.get('/security/soc', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const logs = global.__adminLogBuffer || [];
    const now  = Date.now();
    const h24  = now - 86400000;

    const secLogs = logs.filter(_isSecurityEntry);
    const ts24    = (e) => new Date(e.ts).getTime() > h24;

    const honeypotHits24h   = secLogs.filter(e => e.msg.includes('[honeypot]') && e.msg.includes('HIT')       && ts24(e)).length;
    const honeypotHitsTotal = secLogs.filter(e => e.msg.includes('[honeypot]') && e.msg.includes('HIT')).length;
    const tarpit24h         = secLogs.filter(e => e.msg.includes('[tarpit]')                                   && ts24(e)).length;
    const abuseipdbBans24h  = secLogs.filter(e => e.msg.includes('[abuseipdb]') && e.msg.includes('Pre-ban')  && ts24(e)).length;
    const trafficBans24h    = secLogs.filter(e => e.msg.includes('[trafficGuard]') && e.msg.includes('BAN')   && ts24(e)).length;
    const threatsBlocked24h = honeypotHits24h + abuseipdbBans24h + trafficBans24h;

    const bans = await listActiveBans();

    // AbuseIPDB daily quota counters from Redis
    const today = new Date().toISOString().slice(0, 10);
    let abuseipdbChecks = 0, abuseipdbReports = 0;
    try {
      const [ck, rk] = await Promise.all([
        redis.get(`abuseipdb:quota:check:${today}`).catch(() => null),
        redis.get(`abuseipdb:quota:report:${today}`).catch(() => null),
      ]);
      abuseipdbChecks  = parseInt(ck  || '0', 10);
      abuseipdbReports = parseInt(rk || '0', 10);
    } catch {}

    // Tarpit levels for currently-banned IPs (cap to 30 to avoid Redis fan-out)
    let tarpitLevels = {};
    try {
      const { getTarpitLevel } = require('../middleware/tarpit');
      const pairs = await Promise.all(
        bans.slice(0, 30).map(async b => [b.ip, await getTarpitLevel(b.ip).catch(() => 0)])
      );
      pairs.forEach(([ip, lv]) => { tarpitLevels[ip] = lv; });
    } catch {}

    const recentEvents = secLogs.slice(-150).reverse().map(e => ({
      ts:    e.ts,
      level: e.level,
      msg:   e.msg,
      tag:   _tagEntry(e),
    }));

    res.json({
      stats: {
        activeBans:          bans.length,
        honeypotHits24h,
        honeypotHitsTotal,
        tarpit24h,
        abuseipdbBans24h,
        trafficBans24h,
        threatsBlocked24h,
        abuseipdbChecks,
        abuseipdbReports,
        abuseipdbCheckLimit:  900,
        abuseipdbReportLimit: 900,
      },
      bans,
      tarpitLevels,
      recentEvents,
      generatedAt: new Date().toISOString(),
    });
  } catch (err) { next(err); }
});

// GET /admin/security/stream  —  SSE stream of security events only
router.get('/security/stream', verifyAdmin, requirePermission('canManageBlocklist'), (req, res) => {
  res.setHeader('Content-Type',  'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection',    'keep-alive');
  res.flushHeaders();

  // Replay the last 75 security events immediately so the client has context
  const logs = global.__adminLogBuffer || [];
  logs.filter(_isSecurityEntry).slice(-75).forEach(e =>
    res.write(`data: ${JSON.stringify({ ts: e.ts, level: e.level, msg: e.msg, tag: _tagEntry(e) })}\n\n`)
  );

  const send = (e) => {
    if (!res.destroyed)
      res.write(`data: ${JSON.stringify({ ts: e.ts, level: e.level, msg: e.msg, tag: _tagEntry(e) })}\n\n`);
  };
  global.__socClients.push(send);
  const hb = setInterval(() => { if (!res.destroyed) res.write(': heartbeat\n\n'); }, 20000);

  req.on('close', () => {
    clearInterval(hb);
    const i = global.__socClients.indexOf(send);
    if (i !== -1) global.__socClients.splice(i, 1);
  });
});

// POST /admin/security/ban  —  manual IP ban from SOC console
router.post('/security/ban', verifyAdmin, requirePermission('canManageBlocklist'), async (req, res, next) => {
  try {
    const { ip, reason = 'Manual ban (SOC)', minutes = 1440 } = req.body;
    if (!ip || typeof ip !== 'string' || ip.trim().length < 2 || ip.trim().length > 100) {
      return res.status(400).json({ error: 'ip required' });
    }
    const cleanIp = ip.trim();
    // Clamp duration: minimum 1 minute, maximum 30 days
    const ttl = Math.max(60, Math.min(parseInt(minutes, 10) || 1440, 43200) * 60);
    await redis.set(`sec:ban:${cleanIp}`, reason.slice(0, 200), ttl);
    console.warn(`[trafficGuard] SOC manual ban: ${cleanIp} — "${reason}" (${Math.round(ttl / 60)}m)`);
    audit('security_manual_ban', {
      req,
      actor: { employeeId: req.user?.employeeId, email: req.user?.email || req.user?.username, role: req.user?.role },
      details: { ip: cleanIp, reason, ttlSeconds: ttl, ttlMinutes: Math.round(ttl / 60) },
    });
    res.json({
      ok:        true,
      ip:        cleanIp,
      ttlSeconds: ttl,
      expiresAt: new Date(Date.now() + ttl * 1000).toISOString(),
    });
  } catch (err) { next(err); }
});

module.exports = router;
