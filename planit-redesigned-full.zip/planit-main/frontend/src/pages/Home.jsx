import { useState, useEffect, useRef, useCallback } from 'react';
import { getUserTimezone, localDateTimeToUTC, getTimezoneOptions, detectTimezone } from '../utils/timezoneUtils';
import { validateEmail } from '../utils/validators';
import { useNavigate, useLocation } from 'react-router-dom';
import PublicNav from '../components/ui/PublicNav';
import PublicFooter from '../components/ui/PublicFooter';
import {
  Calendar, Users, MessageSquare, BarChart3, FileText, Shield, Copy, Check, Lock,
  ArrowRight, Link, Eye, EyeOff, ChevronRight, Zap, Clock,
  CheckCircle2, TrendingUp, ListChecks, Timer,
  Brain, ArrowUpRight, AlertCircle, UtensilsCrossed, MapPin, QrCode, Layers, Search, CornerDownRight, Bot,
  Share2, Ticket, CheckSquare, X, Sparkles
} from 'lucide-react';
import { eventAPI } from '../services/api';
import { trackFeature, flushTracker } from '../services/tracker';
import { trackGAEvent } from '../services/analytics';
import RecoveryCodeModal from '../components/RecoveryCodeModal';
import toast from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { HomePreloader, HomeScrollChrome, HeroHeadline, ScrollFloat, MotionReveal, useSiteReady } from '../components/HomeMotion';
import { useWhiteLabel } from '../context/WhiteLabelContext';
import { SmoothScroll, PerfGovernor, Aurora, BlurText, SpotlightStage } from '../components/liquid/LiquidKit';
import { ZoomReveal, ScrollStory } from '../components/liquid/ScrollStory';
import { MEDIA } from '../content/media';

/*
PLANIT SOFTWARE LICENSE AGREEMENT
Copyright (c) 2026 Aakshat Hariharan. All rights reserved.

PLEASE READ THIS LICENSE AGREEMENT CAREFULLY BEFORE ACCESSING, VIEWING,
OR USING THIS SOFTWARE. BY ACCESSING THE REPOSITORY, VIEWING THE SOURCE
CODE, OR USING THE HOSTED SERVICE, YOU ACKNOWLEDGE THAT YOU HAVE READ
THIS AGREEMENT, UNDERSTAND IT, AND AGREE TO BE BOUND BY ITS TERMS. IF
YOU DO NOT AGREE TO THESE TERMS, YOU MUST IMMEDIATELY CEASE ALL ACCESS
TO AND USE OF THIS SOFTWARE.

================================================================================
SECTION 1 -- DEFINITIONS
================================================================================

1.1  "Software" means the PlanIt application in its entirety, including but
     not limited to all source code, object code, compiled binaries, scripts,
     configuration files, database schemas, API definitions, frontend
     components, backend services, routing infrastructure, watchdog services,
     documentation, design assets, visual layouts, user interface elements,
     architectural decisions, and all related materials made available in this
     repository or through the hosted service.

1.2  "Author" means Aakshat Hariharan, the sole creator and owner of the
     Software and all intellectual property rights therein.

1.3  "You" or "Licensee" means any individual, organization, company,
     partnership, or other legal entity that accesses, views, downloads,
     copies, or otherwise interacts with the Software or any portion thereof.

1.4  "Hosted Service" means the publicly accessible deployment of the
     Software operated by the Author at planitapp.onrender.com and any
     associated domains or subdomains.

1.5  "Derivative Work" means any work, software, product, service, or
     creation that is based on, derived from, substantially similar to,
     inspired by, or incorporates any portion of the Software, including
     works that replicate the design, architecture, functionality, or
     user experience of the Software in any form.

1.6  "Commercial Use" means any use of the Software or any portion thereof
     in connection with any activity intended to generate revenue, profit,
     or other financial or commercial benefit, whether directly or indirectly.

1.7  "Distribute" means to make available, publish, transmit, share,
     sublicense, sell, rent, lease, lend, or otherwise transfer the Software
     or any portion thereof to any third party by any means.

1.8  "Deploy" means to install, run, host, execute, or operate the Software
     or any portion thereof on any server, device, infrastructure, cloud
     platform, virtual machine, container, or computing environment.

================================================================================
SECTION 2 -- GRANT OF LIMITED LICENSE
================================================================================

2.1  Subject to the terms and conditions of this Agreement, the Author
     hereby grants You a limited, non-exclusive, non-transferable,
     non-sublicensable, revocable license to:

     (a) View the source code of the Software solely for personal,
         non-commercial educational and reference purposes; and

     (b) Access and use the Hosted Service for its intended purpose of
         event planning, subject to the Terms of Service of the Hosted
         Service.

2.2  This license does not grant You any rights to the Software except
     as expressly set forth in Section 2.1. All rights not expressly
     granted herein are reserved by the Author.

2.3  The Author reserves the right to revoke this limited license at any
     time, for any reason or no reason, upon notice or without notice.

2.4  Making the repository publicly accessible does not, under any
     circumstances, constitute a grant of any rights beyond those expressly
     set forth in Section 2.1, nor does it constitute a dedication of the
     Software to the public domain.

================================================================================
SECTION 3 -- RESTRICTIONS
================================================================================

3.1  You expressly agree that You will NOT, without prior explicit written
     permission from the Author:

     (a) Copy, clone, fork, mirror, scrape, or otherwise reproduce the
         Software or any portion thereof, in whole or in part, in any
         medium or format, whether digital or physical;

     (b) Deploy, host, run, or execute the Software or any portion thereof
         on any server, device, or infrastructure other than the Author's
         official Hosted Service;

     (c) Distribute, sublicense, sell, rent, lease, transfer, publish,
         or otherwise make the Software or any portion thereof available
         to any third party in any form;

     (d) Modify, adapt, translate, reverse engineer, decompile, disassemble,
         or attempt to derive the source code of any compiled portion of
         the Software;

     (e) Create any Derivative Work based on or substantially similar to
         the Software, including recreating its functionality, architecture,
         design, or user experience in any other codebase or product;

     (f) Use the Software or any portion of its source code, design,
         architecture, or functionality as the basis for any competing
         product or service, whether commercial or non-commercial;

     (g) Use the Software for any Commercial Use without a separately
         negotiated commercial license agreement executed in writing by
         the Author;

     (h) Remove, alter, obscure, or replace any copyright notices, license
         notices, proprietary markings, or attribution notices contained
         in or accompanying the Software;

     (i) Use the name "PlanIt", the PlanIt logo, or the name "Aakshat
         Hariharan" in connection with any product, service, or
         organization in a manner that suggests endorsement, affiliation,
         or sponsorship without prior written permission from the Author;

     (j) Use the Software in any manner that violates any applicable local,
         state, national, or international law or regulation;

     (k) Circumvent, disable, or interfere with any technical measures
         implemented in the Software to enforce the terms of this license,
         including but not limited to the cryptographic license integrity
         verification system embedded in the Software's backend;

     (l) Access the Software's backend services, APIs, or database
         infrastructure through any means other than the official Hosted
         Service's user interface, except as explicitly authorized by
         the Author in writing;

     (m) Use any automated tools, bots, scrapers, or scripts to access,
         download, or index the Software's source code or the Hosted
         Service's content at scale.

3.2  The restrictions set forth in Section 3.1 apply regardless of whether
     Your intended use is personal, educational, academic, commercial,
     non-profit, or for any other purpose.

3.3  The restrictions set forth in this Agreement apply to the Software
     as a whole and to any portion, excerpt, component, module, or file
     thereof, no matter how small.

================================================================================
SECTION 4 -- INTELLECTUAL PROPERTY OWNERSHIP
================================================================================

4.1  The Software and all copies, modifications, and Derivative Works
     thereof, and all intellectual property rights therein, including
     without limitation all copyrights, patents, trade secrets, trademarks,
     and other proprietary rights, are and shall remain the exclusive
     property of the Author.

4.2  Nothing in this Agreement shall be construed to transfer, assign, or
     convey to You any ownership interest in the Software or any intellectual
     property rights therein.

4.3  The design, architecture, visual appearance, user experience, and
     functionality of the Software are trade secrets and confidential
     information of the Author, and You agree to treat them as such.

4.4  Any feedback, suggestions, bug reports, or contributions You provide
     to the Author regarding the Software shall be the sole and exclusive
     property of the Author, and You hereby assign to the Author all
     rights in such feedback without any obligation of compensation or
     attribution to You.

4.5  You acknowledge that the Software embodies substantial creative effort
     and investment by the Author, and that unauthorized use or copying
     would cause irreparable harm to the Author for which monetary damages
     would be inadequate.

================================================================================
SECTION 5 -- TECHNICAL ENFORCEMENT
================================================================================

5.1  The Software includes a cryptographic license integrity verification
     system that runs at server startup and periodically during operation.
     This system uses HMAC proof chains derived from a deployment-specific
     license key to verify that each running instance of the Software is
     an authorized deployment.

5.2  Any attempt to tamper with, circumvent, disable, or bypass this
     verification system constitutes a material breach of this Agreement
     and may also constitute a violation of applicable computer fraud and
     abuse laws.

5.3  Unauthorized deployments will fail to start or will terminate
     automatically. The Author reserves the right to implement additional
     technical measures to prevent unauthorized use at any time.

================================================================================
SECTION 6 -- CONFIDENTIALITY
================================================================================

6.1  You acknowledge that the Software contains confidential and proprietary
     information belonging to the Author, including but not limited to
     source code, algorithms, data structures, database schemas, security
     implementations, and architectural design.

6.2  You agree to maintain the confidentiality of the Software and not to
     disclose, publish, or share any non-public portions of the Software
     with any third party without the Author's prior written consent.

6.3  You agree to take reasonable precautions to prevent unauthorized
     access to or disclosure of the Software, using at least the same
     degree of care You use to protect Your own confidential information,
     but in no event less than reasonable care.

================================================================================
SECTION 7 -- DISCLAIMER OF WARRANTIES
================================================================================

7.1  THE SOFTWARE AND THE HOSTED SERVICE ARE PROVIDED "AS IS" AND "AS
     AVAILABLE" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED.

7.2  THE AUTHOR EXPRESSLY DISCLAIMS ALL WARRANTIES, INCLUDING BUT NOT
     LIMITED TO: (A) ANY IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS
     FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT; (B) ANY
     WARRANTIES THAT THE SOFTWARE WILL BE UNINTERRUPTED, ERROR-FREE, OR
     FREE OF HARMFUL COMPONENTS; (C) ANY WARRANTIES REGARDING THE ACCURACY,
     RELIABILITY, OR COMPLETENESS OF THE SOFTWARE OR ANY CONTENT THEREIN;
     AND (D) ANY WARRANTIES ARISING FROM COURSE OF DEALING, COURSE OF
     PERFORMANCE, OR USAGE OF TRADE.

7.3  YOU ASSUME ALL RISK ARISING FROM YOUR ACCESS TO AND USE OF THE
     SOFTWARE AND THE HOSTED SERVICE.

================================================================================
SECTION 8 -- LIMITATION OF LIABILITY
================================================================================

8.1  TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, IN NO EVENT SHALL
     THE AUTHOR BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
     CONSEQUENTIAL, OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO LOSS
     OF PROFITS, LOSS OF DATA, LOSS OF GOODWILL, BUSINESS INTERRUPTION,
     OR ANY OTHER COMMERCIAL DAMAGES OR LOSSES, ARISING OUT OF OR RELATED
     TO THIS AGREEMENT OR YOUR USE OF OR INABILITY TO USE THE SOFTWARE,
     EVEN IF THE AUTHOR HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

8.2  THE AUTHOR'S TOTAL CUMULATIVE LIABILITY TO YOU FOR ANY AND ALL CLAIMS
     ARISING OUT OF OR RELATED TO THIS AGREEMENT SHALL NOT EXCEED THE
     GREATER OF (A) THE AMOUNT YOU PAID TO THE AUTHOR IN THE TWELVE MONTHS
     PRECEDING THE CLAIM, OR (B) ONE HUNDRED DOLLARS (USD $100.00).

================================================================================
SECTION 9 -- INDEMNIFICATION
================================================================================

9.1  You agree to indemnify, defend, and hold harmless the Author from and
     against any and all claims, damages, losses, liabilities, costs, and
     expenses (including reasonable attorneys' fees) arising out of or
     related to: (a) Your breach of this Agreement; (b) Your use of or
     access to the Software in violation of this Agreement; (c) Your
     violation of any applicable law or regulation; or (d) Your
     infringement of any third-party rights.

================================================================================
SECTION 10 -- TERMINATION
================================================================================

10.1 This Agreement and the license granted herein are effective until
     terminated. The Author may terminate this Agreement and the license
     immediately and without notice if You breach any term of this Agreement.

10.2 Upon termination of this Agreement for any reason: (a) all rights
     granted to You hereunder shall immediately terminate; (b) You must
     immediately cease all use of and access to the Software; (c) You must
     immediately destroy all copies of the Software in Your possession
     or control; and (d) You must certify in writing to the Author that
     You have complied with the foregoing obligations upon request.

10.3 Termination of this Agreement shall not limit the Author's rights
     or remedies at law or in equity. Sections 1, 3, 4, 6, 7, 8, 9,
     10, 11, and 12 shall survive termination of this Agreement.

================================================================================
SECTION 11 -- ENFORCEMENT AND REMEDIES
================================================================================

11.1 You acknowledge that any breach of this Agreement would cause
     irreparable harm to the Author for which monetary damages would be
     an inadequate remedy, and that the Author shall be entitled to seek
     equitable relief, including injunctive relief and specific performance,
     in addition to all other remedies available at law or in equity,
     without the requirement of posting a bond or other security.

11.2 The Author reserves the right to pursue all available legal and
     equitable remedies for violations of this Agreement, including but
     not limited to injunctive relief, damages, disgorgement of profits,
     attorneys' fees, and court costs.

11.3 The failure of the Author to enforce any provision of this Agreement
     shall not constitute a waiver of the Author's right to enforce that
     provision or any other provision in the future.

================================================================================
SECTION 12 -- GENERAL PROVISIONS
================================================================================

12.1 Governing Law. This Agreement shall be governed by and construed in
     accordance with the laws of the jurisdiction in which the Author
     resides, without regard to its conflict of law provisions.

12.2 Entire Agreement. This Agreement constitutes the entire agreement
     between You and the Author with respect to the subject matter hereof
     and supersedes all prior or contemporaneous agreements, representations,
     warranties, and understandings with respect to the Software.

12.3 Severability. If any provision of this Agreement is held to be
     invalid, illegal, or unenforceable, the remaining provisions shall
     continue in full force and effect, and the invalid, illegal, or
     unenforceable provision shall be modified to the minimum extent
     necessary to make it valid, legal, and enforceable.

12.4 No Waiver. No waiver by the Author of any breach of this Agreement
     shall be deemed a waiver of any subsequent breach of the same or any
     other provision.

12.5 Assignment. You may not assign or transfer this Agreement or any
     rights or obligations hereunder, in whole or in part, without the
     Author's prior written consent. Any purported assignment without such
     consent shall be null and void. The Author may assign this Agreement
     freely without restriction.

12.6 Contact. For licensing inquiries, permission requests, or to report
     violations of this Agreement, contact the Author through the official
     support page at planitapp.onrender.com or planit.userhelp@gmail.com

================================================================================

Copyright (c) 2026 Aakshat Hariharan. All rights reserved.
*/

// ─────────────────────────────────────────────────────────────────────────────
// GLOBAL STYLES, injected once
// ─────────────────────────────────────────────────────────────────────────────
const GLOBAL_CSS = `

  :root {
    --accent-1: #2f5bff;
    --accent-2: #5f84ff;
    --glow-1: rgba(47,91,255,0.18);
    --glow-2: rgba(95,132,255,0.12);
    --glow-3: rgba(251,146,60,0.16);
    --glow-4: rgba(236,72,153,0.14);
    --glow-5: rgba(45,212,191,0.14);
    --surface-glass: rgba(255,255,255,0.03);
    --border-subtle: rgba(255,255,255,0.06);
  }

  @keyframes shake {
    0%,100% { transform: translateX(0); }
    20%,60%  { transform: translateX(-6px); }
    40%,80%  { transform: translateX(6px); }
  }
  .animate-shake { animation: shake 0.45s ease-in-out; }
  @keyframes hero-word-in {
    0%   { opacity:0; transform: translateY(28px) skewY(3deg); filter: blur(6px); }
    100% { opacity:1; transform: translateY(0) skewY(0deg);   filter: blur(0);   }
  }
  @keyframes grid-pulse {
    0%,100% { opacity:0.018; }
    50%      { opacity:0.042; }
  }
  @keyframes cta-shimmer {
    0%   { background-position: -200% center; }
    100% { background-position:  200% center; }
  }
  @keyframes float-gentle {
    0%,100% { transform: translateY(0px); }
    50%     { transform: translateY(-8px); }
  }
  @keyframes scroll-indicator-bounce {
    0%,100% { opacity:0.3; transform:translateY(0); }
    50%     { opacity:0.7; transform:translateY(6px); }
  }
  @keyframes tick-in {
    0%   { opacity:0; transform:scale(0.6); }
    80%  { transform:scale(1.15); }
    100% { opacity:1; transform:scale(1); }
  }

  .font-syne    { font-family: var(--font-display); }
  .hero-word    { animation: hero-word-in 0.7s cubic-bezier(0.22,1,0.36,1) both; }
  .gradient-pop {
    background: linear-gradient(90deg, #5f84ff 0%, #f472b6 45%, #fb923c 100%);
    background-size: 200% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: cta-shimmer 5s linear infinite;
  }
  .cta-primary  {
    background: linear-gradient(135deg, #fff 0%, #e8e8f0 100%);
    background-size: 200% auto;
    transition: background-position 0.5s ease, transform 0.2s ease, box-shadow 0.3s ease;
  }
  .cta-primary:hover {
    background-position: right center;
    transform: translateY(-2px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.4), 0 0 30px rgba(47,91,255,0.15), 0 0 46px rgba(95,132,255,0.10);
  }
  .cta-venue {
    transition: transform 0.2s ease, box-shadow 0.3s ease, border-color 0.3s ease;
  }
  .cta-venue:hover {
    transform: translateY(-2px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.4), 0 0 30px rgba(249,115,22,0.12);
    border-color: rgba(249,115,22,0.6);
  }
  .branch-card {
    transition: transform 0.4s cubic-bezier(0.22,1,0.36,1), box-shadow 0.4s ease;
  }
  .branch-card:hover { transform: translateY(-4px); }
  .branch-card-events:hover { box-shadow: 0 30px 60px rgba(0,0,0,0.5), 0 0 60px rgba(47,91,255,0.08); }
  .branch-card-venue:hover  { box-shadow: 0 30px 60px rgba(0,0,0,0.5), 0 0 60px rgba(249,115,22,0.08); }
  .feature-card {
    transition: transform 0.3s ease, border-color 0.3s ease, box-shadow 0.3s ease;
    border: 1px solid rgba(255,255,255,0.05);
  }
  .feature-card:hover {
    transform: translateY(-3px);
    border-color: rgba(47,91,255,0.25);
    box-shadow: 0 16px 40px rgba(0,0,0,0.4), 0 0 24px rgba(47,91,255,0.07);
  }
  .hero-preview-shell {
    position:relative; overflow:hidden; border:1px solid rgba(255,255,255,0.12); border-radius:28px;
    background:linear-gradient(145deg, rgba(25,25,38,0.92), rgba(9,9,16,0.96));
    box-shadow:0 40px 100px rgba(0,0,0,0.44), 0 0 80px rgba(47,91,255,0.10);
    text-align:left; isolation:isolate;
  }
  .hero-preview-shell::before { content:''; position:absolute; inset:-35% 20% auto; height:260px; z-index:-1; background:radial-gradient(ellipse, rgba(47,91,255,0.18), transparent 68%); pointer-events:none; }
  .hero-preview-shell::after { content:''; position:absolute; inset:0; z-index:-1; opacity:0.35; background-image:radial-gradient(rgba(255,255,255,0.18) 0.8px, transparent 0.8px); background-size:18px 18px; mask-image:linear-gradient(to bottom, black, transparent 78%); pointer-events:none; }
  .hero-preview-chrome { display:flex; align-items:center; justify-content:space-between; gap:12px; padding:15px 18px; border-bottom:1px solid rgba(255,255,255,0.08); background:rgba(255,255,255,0.025); }
  .hero-preview-brand { display:flex; align-items:center; gap:9px; color:rgba(255,255,255,0.88); font-size:12px; font-weight:800; letter-spacing:-0.02em; }
  .hero-preview-brand-mark { width:24px; height:24px; display:grid; place-items:center; border-radius:7px; color:white; background:linear-gradient(135deg,#5f84ff,#1f43e6); box-shadow:0 4px 14px rgba(47,91,255,0.35); }
  .hero-preview-brand-mark svg { width:13px; height:13px; }
  .hero-preview-chrome-meta { display:flex; align-items:center; gap:7px; color:rgba(255,255,255,0.38); font-size:9px; }
  .hero-preview-live { display:inline-flex; align-items:center; gap:5px; color:#7ee4c1; font-weight:700; }
  .hero-preview-live i { width:5px; height:5px; display:block; border-radius:50%; background:#52d4a7; box-shadow:0 0 0 4px rgba(82,212,167,0.12); }
  .hero-preview-tabs { display:flex; align-items:center; gap:6px; padding:12px 18px 0; border-bottom:1px solid rgba(255,255,255,0.08); }
  .hero-preview-tab { position:relative; padding:9px 12px 12px; color:rgba(255,255,255,0.42); border:0; border-radius:9px 9px 0 0; background:transparent; cursor:pointer; font-size:11px; font-weight:700; transition:color .2s ease, background .2s ease; }
  .hero-preview-tab:hover { color:white; background:rgba(255,255,255,0.05); }
  .hero-preview-tab.active { color:white; }
  .hero-preview-tab.active::after { content:''; position:absolute; right:10px; bottom:-1px; left:10px; height:2px; border-radius:4px 4px 0 0; background:#5f84ff; box-shadow:0 0 12px rgba(95,132,255,0.65); }
  .hero-preview-body { display:grid; grid-template-columns:190px 1fr; min-height:318px; }
  .hero-preview-rail { padding:18px 12px; border-right:1px solid rgba(255,255,255,0.08); background:rgba(0,0,0,0.12); }
  .hero-preview-rail-label { margin:4px 7px 8px; color:rgba(255,255,255,0.28); font-size:8px; font-weight:800; letter-spacing:.14em; text-transform:uppercase; }
  .hero-preview-rail-item { display:flex; align-items:center; gap:8px; padding:9px 9px; margin:3px 0; border-radius:9px; color:rgba(255,255,255,0.46); font-size:10px; font-weight:650; transition:background .2s ease, color .2s ease; }
  .hero-preview-rail-item svg { width:13px; height:13px; }
  .hero-preview-rail-item.active { color:#d9d7ff; background:rgba(47,91,255,0.2); }
  .hero-preview-main { min-width:0; padding:24px; }
  .hero-preview-heading { display:flex; align-items:flex-start; justify-content:space-between; gap:18px; }
  .hero-preview-heading p { margin:0 0 5px; color:rgba(255,255,255,0.38); font-size:10px; font-weight:650; }
  .hero-preview-heading h3 { margin:0; color:white; font-size:20px; line-height:1.1; letter-spacing:-.05em; }
  .hero-preview-heading button { padding:8px 10px; border:1px solid rgba(255,255,255,0.13); border-radius:8px; color:rgba(255,255,255,0.7); background:rgba(255,255,255,0.05); cursor:pointer; font-size:9px; font-weight:700; }
  .hero-preview-summary { display:grid; grid-template-columns:1.1fr .9fr; gap:10px; margin-top:20px; }
  .hero-preview-card { padding:15px; border:1px solid rgba(255,255,255,0.09); border-radius:13px; background:rgba(255,255,255,0.045); }
  .hero-preview-card-label { display:flex; align-items:center; justify-content:space-between; color:rgba(255,255,255,0.46); font-size:9px; font-weight:700; }
  .hero-preview-card-label strong { color:rgba(255,255,255,0.8); font-size:10px; }
  .hero-preview-schedule { display:grid; grid-template-columns:38px 1fr; gap:9px; margin-top:13px; }
  .hero-preview-time { color:rgba(255,255,255,0.36); font-size:8px; font-weight:700; }
  .hero-preview-event { padding:0 0 12px 10px; border-left:2px solid #7770ff; }
  .hero-preview-event.teal { border-color:#39bf99; }
  .hero-preview-event strong { display:block; color:rgba(255,255,255,0.82); font-size:10px; }
  .hero-preview-event span { display:block; margin-top:3px; color:rgba(255,255,255,0.36); font-size:8px; }
  .hero-preview-number { margin:15px 0 5px; color:white; font-size:30px; line-height:1; font-weight:800; letter-spacing:-.07em; }
  .hero-preview-positive { display:flex; align-items:center; gap:4px; color:#77e0bf; font-size:8px; font-weight:700; }
  .hero-preview-positive svg { width:10px; height:10px; }
  .hero-preview-bottom { display:grid; grid-template-columns:1fr .9fr; gap:10px; margin-top:10px; }
  .hero-preview-check { display:flex; align-items:center; gap:7px; margin-top:10px; color:rgba(255,255,255,0.54); font-size:9px; }
  .hero-preview-check i { width:14px; height:14px; display:grid; place-items:center; border:1px solid rgba(82,212,167,0.5); border-radius:4px; color:#79e2c2; background:rgba(82,212,167,0.1); font-style:normal; }
  .hero-preview-check i svg { width:9px; height:9px; }
  .hero-preview-bars { height:58px; display:flex; align-items:end; gap:6px; margin-top:10px; }
  .hero-preview-bars span { flex:1; min-height:9px; border-radius:5px 5px 2px 2px; background:#22346f; }
  .hero-preview-bars span:nth-child(1) { height:22px; }.hero-preview-bars span:nth-child(2) { height:34px; }.hero-preview-bars span:nth-child(3) { height:28px; }.hero-preview-bars span:nth-child(4) { height:49px; background:#3f6bff; }.hero-preview-bars span:nth-child(5) { height:41px; }.hero-preview-bars span:nth-child(6) { height:55px; background:#90abff; }
  .hero-preview-guest-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:10px; margin-top:22px; }
  .hero-preview-guest-card strong { display:block; margin-top:8px; color:white; font-size:23px; letter-spacing:-.07em; }
  .hero-preview-guest-card span { color:rgba(255,255,255,0.4); font-size:8px; font-weight:700; }
  .hero-preview-guest-card em { display:block; margin-top:6px; color:#75dfbe; font-size:8px; font-style:normal; font-weight:700; }
  .hero-preview-guest-list { margin-top:10px; border:1px solid rgba(255,255,255,0.09); border-radius:12px; overflow:hidden; }
  .hero-preview-guest-row { display:grid; grid-template-columns:1.4fr .8fr .7fr; gap:8px; align-items:center; padding:10px 13px; border-bottom:1px solid rgba(255,255,255,0.07); color:rgba(255,255,255,0.52); font-size:9px; }
  .hero-preview-guest-row:last-child { border-bottom:0; }
  .hero-preview-person { display:flex; align-items:center; gap:7px; color:rgba(255,255,255,0.8); font-weight:700; }
  .hero-preview-person i { width:20px; height:20px; display:grid; place-items:center; border-radius:50%; color:white; background:#635bff; font-size:7px; font-style:normal; }
  .hero-preview-person i.green { background:#3bb591; }.hero-preview-person i.orange { background:#e98c70; }
  .hero-preview-status { width:max-content; padding:4px 6px; border-radius:5px; color:#7ce2c0; background:rgba(82,212,167,0.11); font-size:8px; font-weight:750; }
  .hero-preview-status.pending { color:#f2c276; background:rgba(240,177,84,0.12); }
  .hero-preview-insights { display:grid; grid-template-columns:1.1fr .9fr; gap:10px; margin-top:22px; }
  .hero-preview-chart { height:135px; margin-top:12px; border-bottom:1px solid rgba(255,255,255,0.14); background:repeating-linear-gradient(to bottom, transparent 0, transparent 31px, rgba(255,255,255,0.06) 32px); }
  .hero-preview-chart svg { width:100%; height:100%; overflow:visible; }
  .hero-preview-forecast { display:flex; flex-direction:column; justify-content:space-between; min-height:172px; background:linear-gradient(145deg,rgba(98,91,255,0.27),rgba(98,91,255,0.08)); }
  .hero-preview-forecast strong { margin-top:18px; color:white; font-size:34px; letter-spacing:-.08em; }
  .hero-preview-forecast p { margin:6px 0 0; color:rgba(222,219,255,0.68); font-size:9px; line-height:1.5; }
  .hero-preview-note { display:flex; align-items:center; gap:7px; margin-top:10px; padding:11px 13px; border:1px solid rgba(255,255,255,0.08); border-radius:10px; color:rgba(255,255,255,0.54); background:rgba(255,255,255,0.035); font-size:9px; font-weight:650; }
  .hero-preview-note svg { width:13px; height:13px; color:#857fff; }
  @media (max-width: 640px) {
    .hero-preview-body { grid-template-columns:82px 1fr; }
    .hero-preview-main { padding:15px 12px; }
    .hero-preview-rail { padding:14px 6px; }
    .hero-preview-rail-item { padding:8px 5px; font-size:8px; gap:5px; }
    .hero-preview-rail-label { margin-left:4px; font-size:7px; }
    .hero-preview-summary, .hero-preview-bottom, .hero-preview-insights { grid-template-columns:1fr; }
    .hero-preview-heading h3 { font-size:16px; }
    .hero-preview-guest-grid { gap:6px; }
    .hero-preview-guest-card { padding:10px; }
    .hero-preview-guest-row { grid-template-columns:1.4fr .7fr .7fr; padding:8px 9px; font-size:8px; }
    .hero-preview-person { gap:4px; }
  }
  .stat-card {
    border: 1px solid rgba(255,255,255,0.06);
    transition: border-color 0.3s ease, box-shadow 0.3s ease, transform 0.3s ease;
  }
  .stat-card:hover {
    border-color: rgba(47,91,255,0.3);
    box-shadow: 0 8px 32px rgba(47,91,255,0.1);
    transform: translateY(-2px);
  }
  .shimmer-white {
    background: linear-gradient(90deg, #fff 0%, #90abff 50%, #fff 100%);
    background-size: 200% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: cta-shimmer 4s linear infinite;
  }
  .shimmer-slate {
    background: linear-gradient(90deg, #94a3b8 0%, #cbd5e1 50%, #94a3b8 100%);
    background-size: 200% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: cta-shimmer 4s linear infinite;
  }
  .typing-dot { animation: float-gentle 1.2s ease-in-out infinite; }
  .typing-dot:nth-child(2) { animation-delay: 0.2s; }
  .typing-dot:nth-child(3) { animation-delay: 0.4s; }
  .nav-link { position:relative; }
  .nav-link::after {
    content:''; position:absolute; bottom:-2px; left:50%; right:50%;
    height:1px; background:var(--accent-1);
    transition: left 0.3s ease, right 0.3s ease;
  }
  .nav-link:hover::after { left:10%; right:10%; }

  @keyframes wiz-overlay-in {
    from { opacity:0; }
    to   { opacity:1; }
  }
  /* ── Onboarding Wizard ─────────────────────────────────────────── */
  @keyframes spin {
    to { transform: rotate(360deg); }
  }
  @keyframes wiz-in-right {
    from { opacity:0; transform:translateX(36px); }
    to   { opacity:1; transform:translateX(0); }
  }
  @keyframes wiz-in-left {
    from { opacity:0; transform:translateX(-36px); }
    to   { opacity:1; transform:translateX(0); }
  }
  @keyframes wiz-q-in {
    from { opacity:0; transform:translateY(14px); }
    to   { opacity:1; transform:translateY(0); }
  }
  @keyframes wiz-pop {
    0%   { opacity:0; transform:scale(0.88); }
    70%  { transform:scale(1.04); }
    100% { opacity:1; transform:scale(1); }
  }
  @keyframes wiz-check {
    0%   { opacity:0; transform:scale(0.5) rotate(-15deg); }
    60%  { transform:scale(1.2) rotate(6deg); }
    100% { opacity:1; transform:scale(1) rotate(0deg); }
  }
  .wiz-forward  { animation: wiz-in-right 0.34s cubic-bezier(0.22,1,0.36,1) both; }
  .wiz-back     { animation: wiz-in-left  0.34s cubic-bezier(0.22,1,0.36,1) both; }
  .wiz-question { animation: wiz-q-in 0.4s cubic-bezier(0.22,1,0.36,1) both; }
  .wiz-card-pop { animation: wiz-pop 0.28s cubic-bezier(0.22,1,0.36,1) both; }
  .wiz-type-card {
    transition: transform 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    cursor: pointer;
  }
  .wiz-type-card:hover  { transform: translateY(-3px) scale(1.02); }
  .wiz-type-card.active { transform: translateY(-2px) scale(1.04); }
  .wiz-input {
    width:100%; background:rgba(10,10,20,0.7); border:1px solid rgba(255,255,255,0.1);
    border-radius:14px; color:#fff; font-size:16px; padding:14px 18px;
    outline:none; transition:border-color 0.2s ease, box-shadow 0.2s ease;
    font-family:'DM Sans',sans-serif;
  }
  .wiz-input::placeholder { color:rgba(255,255,255,0.25); }
  .wiz-input:focus { border-color:rgba(255,255,255,0.3); box-shadow:0 0 0 3px rgba(47,91,255,0.12); }
  .wiz-input.error { border-color:rgba(239,68,68,0.6); box-shadow:0 0 0 3px rgba(239,68,68,0.1); }
  .wiz-input-venue:focus { border-color:rgba(249,115,22,0.4); box-shadow:0 0 0 3px rgba(249,115,22,0.1); }
  .wiz-btn-next {
    background:#fff; color:#111; border:none; border-radius:14px;
    font-size:15px; font-weight:700; padding:14px 28px; cursor:pointer;
    transition:transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
    display:flex; align-items:center; gap:8px; white-space:nowrap;
  }
  .wiz-btn-next:hover:not(:disabled) { transform:translateY(-2px); box-shadow:0 12px 32px rgba(0,0,0,0.35); }
  .wiz-btn-next:disabled { opacity:0.45; cursor:not-allowed; }
  .wiz-btn-next.venue { background:#f97316; color:#fff; }
  .wiz-btn-next.venue:hover:not(:disabled) { background:#fb923c; box-shadow:0 12px 32px rgba(249,115,22,0.3); }
  .wiz-btn-back {
    background:transparent; color:rgba(255,255,255,0.4); border:1px solid rgba(255,255,255,0.1);
    border-radius:14px; font-size:14px; font-weight:600; padding:14px 20px; cursor:pointer;
    transition:color 0.2s ease, border-color 0.2s ease, background 0.2s ease;
    display:flex; align-items:center; gap:6px;
  }
  .wiz-btn-back:hover { color:rgba(255,255,255,0.8); border-color:rgba(255,255,255,0.25); background:rgba(255,255,255,0.04); }
  .wiz-pill {
    width:28px; height:6px; border-radius:99px;
    transition:background 0.3s ease, width 0.3s ease;
  }
  .wiz-select {
    width:100%; background:rgba(10,10,20,0.7); border:1px solid rgba(255,255,255,0.1);
    border-radius:14px; color:#fff; font-size:15px; padding:13px 18px;
    outline:none; appearance:none; cursor:pointer;
    font-family:'DM Sans',sans-serif;
    transition:border-color 0.2s ease;
  }
  .wiz-select:focus { border-color:rgba(255,255,255,0.3); }
  .dark-input {
    width:100%; background:rgba(10,10,20,0.7); border:1px solid rgba(255,255,255,0.1);
    border-radius:10px; color:#fff; font-size:14px; padding:11px 14px;
    outline:none; transition:border-color 0.2s ease;
    font-family:'DM Sans',sans-serif;
  }
  .dark-input::placeholder { color:rgba(255,255,255,0.25); }
  .dark-input:focus { border-color:rgba(255,255,255,0.28); }

  /* ── Icon micro-interactions ─────────────────────────────────────── */
  .feature-icon { transition: transform 0.5s cubic-bezier(0.22,1,0.36,1), background 0.5s ease; }
  .group:hover .feature-icon { transform: rotate(-8deg) scale(1.12); }
  .feature-icon svg { transition: transform 0.4s ease; }
  .group:hover .feature-icon svg { transform: scale(1.08); }

  /* ── Respect reduced-motion preference ───────────────────────────── */
  @media (prefers-reduced-motion: reduce) {
    *, *::before, *::after {
      animation-duration: 0.001ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.001ms !important;
      scroll-behavior: auto !important;
    }
  }
`;

function InjectGlobalCSS() {
  useEffect(() => {
    const id = 'planit-home-styles';
    if (!document.getElementById(id)) {
      const s = document.createElement('style'); s.id = id; s.textContent = GLOBAL_CSS;
      document.head.appendChild(s);
    }
    return () => { const el = document.getElementById(id); if (el) el.remove(); };
  }, []);
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// OPENING CINEMATIC, a movie-title-style entrance:
//   black → distant light → atmosphere/particles drift in → a multilingual
//   greeting montage that accelerates → a sudden stop to black → "PLANIT"
//   assembles from separated letters with a light sweep and particle
//   convergence → tagline → cinematic bloom → camera pullback → the panel
//   rises to reveal the real homepage underneath.
//
// Everything here is one coordinated requestAnimationFrame loop keyed to real
// elapsed time (never chained setTimeouts), and every visual is written
// straight to the DOM/canvas via refs, no React re-renders during playback.
// That's what keeps this smooth and identical on every run: every layer's
// look at any instant is a pure function of elapsed milliseconds, not of how
// many frames fired or how busy the main thread happened to be.
// ─────────────────────────────────────────────────────────────────────────────

// ── Easing ──────────────────────────────────────────────────────────────────
const clamp01 = t => (t < 0 ? 0 : t > 1 ? 1 : t);
const lerp = (a, b, t) => a + (b - a) * t;
const easeOutCubic = t => 1 - Math.pow(1 - t, 3);
const easeInCubic = t => t * t * t;
const easeInOutCubic = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
const easeInOutExpo = t => (t <= 0 ? 0 : t >= 1 ? 1 : t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2);

// ── The multilingual montage, reuses the greetings already established for
// this cinematic. Each gets its own restrained visual treatment so the
// montage reads as a system of variations, not a single repeated effect.
const CINEMATIC_WORDS = [
  { text: 'Hello',     variant: 'emerge',      dur: 700 },
  { text: 'Hola',      variant: 'horizontal',  dur: 450 },
  { text: 'Bonjour',   variant: 'tracking',    dur: 400 },
  { text: 'こんにちは',   variant: 'depthBlur',   dur: 350 },
  { text: '안녕하세요',   variant: 'converge',    dur: 300 },
  { text: 'Ciao',      variant: 'push',        dur: 250 },
  { text: 'Привет',    variant: 'directional', dur: 200 },
];

// ── Master timeline (ms from mount), computed once. Guidelines, tuned by
// feel, not rigid: total runtime lands around 8s.
function buildTimeline() {
  const DARK_END = 650;
  const ENV_END = 1650;
  const wordStarts = [];
  let acc = ENV_END;
  for (const w of CINEMATIC_WORDS) { wordStarts.push(acc); acc += w.dur; }
  const WORDS_END = acc;
  const SILENCE_END = WORDS_END + 400;
  const TITLE_START = SILENCE_END;
  const TITLE_LOCK = TITLE_START + 900;
  const SWEEP_END = TITLE_LOCK + 450;
  const TAGLINE_START = TITLE_LOCK + 100;
  const TAGLINE_END = TAGLINE_START + 700;
  const BLOOM_START = Math.max(SWEEP_END, TAGLINE_END);
  const BLOOM_END = BLOOM_START + 450;
  const PULLBACK_START = BLOOM_END;
  const PULLBACK_END = PULLBACK_START + 900;
  const PANEL_RISE_START = PULLBACK_START + 400;
  const PANEL_RISE_END = PANEL_RISE_START + 750;
  return {
    DARK_END, ENV_END, wordStarts, WORDS_END, SILENCE_END, TITLE_START, TITLE_LOCK,
    SWEEP_END, TAGLINE_START, TAGLINE_END, BLOOM_START, BLOOM_END,
    PULLBACK_START, PULLBACK_END, PANEL_RISE_START, PANEL_RISE_END,
    COMPLETE: PANEL_RISE_END,
  };
}
const TIMELINE = buildTimeline();

// Short, simplified timeline for prefers-reduced-motion, same beats, none of
// the camera/particle motion, much shorter.
function buildReducedTimeline() {
  const HELLO_END = 480;
  const MONTAGE_START = HELLO_END + 140;
  const WORD_DUR = 130;
  const MONTAGE_END = MONTAGE_START + WORD_DUR * (CINEMATIC_WORDS.length - 1);
  const SILENCE_END = MONTAGE_END + 160;
  const TITLE_START = SILENCE_END;
  const TITLE_END = TITLE_START + 420;
  const TAGLINE_START = TITLE_END + 120;
  const TAGLINE_END = TAGLINE_START + 360;
  const HOLD_END = TAGLINE_END + 200;
  const CLOSE_END = HOLD_END + 420;
  return { HELLO_END, MONTAGE_START, WORD_DUR, MONTAGE_END, SILENCE_END, TITLE_START, TITLE_END, TAGLINE_START, TAGLINE_END, HOLD_END, COMPLETE: CLOSE_END };
}
const REDUCED_TIMELINE = buildReducedTimeline();

// ── Per-word motion, each variant animates a different combination of
// opacity/translate/scale/blur/tracking, but every one follows the same
// enter → hold → exit shape, so the montage feels like one visual system.
function getWordFrame(variant, localT, slotDur) {
  const frame = { opacity: 1, tx: 0, ty: 0, scale: 1, blur: 0, tracking: 0, rotate: 0 };
  const fadeIn = Math.min(slotDur * 0.42, variant === 'emerge' ? 420 : variant === 'directional' ? 70 : 120);
  const fadeOut = Math.min(slotDur * 0.4, variant === 'emerge' ? 260 : variant === 'directional' ? 60 : 100);

  if (localT < fadeIn) {
    const e = easeOutCubic(clamp01(localT / fadeIn));
    switch (variant) {
      case 'emerge':
        frame.opacity = e; frame.scale = lerp(0.65, 1.04, e); frame.ty = lerp(28, -2, e); frame.blur = lerp(20, 0, e);
        break;
      case 'horizontal':
        frame.opacity = e; frame.tx = lerp(-32, 0, e);
        break;
      case 'tracking':
        frame.opacity = e; frame.tracking = lerp(0.55, 0, e);
        break;
      case 'depthBlur':
        frame.opacity = e; frame.ty = lerp(26, 0, e); frame.blur = lerp(11, 0, e);
        break;
      case 'converge':
        frame.opacity = e; frame.scale = lerp(0.72, 1, e); frame.rotate = lerp(3.5, 0, e);
        break;
      case 'push':
        frame.opacity = e; frame.scale = lerp(1.18, 1, e); frame.blur = lerp(3, 0, e);
        break;
      default: // directional
        frame.opacity = e; frame.tx = lerp(36, 0, e);
    }
    return frame;
  }

  if (localT > slotDur - fadeOut) {
    const e = easeInCubic(clamp01((localT - (slotDur - fadeOut)) / fadeOut));
    switch (variant) {
      case 'emerge':
        frame.opacity = 1 - e; frame.scale = lerp(1, 1.05, e); frame.ty = lerp(0, -14, e); frame.blur = lerp(0, 6, e);
        break;
      case 'horizontal':
        frame.opacity = 1 - e; frame.tx = lerp(0, 28, e);
        break;
      case 'tracking':
        frame.opacity = 1 - e; frame.tracking = lerp(0, 0.42, e);
        break;
      case 'depthBlur':
        frame.opacity = 1 - e; frame.ty = lerp(0, -20, e); frame.blur = lerp(0, 8, e);
        break;
      case 'converge':
        frame.opacity = 1 - e; frame.scale = lerp(1, 1.08, e); frame.rotate = lerp(0, -3, e);
        break;
      case 'push':
        frame.opacity = 1 - e; frame.scale = lerp(1, 0.92, e);
        break;
      default: // directional
        frame.opacity = 1 - e; frame.tx = lerp(0, -32, e);
    }
    return frame;
  }
  return frame; // steady hold
}

// ── Particle field, a small, deterministic set of soft points across three
// depth layers (background/midground/foreground). Foreground particles are
// larger and drift faster, which is what sells the "camera moving forward"
// illusion; background ones barely move. Drawn straight into one canvas
// inside the same master loop, no separate rAF, no React state.
function makeParticles(count) {
  const list = [];
  for (let i = 0; i < count; i++) {
    const layer = i < count * 0.45 ? 0 : i < count * 0.8 ? 1 : 2;
    list.push({
      layer,
      angle: Math.random() * Math.PI * 2,
      baseRadius: 0.14 + Math.random() * 0.34,
      phase: Math.random() * Math.PI * 2,
      driftSpeed: 0.14 + Math.random() * 0.22,
      size: layer === 0 ? 0.7 + Math.random() * 0.6 : layer === 1 ? 1.2 + Math.random() * 0.8 : 1.8 + Math.random() * 1.3,
      baseOpacity: layer === 0 ? 0.16 + Math.random() * 0.16 : layer === 1 ? 0.24 + Math.random() * 0.2 : 0.32 + Math.random() * 0.26,
      convergeJitterX: (Math.random() - 0.5) * 24,
      convergeJitterY: (Math.random() - 0.5) * 16,
      disperseAngle: Math.random() * Math.PI * 2,
      disperseRadius: 0.5 + Math.random() * 0.55,
    });
  }
  return list;
}

function drawParticles(ctx, W, H, elapsed, particles, activeCount) {
  ctx.clearRect(0, 0, W, H);
  const count = activeCount == null ? particles.length : activeCount;
  const cx = W / 2, cy = H * 0.46;
  const minDim = Math.min(W, H);
  const t = elapsed * 0.001;
  const { DARK_END, ENV_END, WORDS_END, SILENCE_END, TITLE_START, TITLE_LOCK, PULLBACK_START, PULLBACK_END, BLOOM_START, BLOOM_END } = TIMELINE;

  let speedMult = 1;
  if (elapsed >= ENV_END && elapsed < WORDS_END) speedMult = lerp(1, 2.4, clamp01((elapsed - ENV_END) / (WORDS_END - ENV_END)));
  else if (elapsed >= WORDS_END) speedMult = 2.4;

  let envelope = 0;
  if (elapsed < DARK_END) envelope = 0;
  else if (elapsed < ENV_END) envelope = easeOutCubic(clamp01((elapsed - DARK_END) / (ENV_END - DARK_END)));
  else if (elapsed < WORDS_END) envelope = 1;
  else if (elapsed < SILENCE_END) envelope = 1 - easeInCubic(clamp01((elapsed - WORDS_END) / (SILENCE_END - WORDS_END)));

  const convergeWindowStart = TITLE_START - 250;
  let convergeT = 0, convergeVisible = 0;
  if (elapsed >= convergeWindowStart && elapsed < PULLBACK_START) {
    convergeT = easeInOutCubic(clamp01((elapsed - convergeWindowStart) / (TITLE_LOCK - convergeWindowStart)));
    convergeVisible = lerp(0, 0.8, easeOutCubic(clamp01((elapsed - convergeWindowStart) / 500)));
  }
  let disperseT = 0;
  if (elapsed >= PULLBACK_START) disperseT = easeInOutCubic(clamp01((elapsed - PULLBACK_START) / (PULLBACK_END - PULLBACK_START)));

  const bloomBoost = (elapsed >= BLOOM_START && elapsed <= BLOOM_END)
    ? Math.sin(clamp01((elapsed - BLOOM_START) / (BLOOM_END - BLOOM_START)) * Math.PI) * 0.5
    : 0;

  const active = envelope > 0.003 || convergeT > 0 || disperseT > 0 || convergeVisible > 0;
  if (!active) return;

  for (let pi = 0; pi < count; pi++) {
    const pt = particles[pi];
    let x, y, opacity;
    if (convergeT > 0 || disperseT > 0) {
      const targetX = cx + pt.convergeJitterX;
      const targetY = cy + pt.convergeJitterY;
      const driftAngle = pt.angle + t * pt.driftSpeed * 0.06;
      const fromX = cx + Math.cos(driftAngle) * pt.baseRadius * minDim;
      const fromY = cy + Math.sin(driftAngle) * pt.baseRadius * minDim * 0.7;
      if (disperseT <= 0) {
        x = lerp(fromX, targetX, convergeT);
        y = lerp(fromY, targetY, convergeT);
        opacity = convergeVisible * pt.baseOpacity * 3 + bloomBoost * pt.baseOpacity;
      } else {
        const outX = cx + Math.cos(pt.disperseAngle) * pt.disperseRadius * minDim;
        const outY = cy + Math.sin(pt.disperseAngle) * pt.disperseRadius * minDim * 0.7;
        x = lerp(targetX, outX, disperseT);
        y = lerp(targetY, outY, disperseT);
        opacity = (1 - disperseT) * convergeVisible * pt.baseOpacity * 3;
      }
    } else {
      const driftAngle = pt.angle + t * pt.driftSpeed * 0.06 * speedMult;
      const depthFactor = pt.layer === 0 ? 0.5 : pt.layer === 1 ? 0.8 : 1.25;
      const r = pt.baseRadius * minDim * depthFactor;
      x = cx + Math.cos(driftAngle) * r + Math.sin(t * 0.3 + pt.phase) * 4 * depthFactor;
      y = cy + Math.sin(driftAngle) * r * 0.7 + Math.cos(t * 0.25 + pt.phase) * 3 * depthFactor;
      opacity = envelope * pt.baseOpacity * (1 + bloomBoost);
    }
    if (opacity <= 0.004) continue;
    ctx.beginPath();
    ctx.fillStyle = `rgba(255,255,255,${clamp01(opacity).toFixed(3)})`;
    ctx.arc(x, y, pt.size * (pt.layer === 2 ? 1.35 : 1), 0, Math.PI * 2);
    ctx.fill();
  }
}

const TITLE_LETTERS = Array.from('PLANIT');

// ── Device capability tiering, a cheap, one-time read of hardware signals
// (never sampled inside the render loop) used only to pick a rendering
// quality level. Three tiers keep this simple: HIGH gets the full particle
// count and a mildly higher canvas resolution, MEDIUM (the common laptop/
// tablet case, and the default for mobile) is the previous baseline, LOW is
// for weak/low-memory devices where the montage should still play but with
// noticeably less to draw per frame.
// Note: the environment layer's entrance no longer animates `filter: blur()`
// at all (see envWrapRef handling below), animating blur across a
// full-screen element every frame was the single most expensive thing this
// cinematic was doing, so it's gone rather than tiered.
const INTRO_QUALITY = {
  LOW:    { particles: 16, dpr: 1   },
  MEDIUM: { particles: 30, dpr: 1   },
  HIGH:   { particles: 54, dpr: 1.5 },
};
function detectIntroQuality() {
  if (typeof window === 'undefined') return 'MEDIUM';
  const isMobile = window.innerWidth < 768 || /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '');
  const cores = navigator.hardwareConcurrency || 4;
  const mem = navigator.deviceMemory; // undefined on many browsers, treat as unknown, not penalized
  if (isMobile) {
    if ((mem !== undefined && mem <= 3) || cores <= 3) return 'LOW';
    return 'MEDIUM';
  }
  if (cores >= 8 && (mem === undefined || mem >= 8)) return 'HIGH';
  if (cores <= 3 || (mem !== undefined && mem <= 3)) return 'LOW';
  return 'MEDIUM';
}

function IntroCinematic({ onComplete }) {
  const [reduced] = useState(
    () => typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
  );
  const [quality] = useState(detectIntroQuality);

  const panelRef = useRef(null);
  const lightRef = useRef(null);
  const envWrapRef = useRef(null);
  const canvasRef = useRef(null);
  const wordRef = useRef(null);
  const titleWrapRef = useRef(null);
  const letterRefs = useRef([]);
  const sweepRef = useRef(null);
  const taglineWrapRef = useRef(null);
  const line1Ref = useRef(null);
  const line2Ref = useRef(null);
  const bloomRef = useRef(null);

  const rafRef = useRef(null);
  const startRef = useRef(null);
  const doneRef = useRef(false);
  const particlesRef = useRef(null);

  const finish = (cb) => { if (!doneRef.current) { doneRef.current = true; cb?.(); } };

  // ── Reduced-motion path: short, simple opacity fades only. ────────────────
  useEffect(() => {
    if (!reduced) return;
    const T = REDUCED_TIMELINE;

    const onKey = (e) => { if (e.key === 'Escape') { cancelAnimationFrame(rafRef.current); finish(onComplete); } };
    window.addEventListener('keydown', onKey);

    const tick = (now) => {
      if (startRef.current == null) startRef.current = now;
      const elapsed = now - startRef.current;

      if (elapsed >= T.COMPLETE) { finish(onComplete); return; }

      // Word (Hello + montage), simple crossfade, no motion.
      let wIdx = -1, wOpacity = 0;
      if (elapsed < T.HELLO_END) { wIdx = 0; wOpacity = easeOutCubic(clamp01(elapsed / T.HELLO_END)); }
      else if (elapsed < T.MONTAGE_START) { wIdx = 0; wOpacity = 1 - clamp01((elapsed - (T.HELLO_END - 80)) / 80); }
      else if (elapsed < T.MONTAGE_END) {
        const rel = elapsed - T.MONTAGE_START;
        const i = Math.min(CINEMATIC_WORDS.length - 2, Math.floor(rel / T.WORD_DUR));
        wIdx = i + 1;
        const localT = rel - i * T.WORD_DUR;
        const p = clamp01(localT / T.WORD_DUR);
        wOpacity = Math.sin(p * Math.PI);
      }
      if (wordRef.current) {
        if (wIdx >= 0 && wordRef.current.dataset.idx !== String(wIdx)) {
          wordRef.current.textContent = CINEMATIC_WORDS[wIdx].text;
          wordRef.current.dataset.idx = String(wIdx);
        }
        wordRef.current.style.opacity = String(wIdx >= 0 ? wOpacity : 0);
      }

      // Title, plain fade, letters already together.
      if (titleWrapRef.current) {
        let op = 0;
        if (elapsed >= T.TITLE_START && elapsed < T.HOLD_END) {
          op = elapsed < T.TITLE_END
            ? easeOutCubic(clamp01((elapsed - T.TITLE_START) / (T.TITLE_END - T.TITLE_START)))
            : 1;
        } else if (elapsed >= T.HOLD_END) {
          op = Math.max(0, 1 - clamp01((elapsed - T.HOLD_END) / (T.COMPLETE - T.HOLD_END)));
        }
        titleWrapRef.current.style.opacity = String(op);
      }
      letterRefs.current.forEach(el => { if (el) el.style.transform = 'translateX(0px)'; });
      if (sweepRef.current) sweepRef.current.style.opacity = '0';

      // Tagline, plain fade.
      if (taglineWrapRef.current) {
        let op = 0;
        if (elapsed >= T.TAGLINE_START && elapsed < T.HOLD_END) {
          op = elapsed < T.TAGLINE_END
            ? easeOutCubic(clamp01((elapsed - T.TAGLINE_START) / (T.TAGLINE_END - T.TAGLINE_START)))
            : 1;
        } else if (elapsed >= T.HOLD_END) {
          op = Math.max(0, 1 - clamp01((elapsed - T.HOLD_END) / (T.COMPLETE - T.HOLD_END)));
        }
        taglineWrapRef.current.style.opacity = String(op);
      }

      // Panel, plain fade out (no slide, minimal motion).
      if (panelRef.current) {
        const fadeStart = T.HOLD_END;
        const op = elapsed >= fadeStart ? 1 - clamp01((elapsed - fadeStart) / (T.COMPLETE - fadeStart)) : 1;
        panelRef.current.style.opacity = String(op);
      }

      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(rafRef.current); window.removeEventListener('keydown', onKey); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced]);

  // ── Full cinematic path. ───────────────────────────────────────────────────
  useEffect(() => {
    if (reduced) return;
    const T = TIMELINE;
    const cfg = INTRO_QUALITY[quality];
    particlesRef.current = makeParticles(cfg.particles);
    // How many of those precomputed particles actually get drawn each frame.
    // Adaptive quality (below) can shrink this on a slow device without ever
    // reallocating the particle array, it just draws a shorter slice of it.
    let activeParticleCount = particlesRef.current.length;

    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    // DPR is capped (and only above 1 on the HIGH tier at all) so a
    // high-density phone screen never blows the canvas up to millions of
    // pixels, see cfg.dpr above.
    const effectiveDPR = Math.min(window.devicePixelRatio || 1, cfg.dpr);
    const resize = () => {
      if (!canvas) return;
      canvas.width = Math.round(window.innerWidth * effectiveDPR);
      canvas.height = Math.round(window.innerHeight * effectiveDPR);
    };
    resize();
    // Debounced, mobile browsers fire `resize` repeatedly as the address
    // bar hides/shows while scrolling; we don't want to touch the canvas
    // (or, if it ever needed to, regenerate particles) on every one of those.
    let resizeTimer = null;
    const onResize = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(resize, 150);
    };
    window.addEventListener('resize', onResize);

    const onKey = (e) => { if (e.key === 'Escape') { cancelAnimationFrame(rafRef.current); finish(onComplete); } };
    window.addEventListener('keydown', onKey);

    // ── Lightweight adaptive quality, a safety net, not the primary
    // strategy (the primary strategy is simply not doing expensive work in
    // the first place). If frame times are consistently poor we quietly
    // draw fewer particles; if they recover we restore. Hysteresis (500ms /
    // 1500ms) avoids flapping back and forth every other frame.
    let slowSince = null, goodSince = null, degraded = false, lastFrameTime = null;
    const minParticles = Math.ceil(particlesRef.current.length * 0.35);

    // Dev-only perf readout, never rendered to the DOM, just a console
    // marker so this is easy to sanity-check while working on it locally.
    const isDev = typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.DEV;
    let devFrames = 0, devTimeAcc = 0, devLastLog = 0;

    const tick = (now) => {
      if (startRef.current == null) startRef.current = now;
      const elapsed = now - startRef.current;
      const frameStart = isDev ? performance.now() : 0;

      if (elapsed >= T.COMPLETE) { finish(onComplete); return; }

      // Act 0, distant light point.
      if (lightRef.current) {
        const p = clamp01((elapsed - 80) / (T.DARK_END - 80));
        let opacity;
        if (elapsed < T.DARK_END) opacity = easeOutCubic(p) * 0.9;
        else opacity = Math.max(0, 0.9 * (1 - clamp01((elapsed - T.DARK_END) / 500)));
        const scale = lerp(0.4, 1, easeOutCubic(p));
        lightRef.current.style.opacity = String(opacity);
        lightRef.current.style.transform = `scale(${scale})`;
      }

      // Act 1, environment (grid + particle canvas wrapper) entrance / hold / fade to black.
      // Deliberately opacity + scale only, never `filter: blur()`, this
      // wrapper is full-screen (it contains the grid SVG *and* the particle
      // canvas), and animating blur across a full-screen element every
      // frame is one of the most expensive things a browser can be asked to
      // do. The zoom-in-from-1.08 alone reads as an atmospheric entrance
      // without paying that cost.
      if (envWrapRef.current) {
        let envOpacity, envScale;
        if (elapsed < T.DARK_END) { envOpacity = 0; envScale = 1.08; }
        else if (elapsed < T.ENV_END) {
          const p = easeOutCubic(clamp01((elapsed - T.DARK_END) / (T.ENV_END - T.DARK_END)));
          envOpacity = p; envScale = lerp(1.08, 1, p);
        } else if (elapsed < T.WORDS_END) {
          envOpacity = 1; envScale = 1;
        } else if (elapsed < T.SILENCE_END) {
          const p = easeInCubic(clamp01((elapsed - T.WORDS_END) / (T.SILENCE_END - T.WORDS_END)));
          envOpacity = lerp(1, 0, Math.min(p * 1.6, 1)); envScale = 1;
        } else {
          envOpacity = 0; envScale = 1;
        }
        envWrapRef.current.style.opacity = String(envOpacity);
        envWrapRef.current.style.transform = `scale(${envScale})`;
      }

      // Particle canvas, drawn every frame regardless of act; the function
      // itself figures out visibility from elapsed time. `activeParticleCount`
      // is the adaptive-quality lever: normally the full array, shrunk to a
      // slice of itself if frame times are struggling (see below).
      if (ctx && canvas) {
        drawParticles(ctx, canvas.width, canvas.height, elapsed, particlesRef.current, activeParticleCount);
      }

      // Acts 2–4, the word montage.
      if (wordRef.current) {
        if (elapsed < T.ENV_END) {
          wordRef.current.style.opacity = '0';
        } else if (elapsed < T.WORDS_END) {
          let idx = 0;
          for (let i = T.wordStarts.length - 1; i >= 0; i--) { if (elapsed >= T.wordStarts[i]) { idx = i; break; } }
          const word = CINEMATIC_WORDS[idx];
          const localT = elapsed - T.wordStarts[idx];
          const frame = getWordFrame(word.variant, localT, word.dur);
          if (wordRef.current.dataset.idx !== String(idx)) {
            wordRef.current.textContent = word.text;
            wordRef.current.dataset.idx = String(idx);
          }
          wordRef.current.style.opacity = String(clamp01(frame.opacity));
          wordRef.current.style.transform = `translate(${frame.tx}px, ${frame.ty}px) scale(${frame.scale}) rotate(${frame.rotate}deg)`;
          wordRef.current.style.filter = frame.blur > 0.05 ? `blur(${frame.blur}px)` : 'none';
          wordRef.current.style.letterSpacing = `${-0.02 + frame.tracking}em`;
        } else {
          wordRef.current.style.opacity = '0';
        }
      }

      // Act 5 (silence) needs no code of its own, the environment and word
      // layers above have already faded to nothing by T.SILENCE_END, and the
      // title below hasn't started yet, so the screen is genuinely black.

      // Act 6, PLANIT: letters separate → converge, wrapper blur/scale/opacity, then light sweep.
      if (titleWrapRef.current) {
        if (elapsed < T.TITLE_START) {
          titleWrapRef.current.style.opacity = '0';
          if (sweepRef.current) sweepRef.current.style.opacity = '0';
        } else if (elapsed < T.PULLBACK_START) {
          const p = clamp01((elapsed - T.TITLE_START) / (T.TITLE_LOCK - T.TITLE_START));
          const eIn = easeOutCubic(clamp01(p / 0.35));
          const eSpacing = easeInOutCubic(p);
          const wrapScale = p < 0.5 ? lerp(0.94, 1.02, easeOutCubic(p / 0.5)) : lerp(1.02, 1, easeOutCubic((p - 0.5) / 0.5));
          titleWrapRef.current.style.opacity = String(eIn);
          titleWrapRef.current.style.transform = `scale(${wrapScale})`;
          titleWrapRef.current.style.filter = eIn < 0.98 ? `blur(${lerp(5, 0, eIn)}px)` : 'none';

          const spacing = lerp(52, 2, eSpacing);
          const n = letterRefs.current.length;
          letterRefs.current.forEach((el, i) => { if (el) el.style.transform = `translateX(${(i - (n - 1) / 2) * spacing}px)`; });

          if (sweepRef.current) {
            if (elapsed >= T.TITLE_LOCK) {
              const sp = clamp01((elapsed - T.TITLE_LOCK) / (T.SWEEP_END - T.TITLE_LOCK));
              sweepRef.current.style.opacity = sp < 1 ? String(Math.sin(sp * Math.PI)) : '0';
              sweepRef.current.style.transform = `translateX(${lerp(-140, 340, sp)}%)`;
            } else {
              sweepRef.current.style.opacity = '0';
            }
          }
        } else {
          const pp = clamp01((elapsed - T.PULLBACK_START) / (T.PULLBACK_END - T.PULLBACK_START));
          titleWrapRef.current.style.opacity = String(1 - easeInCubic(pp));
          titleWrapRef.current.style.transform = `scale(${lerp(1, 1.08, pp)})`;
          titleWrapRef.current.style.filter = 'none';
          if (sweepRef.current) sweepRef.current.style.opacity = '0';
        }
      }

      // Act 7, tagline, two lines staggered slightly.
      if (line1Ref.current && line2Ref.current) {
        if (elapsed < T.PULLBACK_START) {
          [line1Ref.current, line2Ref.current].forEach((el, i) => {
            const localStart = T.TAGLINE_START + i * 140;
            if (elapsed < localStart) { el.style.opacity = '0'; el.style.transform = 'translateY(14px)'; return; }
            const dur = Math.max(T.TAGLINE_END - localStart, 1);
            const e = easeOutCubic(clamp01((elapsed - localStart) / dur));
            el.style.opacity = String(e);
            el.style.transform = `translateY(${lerp(14, 0, e)}px)`;
          });
        } else {
          const pp = clamp01((elapsed - T.PULLBACK_START) / (T.PULLBACK_END - T.PULLBACK_START));
          const op = Math.max(0, 1 - easeInCubic(pp) * 1.3);
          const ty = lerp(0, -10, pp);
          [line1Ref.current, line2Ref.current].forEach(el => { el.style.opacity = String(op); el.style.transform = `translateY(${ty}px)`; });
        }
      }

      // Act 8, cinematic bloom.
      if (bloomRef.current) {
        if (elapsed >= T.BLOOM_START && elapsed <= T.BLOOM_END) {
          const intensity = Math.sin(clamp01((elapsed - T.BLOOM_START) / (T.BLOOM_END - T.BLOOM_START)) * Math.PI);
          bloomRef.current.style.opacity = String(intensity * 0.55);
        } else {
          bloomRef.current.style.opacity = '0';
        }
      }

      // Acts 9–10, camera pullback is expressed above (env fade, title/tagline
      // recede); the panel itself rises last, overlapping the tail of pullback.
      if (panelRef.current) {
        if (elapsed >= T.PANEL_RISE_START) {
          const rp = easeInOutExpo(clamp01((elapsed - T.PANEL_RISE_START) / (T.PANEL_RISE_END - T.PANEL_RISE_START)));
          panelRef.current.style.transform = `translateY(${-100 * rp}%)`;
        }
      }

      // ── Adaptive quality check, cheap arithmetic on numbers we already
      // have, no allocations. A frame taking >22ms is roughly sub-45fps; if
      // that's sustained for ~500ms, draw fewer particles. Recovery needs a
      // longer, calmer window (1500ms under ~18ms/frame) before restoring,
      // so this doesn't flap.
      const frameMs = now - (lastFrameTime ?? now);
      lastFrameTime = now;
      if (frameMs > 22) {
        if (slowSince == null) slowSince = now;
        goodSince = null;
        if (!degraded && now - slowSince > 500) {
          degraded = true;
          activeParticleCount = minParticles;
        }
      } else if (frameMs < 18) {
        if (goodSince == null) goodSince = now;
        slowSince = null;
        if (degraded && now - goodSince > 1500) {
          degraded = false;
          activeParticleCount = particlesRef.current.length;
        }
      } else {
        slowSince = null; goodSince = null;
      }

      if (isDev) {
        devFrames++; devTimeAcc += performance.now() - frameStart;
        if (now - devLastLog > 1000) {
          devLastLog = now;
          // eslint-disable-next-line no-console
          console.debug(
            `[intro-cinematic] ~${Math.round(1000 / (devTimeAcc / devFrames || 1))}fps · ` +
            `${(devTimeAcc / devFrames).toFixed(2)}ms/frame · quality=${quality} · ` +
            `particles=${activeParticleCount}/${particlesRef.current.length}${degraded ? ' (degraded)' : ''}`
          );
          devFrames = 0; devTimeAcc = 0;
        }
      }

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(rafRef.current);
      clearTimeout(resizeTimer);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced, quality]);

  const titleTextStyle = {
    fontSize: 'clamp(2.75rem, 11vw, 7.5rem)', fontWeight: 700, color: '#fff',
    letterSpacing: '-0.01em', lineHeight: 1,
  };

  if (reduced) {
    return (
      <div ref={panelRef} className="fixed inset-0 flex items-center justify-center" style={{ background: '#050505', zIndex: 999 }}>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 20px' }}>
          <div ref={wordRef} style={{ fontSize: 'clamp(2.25rem, 9vw, 6rem)', fontWeight: 600, color: '#fff', letterSpacing: '-0.02em', opacity: 0 }}>Hello</div>
        </div>
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 20px' }}>
          <div ref={titleWrapRef} style={{ display: 'flex', opacity: 0 }}>
            {TITLE_LETTERS.map((ch, i) => (
              <span key={i} ref={el => { letterRefs.current[i] = el; }} style={{ ...titleTextStyle, display: 'inline-block' }}>{ch}</span>
            ))}
          </div>
          <div ref={taglineWrapRef} style={{ marginTop: '1.25rem', textAlign: 'center' }}>
            <div ref={line1Ref} style={{ fontSize: 'clamp(0.8rem,2.2vw,1rem)', fontWeight: 500, letterSpacing: '0.18em', color: 'rgba(255,255,255,0.72)' }}>PLAN SMART.</div>
            <div ref={line2Ref} style={{ fontSize: 'clamp(0.8rem,2.2vw,1rem)', fontWeight: 500, letterSpacing: '0.18em', color: 'rgba(255,255,255,0.72)' }}>EXECUTE FLAWLESSLY.</div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div ref={panelRef} className="fixed inset-0 overflow-hidden" style={{ background: '#04040a', zIndex: 999, willChange: 'transform' }}>
      {/* Act 1, environment: faint grid + soft depth particles. Only
          opacity/transform are ever written to this element's style, so
          that's all it's promoted for, no `filter` in will-change since
          nothing here animates it (see the tick loop above). */}
      <div ref={envWrapRef} aria-hidden="true" style={{ position: 'absolute', inset: 0, opacity: 0, willChange: 'opacity, transform' }}>
        <CinematicGrid />
        <canvas ref={canvasRef} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }} />
      </div>

      {/* Act 0, distant point of light */}
      <div
        ref={lightRef}
        aria-hidden="true"
        style={{
          position: 'absolute', left: '50%', top: '46%', width: 5, height: 5, marginLeft: -2.5, marginTop: -2.5,
          borderRadius: '50%', background: '#fff', opacity: 0,
          boxShadow: '0 0 3px 1px rgba(255,255,255,0.9), 0 0 46px 14px rgba(200,210,255,0.28)',
          willChange: 'transform, opacity',
        }}
      />

      {/* Cinematic vignette, always present, gives the frame depth */}
      <div aria-hidden="true" style={{ position: 'absolute', inset: 0, pointerEvents: 'none', background: 'radial-gradient(ellipse 72% 65% at 50% 48%, transparent 42%, rgba(0,0,0,0.6) 100%)' }} />

      {/* Act 8, bloom */}
      <div
        ref={bloomRef}
        aria-hidden="true"
        style={{
          position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0, mixBlendMode: 'screen',
          background: 'radial-gradient(circle at 50% 46%, rgba(255,255,255,0.9) 0%, rgba(255,255,255,0.22) 32%, transparent 66%)',
        }}
      />

      {/* Word layer (Hello + montage) */}
      <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 20px' }}>
        <div
          ref={wordRef}
          style={{
            fontSize: 'clamp(2.25rem, 9vw, 6rem)', fontWeight: 600, color: '#fff', letterSpacing: '-0.02em',
            opacity: 0, whiteSpace: 'nowrap', willChange: 'transform, opacity, filter',
          }}
        />
      </div>

      {/* Title + tagline layer */}
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 20px' }}>
        <div ref={titleWrapRef} style={{ position: 'relative', display: 'flex', opacity: 0, willChange: 'transform, opacity, filter' }}>
          {TITLE_LETTERS.map((ch, i) => (
            <span key={i} ref={el => { letterRefs.current[i] = el; }} style={{ ...titleTextStyle, display: 'inline-block', willChange: 'transform' }}>{ch}</span>
          ))}
          <div
            ref={sweepRef}
            aria-hidden="true"
            style={{
              position: 'absolute', top: 0, bottom: 0, left: 0, width: '26%', opacity: 0, pointerEvents: 'none',
              background: 'linear-gradient(78deg, transparent 0%, rgba(255,255,255,0.65) 45%, transparent 100%)',
              mixBlendMode: 'screen', transform: 'translateX(-140%)',
            }}
          />
        </div>
        <div ref={taglineWrapRef} style={{ marginTop: '1.4rem', textAlign: 'center' }}>
          <div ref={line1Ref} style={{ fontSize: 'clamp(0.8rem,2.2vw,1rem)', fontWeight: 500, letterSpacing: '0.18em', color: 'rgba(255,255,255,0.72)', opacity: 0 }}>PLAN SMART.</div>
          <div ref={line2Ref} style={{ fontSize: 'clamp(0.8rem,2.2vw,1rem)', fontWeight: 500, letterSpacing: '0.18em', color: 'rgba(255,255,255,0.72)', opacity: 0, marginTop: 4 }}>EXECUTE FLAWLESSLY.</div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// ANIMATED GRID BACKGROUND
// ─────────────────────────────────────────────────────────────────────────────
function CinematicGrid() {
  return (
    <div aria-hidden="true" style={{ position:'absolute', inset:0, overflow:'hidden', pointerEvents:'none', zIndex:0 }}>
      {/* Animated grid lines */}
      <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', animation:'grid-pulse 6s ease-in-out infinite' }} preserveAspectRatio="xMidYMid slice">
        <defs>
          <pattern id="grid-sm" width="60" height="60" patternUnits="userSpaceOnUse">
            <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="1"/>
          </pattern>
          <pattern id="grid-lg" width="240" height="240" patternUnits="userSpaceOnUse">
            <path d="M 240 0 L 0 0 0 240" fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="1"/>
          </pattern>
          <radialGradient id="grid-fade" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor="white" stopOpacity="1"/>
            <stop offset="100%" stopColor="white" stopOpacity="0"/>
          </radialGradient>
          <mask id="grid-mask"><rect width="100%" height="100%" fill="url(#grid-fade)"/></mask>
        </defs>
        <rect width="100%" height="100%" fill="url(#grid-sm)" mask="url(#grid-mask)"/>
        <rect width="100%" height="100%" fill="url(#grid-lg)" mask="url(#grid-mask)"/>
      </svg>
    </div>
  );
}

function slugify(text) {
  return text.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').substring(0, 40);
}
function makeSubdomain(title) {
  const slug = slugify(title);
  if (!slug) return '';
  return `${slug}-${Math.random().toString(36).substring(2, 6)}`;
}

function useScrollReveal(threshold = 0.1) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVisible(true); obs.unobserve(el); } }, { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return [ref, visible];
}

function AnimatedCounter({ end, duration = 2000, suffix = '' }) {
  const [count, setCount] = useState(0);
  const [ref, visible] = useScrollReveal(0.1);
  useEffect(() => {
    if (!visible) return;
    let startTime, raf;
    const animate = (ts) => {
      if (!startTime) startTime = ts;
      const pct = Math.min((ts - startTime) / duration, 1);
      setCount(Math.floor(end * pct));
      if (pct < 1) raf = requestAnimationFrame(animate);
    };
    raf = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(raf);
  }, [visible, end, duration]);
  return <span ref={ref} className="tabular-nums">{count}{suffix}</span>;
}

function CopyLinkBox({ eventId, subdomain, mode }) {
  const [copiedRsvp, setCopiedRsvp] = useState(false);
  const [copiedEvent, setCopiedEvent] = useState(false);

  const rsvpLink  = subdomain ? `${window.location.origin}/rsvp/${subdomain}` : null;
  const eventLink = subdomain ? `${window.location.origin}/e/${subdomain}` : `${window.location.origin}/event/${eventId}`;

  const showRsvp = mode !== 'table-service' && rsvpLink;

  const copyRsvp = () => {
    navigator.clipboard.writeText(rsvpLink);
    setCopiedRsvp(true); toast.success('RSVP link copied');
    setTimeout(() => setCopiedRsvp(false), 2000);
  };
  const copyEvent = () => {
    navigator.clipboard.writeText(eventLink);
    setCopiedEvent(true); toast.success('Event link copied');
    setTimeout(() => setCopiedEvent(false), 2000);
  };

  return (
    <div className="mt-3 space-y-2">
      {showRsvp && (
        <div className="rounded-2xl border border-indigo-700/50 overflow-hidden bg-indigo-950/40 hover:border-indigo-600/60 transition-all duration-300">
          <div className="flex items-center gap-3 px-4 py-3">
            <div className="flex-shrink-0 text-xs font-bold text-indigo-400 uppercase tracking-wider w-14">RSVP</div>
            <span className="flex-1 text-xs text-indigo-300 font-mono truncate">{rsvpLink}</span>
            <button onClick={copyRsvp} className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl transition-all duration-300 ${copiedRsvp ? 'bg-emerald-500 text-white' : 'bg-indigo-600 text-white hover:bg-indigo-500'}`}>
              {copiedRsvp ? <><Check className="w-3 h-3" />Copied</> : <><Copy className="w-3 h-3" />Copy</>}
            </button>
          </div>
        </div>
      )}
      <div className="rounded-2xl border border-neutral-700 overflow-hidden bg-neutral-900 hover:border-neutral-600 transition-all duration-300">
        <div className="flex items-center gap-3 px-4 py-3">
          <div className="flex-shrink-0 text-xs font-bold text-neutral-500 uppercase tracking-wider w-14">Space</div>
          <span className="flex-1 text-xs text-neutral-300 font-mono truncate">{eventLink}</span>
          <button onClick={copyEvent} className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-xl transition-all duration-300 ${copiedEvent ? 'bg-emerald-500 text-white' : 'bg-white text-neutral-900 hover:bg-neutral-100'}`}>
            {copiedEvent ? <><Check className="w-3 h-3" />Copied</> : <><Copy className="w-3 h-3" />Copy</>}
          </button>
        </div>
      </div>
      {showRsvp && (
        <p className="text-xs text-neutral-600 px-1">The RSVP link is the primary shareable link. Enable the RSVP page in Event Settings to activate it.</p>
      )}
    </div>
  );
}

// Grouped reveal for card grids: the whole grid fades up as ONE unit with a quick, even
// cascade, instead of every card waiting for its own scroll trigger and blur filter.
const GRID_PARENT = { hidden: {}, show: { transition: { staggerChildren: 0.05 } } };
const GRID_CHILD = {
  hidden: { opacity: 0, y: 18 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] } },
};

function Reveal(props) {
  return <MotionReveal {...props} />;
}

// A soft, low-opacity gradient seam used between major sections so the page
// reads as one continuous surface rather than a stack of hard-edged blocks.
function SectionSeam({ tint = 'indigo' }) {
  const colors = {
    indigo: 'rgba(47,91,255,0.5)',
    orange: 'rgba(249,115,22,0.4)',
    violet: 'rgba(95,132,255,0.4)',
    neutral: 'rgba(255,255,255,0.15)',
  };
  return (
    <div aria-hidden="true" className="relative h-px w-full overflow-hidden" style={{ zIndex: 1 }}>
      <div style={{
        position: 'absolute', inset: 0, margin: '0 auto', maxWidth: 420, height: 1,
        background: `linear-gradient(90deg, transparent, ${colors[tint] || colors.indigo}, transparent)`,
        opacity: 0.6,
      }} />
    </div>
  );
}

function SectionHeader({ eyebrow, title, subtitle }) {
  return (
    <Reveal className="text-center mb-20">
      {eyebrow && (
        <p className="inline-flex items-center gap-2 text-xs font-bold text-neutral-500 uppercase tracking-[0.2em] mb-4">
          <span className="w-4 h-px bg-neutral-700" />{eyebrow}<span className="w-4 h-px bg-neutral-700" />
        </p>
      )}
      <h2 className="font-syne text-3xl sm:text-5xl md:text-6xl font-black text-white mb-5 leading-[1.05] tracking-tight">{title}</h2>
      {subtitle && <p className="text-lg sm:text-xl text-neutral-400 max-w-2xl mx-auto leading-relaxed">{subtitle}</p>}
    </Reveal>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// SLUG FINDER, lets users jump directly to an event by its link/slug
// ─────────────────────────────────────────────────────────────────────────────
function SlugFinder({ compact = false }) {
  const navigate = useNavigate();
  const [value, setValue] = useState('');
  const [shaking, setShaking] = useState(false);

  const handleGo = () => {
    const raw = value.trim();
    if (!raw) return;

    // Accept full URL (e.g. https://planitapp.onrender.com/e/my-slug) or bare slug
    let slug = raw;
    try {
      const url = new URL(raw.startsWith('http') ? raw : `https://x.com/${raw}`);
      const rsvpMatch  = url.pathname.match(/\/rsvp\/([^/?#]+)/);
      const eventMatch = url.pathname.match(/\/e\/([^/?#]+)/);
      if (rsvpMatch)       slug = rsvpMatch[1];
      else if (eventMatch) slug = eventMatch[1];
      else                 slug = url.pathname.replace(/^\/+|\/+$/g, '');
    } catch {
      // not a URL, use raw as slug
    }
    // Strip leading prefixes if typed manually
    slug = slug.replace(/^\/?(rsvp\/|e\/)?/, '').replace(/\/+$/, '');

    if (!slug) {
      setShaking(true);
      setTimeout(() => setShaking(false), 500);
      return;
    }
    navigate(`/e/${slug}`);
  };

  const handleKey = (e) => { if (e.key === 'Enter') handleGo(); };

  if (compact) {
    return (
      <div className={`flex items-center gap-2 ${shaking ? 'animate-shake' : ''}`}>
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500 pointer-events-none" />
          <input
            type="text"
            value={value}
            onChange={e => setValue(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Paste an event link or slug…"
            className="w-full h-10 pl-10 pr-4 rounded-xl text-sm text-white placeholder-neutral-600 border border-neutral-800 focus:border-neutral-600 focus:outline-none transition-colors"
            style={{ background: 'rgba(255,255,255,0.04)' }}
          />
        </div>
        <button
          onClick={handleGo}
          className="flex-shrink-0 flex items-center gap-1.5 h-10 px-4 rounded-xl text-sm font-bold bg-white text-neutral-900 hover:bg-neutral-100 hover:scale-105 transition-all"
        >
          Go <CornerDownRight className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  return (
    <div className={`mx-auto flex max-w-sm items-center gap-1 rounded-xl border border-white/15 bg-white/[0.05] p-1 backdrop-blur-sm transition-colors focus-within:border-[var(--pi-blue-400)] ${shaking ? 'animate-shake' : ''}`}>
      <div className="relative flex-1">
        <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50 pointer-events-none" />
        <input
          type="text"
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={handleKey}
          placeholder="Have a link? Paste it here…"
          aria-label="Event link or URL name" className="w-full h-11 pl-10 pr-4 rounded-lg text-sm text-white placeholder-white/40 bg-transparent focus:outline-none"
        />
      </div>
      <button
        onClick={handleGo}
        className="flex-shrink-0 flex items-center gap-1.5 h-11 px-4 rounded-lg text-sm font-semibold bg-white text-neutral-900 hover:bg-white/90 transition-all"
      >
        Go <CornerDownRight className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description, delay = 0 }) {
  return (
    <Reveal delay={delay}>
      <div className="group relative p-6 sm:p-10 rounded-2xl border border-neutral-800/80 bg-neutral-900/40 hover:border-neutral-600 hover:bg-neutral-800/50 transition-all duration-500 h-full">
        <div className="mb-5">
          <div className="feature-icon w-14 h-14 rounded-2xl bg-neutral-800 flex items-center justify-center group-hover:bg-white group-hover:shadow-[0_0_24px_rgba(47,91,255,0.35)]">
            <Icon className="w-7 h-7 text-neutral-400 group-hover:text-neutral-900 transition-colors duration-500" />
          </div>
        </div>
        <h3 className="text-lg font-semibold text-white mb-3">{title}</h3>
        <p className="text-sm text-neutral-400 leading-relaxed">{description}</p>
      </div>
    </Reveal>
  );
}

function TestimonialCard({ quote, author, role, event, delay = 0, direction = 'up' }) {
  return (
    <Reveal delay={delay} direction={direction}>
      <div className="lq-glass lq-lift group relative p-8 rounded-[1.25rem] h-full">
        <span aria-hidden="true" className="absolute top-5 right-7 lq-display text-6xl text-white/15 group-hover:text-white/30 transition-colors duration-500 select-none leading-none">"</span>
        <div className="flex items-start gap-4 mb-5">
          <div className="flex-shrink-0 w-12 h-12 rounded-full bg-white flex items-center justify-center ring-1 ring-white/10 group-hover:ring-2 group-hover:ring-indigo-400/40 transition-all duration-500">
            <span className="text-base font-bold text-neutral-900">{author.charAt(0)}</span>
          </div>
          <div>
            <p className="text-base font-semibold text-white">{author}</p>
            <p className="text-xs text-neutral-500">{role}</p>
            <p className="text-xs text-neutral-600 mt-0.5">{event}</p>
          </div>
        </div>
        <p className="relative text-sm text-neutral-300 leading-relaxed mb-1">"{quote}"</p>
      </div>
    </Reveal>
  );
}


// 
// ENTERPRISE INTERACTIVE DEMO
// 

// 
// ENTERPRISE INTERACTIVE DEMO
// 

const DEMO_GUESTS = [
  { id: 1, name: 'Sarah Johnson',   group: 4, table: 12, code: 'SJ4A-X9', role: 'VIP',      status: 'normal' },
  { id: 2, name: 'Marcus Rivera',   group: 2, table: 5,  code: 'MR2B-K3', role: 'Speaker',  status: 'normal' },
  { id: 3, name: 'Priya Sharma',    group: 1, table: 8,  code: 'PS1C-M7', role: 'Attendee', status: 'normal' },
  { id: 4, name: 'Tom & Lisa Chen', group: 2, table: 3,  code: 'TC2D-R1', role: 'Sponsor',  status: 'normal' },
  { id: 5, name: 'Dev Patel',       group: 6, table: 15, code: 'DP6E-N5', role: 'Attendee', status: 'blocked',  blockReason: 'Duplicate identity: another invite with same email already checked in' },
  { id: 6, name: 'Amara Okafor',    group: 1, table: 7,  code: 'AO1F-Q2', role: 'Attendee', status: 'flagged',  flagReason: 'Low trust score: 42/100, scanned from 3 different devices' },
];

function ScrollProgressBar() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const update = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      setProgress(docHeight > 0 ? (scrollTop / docHeight) * 100 : 0);
    };
    window.addEventListener('scroll', update, { passive: true });
    return () => window.removeEventListener('scroll', update);
  }, []);
  return (
    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: 2, zIndex: 9999, background: 'rgba(255,255,255,0.04)', pointerEvents: 'none' }}>
      <div style={{ height: '100%', width: `${progress}%`, background: 'linear-gradient(90deg,#2f5bff,#5f84ff)', transition: 'width .1s linear', boxShadow: '0 0 8px rgba(47,91,255,0.5)' }} />
    </div>
  );
}

function QRPattern({ code, size = 40, faded = false }) {
  const cells = 10;
  const hash = code.split('').reduce((acc, c) => acc * 31 + c.charCodeAt(0), 7);
  return (
    <div style={{ width: size, height: size, display: 'grid', gridTemplateColumns: `repeat(${cells}, 1fr)`, gap: 1, padding: 3, background: faded ? '#333' : 'white', borderRadius: 6, opacity: faded ? 0.4 : 1 }}>
      {Array.from({ length: cells * cells }, (_, i) => {
        const filled = ((hash * (i + 13) * 1103515245 + 12345) & 0x7fffffff) % 3 !== 0;
        return <div key={i} style={{ background: filled ? (faded ? '#888' : '#111') : (faded ? '#333' : 'white'), borderRadius: 1 }} />;
      })}
    </div>
  );
}

function EnterpriseDemo() {
  const [tab, setTab] = useState('guests');
  const [guests, setGuests] = useState(DEMO_GUESTS.map(g => ({ ...g, checkedIn: false, checking: false, checkedAt: null, scanCount: 0 })));
  const [scanning, setScanning] = useState(null);
  const [lastChecked, setLastChecked] = useState(null);
  const [securityLog, setSecurityLog] = useState([]);
  const [overrideTarget, setOverrideTarget] = useState(null); // guest being overridden
  const [overridePin, setOverridePin] = useState('');
  const [overrideError, setOverrideError] = useState('');
  const [overrideSuccess, setOverrideSuccess] = useState(false);
  const [simulating, setSimulating] = useState(false);

  const checkedInCount = guests.filter(g => g.checkedIn).length;
  const totalGuests = guests.reduce((s, g) => s + g.group, 0);
  const checkedInPeople = guests.filter(g => g.checkedIn).reduce((s, g) => s + g.group, 0);
  const pct = Math.round((checkedInPeople / totalGuests) * 100);

  const addLog = (entry) => setSecurityLog(prev => [{ ...entry, id: Date.now() + Math.random(), ts: new Date() }, ...prev].slice(0, 20));

  const handleCheckIn = (guest) => {
    if (scanning) return;

    // Already checked in → duplicate attempt
    if (guest.checkedIn) {
      addLog({ type: 'duplicate', severity: 'high', name: guest.name, msg: `Duplicate scan: ${guest.name} already checked in at ${guest.checkedAt?.toLocaleTimeString()}` });
      return;
    }

    // Blocked guest
    if (guest.status === 'blocked') {
      addLog({ type: 'blocked', severity: 'critical', name: guest.name, msg: `BLOCKED: ${guest.name}, ${guest.blockReason}` });
      setOverrideTarget(guest);
      return;
    }

    // Flagged guest
    if (guest.status === 'flagged') {
      addLog({ type: 'flagged', severity: 'high', name: guest.name, msg: `WARNING: ${guest.name}, ${guest.flagReason}` });
      setOverrideTarget(guest);
      return;
    }

    // Normal check-in
    setScanning(guest.id);
    setGuests(prev => prev.map(g => g.id === guest.id ? { ...g, checking: true, scanCount: g.scanCount + 1 } : g));
    setTimeout(() => {
      const now = new Date();
      setGuests(prev => prev.map(g => g.id === guest.id ? { ...g, checkedIn: true, checking: false, checkedAt: now } : g));
      setLastChecked(guest.id);
      setScanning(null);
      addLog({ type: 'success', severity: 'ok', name: guest.name, msg: `Checked in: ${guest.name}, party of ${guest.group}, table ${guest.table}` });
      setTimeout(() => setLastChecked(null), 2500);
    }, 900);
  };

  const handleOverride = () => {
    if (overridePin !== '1234') {
      setOverrideError('Wrong PIN. Try 1234 for this demo.');
      return;
    }
    setOverrideError('');
    setOverrideSuccess(true);
    const target = overrideTarget;
    setTimeout(() => {
      const now = new Date();
      setGuests(prev => prev.map(g => g.id === target.id ? { ...g, checkedIn: true, checking: false, checkedAt: now, status: 'normal' } : g));
      addLog({ type: 'override', severity: 'medium', name: target.name, msg: `Manager override approved: ${target.name} manually checked in` });
      setOverrideTarget(null);
      setOverridePin('');
      setOverrideSuccess(false);
    }, 1000);
  };

  const simulateUnauthorized = () => {
    if (simulating) return;
    setSimulating(true);
    const fakeCodes = ['XX99-ZZ', 'FAKE-001', 'HACK-123'];
    const code = fakeCodes[Math.floor(Math.random() * fakeCodes.length)];
    addLog({ type: 'unauthorized', severity: 'critical', name: 'Unknown', msg: `UNAUTHORIZED: Code "${code}" not found, possible forged ticket` });
    setTimeout(() => {
      addLog({ type: 'ratelimit', severity: 'medium', name: 'System', msg: `Rate limit triggered: IP blocked for 60s after 3 failed attempts` });
      setSimulating(false);
    }, 1200);
    if (tab !== 'security') setTab('security');
  };

  const handleReset = () => {
    setGuests(DEMO_GUESTS.map(g => ({ ...g, checkedIn: false, checking: false, checkedAt: null, scanCount: 0 })));
    setSecurityLog([]);
    setLastChecked(null);
    setScanning(null);
    setOverrideTarget(null);
    setOverridePin('');
    setOverrideError('');
  };

  const roleColors = {
    VIP: 'text-amber-400 bg-amber-400/10',
    Speaker: 'text-blue-400 bg-blue-400/10',
    Sponsor: 'text-blue-400 bg-blue-400/10',
    Attendee: 'text-neutral-400 bg-neutral-800',
  };
  const logColors = {
    ok: 'text-emerald-400 border-emerald-800/40 bg-emerald-950/20',
    high: 'text-amber-400 border-amber-800/40 bg-amber-950/20',
    critical: 'text-red-400 border-red-800/40 bg-red-950/20',
    medium: 'text-blue-400 border-blue-800/40 bg-blue-950/20',
  };
  const logIcons = { success: '+', duplicate: '!', blocked: 'x', flagged: '!', unauthorized: 'x', override: 'o', ratelimit: '-' };

  return (
    <div className="bg-neutral-900/60 rounded-3xl border border-neutral-800 overflow-hidden">

      {/* Manager override modal */}
      {overrideTarget && !overrideSuccess && (
        <div className="absolute inset-0 z-10 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.85)', borderRadius: 24 }}>
          <div className="w-full max-w-xs mx-4 bg-neutral-900 rounded-2xl border border-neutral-700 p-6">
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold mb-4 ${overrideTarget.status === 'blocked' ? 'bg-red-950/50 border border-red-800/50 text-red-400' : 'bg-amber-950/50 border border-amber-800/50 text-amber-400'}`}>
              {overrideTarget.status === 'blocked' ? 'Guest Blocked' : 'Guest Flagged'}
            </div>
            <p className="text-sm font-bold text-white mb-1">{overrideTarget.name}</p>
            <p className="text-xs text-neutral-500 mb-4">{overrideTarget.blockReason || overrideTarget.flagReason}</p>
            <p className="text-xs font-bold text-neutral-400 mb-2">Manager PIN required to override</p>
            <input
              type="password"
              maxLength={4}
              value={overridePin}
              onChange={e => { setOverridePin(e.target.value); setOverrideError(''); }}
              placeholder="Enter PIN (hint: 1234)"
              className="dark-input text-center text-lg font-mono tracking-widest mb-2"
              autoFocus
            />
            {overrideError && <p className="text-xs text-red-400 mb-2">{overrideError}</p>}
            <div className="flex gap-2 mt-3">
              <button onClick={() => { setOverrideTarget(null); setOverridePin(''); setOverrideError(''); }}
                className="flex-1 py-2 text-xs font-bold text-neutral-400 bg-neutral-800 rounded-xl hover:bg-neutral-700 transition-all">
                Cancel
              </button>
              <button onClick={handleOverride}
                className="flex-1 py-2 text-xs font-bold text-white bg-white/10 border border-white/20 rounded-xl hover:bg-white/20 transition-all">
                Override
              </button>
            </div>
          </div>
        </div>
      )}
      {overrideTarget && overrideSuccess && (
        <div className="absolute inset-0 z-10 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.85)', borderRadius: 24 }}>
          <div className="text-center">
            <div className="w-14 h-14 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-3 animate-bounce">
              <Check className="w-7 h-7 text-white" />
            </div>
            <p className="text-sm font-bold text-emerald-400">Override approved</p>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="px-5 pt-5 pb-0" style={{ position: 'relative' }}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded-full text-xs font-bold text-emerald-400 mb-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
              Live Check-in Demo
            </div>
            <h3 className="text-sm font-bold text-white">Tech Summit 2025</h3>
            <p className="text-xs text-neutral-500">{DEMO_GUESTS.length} invites · {totalGuests} guests</p>
          </div>
          <div className="relative w-12 h-12 flex-shrink-0">
            <svg className="w-12 h-12 -rotate-90" viewBox="0 0 48 48">
              <circle cx="24" cy="24" r="18" fill="none" stroke="#262626" strokeWidth="4" />
              <circle cx="24" cy="24" r="18" fill="none" stroke="#10b981" strokeWidth="4"
                strokeDasharray={`${2 * Math.PI * 18}`}
                strokeDashoffset={`${2 * Math.PI * 18 * (1 - pct / 100)}`}
                strokeLinecap="round"
                style={{ transition: 'stroke-dashoffset 0.6s ease' }} />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <span className="text-xs font-black text-white">{pct}%</span>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 border-b border-neutral-800">
          {['guests', 'security', 'analytics'].map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-3 py-2.5 text-xs font-bold capitalize transition-all duration-200 border-b-2 -mb-px flex items-center gap-1.5 ${tab === t ? 'text-white border-white bg-white/5 rounded-t-lg' : 'text-neutral-500 border-transparent hover:text-neutral-300 hover:bg-white/3 rounded-t-lg'}`}>
              {t === 'security' && securityLog.length > 0 && (
                <span className="w-4 h-4 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-black" style={{ fontSize: 9 }}>
                  {securityLog.filter(l => l.severity === 'critical' || l.severity === 'high').length}
                </span>
              )}
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* GUESTS TAB */}
      {tab === 'guests' && (
        <div className="p-3" style={{ minHeight: 280, maxHeight: 360, overflowY: 'auto' }}>
          <div className="space-y-2">
            {guests.map(guest => {
              const isBlocked = guest.status === 'blocked' && !guest.checkedIn;
              const isFlagged = guest.status === 'flagged' && !guest.checkedIn;
              return (
                <div key={guest.id}
                  className={`flex items-center gap-3 p-3 rounded-2xl border transition-all duration-300 ${
                    guest.checkedIn  ? 'border-emerald-800/50 bg-emerald-950/30' :
                    guest.checking   ? 'border-neutral-600 bg-neutral-800/80' :
                    isBlocked        ? 'border-red-900/60 bg-red-950/20' :
                    isFlagged        ? 'border-amber-900/50 bg-amber-950/15' :
                    'border-neutral-800 bg-neutral-900/50 hover:border-neutral-700'
                  }`}>

                  {/* QR / status icon */}
                  <div className="flex-shrink-0">
                    {guest.checking ? (
                      <div className="w-10 h-10 rounded-lg border border-neutral-700 bg-neutral-800 flex items-center justify-center">
                        <div className="w-4 h-4 border-2 border-neutral-400 border-t-white rounded-full animate-spin" />
                      </div>
                    ) : guest.checkedIn ? (
                      <div className="w-10 h-10 rounded-lg bg-emerald-500 flex items-center justify-center">
                        <Check className="w-5 h-5 text-white" />
                      </div>
                    ) : isBlocked ? (
                      <div className="w-10 h-10 rounded-lg bg-red-950/60 border border-red-900/50 flex items-center justify-center">
                        <Shield className="w-5 h-5 text-red-400" />
                      </div>
                    ) : isFlagged ? (
                      <div className="w-10 h-10 rounded-lg bg-amber-950/60 border border-amber-900/50 flex items-center justify-center">
                        <span className="text-amber-400 font-black text-xs">FLAG</span>
                      </div>
                    ) : (
                      <QRPattern code={guest.code} size={40} />
                    )}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="text-sm font-semibold text-white truncate">{guest.name}</p>
                      <span className={`text-xs px-1.5 py-0.5 rounded font-medium flex-shrink-0 ${roleColors[guest.role]}`}>{guest.role}</span>
                      {isBlocked && <span className="text-xs px-1.5 py-0.5 rounded font-bold flex-shrink-0 bg-red-950/60 text-red-400 border border-red-900/40">BLOCKED</span>}
                      {isFlagged && <span className="text-xs px-1.5 py-0.5 rounded font-bold flex-shrink-0 bg-amber-950/50 text-amber-400 border border-amber-900/40">FLAGGED</span>}
                    </div>
                    <p className="text-xs text-neutral-500 truncate">
                      {guest.checkedIn
                        ? `Checked in · Party of ${guest.group} · Table ${guest.table}`
                        : isBlocked ? guest.blockReason
                        : isFlagged ? guest.flagReason
                        : `Party of ${guest.group} · Table ${guest.table}`}
                    </p>
                  </div>

                  {/* Action */}
                  <button
                    onClick={() => handleCheckIn(guest)}
                    disabled={!!scanning}
                    className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition-all duration-200 ${
                      guest.checkedIn   ? 'bg-emerald-950/40 text-emerald-600 cursor-default' :
                      scanning === guest.id ? 'bg-neutral-700 text-neutral-400 cursor-wait' :
                      scanning          ? 'bg-neutral-800 text-neutral-600 cursor-not-allowed' :
                      isBlocked         ? 'bg-red-950/50 text-red-400 border border-red-900/40 hover:bg-red-900/40' :
                      isFlagged         ? 'bg-amber-950/50 text-amber-400 border border-amber-900/40 hover:bg-amber-900/40' :
                      'bg-white text-neutral-900 hover:bg-neutral-100 hover:scale-105 active:scale-95'
                    }`}>
                    {guest.checkedIn ? 'Done' : scanning === guest.id ? '…' : isBlocked ? 'Blocked' : isFlagged ? 'Review' : 'Scan'}
                  </button>

                  {lastChecked === guest.id && (
                    <span className="flex-shrink-0 text-xs text-emerald-400 font-bold animate-pulse">In!</span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Simulate unauthorized */}
          <div className="mt-3 p-3 rounded-2xl border border-dashed border-neutral-700 bg-neutral-900/30">
            <p className="text-xs text-neutral-600 mb-2 font-medium">Simulate security scenarios:</p>
            <div className="flex gap-2">
              <button onClick={simulateUnauthorized} disabled={simulating}
                className="flex-1 py-1.5 text-xs font-bold text-red-400 border border-red-900/50 rounded-xl bg-red-950/20 hover:bg-red-950/40 transition-all disabled:opacity-40">
                {simulating ? 'Scanning…' : 'Try forged ticket'}
              </button>
              {(checkedInCount > 0 || securityLog.length > 0) && (
                <button onClick={handleReset} className="px-3 py-1.5 text-xs text-neutral-600 hover:text-neutral-400 border border-neutral-800 rounded-xl transition-colors">
                  Reset
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SECURITY TAB */}
      {tab === 'security' && (
        <div className="p-4" style={{ minHeight: 280, maxHeight: 360, overflowY: 'auto' }}>
          {/* Security overview badges */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            {[
              { label: 'Blocked', count: guests.filter(g => g.status === 'blocked' && !g.checkedIn).length, color: 'text-red-400', bg: 'bg-red-950/30 border-red-900/40' },
              { label: 'Flagged', count: guests.filter(g => g.status === 'flagged' && !g.checkedIn).length, color: 'text-amber-400', bg: 'bg-amber-950/30 border-amber-900/40' },
              { label: 'Alerts', count: securityLog.filter(l => l.severity !== 'ok').length, color: 'text-blue-400', bg: 'bg-blue-950/30 border-blue-900/40' },
            ].map(s => (
              <div key={s.label} className={`text-center p-2.5 rounded-xl border ${s.bg}`}>
                <div className={`text-xl font-black tabular-nums ${s.color}`}>{s.count}</div>
                <div className="text-xs text-neutral-500">{s.label}</div>
              </div>
            ))}
          </div>

          {/* Security features list */}
          <div className="space-y-2 mb-4">
            <p className="text-xs font-bold text-neutral-600 uppercase tracking-widest">Active protections</p>
            {[
              { icon: 'X', label: 'Duplicate detection', desc: 'Flags same identity across multiple invites', active: true, color: 'text-emerald-400' },
              { icon: '-', label: 'Rate limiting', desc: '3 failed scans → 60s IP lockout', active: true, color: 'text-emerald-400' },
              { icon: '!', label: 'Trust scoring', desc: 'Flags low-trust guests for manual review', active: true, color: 'text-emerald-400' },
              { icon: 'O', label: 'Manager override', desc: 'PIN-protected override for blocked guests', active: true, color: 'text-emerald-400' },
              { icon: 'Q', label: 'QR forgery detection', desc: 'Rejects codes not in guest registry', active: true, color: 'text-emerald-400' },
            ].map((f, i) => (
              <div key={i} className="flex items-start gap-3 p-2.5 bg-neutral-900/40 rounded-xl border border-neutral-800">
                <span className={`text-sm font-black flex-shrink-0 mt-0.5 ${f.color}`}>{f.icon}</span>
                <div>
                  <p className="text-xs font-bold text-white">{f.label}</p>
                  <p className="text-xs text-neutral-500">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Live log */}
          <p className="text-xs font-bold text-neutral-600 uppercase tracking-widest mb-2">Security log</p>
          {securityLog.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-xs text-neutral-700">No events yet.</p>
              <p className="text-xs text-neutral-700 mt-1">Go to Guests → try scanning blocked/flagged guests or a forged ticket.</p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {securityLog.map(entry => (
                <div key={entry.id} className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-xs ${logColors[entry.severity]}`}>
                  <span className="font-black flex-shrink-0 mt-0.5">{logIcons[entry.type] || '·'}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium leading-snug">{entry.msg}</p>
                    <p className="opacity-50 mt-0.5">{entry.ts.toLocaleTimeString()}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ANALYTICS TAB */}
      {tab === 'analytics' && (
        <div className="p-4" style={{ minHeight: 280, maxHeight: 360, overflowY: 'auto' }}>
          <div className="grid grid-cols-3 gap-2 mb-4">
            {[
              { label: 'Arrived',  value: checkedInPeople, color: 'text-emerald-400' },
              { label: 'Pending',  value: totalGuests - checkedInPeople, color: 'text-amber-400' },
              { label: 'Checked',  value: checkedInCount, color: 'text-blue-400' },
            ].map(s => (
              <div key={s.label} className="text-center p-3 bg-neutral-900 rounded-2xl border border-neutral-800">
                <div className={`text-2xl font-black tabular-nums ${s.color}`}>{s.value}</div>
                <div className="text-xs text-neutral-500 mt-0.5">{s.label}</div>
              </div>
            ))}
          </div>

          <p className="text-xs font-bold text-neutral-600 uppercase tracking-widest mb-3">Guest breakdown</p>
          <div className="space-y-2.5 mb-4">
            {guests.map(g => (
              <div key={g.id}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-neutral-400 truncate">{g.name}</span>
                  <span className="text-xs text-neutral-500 flex-shrink-0 ml-2">
                    {g.checkedIn ? `${g.group}/${g.group}` : `0/${g.group}`}
                  </span>
                </div>
                <div className="h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full transition-all duration-700 ${
                    g.checkedIn ? 'bg-emerald-500' :
                    g.checking  ? 'bg-neutral-600' :
                    g.status === 'blocked' ? 'bg-red-800' :
                    g.status === 'flagged' ? 'bg-amber-800' : 'bg-neutral-700'
                  }`} style={{ width: g.checkedIn ? '100%' : g.checking ? '45%' : '0%' }} />
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 bg-neutral-900 rounded-2xl border border-neutral-800">
            <div className="flex justify-between mb-2">
              <span className="text-xs font-bold text-neutral-400">Overall attendance</span>
              <span className="text-xs font-black text-white">{pct}%</span>
            </div>
            <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 rounded-full transition-all duration-700" style={{ width: `${pct}%` }} />
            </div>
            <p className="text-xs text-neutral-600 mt-2">{checkedInPeople} of {totalGuests} guests arrived</p>
          </div>

          {checkedInCount === 0 && (
            <p className="text-center text-xs text-neutral-600 mt-4">← Switch to Guests and start checking people in</p>
          )}
        </div>
      )}
    </div>
  );
}

import CrossPlatformAd from '../components/CrossPlatformAd';
import TurnstileWidget from '../components/TurnstileWidget';



// 
// MAIN
// 

// ─────────────────────────────────────────────────────────────────────────────
// ONBOARDING WIZARD
// ─────────────────────────────────────────────────────────────────────────────
const EVENT_TYPES = [
  { id:'wedding',    label:'Wedding',          hint:'Ceremony, reception, the works' },
  { id:'birthday',   label:'Birthday',         hint:'Milestone or casual celebration' },
  { id:'conference', label:'Conference',       hint:'Speakers, sessions, networking' },
  { id:'corporate',  label:'Corporate',        hint:'Retreat, offsite, team event' },
  { id:'festival',   label:'Festival',         hint:'Multi-stage, outdoor, crowd' },
  { id:'other',      label:'Other',            hint:'Something totally unique' },
];
const VENUE_TYPES = [
  { id:'restaurant', label:'Restaurant',       hint:'Full-service dining floor' },
  { id:'cafe',       label:'Cafe',             hint:'Counter service and tables' },
  { id:'bar',        label:'Bar / Pub',        hint:'Drinks-led with seating' },
  { id:'popup',      label:'Pop-up',           hint:'Temporary or market stall' },
  { id:'hotel',      label:'Hotel dining',     hint:'In-house restaurant or lounge' },
  { id:'other',      label:'Other venue',      hint:'Something different entirely' },
];

// ─────────────────────────────────────────────────────────────────────────────
// DEVICE FRAME, chrome wrapper so mockups read as "a screen", not a raw div
// ─────────────────────────────────────────────────────────────────────────────
function DeviceFrame({ variant = 'browser', children }) {
  if (variant === 'phone') {
    return (
      <div className="relative mx-auto" style={{ width: 260 }}>
        <div className="rounded-[2.25rem] border-[6px] border-neutral-800 bg-neutral-950 shadow-2xl overflow-hidden relative" style={{ height: 480 }}>
          <div className="absolute left-1/2 -translate-x-1/2 top-0 w-20 h-4 bg-neutral-800 rounded-b-xl z-20" />
          <div className="w-full h-full overflow-hidden">{children}</div>
        </div>
      </div>
    );
  }
  if (variant === 'tablet') {
    return (
      <div className="relative mx-auto w-full" style={{ maxWidth: 440 }}>
        <div className="rounded-[1.5rem] border-[8px] border-neutral-800 bg-neutral-950 shadow-2xl overflow-hidden">
          {children}
        </div>
      </div>
    );
  }
  // browser
  return (
    <div className="relative mx-auto w-full rounded-2xl border border-neutral-800 bg-neutral-950 shadow-2xl overflow-hidden">
      <div className="flex items-center gap-1.5 px-4 py-3 border-b border-neutral-800 bg-neutral-900/60">
        <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
        <span className="w-2.5 h-2.5 rounded-full bg-amber-500/70" />
        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/70" />
        <div className="ml-3 flex-1 h-6 rounded-md bg-neutral-800/70 flex items-center px-3 max-w-xs">
          <span className="text-[10px] text-neutral-500 truncate">app.planit.events/acme-summit</span>
        </div>
      </div>
      {children}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAGNETIC LINK, pulls toward the cursor when nearby (hover polish, CTA row)
// ─────────────────────────────────────────────────────────────────────────────
function MagneticLink({ className = '', children, strength = 12, ...props }) {
  const ref = useRef(null);
  const onMouseMove = (e) => {
    const el = ref.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const x = (e.clientX - r.left - r.width / 2) / (r.width / 2);
    const y = (e.clientY - r.top - r.height / 2) / (r.height / 2);
    el.style.transform = `translate(${(x * strength).toFixed(1)}px, ${(y * strength).toFixed(1)}px)`;
  };
  const onMouseLeave = () => { if (ref.current) ref.current.style.transform = 'translate(0px,0px)'; };
  return (
    <a ref={ref} onMouseMove={onMouseMove} onMouseLeave={onMouseLeave} className={className}
      style={{ transition: 'transform 0.2s cubic-bezier(0.22,1,0.36,1)' }} {...props}>
      {children}
    </a>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// RSVP MOCKUP (phone), fake render, but the status buttons actually respond
// ─────────────────────────────────────────────────────────────────────────────
const RSVP_STATUS_STYLE = {
  yes:   'bg-emerald-500 border-emerald-500 text-white',
  maybe: 'bg-amber-500 border-amber-500 text-white',
  no:    'bg-red-500 border-red-500 text-white',
};
function RSVPMockup() {
  const [status, setStatus] = useState(null);
  const [count, setCount] = useState(84);
  const pick = (key) => {
    setCount(c => {
      if (key === status) return c;
      if (key === 'yes') return c + 1;
      if (status === 'yes') return c - 1;
      return c;
    });
    setStatus(key);
  };
  return (
    <div className="h-full flex flex-col text-white" style={{ background: '#0d0714' }}>
      <div className="relative flex-shrink-0 flex items-end p-4" style={{
        height: 168,
        background: 'radial-gradient(circle at 20% 20%, rgba(47,91,255,0.55) 0%, transparent 45%), radial-gradient(circle at 85% 15%, rgba(255,209,102,0.5) 0%, transparent 40%), radial-gradient(circle at 80% 90%, rgba(255,93,143,0.55) 0%, transparent 45%), linear-gradient(135deg,#150a24,#0e1626)',
      }}>
        <div>
          <span className="inline-block text-[9px] font-bold uppercase tracking-widest px-2 py-1 rounded-full bg-white/15 backdrop-blur mb-1.5">You&apos;re invited</span>
          <p className="font-syne font-black text-lg leading-tight">Summer Rooftop<br />Social</p>
        </div>
      </div>
      <div className="flex-1 p-4 flex flex-col gap-2.5">
        <div className="flex items-center gap-2 text-[11px] text-neutral-400"><Calendar className="w-3 h-3 flex-shrink-0" /> Sat, Aug 16 · 7:00 PM</div>
        <div className="flex items-center gap-2 text-[11px] text-neutral-400"><MapPin className="w-3 h-3 flex-shrink-0" /> The Hendrick Rooftop</div>
        <div className="flex gap-1.5 mt-2">
          {[{ key:'yes', label:'Attending' }, { key:'maybe', label:'Maybe' }, { key:'no', label:"Can't go" }].map(o => (
            <button key={o.key} onClick={() => pick(o.key)}
              className={`flex-1 py-2 rounded-xl text-[10px] font-bold border transition-all duration-200 ${status === o.key ? RSVP_STATUS_STYLE[o.key] : 'border-white/15 text-neutral-400 hover:border-white/30'}`}>
              {o.label}
            </button>
          ))}
        </div>
        <div className="mt-auto flex items-center justify-between pt-3 border-t border-white/10">
          <span className="text-[10px] text-neutral-500">Going</span>
          <span className="text-sm font-black tabular-nums">{count} guests</span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// EVENT SPACE MOCKUP (browser), fake render; a typing bubble resolves into
// a new message once, so the panel has a little life without needing real data
// ─────────────────────────────────────────────────────────────────────────────
function EventSpaceMockup() {
  const [messages, setMessages] = useState([
    { id: 1, user: 'Maya',  text: 'Can we push the sound check to 4pm?', me: false },
    { id: 2, user: 'You',   text: 'Works for me. Updating the run of show now.', me: true },
  ]);
  const [typing, setTyping] = useState(false);
  useEffect(() => {
    const t1 = setTimeout(() => setTyping(true), 1400);
    const t2 = setTimeout(() => {
      setTyping(false);
      setMessages(m => [...m, { id: Date.now(), user: 'Jordan', text: 'Floor plan is finalized ✅', me: false }]);
    }, 2900);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);
  const tasks = [
    { label: 'Confirm catering headcount', done: true },
    { label: 'Print name badges',          done: true },
    { label: 'Brief volunteer team',       done: false },
    { label: 'Load in AV equipment',       done: false },
  ];
  return (
    <div className="flex text-white" style={{ background: '#0a0a0f', height: 340 }}>
      <div className="w-2/3 flex flex-col border-r border-white/5">
        <div className="px-4 py-2.5 border-b border-white/5 flex items-center gap-2 flex-shrink-0">
          <MessageSquare className="w-3.5 h-3.5 text-indigo-400" /><span className="text-xs font-bold"># general</span>
        </div>
        <div className="flex-1 p-4 space-y-3 overflow-hidden">
          {messages.map(m => (
            <div key={m.id} className={`flex ${m.me ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[75%] px-3 py-2 rounded-2xl text-[11px] leading-snug ${m.me ? 'bg-indigo-500 text-white rounded-br-sm' : 'bg-white/8 text-neutral-200 rounded-bl-sm'}`}>
                {!m.me && <p className="text-[9px] font-bold text-indigo-300 mb-0.5">{m.user}</p>}
                {m.text}
              </div>
            </div>
          ))}
          {typing && (
            <div className="flex justify-start">
              <div className="px-3 py-2.5 rounded-2xl bg-white/8 flex gap-1 rounded-bl-sm">
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-500 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="w-1/3 p-3.5 flex flex-col gap-2.5 overflow-hidden">
        <div className="flex items-center gap-1.5 mb-0.5 flex-shrink-0"><ListChecks className="w-3.5 h-3.5 text-emerald-400" /><span className="text-xs font-bold">Tasks</span></div>
        {tasks.map(t => (
          <div key={t.label} className="flex items-start gap-2">
            <div className={`w-3.5 h-3.5 rounded-md border flex-shrink-0 mt-0.5 flex items-center justify-center ${t.done ? 'bg-emerald-500 border-emerald-500' : 'border-white/20'}`}>
              {t.done && <Check className="w-2.5 h-2.5 text-white" />}
            </div>
            <span className={`text-[10.5px] leading-snug ${t.done ? 'text-neutral-500 line-through' : 'text-neutral-300'}`}>{t.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// PRODUCT SHOWCASE, static, no scroll logic. Each step sits directly next to
// its own device frame; nothing swaps, nothing is pinned. Step 3 renders the
// real EnterpriseDemo (already built above), so that one isn't even a fake
// render, it's genuinely interactive.
// ─────────────────────────────────────────────────────────────────────────────
const SHOWCASE_STEPS = [
  { key: 'rsvp',    eyebrow: 'Step 01', title: 'Guests RSVP in seconds',   desc: 'No app, no account: a beautiful invite page guests can respond to from any phone.',                                device: 'phone',   node: <RSVPMockup /> },
  { key: 'space',   eyebrow: 'Step 02', title: 'Your team plans together', desc: 'Chat, shared tasks, and polls in one live workspace instead of five different apps.',                                device: 'browser', node: <EventSpaceMockup /> },
  { key: 'checkin', eyebrow: 'Step 03', title: 'Check them in at the door',desc: 'Real, working check-in demo below. Duplicate detection and manager overrides included. Try it.',                     device: 'tablet',  node: <EnterpriseDemo /> },
];
function ProductShowcase() {
  return (
    <section id="showcase" className="relative overflow-hidden">
      <Aurora palette="sunset" stars={false} />
      <div className="relative max-w-6xl mx-auto px-6 sm:px-10 py-20 sm:py-28">
        <Reveal className="text-center mb-16 sm:mb-20">
          <p className="lq-kicker mb-5">{'// See it in action'}</p>
          <h2 className="font-syne text-3xl sm:text-5xl font-black text-white leading-tight">
            Not just a Free Trial.<br /><span className="text-white/40">This is the real thing.</span>
          </h2>
        </Reveal>

        <div className="space-y-20 sm:space-y-28">
          {SHOWCASE_STEPS.map((s, i) => (
            <div key={s.key} className={`grid grid-cols-[minmax(0,1fr)] lg:grid-cols-2 gap-10 lg:gap-16 items-center ${i % 2 === 1 ? 'lg:[&>*:first-child]:order-2' : ''}`}>
              <Reveal direction={i % 2 === 1 ? 'right' : 'left'}>
                <span className="lq-kicker mb-3 block">{'// '}{s.eyebrow}</span>
                <h3 className="font-syne text-2xl sm:text-3xl font-black mb-3 text-white">{s.title}</h3>
                <p className="text-sm sm:text-base font-light leading-snug max-w-sm text-white/75">{s.desc}</p>
              </Reveal>
              <Reveal direction={i % 2 === 1 ? 'left' : 'right'} delay={100}>
                <DeviceFrame variant={s.device}>{s.node}</DeviceFrame>
              </Reveal>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Bump this when the Terms / Privacy Policy change in a way that needs fresh consent.
const LEGAL_VERSION = '2026-10-03';

const LEGAL_CHECKS = [
  {
    key: 'agreeTerms',
    error: 'You need to agree to the Terms of Service and Privacy Policy.',
    label: (
      <>
        I agree to the <a href="/terms" target="_blank" rel="noopener noreferrer" style={{ color:'#90abff', textDecoration:'underline' }}>Terms of Service</a> and the{' '}
        <a href="/privacy" target="_blank" rel="noopener noreferrer" style={{ color:'#90abff', textDecoration:'underline' }}>Privacy Policy</a>.
      </>
    ),
  },
  {
    key: 'agreeResponsible',
    error: 'Please confirm you are responsible for your event.',
    label: 'I am responsible for my event and everything posted to it. I will not use PlanIt for anything illegal, harassing, deceptive, or spammy, and I understand PlanIt can remove events that break the rules.',
  },
  {
    key: 'agreeGuestData',
    error: 'Please confirm you will handle guest data responsibly.',
    label: 'I have the right to collect my guests\u2019 information (names, emails, RSVPs, check-ins) and will only use it to run this event.',
  },
  {
    key: 'agreeAge',
    error: 'You must be at least 13 to create an event.',
    label: 'I am at least 13 years old.',
  },
];

function OnboardingWizard({ mode, formData, setFormData, fieldErrors, setFieldErrors, onSubmit, loading, submittedRef, stepControlRef, abuseStatus, requiresVerification, onCaptchaToken, captchaResetKey, onUserInput, onUserPaste }) {
  const isVenue = mode === 'table-service';
  const isRsvp  = mode === 'rsvp';
  const accent  = isVenue ? '#f97316' : '#2f5bff';
  const accentHover = isVenue ? '#fb923c' : '#5f84ff';

  const [step, setStep]           = useState(0);
  const [dir, setDir]             = useState('forward');
  const [stepKey, setStepKey]     = useState(0);
  const [eventType, setEventType] = useState('');
  const [venueType, setVenueType] = useState('');
  const [showPw, setShowPw]       = useState(false);
  const [showPw2, setShowPw2]     = useState(false);
  const [localErr, setLocalErr]   = useState({});
  const firstInputRef             = useRef(null);

  // Expose step navigation to the parent so it can redirect back after a server error
  useEffect(() => {
    if (stepControlRef) {
      stepControlRef.current = {
        goTo: (n) => {
          setDir(n < step ? 'back' : 'forward');
          setStep(n);
          setStepKey(k => k + 1);
          setLocalErr({});
        },
        getStep: () => step,
      };
    }
  });

  // ── Draft persistence state ────────────────────────────────────────────────
  const [pendingDraft, setPendingDraft]           = useState(null);
  const [draftBannerVisible, setDraftBannerVisible] = useState(false);
  const debounceRef = useRef(null);
  const stepRef     = useRef(step);

  // Keep stepRef in sync for beforeunload closure
  useEffect(() => { stepRef.current = step; }, [step]);

  // Mount effect: track feature start, detect saved draft, register abandon listener
  useEffect(() => {
    trackFeature('event_creation_start');
    trackGAEvent('event_creation_started');

    try {
      const raw = localStorage.getItem('planit_event_draft');
      if (raw) {
        const draft = JSON.parse(raw);
        const SEVENTY_TWO_HOURS = 72 * 60 * 60 * 1000;
        if (draft.timestamp && (Date.now() - draft.timestamp) < SEVENTY_TWO_HOURS) {
          setPendingDraft(draft);
          setDraftBannerVisible(true);
        }
      }
    } catch { /* ignore */ }

    const handleBeforeUnload = () => {
      if (!submittedRef?.current) {
        trackFeature('event_creation_abandon', { step: stepRef.current });
        flushTracker();
      }
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-save draft on formData/step change (debounced 1.2s)
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      try {
        const vid = localStorage.getItem('planit_vid');
        localStorage.setItem('planit_event_draft', JSON.stringify({
          // Consent is never restored from a draft; the user re-confirms on the last step.
          formData: { ...formData, agreeTerms: false, agreeResponsible: false, agreeGuestData: false, agreeAge: false },
          step,
          timestamp: Date.now(),
          visitorId: vid,
        }));
      } catch { /* ignore */ }
    }, 1200);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [formData, step]); // eslint-disable-line react-hooks/exhaustive-deps

  // Focus first input on step change
  useEffect(() => {
    const t = setTimeout(() => firstInputRef.current?.focus(), 360);
    return () => clearTimeout(t);
  }, [step]);

  const totalSteps = isVenue ? 4 : (isRsvp ? 5 : 6);

  const go = (delta) => {
    setDir(delta > 0 ? 'forward' : 'back');
    setStep(s => s + delta);
    setStepKey(k => k + 1);
    setLocalErr({});
  };

  const validate = () => {
    const e = {};
    if (step === 1) {
      if (!formData.title.trim()) e.title = isVenue ? 'Venue name is required.' : 'Event title is required.';
    }
    if (!isVenue && step === 2) {
      if (!formData.date)     e.date     = 'Date and time is required.';
      if (!formData.timezone) e.timezone = 'Timezone is required.';
    }
    const nameStep = isVenue ? 2 : (isRsvp ? 3 : 4);
    if (step === nameStep) {
      if (!formData.organizerName.trim()) e.organizerName = isVenue ? 'Manager name is required.' : 'Your name is required.';
      if (!formData.organizerEmail.trim()) e.organizerEmail = 'Email is required.';
      else if (!validateEmail(formData.organizerEmail.trim())) e.organizerEmail = 'Please enter a valid email.';
    }
    const pwStep = isVenue ? 3 : (isRsvp ? 4 : 5);
    if (step === pwStep) {
      if (!formData.accountPassword) e.accountPassword = 'Password is required.';
      else if (formData.accountPassword.length < 4) e.accountPassword = 'Must be at least 4 characters.';
      for (const c of LEGAL_CHECKS) if (!formData[c.key]) e[c.key] = c.error;
    }
    setLocalErr(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (!validate()) return;
    if (step < totalSteps - 1) { go(1); }
    else { onSubmit(); }
  };

  const update = (field) => (e) => {
    onUserInput?.();
    setFormData(p => ({ ...p, [field]: e.target.value, ...(field === 'timezone' ? { _tzTouched: true } : {}) }));
    if (localErr[field]) setLocalErr(p => ({ ...p, [field]: '' }));
    if (fieldErrors[field]) setFieldErrors(p => ({ ...p, [field]: '' }));
  };

  // Deep links from the shared nav: /?start=events|venue|rsvp opens that branch,
  // /#features (or any section id) scrolls to it once the loader has finished.
  useEffect(() => {
    if (preloading) return undefined;
    const start = new URLSearchParams(location.search).get('start');
    if (!isWL && ['events', 'venue', 'rsvp'].includes(start)) {
      selectBranch(start);
      navigate('/', { replace: true });
      return undefined;
    }
    if (location.hash) {
      const id = location.hash.slice(1);
      const t = setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 350);
      return () => clearTimeout(t);
    }
    return undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, location.hash, preloading, isWL]);

  const handleTitleChange = (e) => {
    onUserInput?.();
    const title = e.target.value;
    setFormData(prev => ({
      ...prev, title,
      subdomain: prev._subdomainTouched ? prev.subdomain : makeSubdomain(title),
    }));
    if (localErr.title) setLocalErr(p => ({ ...p, title: '' }));
  };

  // Merge server-side errors into localErr
  const err = { ...localErr, ...fieldErrors };

  const renderStatusCard = () => abuseStatus ? (
    <div style={{ background:'rgba(47,91,255,0.10)', border:'1px solid rgba(95,132,255,0.35)', borderRadius:14, padding:'12px 14px', marginBottom:18, color:'#dfe7ff', fontSize:13, lineHeight:1.5 }}>
      <strong style={{ display:'block', marginBottom:4 }}>{abuseStatus.title}</strong>
      <span>{abuseStatus.message}</span>
    </div>
  ) : null;

  // ── Step content factory ────────────────────────────────────────────────────
  const renderStep = () => {
    // Step 0: type picker
    if (step === 0) {
      const types = isVenue ? VENUE_TYPES : EVENT_TYPES;
      const selected = isVenue ? venueType : eventType;
      const setSelected = isVenue
        ? (id) => { setVenueType(id); }
        : (id) => { setEventType(id); };
      return (
        <div>
          <p className="wiz-question" style={{ fontSize:'clamp(1.5rem,4vw,2.2rem)', fontFamily:'var(--font-display)', fontWeight:800, color:'#fff', lineHeight:1.15, marginBottom:8 }}>
            {isVenue ? 'What kind of venue?' : 'What are you planning?'}
          </p>
          <p style={{ fontSize:14, color:'rgba(255,255,255,0.35)', marginBottom:28 }}>
            This helps us personalise your setup. You can change anything later.
          </p>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(140px,1fr))', gap:10, marginBottom:4 }}>
            {types.map((t, i) => {
              const active = selected === t.id;
              return (
                <button key={t.id} type="button"
                  className={`wiz-type-card${active ? ' active' : ''}`}
                  style={{
                    background: active ? (isVenue ? 'rgba(249,115,22,0.12)' : 'rgba(47,91,255,0.12)') : 'rgba(255,255,255,0.03)',
                    border: `1.5px solid ${active ? accent : 'rgba(255,255,255,0.07)'}`,
                    borderRadius:12, padding:'14px 10px', textAlign:'center',
                    boxShadow: active ? `0 0 20px ${accent}28` : 'none',
                    animationDelay:`${i*0.04}s`,
                  }}
                  onClick={() => { setSelected(t.id); }}
                >
                  <div style={{ fontSize:13, fontWeight:700, color: active ? '#fff' : 'rgba(255,255,255,0.55)', marginBottom:4, letterSpacing:'-0.01em' }}>{t.label}</div>
                  <div style={{ fontSize:11, color:'rgba(255,255,255,0.28)', lineHeight:1.3 }}>{t.hint}</div>
                </button>
              );
            })}
          </div>
          {selected && (
            <p style={{ fontSize:12, color: isVenue ? '#fb923c' : '#5f84ff', marginTop:12, display:'flex', alignItems:'center', gap:6 }}>
              <CheckCircle2 style={{ width:13, height:13 }} />
              Selection confirmed. Continue when ready.
            </p>
          )}
        </div>
      );
    }

    // Step 1: Name
    if (step === 1) {
      return (
        <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
          <div>
            <p className="wiz-question" style={{ fontSize:'clamp(1.5rem,4vw,2.2rem)', fontFamily:'var(--font-display)', fontWeight:800, color:'#fff', lineHeight:1.15, marginBottom:8 }}>
              {isVenue ? 'What\'s your venue called?' : 'What\'s your event called?'}
            </p>
            <p style={{ fontSize:14, color:'rgba(255,255,255,0.35)', marginBottom:24 }}>
              {isVenue ? 'Your restaurant name (guests will see this).' : 'Give it a name your team will recognise.'}
            </p>
          </div>
          <div>
            <input
              ref={firstInputRef}
              type="text"
              className={`wiz-input${isVenue ? ' wiz-input-venue' : ''}${err.title ? ' error' : ''}`}
              placeholder={isVenue ? 'Taverna Roma, The Oak Room…' : 'Summer Company Retreat 2025'}
              value={formData.title}
              onChange={handleTitleChange}
              onKeyDown={e => e.key === 'Enter' && next()}
              autoComplete="off"
            />
            {err.title && <p style={{ fontSize:12, color:'#f87171', marginTop:6, display:'flex', alignItems:'center', gap:5 }}><AlertCircle style={{ width:12, height:12 }} />{err.title}</p>}
          </div>
          {formData.title && (
            <div style={{ background: err.subdomain ? 'rgba(248,113,113,0.06)' : 'rgba(255,255,255,0.03)', border: err.subdomain ? '1px solid rgba(248,113,113,0.5)' : '1px solid rgba(255,255,255,0.07)', borderRadius:12, padding:'10px 14px' }}>
              <p style={{ fontSize:11, color: err.subdomain ? '#f87171' : 'rgba(255,255,255,0.3)', marginBottom:4, textTransform:'uppercase', letterSpacing:'0.12em' }}>Your URL</p>
              <div style={{ display:'flex', alignItems:'center', gap:0 }}>
                <span style={{ fontSize:13, color:'rgba(255,255,255,0.25)', fontFamily:'monospace' }}>/e/</span>
                <input
                  type="text"
                  value={formData.subdomain}
                  onChange={(e) => {
                    const cleaned = e.target.value.toLowerCase().replace(/[^a-z0-9-]/g,'-').replace(/-{2,}/g,'-');
                    setFormData(p => ({ ...p, subdomain: cleaned, _subdomainTouched: true }));
                    if (fieldErrors.subdomain) setFieldErrors(p => ({ ...p, subdomain: '' }));
                  }}
                  style={{ flex:1, background:'transparent', border:'none', outline:'none', color: err.subdomain ? '#fca5a5' : 'rgba(255,255,255,0.7)', fontFamily:'monospace', fontSize:13 }}
                  spellCheck={false}
                />
              </div>
              {err.subdomain && <p style={{ fontSize:12, color:'#f87171', marginTop:6, display:'flex', alignItems:'center', gap:5 }}><AlertCircle style={{ width:12, height:12 }} />{err.subdomain}</p>}
            </div>
          )}
          {!isVenue && (
            <div>
              <textarea
                className={`wiz-input${err.description ? ' error' : ''}`}
                style={{ resize:'none', minHeight:80 }}
                placeholder="A short description (optional)"
                value={formData.description}
                onChange={update('description')}
                rows={3}
              />
            </div>
          )}
        </div>
      );
    }

    // Events Step 2: Date + location + enterprise
    if (!isVenue && step === 2) {
      return (
        <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
          <div>
            <p className="wiz-question" style={{ fontSize:'clamp(1.5rem,4vw,2.2rem)', fontFamily:'var(--font-display)', fontWeight:800, color:'#fff', lineHeight:1.15, marginBottom:8 }}>
              When and where?
            </p>
            <p style={{ fontSize:14, color:'rgba(255,255,255,0.35)', marginBottom:24 }}>
              Set the date and location (guests see this on their invite).
            </p>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div style={{ gridColumn:'1/-1' }}>
              <label style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.1em' }}>Date & time *</label>
              <input
                ref={firstInputRef}
                type="datetime-local"
                className={`wiz-input${err.date ? ' error' : ''}`}
                value={formData.date}
                onChange={update('date')}
                style={{ colorScheme:'dark' }}
              />
              {err.date && <p style={{ fontSize:12, color:'#f87171', marginTop:5 }}>{err.date}</p>}
            </div>
            <div style={{ gridColumn:'1/-1' }}>
              <label style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.1em' }}>Timezone *</label>
              <div style={{ position:'relative' }}>
                <select className="wiz-select" value={formData.timezone} onChange={update('timezone')}>
                  {getTimezoneOptions(formData.timezone).map(tz => <option key={tz.value} value={tz.value}>{tz.label}</option>)}
                </select>
                <ChevronRight style={{ position:'absolute', right:14, top:'50%', transform:'translateY(-50%) rotate(90deg)', width:16, height:16, color:'rgba(255,255,255,0.3)', pointerEvents:'none' }} />
              </div>
            </div>
            <div style={{ gridColumn:'1/-1' }}>
              <label style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.1em' }}>Location</label>
              <input
                type="text"
                className="wiz-input"
                placeholder="Central Park, NYC"
                value={formData.location}
                onChange={update('location')}
              />
            </div>
          </div>
        </div>
      );
    }

    // Events Step 3: Enterprise decision slide (not shown for RSVP-only events)
    if (!isVenue && !isRsvp && step === 3) {
      const isEnt = formData.isEnterpriseMode;
      return (
        <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
          <p className="wiz-question" style={{ fontSize:'clamp(1.3rem,3.5vw,2rem)', fontFamily:'var(--font-display)', fontWeight:800, color:'#fff', lineHeight:1.15, marginBottom:8 }}>
            Choose your event mode.
          </p>
          <p style={{ fontSize:14, color:'rgba(255,255,255,0.35)', marginBottom:24 }}>
            This setting <span style={{ color:'rgba(239,68,68,0.85)', fontWeight:700 }}>cannot be changed</span> after your event is created. Choose carefully.
          </p>

          {/* Mode cards */}
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:20 }}>
            {/* Standard */}
            <button type="button"
              onClick={() => setFormData(p => ({ ...p, isEnterpriseMode: false }))}
              style={{
                background: !isEnt ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.02)',
                border: `1.5px solid ${!isEnt ? 'rgba(255,255,255,0.3)' : 'rgba(255,255,255,0.07)'}`,
                borderRadius:14, padding:'16px 14px', cursor:'pointer', textAlign:'left',
                transition:'all 0.2s ease',
                boxShadow: !isEnt ? '0 0 24px rgba(255,255,255,0.06)' : 'none',
              }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                <div style={{ width:28, height:28, borderRadius:8, background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.12)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <Calendar style={{ width:14, height:14, color:'rgba(255,255,255,0.6)' }} />
                </div>
                <span style={{ fontSize:13, fontWeight:700, color: !isEnt ? '#fff' : 'rgba(255,255,255,0.4)' }}>Standard</span>
                {!isEnt && <span style={{ marginLeft:'auto', fontSize:10, background:'rgba(255,255,255,0.1)', borderRadius:6, padding:'2px 6px', color:'rgba(255,255,255,0.5)', fontWeight:600 }}>Selected</span>}
              </div>
              <ul style={{ fontSize:12, color:'rgba(255,255,255,0.35)', lineHeight:1.7, listStyle:'none', padding:0, margin:0 }}>
                {['Open RSVP link', 'Team chat & tasks', 'Polls & budget', 'Unlimited members'].map(f => (
                  <li key={f} style={{ display:'flex', alignItems:'center', gap:5 }}>
                    <span style={{ color:'rgba(255,255,255,0.2)', fontSize:10 }}>✓</span>{f}
                  </li>
                ))}
              </ul>
            </button>

            {/* Enterprise */}
            <button type="button"
              onClick={() => setFormData(p => ({ ...p, isEnterpriseMode: true }))}
              style={{
                background: isEnt ? 'rgba(47,91,255,0.12)' : 'rgba(47,91,255,0.03)',
                border: `1.5px solid ${isEnt ? 'rgba(47,91,255,0.55)' : 'rgba(47,91,255,0.15)'}`,
                borderRadius:14, padding:'16px 14px', cursor:'pointer', textAlign:'left',
                transition:'all 0.2s ease',
                boxShadow: isEnt ? '0 0 28px rgba(47,91,255,0.15)' : 'none',
              }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                <div style={{ width:28, height:28, borderRadius:8, background:'rgba(47,91,255,0.15)', border:'1px solid rgba(47,91,255,0.3)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                  <Zap style={{ width:14, height:14, color:'#5f84ff' }} />
                </div>
                <span style={{ fontSize:13, fontWeight:700, color: isEnt ? '#90abff' : 'rgba(47,91,255,0.5)' }}>Enterprise</span>
                {isEnt && <span style={{ marginLeft:'auto', fontSize:10, background:'rgba(47,91,255,0.2)', borderRadius:6, padding:'2px 6px', color:'#90abff', fontWeight:600 }}>Selected</span>}
              </div>
              <ul style={{ fontSize:12, color: isEnt ? 'rgba(165,180,252,0.6)' : 'rgba(47,91,255,0.4)', lineHeight:1.7, listStyle:'none', padding:0, margin:0 }}>
                {['Personalized QR invites', 'Check-in dashboard', 'Everything in Standard', 'Table assignments + groups'].map(f => (
                  <li key={f} style={{ display:'flex', alignItems:'center', gap:5 }}>
                    <span style={{ color: isEnt ? 'rgba(47,91,255,0.6)' : 'rgba(47,91,255,0.25)', fontSize:10 }}>✦</span>{f}
                  </li>
                ))}
              </ul>
            </button>
          </div>

          {/* When to use Enterprise, description block */}
          <div style={{
            background:'rgba(47,91,255,0.05)', border:'1px solid rgba(47,91,255,0.12)',
            borderRadius:14, padding:'14px 16px',
          }}>
            <p style={{ fontSize:12, fontWeight:700, color:'rgba(47,91,255,0.7)', marginBottom:8, textTransform:'uppercase', letterSpacing:'0.08em' }}>When to use Enterprise mode</p>
            <p style={{ fontSize:13, color:'rgba(255,255,255,0.35)', lineHeight:1.65, margin:0 }}>
              Enterprise is built for <strong style={{ color:'rgba(255,255,255,0.55)' }}>large, ticketed, or access-controlled events</strong> where every guest gets a unique QR invite: galas, conferences, award nights, corporate parties with 50+ attendees. If your event is open RSVP or team-only, Standard is all you need.
            </p>
          </div>

          {/* Immutable warning */}
          <div style={{ display:'flex', alignItems:'flex-start', gap:8, marginTop:14, padding:'10px 14px', background:'rgba(239,68,68,0.07)', border:'1px solid rgba(239,68,68,0.18)', borderRadius:10 }}>
            <AlertCircle style={{ width:14, height:14, color:'#f87171', flexShrink:0, marginTop:1 }} />
            <p style={{ fontSize:12, color:'rgba(239,68,68,0.75)', lineHeight:1.5, margin:0 }}>
              <strong>This cannot be changed later.</strong> Once your event is created, switching between Standard and Enterprise modes is not possible.
            </p>
          </div>
        </div>
      );
    }

    // Name step (events: 4, rsvp: 3, venue: 2)
    const nameStep = isVenue ? 2 : (isRsvp ? 3 : 4);
    if (step === nameStep) {
      return (
        <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
          <div>
            <p className="wiz-question" style={{ fontSize:'clamp(1.5rem,4vw,2.2rem)', fontFamily:'var(--font-display)', fontWeight:800, color:'#fff', lineHeight:1.15, marginBottom:8 }}>
              {isVenue ? 'Who manages this venue?' : 'Who\'s organizing this?'}
            </p>
            <p style={{ fontSize:14, color:'rgba(255,255,255,0.35)', marginBottom:24 }}>
              {isVenue ? 'We\'ll send important updates here and you\'ll use this to log back in.' : 'This is your organizer account. Keep these details safe.'}
            </p>
          </div>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
            <div style={{ gridColumn:'1/-1' }}>
              <label style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.1em' }}>{isVenue ? 'Manager name' : 'Your name'} *</label>
              <input
                ref={firstInputRef}
                type="text"
                className={`wiz-input${isVenue ? ' wiz-input-venue' : ''}${err.organizerName ? ' error' : ''}`}
                placeholder={isVenue ? 'Head Manager' : 'Alex Smith'}
                value={formData.organizerName}
                onChange={update('organizerName')}
                onKeyDown={e => e.key === 'Enter' && next()}
              />
              {err.organizerName && <p style={{ fontSize:12, color:'#f87171', marginTop:5 }}>{err.organizerName}</p>}
            </div>
            <div style={{ gridColumn:'1/-1' }}>
              <label style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.1em' }}>{isVenue ? 'Manager email' : 'Your email'} *</label>
              <input
                type="email"
                className={`wiz-input${isVenue ? ' wiz-input-venue' : ''}${err.organizerEmail ? ' error' : ''}`}
                placeholder={isVenue ? 'manager@restaurant.com' : 'alex@company.com'}
                value={formData.organizerEmail}
                onChange={update('organizerEmail')}
                onKeyDown={e => e.key === 'Enter' && next()}
              />
              {err.organizerEmail && <p style={{ fontSize:12, color:'#f87171', marginTop:5 }}>{err.organizerEmail}</p>}
            </div>
          </div>
        </div>
      );
    }

    // Password step (events: 5, rsvp: 4, venue: 3)
    const pwStep = isVenue ? 3 : (isRsvp ? 4 : 5);
    if (step === pwStep) {
      const secondPwLabel = isVenue ? 'Staff password' : 'Event password';
      const secondPwHint  = isVenue
        ? 'PIN your floor staff enter to log in (optional)'
        : isRsvp
          ? "Restrict who can access your event space (optional). Your RSVP page itself stays open to anyone with the link, unless you password-protect it separately in RSVP Settings."
          : 'Restrict who can join your event (optional)';
      return (
        <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
          <div>
            <p className="wiz-question" style={{ fontSize:'clamp(1.5rem,4vw,2.2rem)', fontFamily:'var(--font-display)', fontWeight:800, color:'#fff', lineHeight:1.15, marginBottom:8 }}>
              {isVenue ? 'Secure your venue.' : 'Secure your event.'}
            </p>
            <p style={{ fontSize:14, color:'rgba(255,255,255,0.35)', marginBottom:24 }}>
              {isVenue
                ? 'Set a password to manage the venue. Share a staff PIN with your team.'
                : 'Your account password gets you back in from any device.'}
            </p>
          </div>
          <div>
            <label style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.1em' }}>
              <Lock style={{ width:12, height:12, display:'inline', marginRight:5, verticalAlign:'middle' }} />
              {isVenue ? 'Organizer password' : 'Account password'} *
            </label>
            <div style={{ position:'relative' }}>
              <input
                ref={firstInputRef}
                type={showPw ? 'text' : 'password'}
                className={`wiz-input${isVenue ? ' wiz-input-venue' : ''}${err.accountPassword ? ' error' : ''}`}
                style={{ paddingRight:48 }}
                placeholder="Minimum 4 characters"
                value={formData.accountPassword}
                onChange={update('accountPassword')}
                minLength={4}
                onKeyDown={e => e.key === 'Enter' && next()}
              />
              <button type="button" onClick={() => setShowPw(p => !p)}
                style={{ position:'absolute', right:14, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'rgba(255,255,255,0.35)', display:'flex', alignItems:'center' }}>
                {showPw ? <EyeOff style={{ width:18, height:18 }} /> : <Eye style={{ width:18, height:18 }} />}
              </button>
            </div>
            {err.accountPassword && <p style={{ fontSize:12, color:'#f87171', marginTop:5, display:'flex', alignItems:'center', gap:5 }}><AlertCircle style={{ width:12, height:12 }} />{err.accountPassword}</p>}
          </div>
          <div>
            <label style={{ fontSize:12, color:'rgba(255,255,255,0.4)', display:'block', marginBottom:6, textTransform:'uppercase', letterSpacing:'0.1em' }}>
              <Shield style={{ width:12, height:12, display:'inline', marginRight:5, verticalAlign:'middle' }} />
              {secondPwLabel} <span style={{ color:'rgba(255,255,255,0.2)', textTransform:'none', letterSpacing:'normal', fontSize:11 }}>(optional)</span>
            </label>
            <div style={{ position:'relative' }}>
              <input
                type={showPw2 ? 'text' : 'password'}
                className={`wiz-input${isVenue ? ' wiz-input-venue' : ''}`}
                style={{ paddingRight:48 }}
                placeholder={isVenue ? 'Staff PIN or password' : 'Leave empty for open access'}
                value={isVenue ? formData.staffPassword : formData.password}
                onChange={update(isVenue ? 'staffPassword' : 'password')}
              />
              <button type="button" onClick={() => setShowPw2(p => !p)}
                style={{ position:'absolute', right:14, top:'50%', transform:'translateY(-50%)', background:'none', border:'none', cursor:'pointer', color:'rgba(255,255,255,0.35)', display:'flex', alignItems:'center' }}>
                {showPw2 ? <EyeOff style={{ width:18, height:18 }} /> : <Eye style={{ width:18, height:18 }} />}
              </button>
            </div>
            <p style={{ fontSize:12, color:'rgba(255,255,255,0.25)', marginTop:6 }}>{secondPwHint}</p>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:10, marginTop:4, paddingTop:16, borderTop:'1px solid rgba(255,255,255,0.08)' }}>
            {LEGAL_CHECKS.map(c => (
              <div key={c.key}>
                <label style={{ display:'flex', alignItems:'flex-start', gap:10, cursor:'pointer', fontSize:12.5, lineHeight:1.5, color:'rgba(255,255,255,0.55)' }}>
                  <input
                    type="checkbox"
                    checked={!!formData[c.key]}
                    onChange={(e) => {
                      onUserInput?.();
                      const checked = e.target.checked;
                      setFormData(p => ({ ...p, [c.key]: checked }));
                      if (checked) setLocalErr(prev => { const n = { ...prev }; delete n[c.key]; return n; });
                    }}
                    style={{ marginTop:3, width:16, height:16, flexShrink:0, accentColor: accent, cursor:'pointer' }}
                  />
                  <span>{c.label}</span>
                </label>
                {err[c.key] && <p style={{ fontSize:12, color:'#f87171', marginTop:4, marginLeft:26, display:'flex', alignItems:'center', gap:5 }}><AlertCircle style={{ width:12, height:12 }} />{err[c.key]}</p>}
              </div>
            ))}
          </div>
        </div>
      );
    }

    return null;
  };

  const isLastStep = step === totalSteps - 1;
  const canSkipType = step === 0; // type picker: can proceed without selection

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:0 }}>
      {/* Progress bar */}
      <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:36 }}>
        {Array.from({ length: totalSteps }).map((_, i) => (
          <div key={i} className="wiz-pill" style={{
            background: i < step ? accent : i === step ? accent : 'rgba(255,255,255,0.1)',
            width: i === step ? 40 : 28,
            opacity: i > step ? 0.4 : 1,
          }} />
        ))}
        <span style={{ marginLeft:'auto', fontSize:12, color:'rgba(255,255,255,0.3)', whiteSpace:'nowrap' }}>
          Step {step + 1} of {totalSteps}
        </span>
      </div>

      {/* Draft recovery banner */}
      {draftBannerVisible && pendingDraft && (
        <div style={{
          background: 'rgba(47,91,255,0.08)',
          border: '1px solid rgba(47,91,255,0.2)',
          borderRadius: 12,
          padding: '14px 16px',
          marginBottom: 24,
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          flexWrap: 'wrap',
        }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ fontSize: 14, fontWeight: 600, color: '#90abff', margin: 0 }}>
              You were in the middle of creating an event.
            </p>
            <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', margin: '3px 0 0' }}>
              Want to continue where you left off?
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setFormData(pendingDraft.formData);
              setStep(pendingDraft.step);
              setStepKey(k => k + 1);
              setPendingDraft(null);
              setDraftBannerVisible(false);
            }}
            style={{
              background: '#2f5bff', color: '#fff', border: 'none',
              borderRadius: 8, padding: '8px 16px',
              fontSize: 13, fontWeight: 700, cursor: 'pointer', flexShrink: 0,
            }}
          >
            Continue
          </button>
          <button
            type="button"
            onClick={() => {
              localStorage.removeItem('planit_event_draft');
              setPendingDraft(null);
              setDraftBannerVisible(false);
            }}
            style={{
              background: 'transparent', color: 'rgba(255,255,255,0.4)',
              border: '1px solid rgba(255,255,255,0.1)',
              borderRadius: 8, padding: '8px 16px',
              fontSize: 13, fontWeight: 600, cursor: 'pointer', flexShrink: 0,
            }}
          >
            Start Fresh
          </button>
        </div>
      )}

      {/* Animated step content */}
      <div key={stepKey} className={dir === 'forward' ? 'wiz-forward' : 'wiz-back'}
        onPaste={onUserPaste}
        style={{ minHeight:260 }}>
        {renderStatusCard()}
            {renderStep()}
            {requiresVerification && (
              <div style={{ marginTop:18, display:'flex', flexDirection:'column', alignItems:'center', gap:10 }}>
                <p style={{ color:'rgba(255,255,255,0.65)', fontSize:13, textAlign:'center' }}>Please complete the verification step to continue.</p>
                <TurnstileWidget onToken={onCaptchaToken} resetKey={captchaResetKey} theme="dark" />
              </div>
            )}
      </div>

      {/* Nav */}
      <div style={{ display:'flex', gap:10, marginTop:36 }}>
        {step > 0 && (
          <button className="wiz-btn-back" type="button" onClick={() => go(-1)}>
            <ArrowRight style={{ width:14, height:14, transform:'rotate(180deg)' }} /> Back
          </button>
        )}
        <button
          className={`wiz-btn-next${isVenue ? ' venue' : ''}`}
          type="button"
          onClick={next}
          disabled={loading}
          style={{ flex:1, justifyContent:'center' }}
        >
          {loading ? (
            <><div style={{ width:16, height:16, border:`2px solid ${isVenue ? 'rgba(255,255,255,0.4)' : 'rgba(0,0,0,0.3)'}`, borderTop:`2px solid ${isVenue ? '#fff' : '#111'}`, borderRadius:'50%', animation:'spin 0.7s linear infinite' }} />Creating…</>
          ) : isLastStep ? (
            <>{isVenue ? 'Launch venue' : 'Create event'} <ArrowRight style={{ width:16, height:16 }} /></>
          ) : (
            <>Continue <ArrowRight style={{ width:16, height:16 }} /></>
          )}
        </button>
      </div>

      {/* Keyboard hint */}
      <p style={{ fontSize:11, color:'rgba(255,255,255,0.18)', textAlign:'center', marginTop:12 }}>
        Press Enter to continue · Esc to go back
      </p>
    </div>
  );
}

function HeroProductPreview() {
  const [tab, setTab] = useState('overview');
  const tabs = [
    { id: 'overview', label: 'Overview', icon: Layers },
    { id: 'guests', label: 'Guests', icon: Users },
    { id: 'insights', label: 'Insights', icon: BarChart3 },
  ];

  const overview = (
    <motion.div key="overview" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3 }}>
      <div className="hero-preview-heading"><div><p>Tuesday, September 17</p><h3>Spring Product Forum</h3></div><button>View agenda</button></div>
      <div className="hero-preview-summary">
        <div className="hero-preview-card"><div className="hero-preview-card-label"><strong>Today&apos;s plan</strong><span>3 items</span></div><div className="hero-preview-schedule"><span className="hero-preview-time">09:30</span><div className="hero-preview-event"><strong>Speaker arrivals</strong><span>Green room · 8 guests</span></div></div><div className="hero-preview-schedule"><span className="hero-preview-time">10:00</span><div className="hero-preview-event teal"><strong>Keynote begins</strong><span>Main stage · 420 seats</span></div></div></div>
        <div className="hero-preview-card"><div className="hero-preview-card-label"><span>Expected guests</span><TrendingUp /></div><div className="hero-preview-number">428</div><div className="hero-preview-positive"><TrendingUp /> 14% ahead of plan</div></div>
      </div>
      <div className="hero-preview-bottom"><div className="hero-preview-card"><div className="hero-preview-card-label"><strong>Team checklist</strong><span>3 of 4</span></div><div className="hero-preview-check"><i><Check /></i>Confirm signage</div><div className="hero-preview-check"><i><Check /></i>Send guest reminder</div><div className="hero-preview-check"><i />Review catering count</div></div><div className="hero-preview-card"><div className="hero-preview-card-label"><strong>RSVP trend</strong><span>Live</span></div><div className="hero-preview-bars"><span /><span /><span /><span /><span /><span /></div></div></div>
    </motion.div>
  );

  const guests = (
    <motion.div key="guests" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3 }}>
      <div className="hero-preview-heading"><div><p>Spring Product Forum</p><h3>Guest list</h3></div><button>Export list</button></div>
      <div className="hero-preview-guest-grid"><div className="hero-preview-card hero-preview-guest-card"><span>Confirmed</span><strong>428</strong><em>+14% this week</em></div><div className="hero-preview-card hero-preview-guest-card"><span>Pending</span><strong>36</strong><em>8 need a nudge</em></div><div className="hero-preview-card hero-preview-guest-card"><span>Checked in</span><strong>0</strong><em>Event day view</em></div></div>
      <div className="hero-preview-guest-list"><div className="hero-preview-guest-row" style={{ color: 'rgba(255,255,255,0.3)', fontSize: 8, textTransform: 'uppercase', letterSpacing: '.08em', fontWeight: 800 }}><span>Guest</span><span>Source</span><span>Status</span></div><div className="hero-preview-guest-row"><span className="hero-preview-person"><i>AM</i>Alex Morgan</span><span>Team</span><span className="hero-preview-status">Confirmed</span></div><div className="hero-preview-guest-row"><span className="hero-preview-person"><i className="green">JC</i>Jamie Chen</span><span>Invite</span><span className="hero-preview-status">Confirmed</span></div><div className="hero-preview-guest-row"><span className="hero-preview-person"><i className="orange">KT</i>Kai Taylor</span><span>Invite</span><span className="hero-preview-status pending">Pending</span></div></div>
    </motion.div>
  );

  const insights = (
    <motion.div key="insights" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3 }}>
      <div className="hero-preview-heading"><div><p>Spring Product Forum</p><h3>Live insights</h3></div><button>Last 30 days</button></div>
      <div className="hero-preview-insights"><div className="hero-preview-card"><div className="hero-preview-card-label"><strong>Response momentum</strong><span>Aug 18 to Sep 17</span></div><div className="hero-preview-chart"><svg viewBox="0 0 500 140" preserveAspectRatio="none" aria-hidden="true"><path d="M0 116 C60 90 80 103 130 86 S220 62 276 78 S345 45 400 57 S460 35 500 24" fill="none" stroke="#5f84ff" strokeWidth="4" strokeLinecap="round" /><path d="M0 116 C60 90 80 103 130 86 S220 62 276 78 S345 45 400 57 S460 35 500 24 L500 140 L0 140Z" fill="url(#heroChartFade)" opacity=".25" /><defs><linearGradient id="heroChartFade" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#5f84ff" /><stop offset="1" stopColor="#5f84ff" stopOpacity="0" /></linearGradient></defs></svg></div></div><div className="hero-preview-card hero-preview-forecast"><div className="hero-preview-card-label"><strong>Attendance forecast</strong><TrendingUp /></div><strong>91%</strong><p>Based on responses, reminders, and guest history.</p></div></div>
      <div className="hero-preview-note"><TrendingUp /> Response rate is up 14% since your last reminder.</div>
    </motion.div>
  );

  const content = tab === 'guests' ? guests : tab === 'insights' ? insights : overview;
  return (
    <Reveal delay={180} className="w-full max-w-6xl mx-auto mt-16 sm:mt-24">
      <div className="hero-preview-shell">
        <div className="hero-preview-chrome"><div className="hero-preview-brand"><span className="hero-preview-brand-mark"><Calendar /></span>PlanIt workspace</div><div className="hero-preview-chrome-meta"><span className="hero-preview-live"><i /> Live</span><span>planit.app/workspace</span></div></div>
        <div className="hero-preview-tabs" role="tablist" aria-label="Product preview views">{tabs.map(({ id, label, icon: Icon }) => <button key={id} className={`hero-preview-tab ${tab === id ? 'active' : ''}`} role="tab" aria-selected={tab === id} onClick={() => setTab(id)}><Icon className="inline-block w-3 h-3 mr-1.5" />{label}</button>)}</div>
        <div className="hero-preview-body">
          <aside className="hero-preview-rail"><div className="hero-preview-rail-label">Workspace</div><div className={`hero-preview-rail-item ${tab === 'overview' ? 'active' : ''}`}><Layers />Overview</div><div className="hero-preview-rail-item"><MessageSquare />Updates</div><div className={`hero-preview-rail-item ${tab === 'guests' ? 'active' : ''}`}><Users />Guests</div><div className="hero-preview-rail-item"><FileText />Details</div><div className="hero-preview-rail-label mt-5">Operations</div><div className="hero-preview-rail-item"><QrCode />Check-in</div><div className={`hero-preview-rail-item ${tab === 'insights' ? 'active' : ''}`}><BarChart3 />Insights</div></aside>
          <main className="hero-preview-main"><AnimatePresence mode="wait" initial={false}>{content}</AnimatePresence></main>
        </div>
      </div>
    </Reveal>
  );
}

let homePreloadShown = false;

export default function Home() {
  const { wl, isWL } = useWhiteLabel();
  const wlName    = isWL ? (wl?.branding?.companyName || wl?.clientName || '') : '';
  const wlLogo    = isWL ? (wl?.branding?.logoUrl    || '') : '';
  const wlPrimary = isWL ? (wl?.branding?.primaryColor || '') : '';
  // Pages content from WL portal
  const wlPages   = isWL ? (wl?.pages  || {}) : {};
  const wlFeatures= isWL ? (wl?.features || {}) : {};
  // Home page overrides
  const heroHeadline    = wlPages?.home?.headline    || '';
  const heroSubheadline = wlPages?.home?.subheadline || '';
  const heroCta         = wlPages?.home?.ctaText     || '';
  const heroImage       = wlPages?.home?.heroImageUrl|| '';
  const navigate = useNavigate();
  const location = useLocation();
  // Opening cinematic, plays once per browser session, skipped entirely on
  // white-label domains (they get their own branded hero, not PlanIt's).
  // The opening cinematic is retired: the PlanIt loading screen below is the only
  // loader. To bring the cinematic back, restore the old initial value:
  //   !isWL && typeof window !== 'undefined' && !sessionStorage.getItem('planit_intro_played')
  const [showIntro, setShowIntro] = useState(false);
  // Loading screen (counter + curtain). Plays once per full page load, never on
  // white-label domains. The intro cinematic mounts underneath it so the curtain
  // opens onto the page.
  const siteReady = useSiteReady();
  const [preloading, setPreloading] = useState(() => !isWL && !homePreloadShown);
  const [introGate, setIntroGate] = useState(() => !(!isWL && !homePreloadShown));
  const revealFromPreloader = useCallback(() => setIntroGate(true), []);
  const finishPreloader = useCallback(() => { homePreloadShown = true; setPreloading(false); }, []);
  // Scroll lock: held while the loader or the intro is up, always released after.
  const scrollLocked = preloading || (showIntro && introGate);
  useEffect(() => {
    if (!scrollLocked) return;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, [scrollLocked]);

  // Blur-rise entrance used across the hero. It waits for the loader's iris to
  // start opening (introGate), so the hero plays as the page is revealed
  // instead of finishing unseen behind the loader.
  const blurHidden = { opacity: 0, y: 22 }; // transform + opacity only: blur filters stutter on phones
  const blurShown  = { opacity: 1, y: 0 };
  const enter = (delay) => ({
    initial: blurHidden,
    animate: introGate ? blurShown : blurHidden,
    transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: delay * 0.5 },
  });

  const dismissIntro = () => {
    sessionStorage.setItem('planit_intro_played', '1');
    setShowIntro(false);
  };
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [navScrolled, setNavScrolled] = useState(false);
  // Nav starts transparent over the hero, then picks up a blurred surface once scrolled
  useEffect(() => {
    const onScroll = () => setNavScrolled(window.scrollY > 48);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  const [mode, setMode] = useState('standard');
  const [formData, setFormData] = useState({
    subdomain: '', title: '', description: '', date: '', timezone: getUserTimezone(), location: '',
    organizerName: '', organizerEmail: '', accountPassword: '', password: '', staffPassword: '',
    isEnterpriseMode: false, maxParticipants: 10000,
    agreeTerms: false, agreeResponsible: false, agreeGuestData: false, agreeAge: false,
  });
  // Default the timezone from the visitor's location (IP geo headers via the
  // backend, else browser tz). Never overrides a zone the user already picked.
  useEffect(() => {
    let cancelled = false;
    detectTimezone(() => eventAPI.detectTimezone()).then((tz) => {
      if (cancelled || !tz) return;
      setFormData(f => (f._tzTouched || f.timezone !== getUserTimezone()) ? f : { ...f, timezone: tz });
    });
    return () => { cancelled = true; };
  }, []);
  const [loading, setLoading] = useState(false);
  const [created, setCreated] = useState(null);
  const [showAd, setShowAd] = useState(false);
  const [organizerRecoveryCode, setOrganizerRecoveryCode] = useState(null); // shown once after event creation
  const [showPassword, setShowPassword] = useState(false);
  const [showAccountPassword, setShowAccountPassword] = useState(false);
  const [fieldErrors, setFieldErrors] = useState({});
  const [selectedBranch, setSelectedBranch] = useState(null); // null | 'events' | 'venue' | 'rsvp'
  const [wizardKey, setWizardKey] = useState(0); // increment to hard-reset the wizard
  const [wizardOpen, setWizardOpen] = useState(false); // fullscreen wizard overlay
  const wizardSubmittedRef = useRef(false); // flipped true on successful event creation
  const wizardStepRef = useRef(null);       // populated by OnboardingWizard with { goTo(n), getStep() }
  const [abuseStatus, setAbuseStatus] = useState(null);
  const [requiresVerification, setRequiresVerification] = useState(false);
  const [turnstileToken, setTurnstileToken] = useState('');
  const [captchaResetKey, setCaptchaResetKey] = useState(0);
  const eventFormTimingRef = useRef({ pageLoadedAt: Date.now(), formStartedAt: 0, firstInputAt: 0, largestPasteChars: 0, largestPasteElapsedMs: 0 });
  // On white-label domains, skip the branch selector and go straight to event creation
  useEffect(() => { if (isWL) { setSelectedBranch('events'); setShowIntro(false); } }, [isWL]);
  // The branded WL landing page links here so clients can launch the same
  // protected, full-feature wizard used on the standard PlanIt homepage.
  useEffect(() => {
    if (isWL && new URLSearchParams(window.location.search).get('new') === '1') {
      setSelectedBranch('events');
      setWizardOpen(true);
    }
  }, [isWL]);

  // Close wizard on Escape key
  useEffect(() => {
    const handler = (e) => { if (e.key === 'Escape') setWizardOpen(false); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const selectBranch = (branch) => {
    setSelectedBranch(branch);
    setMode(branch === 'venue' ? 'table-service' : branch === 'rsvp' ? 'rsvp' : 'standard');
    setWizardKey(k => k + 1); // reset wizard to step 0
    setTimeout(() => {
      document.getElementById(branch === 'venue' ? 'planit-venue' : branch === 'rsvp' ? 'planit-rsvp' : 'planit-events')
        ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 50);
  };

  const handleTitleChange = (e) => {
    const title = e.target.value;
    setFormData(prev => ({ ...prev, title, subdomain: prev._subdomainTouched ? prev.subdomain : makeSubdomain(title) }));
  };
  const update = (field) => (e) => {
    if (!eventFormTimingRef.current.firstInputAt) eventFormTimingRef.current.firstInputAt = Date.now();
    setFormData(prev => ({ ...prev, [field]: e.target.value, ...(field === 'subdomain' ? { _subdomainTouched: true } : {}), ...(field === 'timezone' ? { _tzTouched: true } : {}) }));
  };

  // Sanitise a string: trim whitespace, collapse internal whitespace
  const sanitize = (str) => (str || '').trim().replace(/\s+/g, ' ');

  const handleSubmit = async (e) => {
    if (e && e.preventDefault) e.preventDefault();

    //  Client-side field validation 
    const errs = {};
    const isTS = mode === 'table-service';
    if (!formData.title.trim())            errs.title          = isTS ? 'Restaurant name is required.' : 'Event title is required.';
    if (!isTS && !formData.date)           errs.date           = 'Date and time is required.';
    if (!isTS && !formData.timezone)       errs.timezone       = 'Timezone is required.';
    if (!formData.organizerName.trim())    errs.organizerName  = isTS ? 'Manager name is required.' : 'Your name is required.';
    if (!formData.organizerEmail.trim())   errs.organizerEmail = isTS ? 'Manager email is required.' : 'Your email is required.';
    else if (!validateEmail(formData.organizerEmail.trim()))
                                           errs.organizerEmail = 'Please enter a valid email address.';
    if (!formData.accountPassword)         errs.accountPassword = 'Account password is required.';
    else if (formData.accountPassword.length < 4)
                                           errs.accountPassword = 'Password must be at least 4 characters.';
    if (isTS && formData.staffPassword && formData.staffPassword.length < 4)
                                           errs.staffPassword  = 'Staff PIN must be at least 4 characters.';
    for (const c of LEGAL_CHECKS) if (!formData[c.key]) errs[c.key] = c.error;

    if (Object.keys(errs).length > 0) {
      setFieldErrors(errs);
      // Scroll to first error
      const firstField = document.querySelector('.field-error');
      if (firstField) firstField.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    setFieldErrors({});
    setLoading(true);

    const dateValue = (!isTS && formData.date) ? localDateTimeToUTC(formData.date, formData.timezone) : undefined;
    const payload = {
      title:          sanitize(formData.title),
      description:    sanitize(formData.description),
      ...(dateValue ? { date: dateValue, timezone: formData.timezone } : {}),
      location:       sanitize(formData.location),
      organizerName:  sanitize(formData.organizerName),
      organizerEmail: sanitize(formData.organizerEmail),
      accountPassword:formData.accountPassword,
      password:       formData.password || undefined,
      staffPassword:  (isTS && formData.staffPassword) ? formData.staffPassword : undefined,
      subdomain:      formData.subdomain || makeSubdomain(formData.title) || `event-${Date.now()}`,
      isEnterpriseMode: mode === 'enterprise' || formData.isEnterpriseMode,
      isTableServiceMode: isTS,
      eventType:      mode === 'rsvp' ? 'rsvpOnly' : 'standard',
      maxParticipants: formData.maxParticipants,
      agreedToTerms:  true,
      legalVersion:   LEGAL_VERSION,
      ...(turnstileToken ? { turnstileToken } : {}),
      behavior: { ...eventFormTimingRef.current, submittedAt: Date.now(), formStartedAt: eventFormTimingRef.current.formStartedAt || eventFormTimingRef.current.pageLoadedAt },
      browserMeta: {
        webdriver: navigator.webdriver === true,
        language: navigator.language || '',
        platform: navigator.platform || '',
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || '',
        hardwareConcurrency: navigator.hardwareConcurrency || 0,
        deviceMemory: navigator.deviceMemory || 0,
        plugins: navigator.plugins ? Array.from(navigator.plugins).slice(0, 5).map(p => p.name) : [],
        userAgent: navigator.userAgent || '',
      },
    };
    try {
      const response = await eventAPI.create(payload);
      localStorage.setItem('eventToken', response.data.token);
      localStorage.setItem('username', sanitize(formData.organizerName));
      setCreated(response.data.event);
      if (response.data.recoveryCode) {
        setOrganizerRecoveryCode(response.data.recoveryCode);
      }
      // Draft cleanup and completion tracking
      wizardSubmittedRef.current = true;
      localStorage.removeItem('planit_event_draft');
      trackFeature('event_creation_complete');
      trackGAEvent('event_created', { event_type: formData.isEnterpriseMode ? 'enterprise' : 'standard' });
      setRequiresVerification(false);
      setAbuseStatus(null);
      // Cross-promo ad disabled, don't show it after event creation.
      // setShowAd(true);
      return true;
    } catch (error) {
      const data = error.response?.data;

      // Friendly labels for server field paths
      const FIELD_LABELS = {
        date:            'Date and time',
        timezone:        'Timezone',
        title:           mode === 'table-service' ? 'Restaurant name' : 'Event title',
        organizerName:   mode === 'table-service' ? 'Manager name' : 'Your name',
        organizerEmail:  mode === 'table-service' ? 'Manager email' : 'Your email',
        accountPassword: 'Account password',
        password:        mode === 'table-service' ? 'Staff PIN' : 'Event password',
        subdomain:       mode === 'table-service' ? 'Restaurant URL' : 'Event URL',
        agreedToTerms:   'Terms agreement',
      };

      if (data?.requiresVerification || data?.code === 'VERIFICATION_REQUIRED' || data?.code === 'INVALID_VERIFICATION') {
        setRequiresVerification(true);
        setCaptchaResetKey(k => k + 1);
        setTurnstileToken('');
        setAbuseStatus({ title: data?.code === 'INVALID_VERIFICATION' ? 'Invalid Verification' : 'Verification Required', message: data?.userMessage || 'Please complete the verification step to continue.' });
        return;
      }
      if (['TRY_AGAIN_LATER', 'ADDITIONAL_REVIEW_REQUIRED', 'SUBMISSION_RECEIVED'].includes(data?.code)) {
        setAbuseStatus({ title: 'Please Try Again', message: data?.userMessage || 'We couldn’t complete your request right now. Please try again shortly.' });
        return;
      }

      if (data?.errors && Array.isArray(data.errors)) {
        const serverErrs = {};
        const toastMsgs = [];
        data.errors.forEach(e => {
          const path = e.path || e.param || '';
          const label = FIELD_LABELS[path] || path;
          const msg = e.msg || e.message || 'Invalid value';
          // Skip date errors entirely for table-service (shouldn't reach here but safety net)
          if (path === 'date' && mode === 'table-service') return;
          serverErrs[path] = `${label}: ${msg}`;
          toastMsgs.push(`${label}: ${msg}`);
        });
        setFieldErrors(serverErrs);
        if (toastMsgs.length === 1) {
          toast.error(toastMsgs[0]);
        } else if (toastMsgs.length > 1) {
          toast.error(`${toastMsgs.length} fields need attention:\n${toastMsgs.map(m => `• ${m}`).join('\n')}`, { duration: 6000 });
        }
      } else {
        const msg = data?.error || 'Failed to create';
        const isTS2 = mode === 'table-service';
        const isRsvp2 = mode === 'rsvp';
        const nameStepNum = isTS2 ? 2 : (isRsvp2 ? 3 : 4);

        if (msg.includes('already taken')) {
          // Taken slug, show inline error and navigate back to the URL step
          setFieldErrors({ subdomain: 'This URL is already taken. Please choose a different one.' });
          wizardStepRef.current?.goTo(1);
        } else if (msg.includes('not available')) {
          // Banned slug, show inline error and navigate back to the URL step
          setFieldErrors({ subdomain: 'This URL is not available. Please choose a different one.' });
          wizardStepRef.current?.goTo(1);
        } else if (msg.includes('not allowed') || msg.toLowerCase().includes('display name')) {
          // Banned organizer/display name, navigate back to the name step
          setFieldErrors({ organizerName: 'This display name is not allowed. Please choose a different one.' });
          wizardStepRef.current?.goTo(nameStepNum);
        } else if (msg.includes('email')) {
          setFieldErrors({ organizerEmail: 'Please enter a valid email address.' });
          wizardStepRef.current?.goTo(nameStepNum);
        } else if (msg.includes('password')) {
          setFieldErrors({ accountPassword: 'Password must be at least 6 characters.' });
        } else {
          toast.error(msg || 'Something went wrong. Please check your details and try again.');
        }
      }
      return false;
    } finally { setLoading(false); }
  };

  return (
    <div className={`min-h-screen text-white relative${isWL ? '' : ' lq-page'}`} style={{ background: 'var(--bg-base)', overflowX: 'clip', maxWidth: '100vw', isolation: 'isolate' }}>
      <InjectGlobalCSS />
      <PerfGovernor />
      <SmoothScroll enabled={!scrollLocked} />
      <AnimatePresence>
        {showIntro && introGate && <IntroCinematic onComplete={dismissIntro} />}
      </AnimatePresence>
      {preloading && <HomePreloader ready={siteReady} onReveal={revealFromPreloader} onDone={finishPreloader} />}
      {showAd && <CrossPlatformAd trigger="post_event_create" onClose={() => setShowAd(false)} />}
      {/* Recovery code modal, shown once when organizer sets an account password at creation */}
      {organizerRecoveryCode && (
        <RecoveryCodeModal
          code={organizerRecoveryCode}
          onDismiss={() => {
            setOrganizerRecoveryCode(null);
            // Navigate to the event after dismissing the modal
            if (created) {
              const base = created.subdomain ? `/e/${created.subdomain}` : `/event/${created.id}`;
              // Don't auto-navigate, let them read the screen first
            }
          }}
          eventSlug={created?.subdomain}
        />
      )}
      {isWL && <ScrollProgressBar />}
      {!isWL && <HomeScrollChrome rail={false} key={String(selectedBranch)} />}


      {/* Shared floating nav (same component as every public page) */}
      <PublicNav dark showCta={!selectedBranch} />

      <main className="relative" style={{ zIndex: 2, overflowX: 'clip', maxWidth: '100vw' }}>
        {/* HERO: cinematic skyline, clear message, and a responsive product preview */}
        <section id="hero-top" className="relative flex min-h-[100svh] items-center bg-[#05050f]" style={{ overflow: 'hidden', maxWidth: '100vw' }}>
          {(isWL && heroImage)
            ? <div aria-hidden="true" className="absolute inset-0" style={{ backgroundImage: `linear-gradient(180deg, rgba(5,5,15,.25), rgba(5,5,15,.85)), url(${heroImage})`, backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.72 }} />
            : isWL ? <CinematicGrid /> : (
              <div aria-hidden="true" className="pointer-events-none absolute inset-0" style={{
                zIndex: 0,
                backgroundImage: 'linear-gradient(180deg, rgba(5,5,15,.18) 0%, rgba(5,5,15,.25) 34%, rgba(5,5,15,.62) 68%, #05050f 100%), linear-gradient(90deg, rgba(5,5,15,.34) 0%, rgba(5,5,15,.02) 48%, rgba(5,5,15,.3) 100%), url("/media/planit-skyline.webp")',
                backgroundSize: 'cover',
                backgroundPosition: 'center 68%',
                transform: 'scale(1.015)',
              }} />
            )}
          {!isWL && <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-[1] opacity-30" style={{
            backgroundImage: 'linear-gradient(rgba(199,210,254,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(199,210,254,.04) 1px, transparent 1px)',
            backgroundSize: '80px 80px',
            maskImage: 'radial-gradient(ellipse at 50% 32%, black, transparent 78%)',
            WebkitMaskImage: 'radial-gradient(ellipse at 50% 32%, black, transparent 78%)',
          }} />}
          <div className="w-full relative" style={{ zIndex: 2 }}>
            <div className="max-w-[110rem] mx-auto px-4 sm:px-8 lg:px-12 pt-32 pb-14 sm:pt-40 sm:pb-28 lg:pt-44 lg:pb-36 text-center">

              {/* Badge */}
              <motion.div {...enter(0.4)} className="mb-8 sm:mb-10">
                <a href="/help#claude" className="inline-flex max-w-full items-center gap-3 rounded-lg border border-white/15 bg-white/[0.04] py-1.5 pl-1.5 pr-4 text-left backdrop-blur-sm transition-colors hover:border-white/30">
                  <span className="shrink-0 rounded-md bg-[var(--pi-blue-500)] px-2.5 py-1 font-mono text-[10px] font-medium uppercase tracking-[0.14em] text-white">{isWL ? 'Welcome' : 'One workspace'}</span>
                  <span className="min-w-0 break-words text-sm text-white/85">{isWL ? (wlName || 'Your event platform') : 'Plan it together. Run it seamlessly.'}</span>
                </a>
              </motion.div>

              {/* Main headline, word-by-word blur-in */}
              {(isWL && heroHeadline)
                ? (
                  <motion.h1 initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.9, delay:0.25 }}
                    className="font-syne font-black leading-[0.92] tracking-tight mb-8 text-white"
                    style={{ fontSize:'clamp(2.5rem,8.5vw,7rem)' }}>
                    {heroHeadline}
                  </motion.h1>
                ) : (
                  <div className="mb-6 sm:mb-8"><HeroHeadline start={introGate} /></div>
                )
              }

              {/* Sub-headline */}
              <motion.p {...enter(0.9)}
                className="text-base sm:text-lg md:text-xl text-white/80 max-w-sm sm:max-w-2xl mx-auto leading-snug font-light mb-10 sm:mb-12"
              >
                {isWL
                  ? (heroSubheadline || wlName || 'Your event platform')
                  : <>The complete workspace for events &amp; hospitality:{' '}
                      <span className="text-white font-normal">team chat, tasks, RSVP, check-in</span>
                      {' '}and a live floor manager for restaurants.</>
                }
              </motion.p>

              {/* CTAs: one primary, one secondary, two quiet paths */}
              <motion.div {...enter(1.1)} className="mb-10 sm:mb-12">
                <div className="flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
                  <MagneticLink href="#planit-events"
                    onClick={(e) => { e.preventDefault(); selectBranch('events'); }}
                    strength={8}
                    className="cta-primary group inline-flex min-h-[3.25rem] w-full items-center justify-center gap-2.5 rounded-xl bg-white px-7 text-[15px] font-semibold text-neutral-950 shadow-[0_12px_40px_-8px_rgba(47,91,255,0.55)] transition-colors hover:bg-white/90 sm:w-auto">
                    <Calendar className="h-4 w-4" />
                    {(isWL && heroCta) ? heroCta : 'Start with Events'}
                    <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </MagneticLink>
                  <MagneticLink href="#planit-venue"
                    onClick={(e) => { e.preventDefault(); selectBranch('venue'); }}
                    strength={8}
                    className="group inline-flex min-h-[3.25rem] w-full items-center justify-center gap-2.5 rounded-xl border border-white/20 bg-white/[0.04] px-7 text-[15px] font-medium text-white backdrop-blur-sm transition-colors hover:border-white/40 hover:bg-white/10 sm:w-auto">
                    <UtensilsCrossed className="h-4 w-4 text-[var(--pi-venue)]" />
                    Explore Venue
                    <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                  </MagneticLink>
                </div>
                <div className="mt-5 flex flex-wrap items-center justify-center gap-x-6 gap-y-1 text-sm text-white/70">
                  <a href="#create"
                    onClick={(e) => { e.preventDefault(); setSelectedBranch('events'); setMode('enterprise'); setWizardKey(k => k + 1); setTimeout(() => document.getElementById('planit-events')?.scrollIntoView({ behavior:'smooth', block:'start' }), 50); }}
                    className="inline-flex min-h-[2.75rem] items-center gap-1.5 underline-offset-4 transition-colors hover:text-white hover:underline">
                    <Zap className="h-3.5 w-3.5 text-[var(--pi-blue-300)]" />Enterprise check-in
                  </a>
                  <a href="#planit-rsvp"
                    onClick={(e) => { e.preventDefault(); selectBranch('rsvp'); }}
                    className="inline-flex min-h-[2.75rem] items-center gap-1.5 underline-offset-4 transition-colors hover:text-white hover:underline">
                    <CheckSquare className="h-3.5 w-3.5 text-emerald-300" />Just need RSVPs?
                  </a>
                </div>
              </motion.div>

              {/* Slug finder, jump to a private event */}
              <motion.div {...enter(1.2)} className="mb-10 sm:mb-12">
                <p className="t-label mb-3" style={{ color: 'rgba(255,255,255,0.55)' }}>Already have an event link?</p>
                <SlugFinder />
              </motion.div>

              {/* Trust facts: a ruled strip, not three identical tiles */}
              <motion.dl {...enter(1.3)} className="mx-auto mb-12 grid w-full max-w-3xl grid-cols-1 divide-y divide-white/10 border-y border-white/10 text-left sm:mb-14 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
                {[
                  { tag: 'Free forever',   desc: 'No credit card required' },
                  { tag: 'Zero accounts',  desc: 'Guests join by name instantly' },
                  { tag: 'Unlimited team', desc: 'Every organizer & vendor included' },
                ].map(({ tag, desc }, i) => (
                  <div key={tag} className="px-1 py-4 sm:px-6 sm:py-5">
                    <dt className="font-mono text-[10px] uppercase tracking-[0.14em] text-white/45">0{i + 1}</dt>
                    <dd className="mt-2 font-display text-lg font-semibold tracking-tight text-white">{tag}</dd>
                    <dd className="mt-1 text-[13px] leading-snug text-white/65">{desc}</dd>
                  </div>
                ))}
              </motion.dl>

              {/* What's inside */}
              {!isWL && (
                <motion.div {...enter(1.4)} className="mb-14 flex flex-col items-center gap-4 sm:mb-16">
                  <p className="t-label" style={{ color: 'rgba(255,255,255,0.55)' }}>One workspace for the whole event</p>
                  <ul className="flex max-w-md flex-wrap justify-center gap-2 sm:max-w-3xl" aria-label="What's included">
                    {['Team chat', 'Task lists', 'Live polls', 'RSVP', 'QR check-in', 'Seating', 'Claude AI'].map((w) => (
                      <li key={w} className="whitespace-nowrap rounded-md border border-white/12 bg-white/[0.04] px-3 py-1.5 text-sm text-white/90">{w}</li>
                    ))}
                  </ul>
                </motion.div>
              )}

              <ScrollFloat distance={36}><HeroProductPreview /></ScrollFloat>

              {/* Scroll indicator */}
              <div className="mt-10 sm:mt-16 flex flex-col items-center gap-2 cursor-default" style={{ opacity:0.5 }}>
                <span className="text-[10px] font-medium uppercase tracking-[0.25em] text-white/60">Scroll</span>
                <div style={{ width:1, height:36, background:'linear-gradient(to bottom, rgba(165,180,252,0.7), transparent)', animation:'scroll-indicator-bounce 2s ease-in-out infinite' }} />
              </div>
            </div>
          </div>
        </section>

        {!(selectedBranch || isWL) && <ProductShowcase />}

        {!(selectedBranch || isWL) && (
          <>
            <ZoomReveal
              id="real-events" media={MEDIA.home.hero} label="media.js → home.hero"
              kicker="// Made for real nights"
              title="Every event, in one place."
              text="Guest list, seating, door check-in and live updates, on a link your guests can open without an account."
            />
            <ScrollStory id="story" items={MEDIA.home.story} label="media.js → home.story" kicker="// From first invite to last dance" />
          </>
        )}

        {/* ═══════════════════════════════════════════════════════════
            SOCIAL PROOF STRIP, replaces branch gateway
        ═══════════════════════════════════════════════════════════ */}
        <section id="features" className="relative overflow-hidden" style={{ display: (selectedBranch || isWL) ? 'none' : 'block' }}>
          <Aurora palette="violet" density={0.00012} />
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 py-24 sm:py-32">

            {/* Section label */}
            <Reveal className="text-center mb-16">
              <p className="lq-kicker mb-6">{'// The complete event platform'}</p>
              <BlurText
                as="h2"
                text={'Everything in one place.\nNothing spread across five apps.'}
                accent={[4, 5, 6, 7, 8]}
                accentClass="text-white/40"
                className="lq-display text-white leading-[1.05] text-4xl sm:text-6xl lg:text-7xl mb-8"
              />
              <p className="text-white/75 text-base sm:text-lg font-light max-w-2xl mx-auto leading-snug">
                Most teams plan events across group chats, email threads, shared spreadsheets, and scattered notes.
                PlanIt puts it all in one workspace, with your whole team, from day one.
              </p>
            </Reveal>

            {/* Feature grid */}
            <motion.div
              className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-24"
              variants={GRID_PARENT} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.06 }}
            >
              {[
                { icon: MessageSquare, label: 'Real-time team chat',  desc: 'Your planning channel. Typing indicators, persistent history, instant delivery.' },
                { icon: ListChecks,    label: 'Shared task lists',    desc: 'Assign, prioritize, and track every action item from one shared view.' },
                { icon: BarChart3,     label: 'Live polls',           desc: 'Vote on venues, menus, dates. Results update on every screen in real time.' },
                { icon: Users,         label: 'Unlimited team',       desc: 'No per-seat pricing. Add every organizer, vendor, and volunteer for free.' },
                { icon: QrCode,        label: 'QR check-in',          desc: 'Personal QR invites for every guest. Scan at the door, see live attendance.' },
                { icon: Bot,           label: 'Claude AI co-pilot',   desc: 'Manage guests, send announcements, and check attendance, all conversationally.' },
                { icon: FileText,      label: 'File sharing',         desc: 'Floor plans, contracts, schedules, attached directly to the workspace.' },
                { icon: Shield,        label: 'Anti-fraud check-in',  desc: 'Duplicate detection, trust scoring, and manager override built in.' },
                { icon: UtensilsCrossed, label: 'Live floor manager', desc: 'For restaurants: visual floor map, walk-in waitlist, and live table status.' },
              ].map((f, i) => (
                <motion.article
                  key={f.label}
                  variants={GRID_CHILD}
                  className="lq-glass lq-lift group relative flex min-h-[250px] flex-col rounded-[1.25rem] p-6 sm:p-7"
                  onMouseMove={(e) => {
                    const r = e.currentTarget.getBoundingClientRect();
                    e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`);
                    e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`);
                  }}
                >
                  <div aria-hidden="true" className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
                    style={{ background: 'radial-gradient(260px circle at var(--mx, 30%) var(--my, 0%), rgba(95,132,255,0.18), transparent 65%)' }} />
                  <div className="lq-glass relative flex h-11 w-11 shrink-0 items-center justify-center rounded-[0.75rem]">
                    <f.icon className="h-5 w-5 text-white" />
                  </div>
                  <div className="flex-1" />
                  <h3 className="lq-display relative mt-6 w-full min-w-0 max-w-full break-words text-[clamp(1.2rem,5.1vw,1.875rem)] leading-[1.05] text-white sm:text-3xl" style={{ overflowWrap: 'anywhere', whiteSpace: 'normal' }}>{f.label}</h3>
                  <p className="relative mt-3 max-w-[34ch] text-sm font-light leading-snug text-white/85">{f.desc}</p>
                </motion.article>
              ))}
            </motion.div>

            {/* Stats row */}
            <motion.div
              className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-24"
              variants={GRID_PARENT} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.2 }}
            >
                {[
                  { value: '< 60s',   label: 'To create an event',    sub: 'No account needed' },
                  { value: '∞',       label: 'Team members',          sub: 'No per-seat caps' },
                  { value: '4',       label: 'Event modes',           sub: 'Standard, Enterprise, RSVP, Venue' },
                  { value: '7 days',  label: 'Post-event data',       sub: 'Auto-deleted after' },
                ].map((s, i) => (
                  <motion.div key={s.label} variants={GRID_CHILD} className="lq-glass text-center p-6 sm:p-7 rounded-[1.25rem] cursor-default h-full">
                    <div className="lq-display text-4xl sm:text-5xl text-white mb-2 leading-none">{s.value}</div>
                    <div className="text-xs font-medium text-white mb-1">{s.label}</div>
                    <div className="text-xs font-light text-white/60">{s.sub}</div>
                  </motion.div>
                ))}
            </motion.div>

            {/* Three paths */}
            <div className="grid md:grid-cols-3 gap-4 sm:gap-6">
                <Reveal direction="left">
                <a href="#planit-events"
                  onClick={(e) => { e.preventDefault(); selectBranch('events'); }}
                  className="lq-glass lq-lift group relative flex flex-col p-8 sm:p-10 rounded-[1.5rem] h-full">
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ background:'radial-gradient(ellipse at 0% 50%, rgba(47,91,255,0.16) 0%, transparent 60%)' }} />
                  <div className="relative">
                    <div className="lq-glass inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6">
                      <Calendar className="w-3.5 h-3.5 text-indigo-300" />
                      <span className="text-xs font-medium text-white/90">PlanIt Events</span>
                    </div>
                    <h3 className="font-syne text-3xl sm:text-4xl text-white mb-3 leading-none">
                      Planning an event?<br />Start here.
                    </h3>
                    <p className="text-sm font-light text-white/75 leading-snug mb-7 max-w-sm">
                      Weddings, conferences, corporate retreats, galas. The full planning workspace: chat, tasks, RSVP, QR check-in, all in one place.
                    </p>
                    <div className="flex items-center gap-2 text-sm font-medium text-indigo-200 group-hover:text-white transition-colors">
                      Get started free <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform duration-300" />
                    </div>
                  </div>
                </a>
                </Reveal>

                <Reveal direction="up">
                <a href="#planit-rsvp"
                  onClick={(e) => { e.preventDefault(); selectBranch('rsvp'); }}
                  className="lq-glass lq-lift group relative flex flex-col p-8 sm:p-10 rounded-[1.5rem] h-full">
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ background:'radial-gradient(ellipse at 50% 0%, rgba(16,185,129,0.16) 0%, transparent 60%)' }} />
                  <div className="relative">
                    <div className="lq-glass inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6">
                      <CheckSquare className="w-3.5 h-3.5 text-emerald-300" />
                      <span className="text-xs font-medium text-white/90">RSVP Event</span>
                    </div>
                    <h3 className="font-syne text-3xl sm:text-4xl text-white mb-3 leading-none">
                      Just need RSVPs?<br />Skip the rest.
                    </h3>
                    <p className="text-sm font-light text-white/75 leading-snug mb-7 max-w-sm">
                      A beautiful, section-based RSVP page and guest list. No seating charts, no floor management, live in under a minute.
                    </p>
                    <div className="flex items-center gap-2 text-sm font-medium text-emerald-200 group-hover:text-white transition-colors">
                      Create an RSVP page <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform duration-300" />
                    </div>
                  </div>
                </a>
                </Reveal>

                <Reveal direction="right">
                <a href="#planit-venue"
                  onClick={(e) => { e.preventDefault(); selectBranch('venue'); }}
                  className="lq-glass lq-lift group relative flex flex-col p-8 sm:p-10 rounded-[1.5rem] h-full">
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ background:'radial-gradient(ellipse at 100% 50%, rgba(249,115,22,0.16) 0%, transparent 60%)' }} />
                  <div className="relative">
                    <div className="lq-glass inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6">
                      <UtensilsCrossed className="w-3.5 h-3.5 text-orange-300" />
                      <span className="text-xs font-medium text-white/90">PlanIt Venue</span>
                    </div>
                    <h3 className="font-syne text-3xl sm:text-4xl text-white mb-3 leading-none">
                      Running a restaurant<br />or venue floor?
                    </h3>
                    <p className="text-sm font-light text-white/75 leading-snug mb-7 max-w-sm">
                      Live floor map, walk-in waitlist, QR reservations, one-tap seating. Everything front-of-house needs, every service.
                    </p>
                    <div className="flex items-center gap-2 text-sm font-medium text-orange-200 group-hover:text-white transition-colors">
                      Set up your venue <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform duration-300" />
                    </div>
                  </div>
                </a>
                </Reveal>
            </div>
          </div>
        </section>{/* end SOCIAL PROOF STRIP */}

        <SectionSeam tint="indigo" />

        {/* ═══════════════════════════════════════════════════════════
            PLANIT EVENTS, its own "page" section
        ═══════════════════════════════════════════════════════════ */}
        <section id="planit-events" className="relative overflow-hidden" style={{ background: 'var(--bg-surface)', display: selectedBranch === 'events' ? 'block' : 'none' }}>
          <Aurora palette="indigo" stars={false} />
          {/* Page-break top border with glow */}
          <div style={{ height: '2px', background: 'linear-gradient(90deg, transparent, rgba(148,163,184,0.12) 20%, rgba(255,255,255,0.25) 50%, rgba(148,163,184,0.12) 80%, transparent)' }} />
          {/* Background texture */}
          <div className="absolute inset-0 pointer-events-none" style={{
            backgroundImage: 'radial-gradient(circle at 15% 50%, rgba(100,116,139,0.06) 0%, transparent 50%), radial-gradient(circle at 85% 20%, rgba(148,163,184,0.04) 0%, transparent 40%)',
          }} />
          {/* Animated SVG grid decoration */}
          <svg style={{ position:'absolute', top:0, right:0, width:320, height:320, opacity:0.4, pointerEvents:'none' }} viewBox="0 0 320 320" aria-hidden="true">
            <defs><radialGradient id="evg" cx="100%" cy="0%"><stop offset="0%" stopColor="rgba(148,163,184,0.15)"/><stop offset="100%" stopColor="transparent"/></radialGradient></defs>
            <rect width="320" height="320" fill="url(#evg)"/>
            {Array.from({length:6},(_,i)=><line key={i} x1={i*60} y1="0" x2={i*60} y2="320" stroke="rgba(255,255,255,0.04)" strokeWidth="1"/>)}
            {Array.from({length:6},(_,i)=><line key={i} x1="0" y1={i*60} x2="320" y2={i*60} stroke="rgba(255,255,255,0.04)" strokeWidth="1"/>)}
            {/* Floating task nodes */}
            {[[60,60],[180,40],[260,120],[120,200],[200,260]].map(([cx,cy],i)=>(
              <g key={i}>
                <circle cx={cx} cy={cy} r="18" fill="rgba(255,255,255,0.02)" stroke="rgba(255,255,255,0.06)" strokeWidth="1">
                  <animate attributeName="cy" values={`${cy};${cy-8};${cy}`} dur={`${5+i*0.8}s`} begin={`${i*0.6}s`} repeatCount="indefinite"/>
                </circle>
                <line x1={cx} y1={cy-5} x2={cx+8} y2={cy-5} stroke="rgba(255,255,255,0.12)" strokeWidth="1" strokeLinecap="round"/>
                <line x1={cx} y1={cy} x2={cx+12} y2={cy} stroke="rgba(255,255,255,0.08)" strokeWidth="1" strokeLinecap="round"/>
                <line x1={cx} y1={cy+5} x2={cx+6} y2={cy+5} stroke="rgba(255,255,255,0.06)" strokeWidth="1" strokeLinecap="round"/>
              </g>
            ))}
          </svg>

          {/* Product "page header" */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pt-20 pb-4">
            <Reveal>
              <div className="flex items-center gap-4 mb-2">
                <div className="w-10 h-10 rounded-2xl bg-neutral-800 border border-neutral-700 flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-neutral-300" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-[0.3em] text-neutral-600">{isWL ? '' : 'PlanIt'}</div>
                  <div className="text-lg font-black text-white tracking-tight leading-none">Events</div>
                </div>
                <div className="ml-2 h-px flex-1 bg-neutral-800" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-neutral-700">Branch 01</span>
              </div>
            </Reveal>
          </div>

          {/* Hero headline */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pt-10 pb-20">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <Reveal>
                <p className="text-xs font-bold text-neutral-400 uppercase tracking-[0.2em] mb-6">For event teams who actually have a lot going on</p>
                <h2 className="font-syne font-black text-white leading-[0.9] tracking-tight mb-8" style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}>
                  Everything your<br />
                  team needs.<br />
                  <span style={{ color: '#64748b' }}>Nothing you don't.</span>
                </h2>
                <p className="text-neutral-400 text-lg leading-relaxed mb-10 max-w-lg">
                  From 6 months out to the final wrap-up. {isWL ? (wlName || 'Your platform') : 'PlanIt Events'} is the workspace for the whole team: organizers, vendors, volunteers, everyone.
                </p>
                <div className="flex items-center gap-4">
                  <a href="#create" className="inline-flex items-center gap-2 px-6 py-3 bg-white text-neutral-900 rounded-full font-semibold hover:bg-neutral-100 transition-colors text-sm">
                    Start planning free <ArrowRight className="w-4 h-4" />
                  </a>
                  <span className="text-xs text-neutral-700">No credit card · No account needed</span>
                </div>
              </Reveal>

              {/* Animated workspace mockup */}
              <Reveal delay={120}>
                <div className="relative rounded-2xl border border-neutral-800 overflow-hidden" style={{ background: 'rgba(13,13,22,0.9)' }}>
                  {/* App chrome */}
                  <div className="flex items-center gap-2 px-4 py-3 border-b border-neutral-800/60" style={{ background: 'rgba(10,10,18,0.95)' }}>
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                      <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                      <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                    </div>
                    <div className="flex-1 flex justify-center">
                      <div className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-neutral-800/60 border border-neutral-700/40">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-[9px] text-neutral-500 font-mono">Summer Gala 2026</span>
                      </div>
                    </div>
                  </div>
                  {/* Two-panel layout */}
                  <div className="grid grid-cols-5 divide-x divide-neutral-800/60" style={{ minHeight: 320 }}>
                    {/* Sidebar */}
                    <div className="col-span-2 p-4 space-y-1">
                      {[['Chat','active'],['Tasks',''],['Guests',''],['Polls',''],['Budget','']].map(([label,active]) => (
                        <div key={label} className={`flex items-center gap-2 px-2.5 py-2 rounded-lg text-xs font-semibold transition-colors ${active ? 'bg-white/6 text-white' : 'text-neutral-600 hover:text-neutral-400'}`}>
                          <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: active ? 'rgba(255,255,255,0.5)' : '#404040' }} />{label}
                        </div>
                      ))}
                    </div>
                    {/* Chat panel */}
                    <div className="col-span-3 flex flex-col">
                      <div className="px-3 py-2 border-b border-neutral-800/40">
                        <span className="text-[10px] font-bold text-neutral-500"># planning-team</span>
                      </div>
                      <div className="flex-1 p-3 space-y-2.5 overflow-hidden">
                        <div className="msg-1 flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-blue-600/40 flex-shrink-0 mt-0.5 flex items-center justify-center">
                            <span className="text-[7px] font-bold text-blue-300">A</span>
                          </div>
                          <div>
                            <div className="text-[9px] font-bold text-blue-400 mb-0.5">Alex</div>
                            <div className="text-[10px] text-neutral-400 bg-neutral-800/60 px-2 py-1.5 rounded-lg rounded-tl-none">Venue deposit confirmed</div>
                          </div>
                        </div>
                        <div className="msg-2 flex items-start gap-2">
                          <div className="w-5 h-5 rounded-full bg-sky-600/40 flex-shrink-0 mt-0.5 flex items-center justify-center">
                            <span className="text-[7px] font-bold text-sky-300">S</span>
                          </div>
                          <div>
                            <div className="text-[9px] font-bold text-sky-400 mb-0.5">Sam</div>
                            <div className="text-[10px] text-neutral-400 bg-neutral-800/60 px-2 py-1.5 rounded-lg rounded-tl-none">Floor plan uploaded to files</div>
                          </div>
                        </div>
                        <div className="msg-3 flex items-start gap-2 justify-end">
                          <div>
                            <div className="text-[10px] text-neutral-300 bg-neutral-700/80 px-2 py-1.5 rounded-lg rounded-tr-none">On it! Creating checklist now</div>
                          </div>
                        </div>
                      </div>
                      {/* typing */}
                      <div className="px-3 pb-3">
                        <div className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-neutral-800/40 border border-neutral-700/30">
                          <span className="text-[9px] text-neutral-600">Alex is typing</span>
                          <div className="flex items-end gap-0.5">
                            <div className="typing-dot w-1 h-1 rounded-full bg-neutral-500" />
                            <div className="typing-dot w-1 h-1 rounded-full bg-neutral-500" />
                            <div className="typing-dot w-1 h-1 rounded-full bg-neutral-500" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>

          {/* Features grid */}
          <div className="relative border-t border-neutral-800/40">
            <div className="max-w-screen-xl mx-auto px-6 sm:px-10 py-16">
              <Reveal className="mb-10">
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-neutral-600 mb-2">What's included</p>
                <h3 className="font-syne text-2xl font-black text-white">Every tool. One workspace.</h3>
              </Reveal>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { icon: MessageSquare, label: 'Real-time team chat',    desc: 'Typing indicators, reactions, threads. Your team stays in sync.' },
                  { icon: ListChecks,    label: 'Task management',        desc: 'Assign tasks, set deadlines, track completion down to the wire.' },
                  { icon: BarChart3,     label: 'Polls & voting',         desc: 'Vote on venues, dates, menus. Live results instantly.' },
                  { icon: FileText,      label: 'File sharing',           desc: 'Contracts, floor plans, schedules, all in one place.' },
                  { icon: Users,         label: 'Unlimited team',         desc: 'No caps. Every organizer, vendor, and volunteer included.' },
                  { icon: QrCode,        label: 'QR check-in',           desc: 'Professional guest check-in with real-time attendance.' },
                  { icon: Bot,           label: 'Claude AI co-pilot',    desc: 'Manage your whole event by talking to Claude. Add guests, check-ins, announcements, all conversationally.' },
                ].map((f, i) => (
                  <Reveal key={f.label} delay={(i % 3) * 60} direction={i % 3 === 0 ? 'left' : i % 3 === 2 ? 'right' : 'up'}>
                    <div className="lq-glass lq-lift group p-6 rounded-[1.25rem] h-full">
                      <div className="feature-icon w-9 h-9 rounded-xl bg-neutral-800 border border-neutral-700/50 flex items-center justify-center mb-4 group-hover:bg-neutral-700">
                        <f.icon className="w-4 h-4 text-neutral-400" />
                      </div>
                      <div className="text-sm font-bold text-white mb-1.5 tracking-tight">{f.label}</div>
                      <div className="text-xs text-neutral-400 leading-relaxed">{f.desc}</div>
                    </div>
                  </Reveal>
                ))}
              </div>
            </div>
          </div>

          {/* Invite/RSVP demo advertisement */}
          <div className="border-t border-neutral-800/40">
            <div className="max-w-screen-xl mx-auto px-6 sm:px-10 py-16">
              <Reveal>
                <div
                  onClick={() => navigate('/demo/invite')}
                  role="link"
                  tabIndex={0}
                  onKeyDown={(e) => { if (e.key === 'Enter') navigate('/demo/invite'); }}
                  className="lq-glass lq-lift group relative flex flex-col sm:flex-row items-stretch gap-0 rounded-[1.5rem] cursor-pointer"
                >
                  <div className="flex-1 p-8 sm:p-10">
                    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-indigo-500/20 bg-indigo-500/8 mb-5">
                      <Ticket className="w-3.5 h-3.5 text-indigo-400" />
                      <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">See it in action</span>
                    </div>
                    <h3 className="font-syne text-2xl sm:text-3xl font-black text-white mb-3 leading-tight">
                      Invites and RSVP pages guests actually want to share.
                    </h3>
                    <p className="text-sm text-neutral-500 leading-relaxed mb-6 max-w-lg">
                      Live countdowns, who else is going, a QR entry pass, and a personalized share card for every guest. Try the real thing below, no account needed.
                    </p>
                    <div className="flex flex-wrap gap-3">
                      <span className="inline-flex items-center gap-2 text-sm font-bold text-indigo-400 group-hover:text-indigo-300 transition-colors">
                        Try the invite demo <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-300" />
                      </span>
                      <a
                        href="/demo/rsvp"
                        onClick={(e) => e.stopPropagation()}
                        className="inline-flex items-center gap-2 text-sm font-bold text-neutral-400 hover:text-neutral-200 transition-colors"
                      >
                        <Share2 className="w-3.5 h-3.5" /> Try the RSVP demo
                      </a>
                    </div>
                  </div>
                  <div className="hidden sm:flex w-64 flex-shrink-0 items-center justify-center p-8 border-l border-indigo-500/10" style={{ background: 'rgba(0,0,0,0.2)' }}>
                    <div className="w-full rounded-2xl border border-neutral-800 bg-neutral-950 p-4">
                      <p className="text-[10px] uppercase tracking-widest text-neutral-600 mb-2">You're invited to</p>
                      <p className="font-syne text-lg font-black text-white mb-3 leading-tight">Bonfire &amp; vinyl</p>
                      <div className="flex gap-1.5 mb-3">
                        {['D', 'H', 'M', 'S'].map((u) => (
                          <div key={u} className="flex-1 text-center rounded-md bg-neutral-900 border border-neutral-800 py-1.5">
                            <div className="text-xs font-mono font-bold text-neutral-300">09</div>
                            <div className="text-[8px] text-neutral-600">{u}</div>
                          </div>
                        ))}
                      </div>
                      <div className="h-8 rounded-lg bg-indigo-500/80 flex items-center justify-center text-[11px] font-bold text-white">I'm going</div>
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>

          {/* Enterprise strip */}
          <div className="border-t border-neutral-800/40">
            <div className="max-w-screen-xl mx-auto px-6 sm:px-10 py-12">
              <Reveal>
                <div className="lq-glass lq-lift flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 p-6 rounded-[1.25rem]">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-neutral-800 border border-neutral-700 flex items-center justify-center flex-shrink-0">
                      <Zap className="w-5 h-5 text-neutral-400" />
                    </div>
                    <div>
                      <div className="text-sm font-black text-white mb-0.5">Enterprise Mode</div>
                      <div className="text-xs text-neutral-600">Personalized QR invites, check-in dashboard, real-time attendance analytics. For 100+ guest events.</div>
                    </div>
                  </div>
                  <a href="#create" className="flex-shrink-0 inline-flex items-center gap-2 px-5 py-2.5 border border-neutral-700 rounded-xl text-xs font-bold text-neutral-300 hover:border-neutral-500 hover:text-white transition-all">
                    Set up Enterprise <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </Reveal>
            </div>
          </div>

          {/* Bottom page-break */}
          <div style={{ height: '2px', background: 'linear-gradient(90deg, transparent, rgba(148,163,184,0.08) 20%, rgba(255,255,255,0.15) 50%, rgba(148,163,184,0.08) 80%, transparent)' }} />
        </section>

        {/* ═══════════════════════════════════════════════════════════
            BRANCH TRANSITION, visual page turn
        ═══════════════════════════════════════════════════════════ */}
        <div className="relative py-12 flex items-center justify-center overflow-hidden" style={{ background: 'var(--bg-base)', display: selectedBranch ? 'none' : 'flex' }}>
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(249,115,22,0.04) 0%, transparent 60%)' }} />
          <Reveal>
            <div className="relative flex items-center gap-5 text-center">
              <div className="h-px w-16 bg-neutral-800" />
              <div className="flex items-center gap-3 px-5 py-2.5 rounded-full border border-neutral-800" style={{ background: 'rgba(255,255,255,0.02)' }}>
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-neutral-700 uppercase tracking-widest">
                  <Calendar className="w-3 h-3 text-neutral-700" /> Events
                </div>
                <span className="text-neutral-800">·</span>
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-neutral-700 uppercase tracking-widest">
                  <UtensilsCrossed className="w-3 h-3 text-neutral-700" /> Venue
                </div>
              </div>
              <div className="h-px w-16 bg-neutral-800" />
            </div>
          </Reveal>
        </div>

        {/* ═══════════════════════════════════════════════════════════
            PLANIT RSVP, its own "page" section
        ═══════════════════════════════════════════════════════════ */}
        <section id="planit-rsvp" className="relative overflow-hidden" style={{ background: 'rgba(6,20,16,0.97)', display: selectedBranch === 'rsvp' ? 'block' : 'none' }}>
          <Aurora palette="mint" stars={false} />
          <div style={{ height: '2px', background: 'linear-gradient(90deg, transparent, rgba(16,185,129,0.15) 20%, rgba(52,211,153,0.3) 50%, rgba(16,185,129,0.15) 80%, transparent)' }} />
          <div className="absolute inset-0 pointer-events-none" style={{
            backgroundImage: 'radial-gradient(circle at 15% 40%, rgba(16,185,129,0.07) 0%, transparent 50%), radial-gradient(circle at 85% 10%, rgba(52,211,153,0.05) 0%, transparent 40%)',
          }} />

          {/* Product "page header" */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pt-20 pb-4">
            <Reveal>
              <div className="flex items-center gap-4 mb-2">
                <div className="w-10 h-10 rounded-2xl bg-emerald-950/60 border border-emerald-800/50 flex items-center justify-center">
                  <CheckSquare className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-[0.3em] text-emerald-800">{isWL ? '' : 'PlanIt'}</div>
                  <div className="text-lg font-black text-white tracking-tight leading-none">RSVP</div>
                </div>
                <div className="ml-2 h-px flex-1 bg-emerald-900/50" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-800">Branch 03</span>
              </div>
            </Reveal>
          </div>

          {/* Hero headline */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pt-10 pb-16">
            <Reveal>
              <p className="text-xs font-bold text-emerald-500/70 uppercase tracking-[0.2em] mb-6">For when the guest list is the whole job</p>
              <h2 className="font-syne font-black text-white leading-[0.9] tracking-tight mb-8 max-w-3xl" style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}>
                A gorgeous RSVP page.<br />
                <span style={{ color: '#34d399' }}>Nothing else to configure.</span>
              </h2>
              <p className="text-neutral-400 text-lg leading-relaxed mb-10 max-w-lg">
                Drag-and-drop a real page: hero, agenda, photos, FAQ, whatever the event needs. Then share one link. No seating charts, no floor management, no ticketing. Just RSVPs, done beautifully.
              </p>
              <div className="flex items-center gap-4">
                <a href="#create" className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-400 text-emerald-950 rounded-full font-semibold hover:bg-emerald-300 transition-colors text-sm">
                  Create an RSVP page <ArrowRight className="w-4 h-4" />
                </a>
                <span className="text-xs text-emerald-900">Live in under a minute</span>
              </div>
            </Reveal>
          </div>

          {/* Feature highlights */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pb-20">
            <div className="grid sm:grid-cols-3 gap-4">
              {[
                { icon: Layers, label: 'Section-based builder', body: 'Drag, drop, and reorder from a 16-block library: hero, agenda, FAQ, sponsors, and more.' },
                { icon: Zap, label: 'Auto-generated cover', body: 'Pick a template and accent color; your event\u2019s cover graphic builds itself, no design work.' },
                { icon: Users, label: 'Guest list + check-in', body: 'The same guest list and simple check-in as every PlanIt event, without the extra setup.' },
              ].map(({ icon: Icon, label, body }, i) => (
                <Reveal key={label} delay={i * 80}>
                  <div className="lq-glass lq-lift p-6 rounded-[1.25rem] h-full">
                    <Icon className="w-5 h-5 text-emerald-400 mb-3" />
                    <p className="text-sm font-bold text-white mb-1.5">{label}</p>
                    <p className="text-xs text-neutral-500 leading-relaxed">{body}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>

          {/* Standard Event vs RSVP Event comparison, styled cards, not a plain table */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pb-24">
            <Reveal>
              <p className="text-xs font-bold text-neutral-500 uppercase tracking-[0.2em] mb-6 text-center">Which one do you actually need?</p>
              <div className="grid md:grid-cols-2 gap-5">
                {/* Standard Event card */}
                <div className="lq-glass rounded-[1.5rem] p-8">
                  <div className="flex items-center gap-2 mb-1">
                    <Calendar className="w-4 h-4 text-indigo-400" />
                    <span className="text-sm font-black text-white">Standard Event</span>
                  </div>
                  <p className="text-xs text-neutral-600 mb-6">The full workspace</p>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between border-b border-neutral-800/60 pb-3"><span className="text-neutral-500">Setup time</span><span className="text-neutral-300 font-semibold">~5–10 min</span></div>
                    <div className="flex items-start justify-between border-b border-neutral-800/60 pb-3"><span className="text-neutral-500">Included</span><span className="text-neutral-300 font-semibold text-right">Seating charts, floor management,<br />enterprise check-in, RSVP page</span></div>
                    <div className="flex items-center justify-between"><span className="text-neutral-500">Best for</span><span className="text-neutral-300 font-semibold">Weddings, galas, multi-day events</span></div>
                  </div>
                </div>
                {/* RSVP Event card */}
                <div className="lq-glass rounded-[1.5rem] p-8 relative">
                  <div className="absolute top-0 right-0 text-[10px] font-black uppercase tracking-widest text-emerald-950 bg-emerald-400 px-3 py-1 rounded-bl-xl">Lightweight</div>
                  <div className="flex items-center gap-2 mb-1">
                    <CheckSquare className="w-4 h-4 text-emerald-400" />
                    <span className="text-sm font-black text-white">RSVP Event</span>
                  </div>
                  <p className="text-xs text-emerald-800 mb-6">Just the RSVP page</p>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between border-b border-emerald-900/40 pb-3"><span className="text-emerald-700">Setup time</span><span className="text-white font-semibold">~1 min</span></div>
                    <div className="flex items-start justify-between border-b border-emerald-900/40 pb-3"><span className="text-emerald-700">Included</span><span className="text-white font-semibold text-right">Guest list, RSVP builder,<br />basic check-in, analytics</span></div>
                    <div className="flex items-start justify-between border-b border-emerald-900/40 pb-3"><span className="text-emerald-700">Intentionally left out</span><span className="text-white font-semibold text-right">Seating charts, floor management,<br />ticketing, advanced fraud detection</span></div>
                    <div className="flex items-center justify-between"><span className="text-emerald-700">Best for</span><span className="text-white font-semibold">Parties, meetups, simple gatherings</span></div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

          <div className="max-w-screen-xl mx-auto px-6 sm:px-10 pb-10">
            <Reveal>
              <div className="flex items-center gap-3">
                <div className="h-px w-16 bg-emerald-900/50" />
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-900 uppercase tracking-widest">
                    <Calendar className="w-3 h-3 text-emerald-900" /> Events
                  </div>
                  <span className="text-emerald-950">·</span>
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-emerald-900 uppercase tracking-widest">
                    <UtensilsCrossed className="w-3 h-3 text-emerald-900" /> Venue
                  </div>
                </div>
                <div className="h-px w-16 bg-emerald-900/50" />
              </div>
            </Reveal>
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════
            PLANIT VENUE, its own "page" section
        ═══════════════════════════════════════════════════════════ */}
        <section id="planit-venue" className="relative overflow-hidden" style={{ background: 'var(--bg-venue)', display: selectedBranch === 'venue' ? 'block' : 'none' }}>
          <Aurora palette="amber" stars={false} />
          {/* Page-break top border with orange glow */}
          <div style={{ height: '2px', background: 'linear-gradient(90deg, transparent, rgba(249,115,22,0.15) 20%, rgba(249,115,22,0.5) 50%, rgba(249,115,22,0.15) 80%, transparent)' }} />
          {/* Background */}
          <div className="absolute inset-0 pointer-events-none" style={{
            backgroundImage: 'radial-gradient(circle at 85% 40%, rgba(249,115,22,0.06) 0%, transparent 50%), radial-gradient(circle at 15% 80%, rgba(234,88,12,0.03) 0%, transparent 40%)',
          }} />
          {/* Animated venue floor SVG decoration */}
          <svg style={{ position:'absolute', top:0, left:0, width:280, height:280, opacity:0.35, pointerEvents:'none' }} viewBox="0 0 280 280" aria-hidden="true">
            <defs><radialGradient id="vng" cx="0%" cy="0%"><stop offset="0%" stopColor="rgba(249,115,22,0.12)"/><stop offset="100%" stopColor="transparent"/></radialGradient></defs>
            <rect width="280" height="280" fill="url(#vng)"/>
            {Array.from({length:5},(_,i)=><line key={i} x1={i*60} y1="0" x2={i*60} y2="280" stroke="rgba(249,115,22,0.05)" strokeWidth="1"/>)}
            {Array.from({length:5},(_,i)=><line key={i} x1="0" y1={i*60} x2="280" y2={i*60} stroke="rgba(249,115,22,0.05)" strokeWidth="1"/>)}
            {/* Mini table shapes */}
            {[[50,60,18,'#22c55e'],[130,50,16,'#ef4444'],[60,160,14,'#f59e0b'],[170,150,18,'#22c55e']].map(([cx,cy,r,c],i)=>(
              <g key={i}>
                <circle cx={cx} cy={cy} r={r} fill={`${c}12`} stroke={c} strokeWidth="1" opacity="0.7">
                  <animate attributeName="cy" values={`${cy};${cy-6};${cy}`} dur={`${4+i*0.9}s`} begin={`${i*0.7}s`} repeatCount="indefinite"/>
                </circle>
                <text x={cx} y={cy+4} textAnchor="middle" fill={c} fontSize="8" fontWeight="800" opacity="0.8">T{i+1}</text>
              </g>
            ))}
          </svg>

          {/* Product "page header" */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pt-20 pb-4">
            <Reveal>
              <div className="flex items-center gap-4 mb-2">
                <div className="w-10 h-10 rounded-2xl bg-orange-500/10 border border-orange-500/25 flex items-center justify-center">
                  <UtensilsCrossed className="w-5 h-5 text-orange-400" />
                </div>
                <div>
                  <div className="text-[10px] font-black uppercase tracking-[0.3em] text-orange-500/40">PlanIt</div>
                  <div className="text-lg font-black text-white tracking-tight leading-none">Venue</div>
                </div>
                <div className="ml-2 h-px flex-1 bg-orange-500/10" />
                <span className="text-[10px] font-bold uppercase tracking-widest text-orange-500/30">Branch 02</span>
              </div>
            </Reveal>
          </div>

          {/* Hero headline */}
          <div className="relative max-w-screen-xl mx-auto px-6 sm:px-10 pt-10 pb-20">
            <div className="grid lg:grid-cols-2 gap-16 items-center">
              <Reveal>
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-orange-500/40 mb-6">For restaurants that run a real floor every night</p>
                <h2 className="font-syne font-black text-white leading-[0.9] tracking-tight mb-8" style={{ fontSize: 'clamp(2.2rem, 5vw, 4.5rem)' }}>
                  Run your floor.<br />
                  Know your wait.<br />
                  <span style={{ color: 'rgba(249,115,22,0.5)' }}>Seat every table.</span>
                </h2>
                <p className="text-neutral-600 text-lg leading-relaxed mb-10 max-w-lg">
                  Live table states. Walk-in waitlist with a public wait board guests scan at the door. One-tap seating. Your floor data never expires.
                </p>
                <div className="flex items-center gap-4">
                  <a href="#create" onClick={() => setTimeout(() => document.querySelector('[data-mode="table-service"]')?.click(), 100)}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-orange-500 text-white rounded-full font-semibold hover:bg-orange-400 transition-colors text-sm">
                    Set up your venue <ArrowRight className="w-4 h-4" />
                  </a>
                  <span className="text-xs text-neutral-700">Free · Data never expires</span>
                </div>
              </Reveal>

              {/* Animated floor map */}
              <Reveal delay={120}>
                <div className="relative rounded-2xl border border-orange-500/15 overflow-hidden" style={{ background: 'rgba(13,10,5,0.95)' }}>
                  {/* App chrome */}
                  <div className="flex items-center justify-between px-4 py-3 border-b border-orange-500/10" style={{ background: 'rgba(10,8,3,0.98)' }}>
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-lg bg-orange-500/15 border border-orange-500/20 flex items-center justify-center">
                        <UtensilsCrossed className="w-2.5 h-2.5 text-orange-400" />
                      </div>
                      <span className="text-xs font-bold text-neutral-400">Taverna Roma</span>
                      <span className="text-[9px] text-orange-400/40 font-bold uppercase tracking-wider">PlanIt Venue</span>
                    </div>
                    <div className="flex gap-2">
                      {[['#22c55e','3 Free'],['#ef4444','4 Occ'],['#5f84ff','1 Cln']].map(([c,l]) => (
                        <span key={l} className="flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded-md bg-neutral-900 text-neutral-500">
                          <span className="w-1.5 h-1.5 rounded-full" style={{ background: c }} />{l}
                        </span>
                      ))}
                    </div>
                  </div>
                  {/* Floor plan SVG */}
                  <div className="p-4">
                    <svg viewBox="0 0 520 260" className="w-full" style={{ height: 220 }}>
                      <defs>
                        <pattern id="vg" width="28" height="28" patternUnits="userSpaceOnUse">
                          <path d="M 28 0 L 0 0 0 28" fill="none" stroke="rgba(249,115,22,0.04)" strokeWidth="0.5" />
                        </pattern>
                      </defs>
                      <rect width="520" height="260" fill="url(#vg)" />
                      {/* Zone */}
                      <rect x="18" y="10" width="155" height="90" rx="8" fill="rgba(249,115,22,0.02)" stroke="rgba(249,115,22,0.08)" strokeDasharray="6 3" />
                      <text x="95" y="58" textAnchor="middle" fill="rgba(249,115,22,0.2)" fontSize="11" fontWeight="700" letterSpacing="2">MAIN ROOM</text>
                      {/* Tables */}
                      {[
                        {x:65,  y:155, r:26, status:'available', label:'T1', cap:'4'},
                        {x:145, y:155, r:26, status:'occupied',  label:'T2', cap:'4', party:'Smith', time:'38m'},
                        {x:215, y:135, r:30, status:'occupied',  label:'T3', cap:'6', party:'Chen',  time:'19m'},
                        {x:300, y:155, r:26, status:'cleaning',  label:'T4', cap:'4'},
                        {x:370, y:135, r:30, status:'available', label:'T5', cap:'6'},
                        {x:455, y:155, r:26, status:'reserved',  label:'T6', cap:'4', party:'Jones'},
                      ].map(t => {
                        const c = t.status==='available'?'#22c55e':t.status==='occupied'?'#ef4444':t.status==='cleaning'?'#5f84ff':'#f59e0b';
                        const pulse = t.status === 'available';
                        return (
                          <g key={t.label}>
                            <circle cx={t.x} cy={t.y} r={t.r+4} fill="none" stroke={c} strokeWidth="1.5" opacity={pulse ? undefined : "0.5"} className={pulse ? 'table-pulse-ring' : ''} />
                            <circle cx={t.x} cy={t.y} r={t.r} fill={`${c}18`} stroke={c} strokeWidth="1" className={pulse ? 'table-pulse-fill' : ''} />
                            <text x={t.x} y={t.y-3} textAnchor="middle" fill="rgba(255,255,255,0.9)" fontSize="9" fontWeight="800">{t.label}</text>
                            <text x={t.x} y={t.y+8} textAnchor="middle" fill={c} fontSize="8">{t.cap}</text>
                            {t.time && <text x={t.x+t.r-2} y={t.y-t.r+4} textAnchor="middle" fill="white" fontSize="7.5" fontWeight="700" opacity="0.8">{t.time}</text>}
                          </g>
                        );
                      })}
                      {/* Waitlist widget */}
                      <rect x="18" y="178" width="130" height="60" rx="8" fill="rgba(245,158,11,0.06)" stroke="rgba(245,158,11,0.18)" />
                      <text x="30" y="196" fill="#f59e0b" fontSize="8" fontWeight="800" letterSpacing="1">WAITLIST</text>
                      <text x="90" y="196" fill="rgba(245,158,11,0.5)" fontSize="8" fontWeight="700" className="waitlist-tick">·3</text>
                      <text x="30" y="212" fill="rgba(255,255,255,0.4)" fontSize="8">Martinez · 4 · ~14m</text>
                      <text x="30" y="226" fill="rgba(255,255,255,0.4)" fontSize="8">Taylor · 2 · ~8m</text>
                    </svg>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>

          {/* Features grid */}
          <div className="relative border-t border-orange-500/8">
            <div className="max-w-screen-xl mx-auto px-6 sm:px-10 py-16">
              <Reveal className="mb-10">
                <p className="text-xs font-bold uppercase tracking-[0.2em] text-orange-500/40 mb-2">What's included</p>
                <h3 className="font-syne text-2xl font-black text-white">Your whole floor, in one screen.</h3>
              </Reveal>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  { icon: Layers,       label: 'Visual floor editor',    desc: 'Drag tables to match your exact layout. Zones, shapes, labels.' },
                  { icon: Users,        label: 'Walk-in waitlist',       desc: 'Add parties instantly. Estimated wait times update as tables clear.' },
                  { icon: QrCode,       label: 'Public wait board',      desc: 'Guests scan the door QR, see the queue, and join from their phone.' },
                  { icon: MapPin,       label: 'Live sync',              desc: 'Every status update hits all staff screens in real time.' },
                  { icon: CheckCircle2, label: 'One-tap seat next',      desc: 'Auto-picks the tightest-fit table and seats the next waiting party.' },
                  { icon: Clock,        label: 'Data never expires',     desc: 'Your floor plan and history persist forever. No cleanup, no resets.' },
                ].map((f, i) => (
                  <Reveal key={f.label} delay={(i % 3) * 60} direction={i % 3 === 0 ? 'left' : i % 3 === 2 ? 'right' : 'up'}>
                    <div className="lq-glass lq-lift group p-6 rounded-[1.25rem] h-full">
                      <div className="w-9 h-9 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center mb-4 transition-all duration-500 group-hover:bg-orange-500/20 group-hover:scale-110 group-hover:-rotate-6">
                        <f.icon className="w-4 h-4 text-orange-400" />
                      </div>
                      <div className="text-sm font-bold text-white mb-1.5 tracking-tight">{f.label}</div>
                      <div className="text-xs text-neutral-500 leading-relaxed">{f.desc}</div>
                    </div>
                  </Reveal>
                ))}
              </div>
            </div>
          </div>

          {/* Bottom page-break */}
          <div style={{ height: '2px', background: 'linear-gradient(90deg, transparent, rgba(249,115,22,0.08) 20%, rgba(249,115,22,0.25) 50%, rgba(249,115,22,0.08) 80%, transparent)' }} />
        </section>

        {/* TESTIMONIALS */}
        <section className="py-32 border-t border-neutral-800/40" style={{ display: selectedBranch === 'events' ? 'block' : 'none' }}>
          <div className="max-w-screen-xl mx-auto px-4 sm:px-8">
            <SectionHeader eyebrow="Testimonials" title="Trusted by event planners" subtitle="See how teams are using PlanIt to execute flawless events" />
            <div className="grid md:grid-cols-3 gap-6">
              <TestimonialCard direction="left" quote="PlanIt transformed how we coordinated our annual company conference. The task management kept our 15-person planning team organized for 6 months of prep. The QR check-in on event day was seamless for 300 attendees." author="Michael Chen" role="Senior Event Coordinator" event="Tech Summit 2025" delay={0} />
              <TestimonialCard direction="up" quote="As a wedding planner, I've used every tool out there. PlanIt stands out because it doesn't require my couples or vendors to create accounts. We used it for 4 months of planning." author="Sarah Williams" role="Lead Wedding Planner" event="Williams-Martinez Wedding" delay={120} />
              <TestimonialCard direction="right" quote="Our nonprofit used PlanIt to coordinate a 500-person fundraising gala. The unlimited participant feature meant we could include our entire board, 30 volunteers, all vendors, and staff." author="David Martinez" role="Development Director" event="Charity Gala 2025" delay={240} />
            </div>
          </div>
        </section>

        <SectionSeam tint="violet" />
        <section className="py-32 border-t border-orange-500/8" style={{ display: selectedBranch === 'venue' ? 'block' : 'none' }}>
          <div className="max-w-screen-xl mx-auto px-4 sm:px-8">
            <SectionHeader eyebrow="Testimonials" title="Trusted by restaurant floors" subtitle="See how venues are using PlanIt to run service, night after night" />
            <div className="grid md:grid-cols-3 gap-6">
              <TestimonialCard direction="left" quote="The floor map alone paid for itself in week one. Our host stand used to be a legal pad. Now every server sees table status update live from their phone." author="Michael Chen" role="General Manager" event="Taverna Roma" delay={0} />
              <TestimonialCard direction="up" quote="Walk-ins used to mean guessing at wait times. Now guests scan a QR at the door, see the real queue, and we seat the next table with one tap." author="Sarah Williams" role="Front of House Manager" event="The Oak Room" delay={120} />
              <TestimonialCard direction="right" quote="Our floor history just sits there. No resets, no cleanup. We can look back at any night and see exactly how service ran." author="David Martinez" role="Operations Lead" event="Bellwood Bistro" delay={240} />
            </div>
          </div>
        </section>

        {/* CLAUDE INTEGRATION */}
        <section className="relative overflow-hidden py-28 border-t border-white/5" style={{ display: selectedBranch === 'events' ? 'block' : 'none' }}>
          <Aurora palette="violet" stars={false} />
          <div className="relative max-w-screen-xl mx-auto px-4 sm:px-8">
            <div className="flex flex-col lg:flex-row items-center gap-16">
              {/* Left: copy */}
              <div className="flex-1">
                <Reveal direction="left">
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full mb-6"
                    style={{ border: '1px solid rgba(95,132,255,0.3)', background: 'rgba(95,132,255,0.08)' }}>
                    <Bot size={13} className="text-blue-400" />
                    <span className="text-blue-400 text-xs font-semibold">Now available · Claude Integration</span>
                  </div>
                  <h2 className="font-syne font-black text-white mb-4 leading-tight" style={{ fontSize: 'clamp(1.8rem,4vw,3rem)' }}>
                    Manage your event<br />by talking to Claude.
                  </h2>
                  <p className="text-neutral-400 text-lg leading-relaxed mb-8 max-w-lg">
                    Add PlanIt to Claude once. Then just have a conversation: build your guest list, set up seating,
                    send announcements, and monitor check-ins without touching the dashboard.
                  </p>
                  <div className="space-y-3 mb-8">
                    {[
                      '"Add Sarah Jones, email sarah@example.com"',
                      '"How many people have checked in so far?"',
                      '"Send an announcement: doors open in 10 minutes"',
                      '"Create 15 round tables of 10"',
                    ].map((q, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <Bot size={14} className="text-blue-500 flex-shrink-0" />
                        <span className="text-sm text-neutral-400 font-mono">{q}</span>
                      </div>
                    ))}
                  </div>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <a
                      href="https://claude.ai/customize/connectors?modal=add-custom-connector&mcpName=PlanIt&mcpServerUrl=https://planit-mcp.onrender.com/mcp"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="group inline-flex items-center gap-2 px-5 py-3 rounded-full text-white font-semibold text-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_12px_28px_rgba(124,58,237,0.35)]"
                      style={{ background: '#1f43e6' }}
                      onMouseEnter={e => e.currentTarget.style.background = '#6d28d9'}
                      onMouseLeave={e => e.currentTarget.style.background = '#1f43e6'}
                    >
                      <Bot size={16} /> Add to Claude <ArrowUpRight size={14} className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </a>
                    <a href="/help#claude"
                      className="inline-flex items-center gap-2 px-5 py-3 lq-glass rounded-full text-white/90 text-sm transition-colors hover:text-white">
                      How it works
                    </a>
                    <a href="/mcp-docs"
                      className="inline-flex items-center gap-2 px-5 py-3 lq-glass rounded-full text-white/90 text-sm transition-colors hover:text-white">
                      View full docs
                    </a>
                  </div>
                </Reveal>
              </div>

              {/* Right: chat mockup */}
              <Reveal delay={120} direction="right" className="flex-1 max-w-md w-full">
                <div className="lq-glass-strong lq-lift rounded-[1.25rem]">
                  {/* Chrome */}
                  <div className="flex items-center gap-2 px-4 py-3" style={{ borderBottom: '1px solid rgba(255,255,255,0.06)', background: 'rgba(10,10,18,0.95)' }}>
                    <div className="flex gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                      <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                      <div className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
                    </div>
                    <div className="flex items-center gap-2 mx-auto">
                      <div className="w-4 h-4 rounded-md bg-blue-600/30 flex items-center justify-center">
                        <Bot size={9} className="text-blue-300" />
                      </div>
                      <span className="text-[11px] text-neutral-500 font-medium">Claude + PlanIt</span>
                    </div>
                  </div>
                  {/* Messages */}
                  <div className="p-4 space-y-3 text-sm">
                    <div className="flex justify-end">
                      <div className="px-3 py-2 rounded-2xl rounded-tr-sm text-neutral-200 text-xs max-w-xs"
                        style={{ background: 'rgba(124,58,237,0.25)', border: '1px solid rgba(124,58,237,0.2)' }}>
                        Add Sarah Jones to the guest list, sarah@example.com
                      </div>
                    </div>
                    <div className="flex gap-2 items-start">
                      <div className="w-6 h-6 rounded-full flex-shrink-0 mt-0.5 flex items-center justify-center" style={{ background: 'rgba(124,58,237,0.2)' }}>
                        <Bot size={11} className="text-blue-300" />
                      </div>
                      <div className="px-3 py-2 rounded-2xl rounded-tl-sm text-neutral-300 text-xs max-w-xs"
                        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)' }}>
                        Done! Sarah Jones has been added. Her invite link is ready to share.
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <div className="px-3 py-2 rounded-2xl rounded-tr-sm text-neutral-200 text-xs max-w-xs"
                        style={{ background: 'rgba(124,58,237,0.25)', border: '1px solid rgba(124,58,237,0.2)' }}>
                        How many people have checked in?
                      </div>
                    </div>
                    <div className="flex gap-2 items-start">
                      <div className="w-6 h-6 rounded-full flex-shrink-0 mt-0.5 flex items-center justify-center" style={{ background: 'rgba(124,58,237,0.2)' }}>
                        <Bot size={11} className="text-blue-300" />
                      </div>
                      <div className="px-3 py-2 rounded-2xl rounded-tl-sm text-neutral-300 text-xs max-w-xs"
                        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)' }}>
                        87 of 150 guests checked in (58%). Last scan 2 minutes ago.
                      </div>
                    </div>
                    <div className="flex justify-end">
                      <div className="px-3 py-2 rounded-2xl rounded-tr-sm text-neutral-200 text-xs max-w-xs"
                        style={{ background: 'rgba(124,58,237,0.25)', border: '1px solid rgba(124,58,237,0.2)' }}>
                        Send an announcement: doors open in 10 minutes
                      </div>
                    </div>
                    <div className="flex gap-2 items-start">
                      <div className="w-6 h-6 rounded-full flex-shrink-0 mt-0.5 flex items-center justify-center" style={{ background: 'rgba(124,58,237,0.2)' }}>
                        <Bot size={11} className="text-blue-300" />
                      </div>
                      <div className="px-3 py-2 rounded-2xl rounded-tl-sm text-neutral-300 text-xs max-w-xs"
                        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.07)' }}>
                        Announcement sent to all guests and staff ✓
                      </div>
                    </div>
                  </div>
                  {/* Footer */}
                  <div className="px-4 pb-4">
                    <div className="flex items-center gap-2 px-3 py-2 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
                      <span className="text-[11px] text-neutral-600 flex-1">Message Claude…</span>
                      <Bot size={12} className="text-neutral-700" />
                    </div>
                  </div>
                </div>
              </Reveal>
            </div>
          </div>
        </section>

        {/* DISCOVER + STATUS CARDS */}
        <section className="py-28 border-t border-neutral-800/40" style={{ display: selectedBranch ? 'block' : 'none' }}>
          <div className="max-w-screen-xl mx-auto px-4 sm:px-8">
            <Reveal className="text-center mb-12">
              <p className="text-xs font-semibold text-neutral-500 uppercase tracking-widest mb-3">Explore more</p>
              <h2 className="font-syne text-4xl md:text-5xl font-black text-white mb-4">Everything you need</h2>
              <p className="text-lg text-neutral-400 max-w-md mx-auto">Find public events and check our service health, all in one place.</p>
            </Reveal>
            <div className={selectedBranch === 'venue' ? 'grid max-w-lg mx-auto gap-6' : 'grid md:grid-cols-2 gap-6'}>
              {/* Discover Card, events only */}
              {selectedBranch !== 'venue' && (
              <Reveal delay={0} direction="left">
                <a href="/discover" className="lq-glass lq-lift group relative block p-8 sm:p-10 rounded-[1.5rem] h-full">
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ background: 'radial-gradient(ellipse at top left, rgba(80,60,200,0.12) 0%, transparent 65%)' }} />
                  <div className="relative">
                    <div className="w-14 h-14 rounded-2xl bg-neutral-800 border border-neutral-700 flex items-center justify-center mb-6 group-hover:bg-white group-hover:border-white transition-all duration-500 group-hover:scale-110">
                      <Zap className="w-7 h-7 text-neutral-300 group-hover:text-neutral-900 transition-colors duration-500" />
                    </div>
                    <h3 className="text-2xl font-bold text-white mb-3">Discover Events</h3>
                    <p className="text-neutral-400 leading-relaxed mb-6">Browse public events happening right now. Find meetups, workshops, and gatherings open to everyone.</p>
                    <div className="flex items-center gap-2 text-sm font-medium text-neutral-300 group-hover:text-white transition-colors">
                      Browse events
                      <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200" />
                    </div>
                  </div>
                </a>
              </Reveal>
              )}

              {/* Status Card */}
              <Reveal delay={120} direction="right">
                <a href="/status" className="lq-glass lq-lift group relative block p-8 sm:p-10 rounded-[1.5rem] h-full">
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                    style={{ background: 'radial-gradient(ellipse at top right, rgba(20,180,80,0.10) 0%, transparent 65%)' }} />
                  <div className="relative">
                    <div className="w-14 h-14 rounded-2xl bg-neutral-800 border border-neutral-700 flex items-center justify-center mb-6 group-hover:bg-white group-hover:border-white transition-all duration-500 group-hover:scale-110">
                      <TrendingUp className="w-7 h-7 text-neutral-300 group-hover:text-neutral-900 transition-colors duration-500" />
                    </div>
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-2xl font-bold text-white">System Status</h3>
                      <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-950/60 border border-emerald-900/50 text-emerald-400">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
                        Operational
                      </span>
                    </div>
                    <p className="text-neutral-400 leading-relaxed mb-6">Monitor real-time uptime, API performance, and incident history. Stay informed about service health.</p>
                    <div className="flex items-center gap-2 text-sm font-medium text-neutral-300 group-hover:text-white transition-colors">
                      View status
                      <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform duration-200" />
                    </div>
                  </div>
                </a>
              </Reveal>
            </div>
          </div>
        </section>

        {/* CREATE EVENT */}
        <SectionSeam tint="neutral" />
        <section id="create" className="py-28 sm:py-32 border-t border-neutral-800/40" style={{ display: selectedBranch ? 'block' : 'none' }}>
          <div className="max-w-8xl mx-auto px-4 sm:px-6">
            <div className="grid lg:grid-cols-2 gap-10 lg:gap-20 items-start">

              <div className="lg:sticky lg:top-24">
                <Reveal direction="left">
                  <div className="mb-10">
                    <h2 className="font-syne font-black text-white mb-6 tracking-tight leading-[1.05]" style={{ fontSize: 'clamp(2.2rem, 4vw, 3.2rem)' }}>
                      {created
                        ? mode === 'table-service' ? 'Venue created!' : mode === 'rsvp' ? 'Your RSVP page is live!' : 'Event created!'
                        : mode === 'table-service' ? 'Set up your venue' : mode === 'enterprise' ? 'Launch an enterprise event' : mode === 'rsvp' ? 'Create your RSVP page' : 'Start planning your event'}
                    </h2>
                    <p className="text-lg sm:text-xl text-neutral-400 leading-relaxed">
                      {created
                        ? mode === 'table-service'
                          ? 'Your floor management system is live. Set up your seating layout and go.'
                          : mode === 'rsvp'
                            ? 'Your section-based RSVP builder is ready. Add blocks, pick a cover, and share your link.'
                            : 'Your planning hub is ready. Share the link with your team and get started.'
                        : mode === 'table-service'
                          ? 'Create your restaurant workspace in 60 seconds. Your data never expires.'
                          : mode === 'enterprise'
                            ? 'Built for large-scale, ticketed events. Every guest gets a personalized QR invite and seamless check-in.'
                            : mode === 'rsvp'
                              ? 'Just a guest list and a beautiful RSVP page. No seating charts, no floor management. Live in under a minute.'
                              : 'Create your event workspace in 60 seconds. No credit card, no hassle, just start planning.'}
                    </p>
                  </div>
                </Reveal>

                {!created && (
                  <Reveal delay={100}>
                    <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-10">
                      {[{ icon: Clock, label: '60 seconds' }, { icon: Shield, label: 'Secure' }, { icon: CheckCircle2, label: 'Free forever' }].map((item, i) => (
                        <div key={i} className="lq-glass lq-lift group text-center p-5 rounded-[1.25rem]">
                          <item.icon className="w-6 h-6 text-neutral-400 mx-auto mb-2 transition-transform duration-400 group-hover:scale-110 group-hover:text-neutral-200" />
                          <p className="text-sm font-semibold text-neutral-300">{item.label}</p>
                        </div>
                      ))}
                    </div>
                    {mode === 'table-service' ? (
                      <div className="lq-glass space-y-3 p-5 sm:p-8 rounded-[1.5rem]">
                        <p className="text-base font-bold text-white mb-4">Everything included in Table Service:</p>
                        {['Visual floor plan editor: drag & drop tables anywhere', 'Live table states: available, occupied, cleaning, reserved', 'Walk-in waitlist with real-time estimated wait times', 'QR code reservations with configurable expiry windows', 'Per-restaurant timing config: dining duration, buffer, hours', 'Instant sync across all staff devices via live socket', 'Data never auto-deleted: your floor plan persists forever', 'Party size tracking and server assignment per table', 'Occupancy overview and turn time estimates at a glance'].map((item, i) => (
                          <div key={i} className="flex items-start gap-3 text-sm text-neutral-400">
                            <CheckCircle2 className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                            <span className="leading-relaxed">{item}</span>
                          </div>
                        ))}
                      </div>
                    ) : mode === 'enterprise' ? (
                      <div className="rounded-3xl border border-indigo-500/20 overflow-hidden" style={{ background: 'rgba(8,8,20,0.7)' }}>
                        {/* Enterprise vs Standard comparison header */}
                        <div className="grid grid-cols-2 border-b border-indigo-500/15">
                          <div className="px-5 py-3 border-r border-indigo-500/10">
                            <span className="text-xs font-bold text-neutral-500 uppercase tracking-widest">Standard</span>
                          </div>
                          <div className="px-5 py-3 flex items-center gap-2" style={{ background: 'rgba(47,91,255,0.06)' }}>
                            <Zap className="w-3 h-3 text-indigo-400" />
                            <span className="text-xs font-bold text-indigo-400 uppercase tracking-widest">Enterprise</span>
                          </div>
                        </div>
                        {[
                          ['Open RSVP link', 'Personalized QR invite per guest'],
                          ['Basic attendance count', 'Real-time check-in dashboard'],
                          ['No guest tracking', 'Group sizes + table assignments'],
                          ['No trust scoring', 'Security flags + override tools'],
                          ['No entry verification', 'Duplicate & fraud detection'],
                          ['Chat, tasks, polls, budget', 'All Standard features included'],
                        ].map(([std, ent], i) => (
                          <div key={i} className="grid grid-cols-2 border-b border-white/[0.04] last:border-b-0">
                            <div className="px-5 py-3 border-r border-white/[0.04] flex items-start gap-2.5">
                              <span className="mt-0.5 text-neutral-600 text-xs flex-shrink-0">✕</span>
                              <span className="text-xs text-neutral-600 leading-relaxed">{std}</span>
                            </div>
                            <div className="px-5 py-3 flex items-start gap-2.5" style={{ background: 'rgba(47,91,255,0.03)' }}>
                              <CheckCircle2 className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0 mt-0.5" />
                              <span className="text-xs text-indigo-300/70 leading-relaxed">{ent}</span>
                            </div>
                          </div>
                        ))}
                        {/* Warning */}
                        <div className="px-5 py-3 flex items-center gap-2" style={{ background: 'rgba(239,68,68,0.06)', borderTop: '1px solid rgba(239,68,68,0.12)' }}>
                          <AlertCircle className="w-3.5 h-3.5 text-red-400/70 flex-shrink-0" />
                          <span className="text-xs text-red-400/60">Mode cannot be changed after creation</span>
                        </div>
                      </div>
                    ) : mode === 'rsvp' ? (
                      <div className="lq-glass space-y-3 p-5 sm:p-8 rounded-[1.5rem]">
                        <p className="text-base font-bold text-white mb-4">What's included in an RSVP Event:</p>
                        {['Section-based drag-and-drop RSVP page builder', 'A 16-block library: hero, agenda, FAQ, gallery, sponsors, and more', 'Auto-generated cover graphic, no design work needed', 'Guest list with the same tools as every PlanIt event', 'Simple check-in (scan or confirm)', 'Analytics on views and responses'].map((item, i) => (
                          <div key={i} className="flex items-start gap-3 text-sm text-neutral-400">
                            <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                            <span className="leading-relaxed">{item}</span>
                          </div>
                        ))}
                        <div className="flex items-start gap-3 text-sm pt-2 mt-2 border-t border-neutral-800/60">
                          <X className="w-5 h-5 text-neutral-600 flex-shrink-0 mt-0.5" />
                          <span className="leading-relaxed text-neutral-600">No seating charts, floor management, ticketing, or enterprise check-in: that's what Standard Event and Venue are for.</span>
                        </div>
                      </div>
                    ) : (
                      <div className="lq-glass space-y-3 p-5 sm:p-8 rounded-[1.5rem]">
                        <p className="text-base font-bold text-white mb-4">Everything included:</p>
                        {['Private event space with custom branded URL', 'Unlimited team members, no caps', 'Real-time chat with file sharing', 'Task lists and deadline tracking', 'Polls, voting, and decision tools', 'RSVP management and tracking', 'Expense splitting and budgets', 'QR check-in for large events', 'Timeline and scheduling tools'].map((item, i) => (
                          <div key={i} className="flex items-start gap-3 text-sm text-neutral-400">
                            <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" />
                            <span className="leading-relaxed">{item}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </Reveal>
                )}

                {created && (
                  <Reveal delay={100}>
                    <div className="space-y-6">
                      <div className="flex items-center justify-center p-10 bg-emerald-500/10 rounded-3xl border border-emerald-500/20">
                        <div className="text-center">
                          <div className="w-20 h-20 mx-auto mb-5 rounded-full bg-emerald-500 flex items-center justify-center animate-bounce shadow-lg">
                            <Check className="w-10 h-10 text-white" />
                          </div>
                          <p className="text-lg font-bold text-emerald-400">
                            {mode === 'table-service' ? 'Venue created!' : mode === 'enterprise' ? 'Enterprise event created!' : mode === 'rsvp' ? 'Your RSVP page is live!' : 'Your planning hub is live!'}
                          </p>
                        </div>
                      </div>
                      {mode === 'table-service' ? (
                        <div className="lq-glass p-8 rounded-[1.5rem]">
                          <div className="flex items-start gap-4">
                            <UtensilsCrossed className="w-6 h-6 text-orange-400 flex-shrink-0 mt-1" />
                            <div className="w-full">
                              <p className="text-base font-bold text-white mb-4">Your venue is live!</p>
                              {formData.staffPassword && (
                                <div className="mb-4 p-3 bg-neutral-800 border border-neutral-700 rounded-xl">
                                  <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-2">Default staff login</p>
                                  <div className="flex justify-between text-sm">
                                    <span className="text-neutral-400">Username</span>
                                    <span className="text-white font-mono font-bold">staff</span>
                                  </div>
                                  <div className="flex justify-between text-sm mt-1">
                                    <span className="text-neutral-400">Password</span>
                                    <span className="text-white font-mono font-bold">{formData.staffPassword}</span>
                                  </div>
                                  <p className="text-xs text-neutral-600 mt-2">Share this with your team: they log in at <code className="text-neutral-500">/login</code></p>
                                </div>
                              )}
                              <ol className="text-sm text-neutral-400 space-y-3 list-decimal ml-5">
                                <li>Open your floor dashboard and click "Edit Layout"</li>
                                <li>Drag and drop tables to match your restaurant's floor plan</li>
                                <li>Set each table's capacity and label</li>
                                <li>Open Settings to configure dining time and operating hours</li>
                                <li>Staff log in at <code className="text-neutral-500">/login</code> and go straight to the floor</li>
                              </ol>
                            </div>
                          </div>
                        </div>
                      ) : mode === 'enterprise' ? (
                        <div className="lq-glass p-8 rounded-[1.5rem]">
                          <div className="flex items-start gap-4">
                            <Zap className="w-6 h-6 text-neutral-400 flex-shrink-0 mt-1" />
                            <div>
                              <p className="text-base font-bold text-white mb-4">Next steps for Enterprise Mode:</p>
                              <ol className="text-sm text-neutral-400 space-y-3 list-decimal ml-5">
                                <li>Enter your event and click "Manage Guest Invites"</li>
                                <li>Add all guests with names, email, and group sizes</li>
                                <li>Send personalized invite links with QR codes to each guest</li>
                                <li>On event day, use the check-in dashboard to scan QR codes</li>
                                <li>View real-time attendance analytics as guests arrive</li>
                              </ol>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <p className="text-sm font-bold text-neutral-300 mb-3">Your event link:</p>
                          <CopyLinkBox eventId={created.id} subdomain={created.subdomain} mode={mode} />
                          <p className="text-xs text-neutral-600 mt-3">Share this link with your planning team to get started</p>
                        </div>
                      )}
                      <button
                        onClick={() => {
                          const base = created.subdomain ? `/e/${created.subdomain}` : `/event/${created.id}`;
                          navigate(
                            mode === 'table-service' ? `${base}/floor`
                              : mode === 'rsvp' ? `${base}/rsvp-dashboard`
                              : `${base}?new=1`
                          );
                        }}
                        className="w-full px-8 py-5 bg-white text-neutral-900 rounded-2xl font-bold hover:scale-105 hover:bg-neutral-100 transition-all duration-300 shadow-xl flex items-center justify-center gap-3 text-lg"
                      >
                        {mode === 'table-service' ? 'Open Floor Dashboard' : mode === 'enterprise' ? 'Set Up Guest Invites' : mode === 'rsvp' ? 'Open RSVP Dashboard' : 'Enter your planning hub'}
                        <ArrowUpRight className="w-5 h-5" />
                      </button>
                    </div>
                  </Reveal>
                )}
              </div>

              {!created && (
                <Reveal delay={80}>
                  <div className="sticky top-24">
                    {/* Mode selector keeps the full set of WL event types available inside the same wizard. */}
                    {(isWL || selectedBranch === 'events' || selectedBranch === 'rsvp') && (
                      <div style={{ display:'flex', gap:6, marginBottom:20, padding:'6px', background:'rgba(255,255,255,0.03)', borderRadius:14, border:'1px solid rgba(255,255,255,0.06)' }}>
                        {[
                          { val:'standard',   label:'Standard',   sub:'Team planning'  },
                          { val:'enterprise', label:'Enterprise', sub:'Large + QR'     },
                          { val:'rsvp',       label:'RSVP',       sub:'Just RSVPs'     },
                          ...(isWL ? [{ val:'table-service', label:'Restaurant', sub:'Tables + bookings' }] : []),
                        ].map(({ val, label, sub }) => (
                          <button key={val} type="button" onClick={() => {
                              setMode(val);
                              setFormData(p => ({ ...p, isEnterpriseMode: val === 'enterprise' }));
                              setWizardKey(k => k + 1);
                              const nextBranch = val === 'table-service' ? 'venue' : val === 'rsvp' ? 'rsvp' : 'events';
                              if (nextBranch !== selectedBranch) {
                                setSelectedBranch(nextBranch);
                                setTimeout(() => document.getElementById(nextBranch === 'venue' ? 'planit-venue' : nextBranch === 'rsvp' ? 'planit-rsvp' : 'planit-events')?.scrollIntoView({ behavior:'smooth', block:'start' }), 50);
                              }
                            }}
                            data-mode={val}
                            style={{
                              flex:1, padding:'9px 12px', borderRadius:10, border:'none', cursor:'pointer',
                              background: mode === val ? (val === 'enterprise' ? 'rgba(47,91,255,0.9)' : val === 'rsvp' ? 'rgba(16,185,129,0.9)' : '#fff') : 'transparent',
                              color: mode === val ? (val === 'enterprise' || val === 'rsvp' ? '#fff' : '#111') : 'rgba(255,255,255,0.4)',
                              fontWeight:700, fontSize:13, transition:'all 0.2s ease',
                              boxShadow: mode === val && val === 'enterprise' ? '0 0 20px rgba(47,91,255,0.3)' : mode === val && val === 'rsvp' ? '0 0 20px rgba(16,185,129,0.3)' : 'none',
                            }}>
                            <div>{label}</div>
                            <div style={{ fontSize:11, opacity:0.6, fontWeight:400, marginTop:1 }}>{sub}</div>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Launch wizard CTA */}
                    <div
                      className="lq-glass-strong"
                      style={{
                        borderRadius:24,
                        padding:'48px 40px',
                        textAlign:'center',
                        position:'relative',
                        overflow:'hidden',
                      }}
                    >
                      {/* Ambient glow */}
                      <div aria-hidden="true" style={{
                        position:'absolute', inset:0, pointerEvents:'none',
                        background: mode === 'table-service'
                          ? 'radial-gradient(ellipse at 50% 0%, rgba(249,115,22,0.07) 0%, transparent 70%)'
                          : mode === 'enterprise'
                            ? 'radial-gradient(ellipse at 50% 0%, rgba(47,91,255,0.12) 0%, transparent 70%)'
                            : 'radial-gradient(ellipse at 50% 0%, rgba(47,91,255,0.08) 0%, transparent 70%)',
                      }} />

                      {/* Icon */}
                      <div style={{
                        width:56, height:56, borderRadius:16, margin:'0 auto 24px',
                        background: mode === 'table-service' ? 'rgba(249,115,22,0.1)' : mode === 'enterprise' ? 'rgba(47,91,255,0.15)' : 'rgba(47,91,255,0.1)',
                        border: mode === 'table-service' ? '1px solid rgba(249,115,22,0.2)' : mode === 'enterprise' ? '1px solid rgba(47,91,255,0.35)' : '1px solid rgba(47,91,255,0.2)',
                        display:'flex', alignItems:'center', justifyContent:'center',
                        boxShadow: mode === 'table-service' ? '0 0 32px rgba(249,115,22,0.12)' : mode === 'enterprise' ? '0 0 40px rgba(47,91,255,0.25)' : '0 0 32px rgba(47,91,255,0.12)',
                      }}>
                        {mode === 'table-service'
                          ? <UtensilsCrossed style={{ width:26, height:26, color:'#f97316' }} />
                          : mode === 'enterprise'
                            ? <Zap style={{ width:26, height:26, color:'#90abff' }} />
                            : <Calendar style={{ width:26, height:26, color:'#5f84ff' }} />
                        }
                      </div>

                      <p style={{
                        fontFamily:'var(--font-display)', fontSize:'clamp(1.4rem,3vw,1.75rem)',
                        fontWeight:800, color:'#fff', lineHeight:1.2, marginBottom:10,
                      }}>
                        {mode === 'table-service' ? 'Launch your venue' : mode === 'enterprise' ? 'Launch enterprise event' : 'Create your event'}
                      </p>
                      <p style={{ fontSize:14, color:'rgba(255,255,255,0.35)', marginBottom:36, lineHeight:1.6, maxWidth:260, margin:'0 auto 36px' }}>
                        {mode === 'table-service'
                          ? 'Set up your floor plan and start managing tables in under 60 seconds.'
                          : mode === 'enterprise'
                            ? 'Personalized QR invites, check-in dashboard, and real-time analytics for large events.'
                            : 'Build your planning workspace in under 60 seconds. No credit card required.'}
                      </p>

                      <button
                        onClick={() => { setFormData(p => ({ ...p, isEnterpriseMode: mode === 'enterprise' })); setWizardKey(k => k + 1); eventFormTimingRef.current.formStartedAt = Date.now(); setWizardOpen(true); }}
                        style={{
                          width:'100%', padding:'16px 28px', borderRadius:14, border:'none', cursor:'pointer',
                          background: mode === 'table-service'
                            ? 'linear-gradient(135deg, #f97316, #fb923c)'
                            : mode === 'enterprise'
                              ? 'linear-gradient(135deg, #1f43e6, #1f43e6)'
                              : 'linear-gradient(135deg, #2f5bff, #5f84ff)',
                          color:'#fff', fontSize:15, fontWeight:700,
                          display:'flex', alignItems:'center', justifyContent:'center', gap:10,
                          transition:'transform 0.2s ease, box-shadow 0.2s ease',
                          boxShadow: mode === 'table-service'
                            ? '0 8px 28px rgba(249,115,22,0.35)'
                            : mode === 'enterprise'
                              ? '0 8px 32px rgba(79,70,229,0.5)'
                              : '0 8px 28px rgba(47,91,255,0.35)',
                          fontFamily:'DM Sans,sans-serif',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.transform='translateY(-2px)'; e.currentTarget.style.boxShadow = mode === 'table-service' ? '0 14px 36px rgba(249,115,22,0.45)' : mode === 'enterprise' ? '0 16px 40px rgba(79,70,229,0.6)' : '0 14px 36px rgba(47,91,255,0.45)'; }}
                        onMouseLeave={e => { e.currentTarget.style.transform=''; e.currentTarget.style.boxShadow = mode === 'table-service' ? '0 8px 28px rgba(249,115,22,0.35)' : mode === 'enterprise' ? '0 8px 32px rgba(79,70,229,0.5)' : '0 8px 28px rgba(47,91,255,0.35)'; }}
                      >
                        {mode === 'table-service' ? 'Set up your venue' : mode === 'enterprise' ? 'Set up enterprise event' : 'Start building'}
                        <ArrowRight style={{ width:18, height:18 }} />
                      </button>

                      {/* Trust signals */}
                      <div style={{ display:'flex', alignItems:'center', justifyContent:'center', gap:20, marginTop:24 }}>
                        {[
                          { icon: Clock, text:'~60 seconds' },
                          { icon: Shield, text:'Encrypted' },
                          { icon: CheckCircle2, text:'Free forever' },
                        ].map(({ icon: Icon, text }) => (
                          <div key={text} style={{ display:'flex', alignItems:'center', gap:5, fontSize:12, color:'rgba(255,255,255,0.28)' }}>
                            <Icon style={{ width:12, height:12 }} />
                            {text}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </Reveal>
              )}

              {/* Fullscreen wizard overlay */}
              {wizardOpen && !created && (
                <div
                  style={{
                    position:'fixed', inset:0, zIndex:1000,
                    background:'rgba(5,5,10,0.96)',
                    backdropFilter:'blur(20px)',
                    display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center',
                    animation:'wiz-overlay-in 0.35s cubic-bezier(0.22,1,0.36,1) both',
                    padding:'24px',
                  }}
                >
                  {/* Ambient orb */}
                  <div aria-hidden="true" style={{
                    position:'absolute', top:'-10%', left:'50%', transform:'translateX(-50%)',
                    width:600, height:600, borderRadius:'50%', pointerEvents:'none',
                    background: mode === 'table-service'
                      ? 'radial-gradient(circle, rgba(249,115,22,0.07) 0%, transparent 65%)'
                      : mode === 'rsvp'
                      ? 'radial-gradient(circle, rgba(16,185,129,0.08) 0%, transparent 65%)'
                      : 'radial-gradient(circle, rgba(47,91,255,0.08) 0%, transparent 65%)',
                    filter:'blur(40px)',
                  }} />

                  {/* Close button */}
                  <button
                    onClick={() => setWizardOpen(false)}
                    style={{
                      position:'absolute', top:24, right:24,
                      width:40, height:40, borderRadius:12,
                      background:'rgba(255,255,255,0.05)',
                      border:'1px solid rgba(255,255,255,0.08)',
                      color:'rgba(255,255,255,0.5)',
                      cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                      transition:'background 0.2s, color 0.2s',
                      fontFamily:'DM Sans,sans-serif',
                      fontSize:20, lineHeight:1,
                    }}
                    onMouseEnter={e => { e.currentTarget.style.background='rgba(255,255,255,0.1)'; e.currentTarget.style.color='#fff'; }}
                    onMouseLeave={e => { e.currentTarget.style.background='rgba(255,255,255,0.05)'; e.currentTarget.style.color='rgba(255,255,255,0.5)'; }}
                    aria-label="Close"
                  >
                    ×
                  </button>

                  {/* Wordmark */}
                  <div style={{ position:'absolute', top:26, left:28, display:'flex', alignItems:'center', gap:10 }}>
                    <div style={{
                      width:32, height:32, borderRadius:9,
                      background: mode === 'table-service' ? 'rgba(249,115,22,0.1)' : mode === 'rsvp' ? 'rgba(16,185,129,0.1)' : 'rgba(47,91,255,0.1)',
                      border: mode === 'table-service' ? '1px solid rgba(249,115,22,0.25)' : mode === 'rsvp' ? '1px solid rgba(16,185,129,0.25)' : '1px solid rgba(47,91,255,0.25)',
                      display:'flex', alignItems:'center', justifyContent:'center',
                    }}>
                      {mode === 'table-service'
                        ? <UtensilsCrossed style={{ width:15, height:15, color:'#f97316' }} />
                        : mode === 'rsvp'
                        ? <CheckSquare style={{ width:15, height:15, color:'#34d399' }} />
                        : <Calendar style={{ width:15, height:15, color:'#5f84ff' }} />
                      }
                    </div>
                    <span style={{ fontFamily:'var(--font-display)', fontWeight:800, fontSize:17, color:'rgba(255,255,255,0.7)', letterSpacing:'-0.02em' }}>PlanIt</span>
                  </div>

                  {/* Wizard card */}
                  <div style={{
                    width:'100%', maxWidth:520,
                    background:'rgba(12,12,20,0.9)',
                    border:'1px solid rgba(255,255,255,0.08)',
                    borderRadius:28,
                    padding:'clamp(28px,6vw,52px)',
                    boxShadow:'0 40px 100px rgba(0,0,0,0.7)',
                    position:'relative',
                  }}>
                    {/* Mode tabs (events + rsvp; hidden for venue) */}
                    {selectedBranch !== 'venue' && (
                      <div style={{ display:'flex', gap:6, marginBottom:32, padding:'6px', background:'rgba(255,255,255,0.03)', borderRadius:14, border:'1px solid rgba(255,255,255,0.06)' }}>
                        {[
                          { val:'standard',   label:'Standard',   sub:'Team planning'  },
                          { val:'enterprise', label:'Enterprise', sub:'Large + QR'     },
                          { val:'rsvp',       label:'RSVP',       sub:'Just RSVPs'     },
                        ].map(({ val, label, sub }) => (
                          <button key={val} type="button" onClick={() => { setMode(val); setFormData(p => ({ ...p, isEnterpriseMode: val === 'enterprise' })); setWizardKey(k => k + 1); if (val === 'rsvp' && selectedBranch !== 'rsvp') setSelectedBranch('rsvp'); if (val !== 'rsvp' && selectedBranch === 'rsvp') setSelectedBranch('events'); }}
                            style={{
                              flex:1, padding:'9px 12px', borderRadius:10, border:'none', cursor:'pointer',
                              background: mode === val ? (val === 'enterprise' ? 'rgba(47,91,255,0.9)' : val === 'rsvp' ? 'rgba(16,185,129,0.9)' : '#fff') : 'transparent',
                              color: mode === val ? (val === 'enterprise' || val === 'rsvp' ? '#fff' : '#111') : 'rgba(255,255,255,0.4)',
                              fontWeight:700, fontSize:13, transition:'all 0.2s ease',
                              fontFamily:'DM Sans,sans-serif',
                              boxShadow: mode === val && val === 'enterprise' ? '0 0 20px rgba(47,91,255,0.35)' : mode === val && val === 'rsvp' ? '0 0 20px rgba(16,185,129,0.35)' : 'none',
                            }}>
                            <div>{label}</div>
                            <div style={{ fontSize:11, opacity:0.6, fontWeight:400, marginTop:1 }}>{sub}</div>
                          </button>
                        ))}
                      </div>
                    )}

                    <OnboardingWizard
                      key={wizardKey}
                      mode={mode}
                      formData={formData}
                      setFormData={setFormData}
                      fieldErrors={fieldErrors}
                      setFieldErrors={setFieldErrors}
                      loading={loading}
                      submittedRef={wizardSubmittedRef}
                      stepControlRef={wizardStepRef}
                      abuseStatus={abuseStatus}
                      requiresVerification={requiresVerification}
                      onCaptchaToken={setTurnstileToken}
                      captchaResetKey={captchaResetKey}
                      onUserInput={() => { if (!eventFormTimingRef.current.firstInputAt) eventFormTimingRef.current.firstInputAt = Date.now(); }}
                      onUserPaste={(e) => { const len = e.clipboardData?.getData('text')?.length || 0; if (len > eventFormTimingRef.current.largestPasteChars) { eventFormTimingRef.current.largestPasteChars = len; eventFormTimingRef.current.largestPasteElapsedMs = Date.now() - (eventFormTimingRef.current.firstInputAt || eventFormTimingRef.current.pageLoadedAt); } }}
                      onSubmit={async () => { const ok = await handleSubmit(); if (ok) setWizardOpen(false); }}
                    />
                  </div>

                  <p style={{ marginTop:20, fontSize:12, color:'rgba(255,255,255,0.18)', letterSpacing:'0.05em' }}>
                    Press Esc to close
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* FINALE: a cinematic close with a clear next step */}
        {!(selectedBranch || isWL) && (
          <SpotlightStage id="start" minHeight="92dvh">
            <div className="flex flex-col justify-between gap-16 px-8 pb-10 pt-28 md:px-16 lg:px-20" style={{ minHeight: '92dvh' }}>
              <div>
                <p className="lq-kicker mb-6">{'// Start'}</p>
                <BlurText
                  as="h2"
                  justify="start"
                  text={"Let's plan\nsomething."}
                  className="lq-display text-white leading-[0.95] text-5xl md:text-7xl lg:text-8xl"
                />
                <p className="mt-6 max-w-[44ch] text-sm md:text-base font-light leading-snug text-white/90">
                  Free for every event. Create your workspace in under a minute: no credit card, and no accounts for your guests.
                </p>
                <div className="mt-8 flex flex-wrap items-center gap-6">
                  <button onClick={() => selectBranch('events')} className="lq-glass-strong inline-flex items-center gap-2 rounded-full px-5 py-2.5 text-sm font-medium text-white">
                    Start with Events <ArrowUpRight className="h-5 w-5" />
                  </button>
                  <button onClick={() => selectBranch('venue')} className="inline-flex items-center gap-2 text-sm font-medium text-white transition-colors hover:text-white/80">
                    Explore Venue <ArrowUpRight className="h-4 w-4" />
                  </button>
                  <button onClick={() => selectBranch('rsvp')} className="inline-flex items-center gap-2 text-sm font-medium text-white transition-colors hover:text-white/80">
                    Just need RSVPs? <ArrowUpRight className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4" aria-label="Highlights">
                {[
                  ['Free forever', 'No credit card, no per-seat pricing'],
                  ['No guest accounts', 'Guests join by name with a personal QR'],
                  ['Unlimited team', 'Organizers, vendors and volunteers'],
                  ['Tidy by default', 'Event data auto-deleted 7 days after'],
                ].map(([t, d]) => (
                  <li key={t} className="lq-glass-strong rounded-[1.25rem] p-5 text-white">
                    <div className="lq-display text-2xl leading-tight">{t}</div>
                    <div className="mt-2 text-xs font-light text-white/90">{d}</div>
                  </li>
                ))}
              </ul>
            </div>
          </SpotlightStage>
        )}

        {/* FOOTER */}
        <PublicFooter compact={!!selectedBranch} />

      </main>
    </div>
  );
}
