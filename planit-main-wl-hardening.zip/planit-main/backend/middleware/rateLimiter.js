const rateLimit = require('express-rate-limit');
const { realIp: resolveRealIp, isPrivate } = require('./realIp');

// ── Real-IP resolver ──────────────────────────────────────────────────────────
// Delegates to the shared realIp module (CF-Connecting-IP → XFF → req.ip)
// which correctly skips all private/internal ranges (10.x, 172.16-31.x, etc.).
// If the resolved IP is private/unknown (internal Render hop without Cloudflare),
// return a per-request unique key so we never rate-limit one user as all users.
function realIp(req) {
  const ip = resolveRealIp(req);
  // If we can't determine a real public IP, derive a key from the Authorization
  // token or a unique request ID so limits don't collapse all traffic onto one key.
  if (isPrivate(ip) || ip === 'unknown') {
    const authHeader = req.headers['authorization'] || '';
    const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7, 47) : null;
    if (token) return `tok:${token}`;
    // Absolute last resort: let it through ungrouped
    // V-08 FIX: Use a FIXED internal bucket instead of random — random keys bypass rate limiting entirely
    return 'internal:unknown';
  }
  return ip;
}

// ── Skip helpers ──────────────────────────────────────────────────────────────
// Health-check and internal mesh routes must NEVER be rate-limited.
// The router pings /api/mesh/health and /api/mesh/seen every 4 minutes.
// The watchdog pings /api/health on every backend every 30 s.
// Counting these against quotas causes false "backend down" alerts.
// Two path forms are checked because req.path is mount-relative:
//   globally-mounted middleware → sees '/api/health'
//   mounted at '/api/'          → sees '/health'
const skipInternal = (req) => {
  const p = req.path;
  return (
    p === '/health'         || p === '/api/health'      ||
    p === '/ping'           || p === '/api/ping'        ||
    p === '/status'         || p === '/api/status'      ||
    p === '/uptime/ping'    || p === '/api/uptime/ping' ||
    p.startsWith('/mesh')   || p.startsWith('/api/mesh')
  );
};

// General API rate limiter — applied to all /api/* except internal paths above.
// V-08 FIX: Skip ALL internal/private traffic (watchdog pings, mesh calls, Render-to-Render
// hops) so they never count against any shared bucket. This mirrors the logic in security.js
// step 4 — internal RFC-1918 IPs are let through without rate counting.
const apiLimiter = rateLimit({
  windowMs: (process.env.RATE_LIMIT_WINDOW || 15) * 60 * 1000,
  max:      process.env.RATE_LIMIT_MAX || 10000,
  standardHeaders: true,
  legacyHeaders:   false,
  skip: (req) => {
    if (skipInternal(req)) return true;
    const ip = resolveRealIp(req);
    // All private/unknown IPs are internal Render mesh hops — never rate-limit them.
    // Previously these collapsed into a single 'internal:unknown' bucket which caused
    // the watchdog to receive 429s and log healthy backends as down.
    return isPrivate(ip) || ip === 'unknown';
  },
  keyGenerator:    realIp,
  handler: (req, res) => {
    res.status(429).json({
      error:       'Too many requests',
      message:     'You have exceeded the rate limit. Please try again later.',
      retryAfter:  res.getHeader('Retry-After'),
    });
  },
});

// Stricter limiter for authentication endpoints
// FIX: Removed skipSuccessfulRequests — it caused successful logins to not count
// toward the limit, allowing unlimited successful logins. All attempts (successful
// or not) must be counted to prevent credential-stuffing and session-farming attacks.
const authLimiter = rateLimit({
  windowMs:        15 * 60 * 1000,
  max:             20,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator:    realIp,
  handler: (req, res) => {
    res.status(429).json({
      error:      'Too many authentication attempts, please try again in 15 minutes.',
      retryAfter: res.getHeader('Retry-After'),
    });
  },
});

// File upload limiter
const uploadLimiter = rateLimit({
  windowMs:        60 * 60 * 1000,
  max:             20,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator:    realIp,
  message:         { error: 'Too many file uploads, please try again later.' },
});

// Event creation limiter
const createEventLimiter = rateLimit({
  windowMs:        60 * 60 * 1000,
  max:             3,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator:    realIp,
  message:         { error: 'Too many events created, please try again later.' },
});

// Chat message limiter
const chatLimiter = rateLimit({
  windowMs:        60 * 1000,
  max:             30,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator: (req) => {
    const ip      = realIp(req);
    const eventId = req.params.eventId || req.body?.eventId || 'none';
    return `${ip}-${eventId}`;
  },
  message: { error: 'Too many messages, please slow down.' },
});

// Join endpoint limiter
const joinLimiter = rateLimit({
  windowMs:        10 * 60 * 1000,
  max:             30,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator: (req) => {
    const ip      = realIp(req);
    const eventId = req.params.eventId || 'none';
    return `join:${ip}:${eventId}`;
  },
  handler: (req, res) => {
    res.status(429).json({
      error:       'Too many join attempts from this network. Please try again later.',
      retryAfter:  res.getHeader('Retry-After'),
    });
  },
});

// Honeypot middleware
function honeypotCheck(req, res, next) {
  if (req.body && req.body._confirm !== undefined) {
    return res.status(200).json({ message: 'Joined successfully', token: null, event: {} });
  }
  next();
}

// Public reservation limiter
const reservationLimiter = rateLimit({
  windowMs:        60 * 60 * 1000,
  max:             10,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator: (req) => {
    const ip        = realIp(req);
    const subdomain = req.params.subdomain || 'none';
    return `reserve:${ip}:${subdomain}`;
  },
  handler: (req, res) => {
    res.status(429).json({
      error:      'Too many reservation attempts from this connection. Please try again in an hour.',
      retryAfter: res.getHeader('Retry-After'),
    });
  },
});

// Reservation availability check limiter
const availabilityLimiter = rateLimit({
  windowMs:        60 * 1000,
  max:             60,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator:    realIp,
  message:         { error: 'Too many availability requests, please slow down.' },
});

// SEC FIX: Invite codes are public lookup keys (guest name/email/phone behind
// them). Without a limiter here, an attacker can brute-force the code space
// from a single IP. Tight per-IP cap; codes are also now high-entropy (see
// events.js) so guessing within this budget is infeasible either way.
const inviteLookupLimiter = rateLimit({
  windowMs:        15 * 60 * 1000,
  max:             30,
  standardHeaders: true,
  legacyHeaders:   false,
  keyGenerator:    realIp,
  message:         { error: 'Too many invite lookups, please slow down.' },
});

module.exports = {
  apiLimiter,
  authLimiter,
  uploadLimiter,      // Apply to: POST /api/files/:eventId/upload
  createEventLimiter,
  chatLimiter,
  joinLimiter,        // Apply to: POST /api/events/join/:eventId
  honeypotCheck,
  reservationLimiter,
  availabilityLimiter,
  inviteLookupLimiter,
};
