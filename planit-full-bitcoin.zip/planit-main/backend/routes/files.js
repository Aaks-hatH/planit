const express = require('express');
const router = express.Router();
const multer = require('multer');
const cloudinary = require('cloudinary').v2;
const { verifyEventAccess: verifyEventToken } = require('../middleware/auth');
const { uploadLimiter } = require('../middleware/rateLimiter');
const File = require('../models/File');
const fs = require('fs');
const os = require('os');
const path = require('path');

// Configure Cloudinary
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true
});

// Use memory storage - files held in memory until we write to a temp path
const storage = multer.memoryStorage();

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // V-05 FIX: SVG removed — can contain <script> tags → stored XSS
    // V-06 FIX: ZIP variants removed — zip bombs with no decompression safety
    const allowedMimes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      // 'image/svg+xml' REMOVED — SVGs execute JS in browser
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'text/plain',
      'text/csv',
      // ZIP variants REMOVED — zip bombs risk
    ];
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('File type not allowed. Only images, PDFs, and common documents are supported.'));
    }
  }
});

// V-07 FIX: Magic byte map — validate actual file contents match declared MIME
const MAGIC_BYTES = {
  'image/jpeg': [[0xFF, 0xD8, 0xFF]],
  'image/png':  [[0x89, 0x50, 0x4E, 0x47]],
  'image/gif':  [[0x47, 0x49, 0x46, 0x38]],
  'image/webp': [[0x52, 0x49, 0x46, 0x46]],
  'application/pdf': [[0x25, 0x50, 0x44, 0x46]],
};
function checkMagicBytes(buffer, declaredMime) {
  const patterns = MAGIC_BYTES[declaredMime];
  if (!patterns) return true; // Office docs: complex magic, defer to Cloudinary
  return patterns.some(magic => magic.every((byte, i) => buffer[i] === byte));
}

// Per-purpose resize presets. Images arrive at wildly different raw sizes
// (a phone photo, a screenshot, a logo exported at 4000px) and were
// previously uploaded completely untouched, which is why hero covers and
// logos could come out stretched, oversized, or slow to load. `crop: limit`
// only ever scales DOWN (never upscales a small image) and preserves aspect
// ratio, so this only trims oversized images down to a sane max instead of
// forcing a specific shape.
const IMAGE_RESIZE_PRESETS = {
  // Wide hero/cover graphics shown behind page copy.
  cover: { width: 1600, height: 900, crop: 'limit' },
  // Small square-ish marks (organizer logo, host avatar).
  logo: { width: 500, height: 500, crop: 'limit' },
  // General attachments/photo-gallery images — cap so nothing multi-megapixel
  // ships to a guest's phone, but keep more headroom than a logo.
  default: { width: 2000, height: 2000, crop: 'limit' },
};

// Upload buffer to Cloudinary via a temporary file on disk.
//
// Previous attempts used upload_stream (stream flushing issues with SDK v1)
// and base64 data URIs (SDK v1 runs local format validation before sending,
// failing with "Invalid image file" even for valid files when resource_type
// is set explicitly).
//
// The only fully reliable method with Cloudinary SDK v1 is to write the buffer
// to a temp file and pass the file path to upload(). This bypasses all client-
// side validation and stream concerns — Cloudinary reads the file directly from
// disk and detects the format itself.
//
// resource_type: 'auto' lets Cloudinary's servers detect image/video/raw —
// removing our manual mimetype check which was the source of the "Invalid image
// file" rejection.
//
// `imagePreset` (optional): one of IMAGE_RESIZE_PRESETS' keys. Applied as an
// eager transformation so the returned/stored URL is already the resized
// asset — pages don't need to know a transform happened. Ignored for
// non-image uploads (PDFs, docs) since transformation only applies to images.
const uploadToCloudinary = async (buffer, filename, imagePreset) => {
  // Sanitize filename for use as a Cloudinary public_id.
  const safeName = (
    filename
      .replace(/\.[^/.]+$/, '')        // strip extension
      .replace(/\s+/g, '_')            // spaces → underscores
      .replace(/[^a-zA-Z0-9_-]/g, '')  // remove unsafe chars
  ) || 'upload';

  // Write the buffer to a uniquely named temp file
  const tmpPath = path.join(os.tmpdir(), `planit-${Date.now()}-${safeName}`);
  fs.writeFileSync(tmpPath, buffer);

  try {
    const preset = IMAGE_RESIZE_PRESETS[imagePreset] || IMAGE_RESIZE_PRESETS.default;
    const result = await cloudinary.uploader.upload(tmpPath, {
      folder: 'planit-events',
      resource_type: 'auto', // Let Cloudinary detect type — avoids client-side validation errors
      // V-15 FIX: Add crypto random suffix so IDs are not predictable/enumerable
      public_id: `${Date.now()}-${require('crypto').randomBytes(6).toString('hex')}-${safeName}`,
      secure: true,
      // Only meaningful for images; Cloudinary ignores transformation for
      // raw/video resource types resolved by 'auto', so this is safe to pass
      // unconditionally for every upload through this helper.
      transformation: [{ ...preset, quality: 'auto', fetch_format: 'auto' }],
    });
    return result;
  } finally {
    // Always clean up the temp file whether upload succeeded or failed
    try { fs.unlinkSync(tmpPath); } catch (_) {}
  }
};

// Upload file
// FIX: Added uploadLimiter — this route had no rate limiting, allowing unlimited uploads.
router.post('/:eventId/upload',
  uploadLimiter,
  verifyEventToken,
  (req, res, next) => {
    upload.single('files')(req, res, (err) => {
      if (err) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({ error: 'File too large', message: 'Maximum file size is 10MB.' });
        }
        if (err.code === 'LIMIT_UNEXPECTED_FILE') {
          return res.status(400).json({ error: 'Unexpected field', message: 'File must be uploaded under the "files" field.' });
        }
        return res.status(400).json({ error: 'Upload error', message: err.message });
      }
      next();
    });
  },
  async (req, res, next) => {
    // Fail fast if Cloudinary is not configured
    if (!process.env.CLOUDINARY_CLOUD_NAME || !process.env.CLOUDINARY_API_KEY || !process.env.CLOUDINARY_API_SECRET) {
      console.error('[PlanIt] Upload failed: Cloudinary environment variables are not set.');
      return res.status(503).json({
        error: 'Storage not configured',
        message: 'File storage is not available. Please contact the administrator.'
      });
    }

    // Track Cloudinary public_id for rollback if DB save fails
    let uploadedPublicId = null;
    let uploadedResourceType = null;

    try {
      const { eventId } = req.params;

      const event = req.event;
      if (!event) {
        return res.status(404).json({ error: 'Event not found' });
      }

      const username = req.eventAccess?.username || req.eventAccess?.sub;
      if (!username) {
        return res.status(403).json({ error: 'Not authorized — could not identify user' });
      }

      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      if (!req.file.buffer || req.file.buffer.length === 0) {
        return res.status(400).json({ error: 'Empty file', message: 'The uploaded file is empty.' });
      }

      // Anti-malware: scan extension and MIME type before touching Cloudinary
      const { scanUpload } = require('../middleware/security');
      const scanResult = scanUpload(req.file);
      if (!scanResult.ok) {
        return res.status(400).json({ error: 'File rejected', message: scanResult.reason });
      }

      // V-07 FIX: Validate magic bytes match declared MIME type (catches MIME spoofing)
      if (!checkMagicBytes(req.file.buffer, req.file.mimetype)) {
        return res.status(400).json({
          error: 'File rejected',
          message: 'File contents do not match the declared file type.',
        });
      }

      // Optional hint from the client ('cover' | 'logo') so images used in
      // specific spots (RSVP page hero, organizer logo) get resized to a
      // preset suited to where they'll actually be displayed, instead of
      // every upload — a hero photo or a tiny logo alike — going through
      // unresized. Anything else (or omitted) falls back to the general
      // default cap so ordinary attachments/photo-gallery images are still
      // capped at a sane size. See IMAGE_RESIZE_PRESETS above.
      const imagePreset = ['cover', 'logo'].includes(req.body?.purpose) ? req.body.purpose : 'default';

      const cloudinaryResult = await uploadToCloudinary(
        req.file.buffer,
        req.file.originalname,
        imagePreset
      );

      uploadedPublicId = cloudinaryResult.public_id;
      uploadedResourceType = cloudinaryResult.resource_type;

      const file = new File({
        eventId,
        filename: req.file.originalname,
        originalName: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        cloudinaryUrl: cloudinaryResult.secure_url,
        cloudinaryPublicId: cloudinaryResult.public_id,
        cloudinaryResourceType: cloudinaryResult.resource_type,
        uploadedBy: username
      });

      await file.save();

      const io = req.app.get('io');
      if (io) {
        io.to(`event-${eventId}`).emit('file_uploaded', {
          file: {
            _id: file._id,
            filename: file.filename,
            size: file.size,
            mimetype: file.mimetype,
            url: file.cloudinaryUrl,
            uploadedBy: file.uploadedBy,
            uploadedAt: file.uploadedAt
          }
        });
      }

      res.json({
        message: 'File uploaded successfully',
        file: {
          _id: file._id,
          filename: file.filename,
          size: file.size,
          mimetype: file.mimetype,
          url: file.cloudinaryUrl,
          uploadedBy: file.uploadedBy,
          uploadedAt: file.uploadedAt
        }
      });
    } catch (error) {
      console.error('[PlanIt] File upload error:', error?.message || error);

      // Roll back Cloudinary upload if DB save failed
      if (uploadedPublicId) {
        try {
          await cloudinary.uploader.destroy(uploadedPublicId, {
            resource_type: uploadedResourceType || 'raw'
          });
        } catch (cleanupError) {
          console.error('[PlanIt] Failed to cleanup Cloudinary upload:', cleanupError);
        }
      }
      next(error);
    }
  }
);

// Get all files for event
router.get('/:eventId', verifyEventToken, async (req, res, next) => {
  try {
    const { eventId } = req.params;

    const files = await File.find({ eventId, isDeleted: false })
      .sort({ uploadedAt: -1 })
      .select('-cloudinaryPublicId')
      .lean();

    const safeFiles = files.map(f => ({
      _id: f._id,
      filename: f.filename,
      size: f.size,
      mimetype: f.mimetype,
      url: f.cloudinaryUrl,
      uploadedBy: f.uploadedBy,
      uploadedAt: f.uploadedAt
    }));

    res.json({ files: safeFiles });
  } catch (error) {
    next(error);
  }
});

// Download/Get file URL (returns Cloudinary URL)
router.get('/:eventId/download/:fileId', verifyEventToken, async (req, res, next) => {
  try {
    const { eventId, fileId } = req.params;

    const file = await File.findOne({ _id: fileId, eventId, isDeleted: false });

    if (!file) {
      return res.status(404).json({ error: 'File not found' });
    }

    res.json({
      url: file.cloudinaryUrl,
      filename: file.filename,
      mimetype: file.mimetype
    });
  } catch (error) {
    next(error);
  }
});

// Delete file
router.delete('/:eventId/:fileId', verifyEventToken, async (req, res, next) => {
  try {
    const { eventId, fileId } = req.params;

    const file = await File.findOne({ _id: fileId, eventId, isDeleted: false });

    if (!file) {
      return res.status(404).json({ error: 'File not found' });
    }

    const event = req.event;
    const username = req.eventAccess?.username || req.eventAccess?.sub;
    const isOrganizer = event.participants.some(
      p => p.username === username && p.role === 'organizer'
    );
    const isUploader = file.uploadedBy === username;

    if (!isOrganizer && !isUploader && req.eventAccess?.isAdminAccess !== true) {
      return res.status(403).json({ error: 'Not authorized to delete this file' });
    }

    await file.deleteFromCloudinary();

    file.isDeleted = true;
    file.deletedAt = new Date();
    file.deletedBy = username;
    await file.save();

    const io = req.app.get('io');
    if (io) {
      io.to(`event-${eventId}`).emit('file_deleted', { fileId });
    }

    res.json({ message: 'File deleted successfully' });
  } catch (error) {
    next(error);
  }
});

module.exports = router;
