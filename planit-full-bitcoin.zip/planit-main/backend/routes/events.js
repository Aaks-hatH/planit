const express = require('express');
const router = express.Router();
const { realIp } = require('../middleware/realIp');
const { body, validationResult } = require('express-validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const axios = require('axios');
const Event = require('../models/Event');
const { recordIdentity } = require('../services/identityService');
const EventParticipant = require('../models/EventParticipant');
const { verifyEventAccess, verifyOrganizer, verifyCheckinAccess } = require('../middleware/auth');
const { createEventLimiter, authLimiter, joinLimiter, reservationLimiter, availabilityLimiter, inviteLookupLimiter } = require('../middleware/rateLimiter');

// SEC FIX: Invite codes are public lookup keys returned in guest-facing URLs.
// Math.random() is not a CSPRNG and its output is guessable given enough
// samples. Use crypto.randomBytes so codes can't be predicted/brute-forced.
const INVITE_CODE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; // 36 chars, same format as before
function generateInviteCode(length = 8) {
  let code = '';
  for (let i = 0; i < length; i++) {
    code += INVITE_CODE_ALPHABET[crypto.randomInt(INVITE_CODE_ALPHABET.length)];
  }
  return code; // 8 chars from a 36-char alphabet via CSPRNG (~41 bits), same shape as the old codes
}
const rateLimit = require('express-rate-limit');

// M4: Per-event password brute-force limiter (keyed on ip:eventId, not just ip)
const eventPasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  keyGenerator: (req) => `pwd:${realIp(req)}:${req.params.eventId || 'none'}`,
  handler: (_req, res) => res.status(429).json({ error: 'Too many password attempts for this event.' }),
  standardHeaders: true,
  legacyHeaders: false,
});
const { secrets } = require('../keys');
const crypto = require('crypto');
const Blocklist = require('../models/Blocklist');
const { analyzeEvent, applyEventSpamResult } = require('../services/spamDetector');
const { verifyTurnstile } = require('../services/captchaService');
const { sendAntiAbuse } = require('../services/antiAbuseResponses');

// ── Timezone helpers ────────────────────────────────────────────────────────
function isValidTimezone(tz) {
  if (!tz || typeof tz !== 'string' || tz.length > 64) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch { return false; }
}

// GET /api/events/detect-timezone
// Best-effort timezone guess from the visitor's IP, using the geo headers that
// Cloudflare ("Add visitor location headers" managed transform) / Vercel add.
// Returns { timezone: null } when no header is present — the client then falls
// back to the browser's timezone. Deliberately NOT under /events/public/* so
// the edge cache never serves one visitor's answer to another.

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
  next();
};

// Returns true if the user can add/delete agenda items.
// Organizers always can; participants can if the event setting is enabled.
function canEditAgenda(event, username) {
  const isOrg = event.participants.some(p => p.username === username && p.role === 'organizer');
  if (isOrg) return true;
  const participantsAllowed = event.settings?.allowParticipantAgenda === true;
  const isParticipant = event.participants.some(p => p.username === username);
  return participantsAllowed && isParticipant;
}

// Create event
router.post('/',
  createEventLimiter,
  [
    body('subdomain').trim().isLength({ min: 3, max: 50 }).matches(/^[a-z0-9-]+$/).withMessage('Invalid subdomain format'),
    body('title').trim().isLength({ min: 1, max: 200 }).withMessage('Title is required'),
    body('date').if(body('isTableServiceMode').not().equals('true')).if(body('isTableServiceMode').not().equals(true)).isISO8601().withMessage('Valid date is required'),
    body('organizerName').trim().isLength({ min: 1, max: 100 }).withMessage('Organizer name is required'),
    body('organizerEmail').isEmail().normalizeEmail().withMessage('Valid email is required'),
    body('password').optional({ values: 'falsy' }).isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('agreedToTerms').custom(v => v === true || v === 'true').withMessage('You must agree to the Terms of Service and Privacy Policy'),
    validate
  ],
  async (req, res, next) => {
    try {
      const { subdomain, title, description, date, location, organizerName, organizerEmail, password, accountPassword, staffPassword, isEnterpriseMode, isTableServiceMode, eventType, settings, maxParticipants, timezone: rawTimezone } = req.body;
      // Store the organizer's chosen IANA timezone (falls back to UTC only if missing/invalid).
      const resolvedTimezone = isValidTimezone(rawTimezone) ? rawTimezone : 'UTC';
      const resolvedEventType = eventType === 'rsvpOnly' ? 'rsvpOnly' : 'standard';

      const existing = await Event.findOne({ subdomain });
      if (existing) return res.status(409).json({ error: 'This event link is already taken.' });

      // Blocklist checks
      const [subdomainBanned, nameBanned] = await Promise.all([
        Blocklist.findOne({ type: 'event', value: subdomain, $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }] }).lean(),
        Blocklist.findOne({ type: 'name',  value: { $regex: new RegExp(`^${organizerName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }, $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }] }).lean(),
      ]);
      if (subdomainBanned) return res.status(403).json({ error: 'This event link is not available.' });
      if (nameBanned)      return res.status(403).json({ error: 'This display name is not allowed.' });

      let hashedPassword = null;
      let isPasswordProtected = false;
      if (password) {
        hashedPassword = await bcrypt.hash(password, 10);
        isPasswordProtected = true;
      }

      // V-10 FIX: Validate x-wl-domain against actual WL record and request origin
      let wlDomain = null;
      const rawWlDomain = req.headers['x-wl-domain']?.toLowerCase().trim();
      if (rawWlDomain) {
        const origin = req.get('origin') || '';
        try {
          const originHost = origin ? new URL(origin).hostname : null;
          if (originHost === rawWlDomain) {
            const WhiteLabelModel = require('../models/WhiteLabel');
            const wl = await WhiteLabelModel.findOne({ domain: rawWlDomain, status: { $in: ['active', 'trial'] } }, { _id: 1 }).lean();
            if (wl) wlDomain = rawWlDomain;
          }
        } catch (_) {}
      }

      // Capture creator metadata for admin debug / spam detection
      const creatorIpAddr      = realIp(req);
      const creatorUserAgent   = (req.headers['user-agent'] || '').slice(0, 500);
      // Fingerprint: prefer client-supplied value (from browser fingerprinting lib on frontend),
      // fall back to a deterministic hash of IP + UA so the field is never blank.
      const _crypto = require('crypto');
      const creatorFingerprint = req.body.fingerprint
        ? String(req.body.fingerprint).slice(0, 200)
        : _crypto.createHash('sha256')
            .update(`${creatorIpAddr}::${creatorUserAgent}`)
            .digest('hex')
            .slice(0, 32);

      const initialSpamResult = await analyzeEvent({
        title,
        description:    description || '',
        subdomain,
        organizerEmail,
        organizerName,
        ip:             creatorIpAddr,
        userAgent:      creatorUserAgent,
        fingerprint:    creatorFingerprint,
        honeypot:       req.body._hp || '',
        browserMeta:    req.body.browserMeta || {},
        behavior:       req.body.behavior || {},
      }).catch(() => ({ score: 0, flags: [], verdict: 'clean', shouldBlock: false }));

      if (initialSpamResult.shouldBlock) {
        return sendAntiAbuse(res, 'tryAgainLater');
      }

      // IMPORTANT: verify the token before anything else when verdict is 'review'.
      // Do NOT re-run analyzeEvent after a valid solve — velocity counters increment
      // on every request, so a resubmission scores higher than the first attempt and
      // could block a user who just correctly passed the CAPTCHA challenge.
      let captchaCleared = false;
      if (initialSpamResult.verdict === 'review') {
        if (!req.body.turnstileToken) {
          return sendAntiAbuse(res, 'verificationRequired', { requiresVerification: true });
        }
        const tsResult = await verifyTurnstile(req.body.turnstileToken, creatorIpAddr, { failOpen: false, context: 'event-create' });
        if (!tsResult.ok) {
          return sendAntiAbuse(res, 'invalidVerification', { requiresVerification: true });
        }
        captchaCleared = true;
      }

      const event = new Event({
        subdomain, title, description, date, timezone: resolvedTimezone, location, organizerName, organizerEmail,
        password: hashedPassword, isPasswordProtected,
        isEnterpriseMode: isEnterpriseMode || false,
        isTableServiceMode: isTableServiceMode || false,
        eventType: resolvedEventType,
        ...(resolvedEventType === 'rsvpOnly' ? { rsvpPage: { enabled: true } } : {}),
        settings: settings || {}, maxParticipants: maxParticipants || 100,
        participants: [{ username: organizerName, role: 'organizer' }],
        wlDomain,
        creatorIp:          creatorIpAddr,
        creatorUserAgent,
        creatorFingerprint,
        // Record when and against which version of the legal text the organizer agreed.
        legalAcceptance: {
          acceptedAt: new Date(),
          version:    String(req.body.legalVersion || '').slice(0, 32),
        },
      });

      await event.save();

      // ── Spam analysis result ────────────────────────────────────────────────
      // The scoring details remain internal. We persist only admin-facing fields
      // already supported by the event model and never expose them to creators.
      applyEventSpamResult(event._id, initialSpamResult).catch(() => {});

      const participantData = { eventId: event._id, username: organizerName, role: 'organizer' };
      let organizerRecoveryCode = null;
      if (accountPassword) {
        participantData.password = await bcrypt.hash(accountPassword, 10);
        participantData.hasPassword = true;
        // Generate recovery code — shown once, never stored in plaintext
        const segs = Array.from({ length: 5 }, () => crypto.randomBytes(2).toString('hex').toUpperCase());
        organizerRecoveryCode = segs.join('-');
        participantData.recoveryCodeHash = await bcrypt.hash(organizerRecoveryCode.replace(/-/g, '').toLowerCase(), 10);
        participantData.recoveryCodeGeneratedAt = new Date();
      }
      await EventParticipant.create(participantData);

      // For table service: create a default "staff" account using the staffPassword if provided
      if (isTableServiceMode && staffPassword && String(staffPassword).length >= 4) {
        const hashed = await bcrypt.hash(String(staffPassword), 10);
        await EventParticipant.create({
          eventId: event._id,
          username: 'staff',
          role: 'staff',
          password: hashed,
          hasPassword: true,
        });
      }

      const token = jwt.sign(
        { eventId: event._id.toString(), username: organizerName, role: 'organizer' },
        secrets.jwt,
        { expiresIn: '24h' }
      );
      const { sendEventConfirmation } = require('../services/emailService');
      sendEventConfirmation(event).catch(() => {});
      recordIdentity(req, { source: 'event_created', name: organizerName, email: organizerEmail, event });

      res.status(201).json({
        message: 'Event created successfully',
        event: { id: event._id, subdomain: event.subdomain, title: event.title, isPasswordProtected: event.isPasswordProtected },
        token,
        // Only present when organizer set an account password — shown once on the frontend, never again
        recoveryCode: organizerRecoveryCode || undefined,
      });
    } catch (error) { next(error); }
  }
);

// Public (no-auth) participant list — only username + hasPassword, no roles
router.get('/detect-timezone', (req, res) => {
  const candidate = req.headers['cf-timezone'] || req.headers['x-vercel-ip-timezone'] || req.headers['x-planit-client-tz'] || null;
  res.set('Cache-Control', 'no-store');
  res.json({ timezone: isValidTimezone(candidate) ? candidate : null });
});

router.get('/public-participants/:eventId', async (req, res, next) => {
  try {
    const participants = await EventParticipant.find({ eventId: req.params.eventId })
      .select('username hasPassword')
      .sort({ lastSeenAt: -1 })
      .lean();
    res.json({ participants: participants.map(p => ({ username: p.username, hasPassword: p.hasPassword })) });
  } catch (error) { next(error); }
});

// Get existing participant names for an event (for join gate dropdown)
// V-04 FIX: Require event access token; scrub roles from non-organizer tokens
router.get('/participants/:eventId', verifyEventAccess, async (req, res, next) => {
  try {
    const participants = await EventParticipant.find({ eventId: req.params.eventId })
      .select('username hasPassword role')
      .sort({ lastSeenAt: -1 })
      .lean();
    const isOrganizer = req.eventAccess?.role === 'organizer' || req.eventAccess?.isAdminAccess;
    res.json({ participants: participants.map(p => ({ username: p.username, hasPassword: p.hasPassword, role: isOrganizer ? p.role : undefined })) });
  } catch (error) { next(error); }
});

// WL discovery — returns events scoped to a white-label domain
// MUST be before /public/:eventId so 'wl' isn't treated as an ObjectId
router.get('/public/wl', async (req, res, next) => {
  try {
    const { domain, limit: rawLimit = 12 } = req.query;
    if (!domain) return res.status(400).json({ error: 'domain required' });
    const limit = Math.min(parseInt(rawLimit) || 12, 50);
    const events = await Event.find({
      wlDomain: domain.toLowerCase().trim(),
      'settings.isPublic': true,
      status: 'active',
    })
    .select('subdomain title description date location participants maxParticipants coverImage themeColor tags createdAt')
    .sort({ date: 1 })
    .limit(limit)
    .lean();
    res.json({
      events: events.map(e => ({
        ...e,
        participantCount: e.participants?.length || 0,
        participants: undefined,
      })),
    });
  } catch (err) { next(err); }
});

// Public info (no auth) — for join gate
// ── Brand info (title/preload) ─────────────────────────────────────────────
// Lightweight, side-effect-free lookup (no view counter) used to brand the
// browser tab title and the loading screen for an event before the page's own
// data arrives. `key` is either a subdomain or a 24-char event id.
// MUST stay above /public/:eventId so "brand" isn't treated as an event id.
router.get('/public/brand/:key', availabilityLimiter, async (req, res, next) => {
  try {
    const key = String(req.params.key || '');
    if (!key || key.length > 100) return res.status(404).json({ error: 'Not found' });
    const isId = /^[a-f0-9]{24}$/i.test(key);
    const q = isId ? Event.findById(key) : Event.findOne({ subdomain: key });
    const ev = await q
      .select('title subdomain eventType isTableServiceMode isEnterpriseMode tableServiceSettings.restaurantName reservationPageSettings.logoUrl reservationPageSettings.accentColor rsvpPage.coverImageUrl')
      .lean();
    if (!ev) return res.status(404).json({ error: 'Not found' });
    const name = (ev.isTableServiceMode && ev.tableServiceSettings?.restaurantName) || ev.title;
    res.set('Cache-Control', 'public, max-age=60');
    res.json({
      id: ev._id, subdomain: ev.subdomain, name, title: ev.title,
      eventType: ev.eventType || 'standard',
      isTableServiceMode: !!ev.isTableServiceMode,
      isEnterpriseMode: !!ev.isEnterpriseMode,
      logoUrl: ev.reservationPageSettings?.logoUrl || '',
      accentColor: ev.reservationPageSettings?.accentColor || '',
    });
  } catch (error) { next(error); }
});

router.get('/public/:eventId', async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    res.json({
      event: {
        id: event._id, subdomain: event.subdomain, title: event.title,
        description: event.description, date: event.date, timezone: event.timezone || 'UTC', location: event.location,
        organizerName: event.organizerName, isPasswordProtected: event.isPasswordProtected,
        maxParticipants: event.maxParticipants, participantCount: event.participants.length,
        status: event.status, rsvpSummary: event.getRsvpSummary(),
        isTableServiceMode: !!event.isTableServiceMode,
        isEnterpriseMode: !!event.isEnterpriseMode,
        eventType: event.eventType || 'standard',
      }
    });
  } catch (error) { next(error); }
});

// Get by subdomain
router.get('/subdomain/:subdomain', async (req, res, next) => {
  try {
    const banned = await Blocklist.findOne({ type: 'event', value: req.params.subdomain, $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }] }).lean();
    if (banned) return res.status(404).json({ error: 'Event not found.' });

    const event = await Event.findOne({ subdomain: req.params.subdomain });
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    await event.incrementViews();
    res.json({
      event: {
        id: event._id, subdomain: event.subdomain, title: event.title, date: event.date, timezone: event.timezone || 'UTC',
        organizerName: event.organizerName, isPasswordProtected: event.isPasswordProtected,
        requiresPassword: event.isPasswordProtected,
        description: event.isPasswordProtected ? undefined : event.description,
        location: event.isPasswordProtected ? undefined : event.location,
        maxParticipants: event.maxParticipants, participantCount: event.participants.length,
        isTableServiceMode: !!event.isTableServiceMode,
        isEnterpriseMode: !!event.isEnterpriseMode,
        eventType: event.eventType || 'standard',
        isClone: !!event.clonedFrom,
      }
    });
  } catch (error) { next(error); }
});

// Verify password + join
router.post('/verify-password/:eventId', authLimiter, eventPasswordLimiter,
  [body('password').notEmpty(), body('username').trim().isLength({ min: 1, max: 100 }), body('accountPassword').optional(), validate],
  async (req, res, next) => {
    try {
      const event = await Event.findById(req.params.eventId).select('+password');
      if (!event) return res.status(404).json({ error: 'Event not found.' });
      if (!event.isPasswordProtected) return res.status(400).json({ error: 'Event is not password protected.' });

      // ── Status checks ──────────────────────────────────────────────────────
      if (event.status === 'cancelled') {
        return res.status(403).json({ error: 'This event has been cancelled and is no longer accepting participants.' });
      }
      if (event.status === 'completed') {
        return res.status(403).json({ error: 'This event has ended and is no longer accepting new participants.' });
      }

      // ── Require approval (must be checked even for password-protected events) ──────
      if (event.settings?.requireApproval) {
        const trimmedUsername = (req.body.username || '').trim();
        if (trimmedUsername) {
          const alreadyParticipant = event.participants?.some(p => p.username === trimmedUsername);
          if (!alreadyParticipant) {
            const alreadyQueued = event.approvalQueue?.some(q => q.username === trimmedUsername);
            if (!alreadyQueued) {
              await Event.findByIdAndUpdate(req.params.eventId, {
                $push: { approvalQueue: { username: trimmedUsername, requestedAt: new Date() } }
              });
              const io = req.app.get('io');
              if (io) io.to(`event_${req.params.eventId}`).emit('approval_request', { username: trimmedUsername });
            }
            return res.status(403).json({
              requiresApproval: true,
              pending: true,
              pollToken: jwt.sign(
                { type: 'approval_poll', eventId: req.params.eventId.toString(), username: trimmedUsername },
                secrets.jwt,
                { expiresIn: '24h' }
              ),
              message: 'Your request has been sent to the organizer. You will be able to join once approved.',
            });
          }
          // Already approved — fall through to verify password and issue token.
        }
      }

      const isMatch = await bcrypt.compare(req.body.password, event.password);
      if (!isMatch) return res.status(401).json({ error: 'Incorrect event password.' });

      const { username, accountPassword } = req.body;

      const pwNameBanned = await Blocklist.findOne({ type: 'name', value: { $regex: new RegExp(`^${username.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }, $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }] }).lean();
      if (pwNameBanned) return res.status(403).json({ error: 'This display name is not allowed.' });

      const existing = await EventParticipant.findOne({ eventId: req.params.eventId, username }).select('+password +recoveryCodeHash +recoveryCodeGeneratedAt');
      let vpRecoveryCode = null;
      if (existing && existing.hasPassword) {
        if (!accountPassword) return res.status(400).json({ error: 'This name has an account — enter your account password.', requiresAccountPassword: true });
        const accountMatch = await bcrypt.compare(accountPassword, existing.password);
        if (!accountMatch) return res.status(401).json({ error: 'Incorrect account password.' });
        await EventParticipant.updateOne({ _id: existing._id }, { $set: { lastSeenAt: new Date() } });
      } else {
        const updateData = { role: 'participant', lastSeenAt: new Date() };
        if (accountPassword) {
          updateData.password = await bcrypt.hash(accountPassword, 10);
          updateData.hasPassword = true;
          // Generate a recovery code when a participant first sets a password
          const segs = Array.from({ length: 5 }, () => crypto.randomBytes(2).toString('hex').toUpperCase());
          vpRecoveryCode = segs.join('-');
          updateData.recoveryCodeHash = await bcrypt.hash(vpRecoveryCode.replace(/-/g, '').toLowerCase(), 10);
          updateData.recoveryCodeGeneratedAt = new Date();
        }
        await EventParticipant.findOneAndUpdate(
          { eventId: req.params.eventId, username },
          updateData,
          { upsert: true, new: true }
        );
      }

      await event.addParticipant(username);

      const io = req.app.get('io');
      if (io) {
        io.to(`event_${req.params.eventId}`).emit('participant_joined', {
          username, role: 'participant', joinedAt: new Date(), participants: event.participants
        });
      }

      // Fire webhooks non-blocking
      fireWebhooks(req.params.eventId, 'participant_joined', { username }).catch(() => {});

      // Organizer role is only granted when the user is a known participant
      // who has already SET an account password AND has just proven they know it.
      // Username-match alone is NOT sufficient — anyone could type the organizer name.
      const participantRecord = await EventParticipant.findOne({ eventId: req.params.eventId, username }).select('+password');
      const verifiedOrganizerByPassword = participantRecord?.hasPassword && accountPassword &&
        event.participants.some(p => p.username === username && p.role === 'organizer');

      const role = verifiedOrganizerByPassword ? 'organizer' : 'participant';
      const token = jwt.sign(
        { eventId: event._id.toString(), username, role },
        secrets.jwt, { expiresIn: '24h' } // V-09 FIX: was '7d' — 24h matches organizer token and reduces stolen-token window
      );
      res.json({ message: 'Access granted', token, event: { id: event._id, title: event.title }, recoveryCode: vpRecoveryCode || undefined });
    } catch (error) { next(error); }
  }
);

// Join (no password)
router.post('/join/:eventId',
  joinLimiter,
  [body('username').trim().isLength({ min: 1, max: 100 }), body('accountPassword').optional(), validate],
  async (req, res, next) => {
    try {
      const event = await Event.findById(req.params.eventId);
      if (!event) return res.status(404).json({ error: 'Event not found.' });
      if (event.isPasswordProtected) return res.status(403).json({ error: 'This event requires a password.' });

      // ── Require approval ───────────────────────────────────────────────────
      if (event.settings?.requireApproval) {
        const { username: reqUsername, message: reqMessage } = req.body;
        const trimmedUsername = (reqUsername || '').trim();
        if (!trimmedUsername) {
          return res.status(400).json({ error: 'Please provide your name to request access.' });
        }

        // If already an approved participant, skip the queue and issue a token normally
        const alreadyParticipant = event.participants?.some(p => p.username === trimmedUsername);
        if (!alreadyParticipant) {
          // Don't add duplicates to the queue
          const alreadyQueued = event.approvalQueue?.some(q => q.username === trimmedUsername);
          if (!alreadyQueued) {
            await Event.findByIdAndUpdate(req.params.eventId, {
              $push: { approvalQueue: { username: trimmedUsername, message: (reqMessage || '').trim().slice(0, 300), requestedAt: new Date() } }
            });
            const io = req.app.get('io');
            if (io) {
              io.to(`event_${req.params.eventId}`).emit('approval_request', { username: trimmedUsername });
            }
          }
          // Return 403 (NOT 202) so Axios treats it as an error and the frontend
          // catch block reliably intercepts it. HTTP 202 is 2xx — Axios resolves it
          // as success and the token-save + onJoined() call would run, bypassing the gate.
          //
          // SECURITY FIX: issue a short-lived poll token scoped to this user + event.
          // The approval-status endpoint now requires this token, preventing anyone
          // from polling for another user's approval status and harvesting a JWT.
          const pollToken = jwt.sign(
            { type: 'approval_poll', eventId: req.params.eventId.toString(), username: trimmedUsername },
            secrets.jwt,
            { expiresIn: '24h' }
          );
          return res.status(403).json({
            requiresApproval: true,
            pending: true,
            pollToken,
            message: 'Your request has been sent to the organizer. You will be able to join once approved.',
          });
        }
        // alreadyParticipant == true: they were approved — fall through to issue token.
      }

      // ── Status checks ──────────────────────────────────────────────────────
      if (event.status === 'cancelled') {
        return res.status(403).json({ error: 'This event has been cancelled and is no longer accepting participants.' });
      }
      if (event.status === 'completed') {
        return res.status(403).json({ error: 'This event has ended and is no longer accepting new participants.' });
      }

      const { username, accountPassword } = req.body;

      const joinNameBanned = await Blocklist.findOne({ type: 'name', value: { $regex: new RegExp(`^${username.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') }, $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }] }).lean();
      if (joinNameBanned) return res.status(403).json({ error: 'This display name is not allowed.' });

      const existing = await EventParticipant.findOne({ eventId: req.params.eventId, username }).select('+password +recoveryCodeHash +recoveryCodeGeneratedAt');
      let joinRecoveryCode = null;
      if (existing && existing.hasPassword) {
        if (!accountPassword) return res.status(400).json({ error: 'This name has an account — enter your account password.', requiresAccountPassword: true });
        const accountMatch = await bcrypt.compare(accountPassword, existing.password);
        if (!accountMatch) return res.status(401).json({ error: 'Incorrect account password.' });
        await EventParticipant.updateOne({ _id: existing._id }, { $set: { lastSeenAt: new Date() } });
      } else {
        const updateData = { role: 'participant', lastSeenAt: new Date() };
        if (accountPassword) {
          updateData.password = await bcrypt.hash(accountPassword, 10);
          updateData.hasPassword = true;
          // Generate a recovery code when a participant first sets a password
          const segs = Array.from({ length: 5 }, () => crypto.randomBytes(2).toString('hex').toUpperCase());
          joinRecoveryCode = segs.join('-');
          updateData.recoveryCodeHash = await bcrypt.hash(joinRecoveryCode.replace(/-/g, '').toLowerCase(), 10);
          updateData.recoveryCodeGeneratedAt = new Date();
        }
        await EventParticipant.findOneAndUpdate(
          { eventId: req.params.eventId, username },
          updateData,
          { upsert: true, new: true }
        );
      }

      await event.addParticipant(username);

      const io = req.app.get('io');
      if (io) {
        io.to(`event_${req.params.eventId}`).emit('participant_joined', {
          username, role: 'participant', joinedAt: new Date(), participants: event.participants
        });
      }

      // Fire webhooks non-blocking
      fireWebhooks(req.params.eventId, 'participant_joined', { username }).catch(() => {});

      // Organizer role is only granted when the user has proven they know their
      // account password AND they are recorded as organizer in the participants list.
      // Username-match alone is NOT sufficient.
      const joinParticipantRecord = await EventParticipant.findOne({ eventId: req.params.eventId, username }).select('+password');
      const verifiedOrganizerByPassword = joinParticipantRecord?.hasPassword && accountPassword &&
        event.participants.some(p => p.username === username && p.role === 'organizer');

      const joinRole = verifiedOrganizerByPassword ? 'organizer' : 'participant';
      const token = jwt.sign(
        { eventId: event._id.toString(), username, role: joinRole },
        secrets.jwt, { expiresIn: '7d' }
      );
      res.json({ message: 'Joined successfully', token, event: { id: event._id, title: event.title }, recoveryCode: joinRecoveryCode || undefined });
    } catch (error) { next(error); }
  }
);

// ── RECOVERY CODE: Generate for any authenticated participant with a password ──
// Available to ALL participants (organizer, participant, staff) who have a password
// set but no recovery code yet. Requires a valid event token (verifyEventAccess).
router.post('/generate-recovery-code/:eventId', verifyEventAccess, async (req, res, next) => {
  try {
    const username = req.eventAccess?.username;
    if (!username) return res.status(401).json({ error: 'Not authenticated.' });

    const participant = await EventParticipant.findOne({ eventId: req.params.eventId, username })
      .select('+password +recoveryCodeHash +recoveryCodeGeneratedAt');

    if (!participant) return res.status(404).json({ error: 'Participant record not found.' });
    if (!participant.hasPassword) return res.status(400).json({ error: 'No account password is set on this account.' });

    // Generate a XXXX-XXXX-XXXX-XXXX-XXXX recovery code
    const segments = Array.from({ length: 5 }, () =>
      crypto.randomBytes(2).toString('hex').toUpperCase()
    );
    const plainCode = segments.join('-');
    const codeHash  = await bcrypt.hash(plainCode.replace(/-/g, '').toLowerCase(), 10);

    await EventParticipant.updateOne(
      { _id: participant._id },
      { $set: { recoveryCodeHash: codeHash, recoveryCodeGeneratedAt: new Date() } }
    );

    // Return the plaintext code ONCE — never stored or returned again
    res.json({ recoveryCode: plainCode });
  } catch (error) { next(error); }
});

// -- RECOVERY CODE STATUS: Check if current participant has a recovery code ----
// Used by the frontend banner to decide whether to show the "generate" prompt.
router.get('/recovery-code-status/:eventId', verifyEventAccess, async (req, res, next) => {
  try {
    const username = req.eventAccess?.username;
    if (!username) return res.status(401).json({ error: 'Not authenticated.' });

    const participant = await EventParticipant.findOne({ eventId: req.params.eventId, username })
      .select('+recoveryCodeHash recoveryCodeGeneratedAt hasPassword');

    if (!participant) return res.status(404).json({ error: 'Participant record not found.' });

    const hasCode = !!participant.recoveryCodeHash;
    const expired = hasCode && participant.recoveryCodeGeneratedAt &&
      Date.now() - new Date(participant.recoveryCodeGeneratedAt).getTime() > 365 * 24 * 60 * 60 * 1000;

    res.json({
      hasPassword: participant.hasPassword,
      hasRecoveryCode: hasCode && !expired,
      participantId: participant._id.toString(),
    });
  } catch (error) { next(error); }
});

// ── FORGOT PASSWORD: Find event by slug or URL (public, no auth) ──────────────
router.get('/by-slug/:slug', async (req, res, next) => {
  try {
    const slug = req.params.slug.trim().toLowerCase();
    const event = await Event.findOne({ subdomain: slug }).select('_id subdomain title').lean();
    if (!event) return res.status(404).json({ error: 'No event found with that link.' });
    res.json({ event: { id: event._id, subdomain: event.subdomain, title: event.title } });
  } catch (error) { next(error); }
});

// ── PASSWORD RESET: Rate-limited, verifies recovery code, resets password ────
// Rate limit: max 3 attempts per IP per event per hour, 24-hour lockout after that.
const resetAttemptStore = new Map(); // { key: { count, windowStart, lockedUntil } }

function getResetKey(ip, eventId) { return `reset:${ip}:${eventId}`; }

function checkResetRateLimit(ip, eventId) {
  const key   = getResetKey(ip, eventId);
  const now   = Date.now();
  const entry = resetAttemptStore.get(key) || { count: 0, windowStart: now, lockedUntil: null };

  if (entry.lockedUntil && now < entry.lockedUntil) {
    const minutesLeft = Math.ceil((entry.lockedUntil - now) / 60000);
    return { allowed: false, locked: true, minutesLeft };
  }

  // Reset window if it's been more than an hour
  if (now - entry.windowStart > 60 * 60 * 1000) {
    entry.count = 0; entry.windowStart = now; entry.lockedUntil = null;
  }

  if (entry.count >= 3) {
    entry.lockedUntil = now + 24 * 60 * 60 * 1000;
    resetAttemptStore.set(key, entry);
    return { allowed: false, locked: true, minutesLeft: 24 * 60 };
  }

  return { allowed: true, entry, key };
}

function recordResetAttempt(key, entry) {
  entry.count++;
  resetAttemptStore.set(key, entry);
  if (entry.count >= 3) {
    entry.lockedUntil = Date.now() + 24 * 60 * 60 * 1000;
    resetAttemptStore.set(key, entry);
  }
}

router.post('/reset-password', async (req, res, next) => {
  const ip = realIp(req);
  try {
    const { slug, username, recoveryCode, newPassword } = req.body;

    if (!slug || !username || !recoveryCode || !newPassword) {
      return res.status(400).json({ error: 'All fields are required.' });
    }
    if (newPassword.length < 4) {
      return res.status(400).json({ error: 'New password must be at least 4 characters.' });
    }

    const event = await Event.findOne({ subdomain: slug.trim().toLowerCase() }).select('_id subdomain title').lean();
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    // Rate limit check
    const limitCheck = checkResetRateLimit(ip, event._id.toString());
    if (!limitCheck.allowed) {
      console.warn(`[reset-password] LOCKED ip=${ip} event=${event._id}`);
      return res.status(429).json({
        error: `Too many reset attempts. Locked out for ${limitCheck.minutesLeft} minutes.`,
        locked: true,
        minutesLeft: limitCheck.minutesLeft,
      });
    }

    const participant = await EventParticipant.findOne({
      eventId: event._id,
      username: username.trim(),
    }).select('+password +recoveryCodeHash +recoveryCodeGeneratedAt');

    // Log attempt regardless of outcome
    console.log(`[reset-password] attempt ip=${ip} event=${slug} username=${username.trim()} found=${!!participant}`);

    if (!participant || !participant.hasPassword) {
      recordResetAttempt(limitCheck.key, limitCheck.entry);
      return res.status(404).json({ error: 'No account found with that name in this event.' });
    }

    if (!participant.recoveryCodeHash) {
      recordResetAttempt(limitCheck.key, limitCheck.entry);
      return res.status(400).json({ error: 'This account has no recovery code on file. Log in and generate one from your event workspace.' });
    }

    // Check expiry — 365 days
    const generated = participant.recoveryCodeGeneratedAt;
    if (!generated || Date.now() - new Date(generated).getTime() > 365 * 24 * 60 * 60 * 1000) {
      recordResetAttempt(limitCheck.key, limitCheck.entry);
      return res.status(400).json({
        error: 'Recovery code has expired (codes expire after 365 days). Log back in to generate a new one.',
        expired: true,
      });
    }

    // Verify recovery code — strip dashes and lowercase
    const normalised = recoveryCode.replace(/-/g, '').toLowerCase().trim();
    const match = await bcrypt.compare(normalised, participant.recoveryCodeHash);
    if (!match) {
      recordResetAttempt(limitCheck.key, limitCheck.entry);
      return res.status(401).json({ error: 'Incorrect recovery code.' });
    }

    // Valid — hash new password, clear recovery code (one-time use)
    const newHash = await bcrypt.hash(newPassword, 10);
    await EventParticipant.updateOne(
      { _id: participant._id },
      {
        $set: { password: newHash, hasPassword: true },
        $unset: { recoveryCodeHash: '', recoveryCodeGeneratedAt: '' },
      }
    );

    console.log(`[reset-password] SUCCESS ip=${ip} event=${slug} username=${username.trim()}`);

    res.json({ message: 'Password reset successfully. Your recovery code has been invalidated.', eventSubdomain: event.subdomain });
  } catch (error) { next(error); }
});

// ── PUBLIC EVENTS LISTING ──────────────────────────────────────────────────
// IMPORTANT: This MUST appear before router.get('/:eventId', ...) otherwise
// Express matches "public" as an eventId and verifyEventAccess throws an error.
router.get('/public', async (req, res, next) => {
  try {
    const page  = parseInt(req.query.page)  || 1;
    const limit = Math.min(parseInt(req.query.limit) || 20, 50);
    const skip  = (page - 1) * limit;

    const query = {
      'settings.isPublic': true,
      status: 'active',
      date: { $gte: new Date() }
    };

    const events = await Event.find(query)
      .select('subdomain title description date location participants maxParticipants coverImage themeColor tags createdAt')
      .sort({ date: 1 })
      .skip(skip)
      .limit(limit)
      .lean();

    const total = await Event.countDocuments(query);

    res.json({
      events: events.map(ev => ({
        ...ev,
        participantCount: (ev.participants || []).length,
        participants: undefined,
      })),
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) { next(error); }
});

// Get full event details (authenticated)

// ─── Public / unauthenticated routes ─────────────────────────────────────────
// MUST be defined before the /:eventId wildcard route

async function findWaitEvent(subdomainOrId, selectFields) {
  const isObjectId = mongoose.Types.ObjectId.isValid(subdomainOrId);
  const query = isObjectId
    ? Event.findById(subdomainOrId)
    : Event.findOne({ subdomain: subdomainOrId });
  return query.select(selectFields).lean();
}

// GET /public/wait/:subdomain/info — static venue branding (infrequent)
router.get('/public/wait/:subdomain/info', availabilityLimiter, async (req, res, next) => {
  try {
    const event = await findWaitEvent(
      req.params.subdomain,
      'title isTableServiceMode tableServiceSettings reservationPageSettings'
    );
    if (!event || !event.isTableServiceMode) return res.status(404).json({ error: 'Not found' });
    const tss = event.tableServiceSettings  || {};
    const rps = event.reservationPageSettings || {};
    res.json({
      name:             tss.restaurantName || event.title || '',
      logoUrl:          rps.logoUrl || '',
      accentColor:      rps.accentColor || '#f97316',
      tagline:          rps.headerTagline || '',
      waitBoardTitle:   rps.waitBoardTitle || '',
      waitBoardMessage: rps.waitBoardMessage || '',
      showPoweredBy:    rps.showPoweredBy !== false,
      walkInOnlyMode:   rps.walkInOnlyMode || false,
      publicWaitBoardEnabled: rps.publicWaitBoardEnabled !== false,
    });
  } catch (err) { next(err); }
});

// GET /public/wait/:subdomain/live — live data (polled every 20s)
router.get('/public/wait/:subdomain/live', availabilityLimiter, async (req, res, next) => {
  try {
    const event = await findWaitEvent(
      req.params.subdomain,
      'title isTableServiceMode tableServiceSettings reservationPageSettings seatingMap tableStates tableServiceWaitlist'
    );
    if (!event || !event.isTableServiceMode) return res.status(404).json({ error: 'Not found' });

    const tss     = event.tableServiceSettings    || {};
    const rps     = event.reservationPageSettings || {};
    const objects = event.seatingMap?.objects || [];
    const states  = event.tableStates || [];
    const waitlist = (event.tableServiceWaitlist || []).filter(w => w.status === 'waiting' || w.status === 'notified');

    // Table stats — prefer seating map objects; fall back to tableStates if no
    // floor plan has been drawn yet so the board shows real occupancy data.
    const tables = objects.filter(o => o.type !== 'zone');
    let tableStats;
    if (tables.length > 0) {
      tableStats = {
        total:     tables.length,
        available: tables.filter(t => { const s = states.find(st => st.tableId === t.id); return !s || s.status === 'available'; }).length,
        occupied:  tables.filter(t => { const s = states.find(st => st.tableId === t.id); return s?.status === 'occupied'; }).length,
        reserved:  tables.filter(t => { const s = states.find(st => st.tableId === t.id); return s?.status === 'reserved'; }).length,
        cleaning:  tables.filter(t => { const s = states.find(st => st.tableId === t.id); return s?.status === 'cleaning'; }).length,
      };
    } else if (states.length > 0) {
      // No seating map yet — derive stats from tableStates
      const activeStates = states.filter(s => s.status !== 'unavailable');
      tableStats = {
        total:     activeStates.length,
        available: activeStates.filter(s => !s.status || s.status === 'available').length,
        occupied:  activeStates.filter(s => s.status === 'occupied').length,
        reserved:  activeStates.filter(s => s.status === 'reserved').length,
        cleaning:  activeStates.filter(s => s.status === 'cleaning').length,
      };
    } else {
      tableStats = { total: 0, available: 0, occupied: 0, reserved: 0, cleaning: 0 };
    }

    // Is the venue currently open?
    // Accept optional ?tz= (IANA timezone) from the client so the check uses the
    // restaurant's local wall-clock time rather than the server's UTC clock.
    let isOpen = true;
    if (tss.operatingHoursOpen && tss.operatingHoursClose) {
      try {
        const tz = req.query.tz || 'UTC';
        const now = new Date();
        const localTimeStr = now.toLocaleTimeString('en-GB', { timeZone: tz, hour: '2-digit', minute: '2-digit', hour12: false });
        const [lh, lm]  = localTimeStr.split(':').map(Number);
        const nowMin    = lh * 60 + lm;
        const [oh, om]  = tss.operatingHoursOpen.split(':').map(Number);
        const [ch, cm]  = tss.operatingHoursClose.split(':').map(Number);
        const openMin   = oh * 60 + om;
        const closeMin  = ch * 60 + cm;
        // Handle overnight spans (e.g. open 22:00, close 02:00)
        if (closeMin > openMin) {
          isOpen = nowMin >= openMin && nowMin < closeMin;
        } else {
          isOpen = nowMin >= openMin || nowMin < closeMin;
        }
      } catch (_) { isOpen = true; }
    }

    // Strip phones from public waitlist
    const publicWaitlist = waitlist.map(w => ({
      id:        w.id,
      partyName: w.partyName,
      partySize: w.partySize,
      status:    w.status,
      addedAt:   w.addedAt,
    }));

    res.json({
      waitTimes:  calcWaitTimes(objects, states, tss, waitlist),
      tableStats,
      waitlist:   publicWaitlist,
      isOpen,
      queueLength: waitlist.length,
      name:        tss.restaurantName || event.title || '',
      logoUrl:     rps.logoUrl || '',
      accentColor: rps.accentColor || '#f97316',
      tagline:     rps.headerTagline || '',
      waitBoardTitle:   rps.waitBoardTitle || '',
      waitBoardMessage: rps.waitBoardMessage || '',
      menus:            rps.menus || [],
    });
  } catch (err) { next(err); }
});

// POST /public/wait/:subdomain/join — public join waitlist (no auth)
router.post('/public/wait/:subdomain/join', availabilityLimiter, async (req, res, next) => {
  try {
    const { partyName, partySize, phone } = req.body;
    if (!partyName?.trim()) return res.status(400).json({ error: 'Party name is required' });
    const sz = parseInt(partySize);
    if (!sz || sz < 1 || sz > 50) return res.status(400).json({ error: 'Invalid party size' });

    const isObjectId = mongoose.Types.ObjectId.isValid(req.params.subdomain);
    const eventDoc = isObjectId
      ? await Event.findById(req.params.subdomain).select('isTableServiceMode tableServiceSettings reservationPageSettings tableServiceWaitlist')
      : await Event.findOne({ subdomain: req.params.subdomain }).select('isTableServiceMode tableServiceSettings reservationPageSettings tableServiceWaitlist');
    if (!eventDoc || !eventDoc.isTableServiceMode) return res.status(404).json({ error: 'Not found' });

    const rps = eventDoc.reservationPageSettings || {};
    if (rps.publicWaitBoardEnabled === false) return res.status(403).json({ error: 'Wait board not active' });

    const entry = {
      id:        require('crypto').randomUUID(),
      partyName: partyName.trim().slice(0, 80),
      partySize: sz,
      phone:     (phone || '').trim().slice(0, 30),
      notes:     '',
      addedAt:   new Date(),
      status:    'waiting',
      source:    'public_board',
    };
    if (!eventDoc.tableServiceWaitlist) eventDoc.tableServiceWaitlist = [];
    eventDoc.tableServiceWaitlist.push(entry);
    await eventDoc.save();

    res.status(201).json({ success: true, entry });
  } catch (err) { next(err); }
});





// ── UTILITIES ─────────────────────────────────────────────────────────────


// Get invite by code (public)
router.get('/invite/:inviteCode', inviteLookupLimiter, async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const invite = await Invite.findOne({ inviteCode: req.params.inviteCode });
    if (!invite) return res.status(404).json({ error: 'Invite not found' });
    
    const event = await Event.findById(invite.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    
    res.json({ 
      invite: {
        code: invite.inviteCode,
        inviteCode: invite.inviteCode,
        guestName: invite.guestName,
        guestEmail: invite.guestEmail,
        guestPhone: invite.guestPhone,
        adults: invite.adults,
        children: invite.children,
        groupSize: invite.groupSize,
        plusOnes: invite.plusOnes,
        checkedIn: invite.checkedIn,
        checkedInAt: invite.checkedInAt,
        status: invite.status,
        notes: invite.notes,
        email: invite.guestEmail
      },
      event: {
        id: event._id,
        title: event.title,
        date: event.date,
        location: event.location,
        description: event.description,
        organizerName: event.organizerName,
        timezone: event.timezone || 'UTC'
      }
    });
  } catch (error) { next(error); }
});

// ─── GET /invite/:inviteCode/qr.svg ──────────────────────────────────────────
// Returns a branded PlanIt QR card for a specific guest invite.
// No auth required — the invite code IS the credential (same as the invite page).
// Matches the dark-card aesthetic of the event QR already used in EventSpace.
router.get('/invite/:inviteCode/qr.svg', inviteLookupLimiter, async (req, res, next) => {
  try {
    const QRCode = require('qrcode');
    const Invite = require('../models/Invite');
    const invite = await Invite.findOne({ inviteCode: req.params.inviteCode.toUpperCase() }).lean();
    if (!invite) return res.status(404).send('Invite not found');

    const event = await Event.findById(invite.eventId).select('title').lean();
    if (!event) return res.status(404).send('Event not found');

    // Use FRONTEND_URL - req.get('host') behind Render proxy returns backend hostname, not the frontend
    const frontendBase = (process.env.FRONTEND_URL || process.env.BASE_DOMAIN || '').replace(/\/$/, '');
    const inviteUrl = frontendBase
      ? `${frontendBase}/invite/${invite.inviteCode}`
      : `${req.protocol}://${req.get('host')}/invite/${invite.inviteCode}`;

    // Clean QR - no center overlay. BarcodeDetector rejects QRs with anything layered on top.
    // PLANIT branding goes below the QR area instead.
    const dataUrl = await QRCode.toDataURL(inviteUrl, {
      width: 260,
      margin: 2,
      color: { dark: '#000000', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    });

    const safeTitle    = (event.title || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').slice(0, 30);
    const safeName     = (invite.guestName || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').slice(0, 28);
    const safeCode     = invite.inviteCode.replace(/[^A-Z0-9]/g, '');

    const W = 300, H = 430;
    const QX = 20, QY = 20, QS = 260;

    const svg = `<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <filter id="glow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="4" stdDeviation="10" flood-color="#000" flood-opacity="0.55"/>
    </filter>
    <clipPath id="qrclip"><rect x="${QX}" y="${QY}" width="${QS}" height="${QS}" rx="10"/></clipPath>
  </defs>
  <rect width="${W}" height="${H}" rx="20" fill="#0a0a0a" filter="url(#glow)"/>
  <rect x="${QX - 4}" y="${QY - 4}" width="${QS + 8}" height="${QS + 8}" rx="14" fill="#ffffff"/>
  <image x="${QX}" y="${QY}" width="${QS}" height="${QS}" href="${dataUrl}" clip-path="url(#qrclip)"/>
  <line x1="20" y1="${QY + QS + 18}" x2="${W - 20}" y2="${QY + QS + 18}" stroke="#1f1f1f" stroke-width="1"/>
  <text x="${W / 2}" y="${QY + QS + 40}" text-anchor="middle"
        fill="#ffffff" font-family="system-ui,-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"
        font-size="13" font-weight="800" letter-spacing="5">PLANIT</text>
  <text x="${W / 2}" y="${QY + QS + 62}" text-anchor="middle"
        fill="#e5e5e5" font-family="system-ui,-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"
        font-size="12" font-weight="600">${safeTitle}</text>
  <text x="${W / 2}" y="${QY + QS + 80}" text-anchor="middle"
        fill="#888" font-family="system-ui,-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"
        font-size="11">${safeName}</text>
  <text x="${W / 2}" y="${QY + QS + 100}" text-anchor="middle"
        fill="#444" font-family="'Courier New',Courier,monospace"
        font-size="11" font-weight="700" letter-spacing="3">${safeCode}</text>
</svg>`;

    res.setHeader('Content-Type', 'image/svg+xml');
    res.setHeader('Cache-Control', 'public, max-age=86400');
    res.send(svg);
  } catch (err) { next(err); }
});


// ── GET /public/reserve/:subdomain ────────────────────────────────────────────
// Returns public restaurant info and reservation config.
router.get('/public/reserve/:subdomain', availabilityLimiter, async (req, res, next) => {
  try {
    const event = await Event.findOne({ subdomain: req.params.subdomain })
      .select('title isTableServiceMode tableServiceSettings reservationPageSettings seatingMap tableStates tableServiceWaitlist')
      .lean();
    if (!event) return res.status(404).json({ error: 'Not found' });
    if (!event.isTableServiceMode) return res.status(404).json({ error: 'Reservation pages are only available for restaurant events.' });

    const rps = event.reservationPageSettings || {};
    const tss = event.tableServiceSettings   || {};

    // Live wait times per common party sizes (1-2, 3-4, 5-8)
    let waitTimes = null;
    if (rps.showLiveWaitTime !== false) {
      try {
        const objects = event.seatingMap?.objects || [];
        const states  = event.tableStates || [];
        const activeWait = (event.tableServiceWaitlist || []).filter(w => w.status === 'waiting' || w.status === 'notified');
        waitTimes = calcWaitTimes(objects, states, tss, activeWait);
      } catch (wtErr) {
        console.error('[reserve] calcWaitTimes failed for', req.params.subdomain, wtErr.message);
        // Non-fatal — proceed without wait time data rather than 500ing the whole page
      }
    }

    res.json({
      name:             tss.restaurantName || event.title,
      tagline:          rps.headerTagline || '',
      description:      rps.publicDescription || '',
      cuisine:          rps.cuisine || '',
      priceRange:       rps.priceRange || '',
      dressCode:        rps.dressCode || '',
      parkingInfo:      rps.parkingInfo || '',
      accessibilityInfo:rps.accessibilityInfo || '',
      address:          rps.address || '',
      phone:            rps.phone || '',
      websiteUrl:       rps.websiteUrl || '',
      instagramHandle:  rps.instagramHandle || '',
      facebookUrl:      rps.facebookUrl || '',
      googleMapsUrl:    rps.googleMapsUrl || '',
      heroImageUrl:     rps.heroImageUrl || '',
      logoUrl:          rps.logoUrl || '',
      accentColor:      rps.accentColor || '#f97316',
      backgroundStyle:  rps.backgroundStyle || 'dark',
      fontStyle:        rps.fontStyle || 'modern',
      announcementBanner:        rps.announcementBannerEnabled ? rps.announcementBanner : '',
      announcementBannerColor:   rps.announcementBannerColor || '#f59e0b',
      operatingHoursOpen:  tss.operatingHoursOpen  || '11:00',
      operatingHoursClose: tss.operatingHoursClose || '22:00',
      operatingDays:    rps.operatingDays || {},
      blackoutDates:    (rps.blackoutDates || []).filter(Boolean).map(b => b.date).filter(Boolean),
      acceptingReservations: rps.acceptingReservations || false,
      confirmationMode:      rps.confirmationMode || 'auto_confirm',
      slotIntervalMinutes:   rps.slotIntervalMinutes || 30,
      maxAdvanceDays:        rps.maxAdvanceDays || 30,
      minAdvanceHours:       rps.minAdvanceHours ?? 1,
      maxPartySizePublic:    rps.maxPartySizePublic || 12,
      minPartySizePublic:    rps.minPartySizePublic || 1,
      requirePhone:          rps.requirePhone !== false,
      requireEmail:          rps.requireEmail || false,
      allowSpecialRequests:  rps.allowSpecialRequests !== false,
      allowDietaryNeeds:     rps.allowDietaryNeeds !== false,
      allowOccasionSelect:   rps.allowOccasionSelect !== false,
      occasionOptions:       rps.occasionOptions?.length ? rps.occasionOptions : ['Birthday','Anniversary','Business Dinner','Date Night','Family Gathering','Other'],
      showLiveWaitTime:      rps.showLiveWaitTime !== false,
      showAvailabilityStatus:rps.showAvailabilityStatus !== false,
      showTableCount:        rps.showTableCount || false,
      availabilityDisplayMode: rps.availabilityDisplayMode || 'slots',
      confirmationMessage:   rps.confirmationMessage || '',
      depositRequired:       rps.depositRequired || false,
      depositAmount:         rps.depositAmount || 0,
      depositNote:           rps.depositNote || '',
      cancellationPolicy:    rps.cancellationPolicy || '',
      cancelCutoffHours:     rps.cancelCutoffHours || 2,
      faqItems:              rps.faqItems || [],
      menus:                 rps.menus || [],
      walkInOnlyMode:        rps.walkInOnlyMode || false,
      termsUrl:              rps.termsUrl || '',
      privacyUrl:            rps.privacyUrl || '',
      showPoweredBy:         rps.showPoweredBy !== false,
      metaTitle:             rps.metaTitle || '',
      metaDescription:       rps.metaDescription || '',
      waitTimes,
    });
  } catch (err) { next(err); }
});

// ── GET /public/reserve/:subdomain/availability ────────────────────────────────
// ?date=YYYY-MM-DD&partySize=N
router.get('/public/reserve/:subdomain/availability', availabilityLimiter, async (req, res, next) => {
  try {
    const { date, partySize, tz } = req.query;
    if (!date || !partySize) return res.status(400).json({ error: 'date and partySize required' });

    const sz = parseInt(partySize);
    if (isNaN(sz) || sz < 1 || sz > 100) return res.status(400).json({ error: 'Invalid party size' });

    const event = await Event.findOne({ subdomain: req.params.subdomain })
      .select('isTableServiceMode tableServiceSettings reservationPageSettings seatingMap restaurantReservations')
      .lean();
    if (!event || !event.isTableServiceMode) return res.status(404).json({ error: 'Not found' });

    const rps = event.reservationPageSettings || {};
    if (!rps.acceptingReservations) return res.json({ slots: [], closed: true });

    // Blackout / day closed
    const dayKey = getDayKey(date + 'T12:00:00');
    const dayConfig = rps.operatingDays?.[dayKey];
    if (dayConfig && dayConfig.open === false) return res.json({ slots: [], closed: true });
    if ((rps.blackoutDates || []).some(b => b.date === date)) {
      return res.json({ slots: [], closed: true, reason: 'Closed this date' });
    }

    // Max per day cap
    const maxPerDay = rps.maxReservationsPerDay || 0;
    if (maxPerDay > 0) {
      const dayStart = tz ? wallClockToUTC(date, '00:00', tz) : new Date(date + 'T00:00:00');
      const dayEnd   = tz ? wallClockToUTC(date, '23:59', tz) : new Date(date + 'T23:59:59');
      const dayCount = (event.restaurantReservations || []).filter(r =>
        (r.status === 'confirmed' || r.status === 'pending') &&
        new Date(r.dateTime) >= dayStart && new Date(r.dateTime) <= dayEnd
      ).length;
      if (dayCount >= maxPerDay) return res.json({ slots: [], closed: true, reason: 'Fully booked for this day' });
    }

    const slots = computeAvailability(date, sz, event, tz);
    res.json({ slots });
  } catch (err) { next(err); }
});

// ── POST /public/reserve/:subdomain ───────────────────────────────────────────
// Create a public reservation. Rate limited.
router.post('/public/reserve/:subdomain', reservationLimiter, async (req, res, next) => {
  try {
    const { partyName, partySize, phone, email, date, timeSlot, occasion, specialRequests, dietaryNeeds, tz } = req.body;

    if (!partyName?.trim()) return res.status(400).json({ error: 'Name is required' });
    if (!partySize || partySize < 1) return res.status(400).json({ error: 'Party size is required' });
    if (!date || !timeSlot) return res.status(400).json({ error: 'Date and time are required' });

    const event = await Event.findOne({ subdomain: req.params.subdomain })
      .select('+restaurantReservations tableServiceSettings reservationPageSettings seatingMap isTableServiceMode');
    if (!event || !event.isTableServiceMode) return res.status(404).json({ error: 'Not found' });

    const rps = event.reservationPageSettings || {};
    if (!rps.acceptingReservations) return res.status(403).json({ error: 'Online reservations are not currently being accepted.' });

    if (rps.requirePhone && !phone?.trim()) return res.status(400).json({ error: 'Phone number is required' });
    if (rps.requireEmail && !email?.trim()) return res.status(400).json({ error: 'Email address is required' });

    const sz = parseInt(partySize);
    if (sz < (rps.minPartySizePublic || 1)) return res.status(400).json({ error: `Minimum party size is ${rps.minPartySizePublic || 1}` });
    if (sz > (rps.maxPartySizePublic || 12)) return res.status(400).json({ error: `Maximum party size for online bookings is ${rps.maxPartySizePublic || 12}` });

    // Build datetime in guest's local timezone → store as correct UTC
    const dateTime = tz ? wallClockToUTC(date, timeSlot, tz) : new Date(`${date}T${timeSlot}:00`);
    if (isNaN(dateTime.getTime())) return res.status(400).json({ error: 'Invalid date/time' });

    // Min advance check
    const minAdvanceMs = (rps.minAdvanceHours ?? 1) * 3600000;
    if (dateTime.getTime() - Date.now() < minAdvanceMs) {
      return res.status(400).json({ error: `Reservations must be made at least ${rps.minAdvanceHours ?? 1} hour(s) in advance` });
    }

    // Max advance check
    const maxAdvanceMs = (rps.maxAdvanceDays || 30) * 86400000;
    if (dateTime.getTime() - Date.now() > maxAdvanceMs) {
      return res.status(400).json({ error: `Reservations can only be made up to ${rps.maxAdvanceDays || 30} days in advance` });
    }

    // Re-check availability
    const slots = computeAvailability(date, sz, event, tz);
    const targetSlot = slots.find(s => s.time === timeSlot);
    if (!targetSlot || targetSlot.status === 'full') {
      return res.status(409).json({ error: 'This time slot is no longer available. Please choose another time.' });
    }

    // Per-day cap re-check
    const maxPerDay = rps.maxReservationsPerDay || 0;
    if (maxPerDay > 0) {
      const dayStart = tz ? wallClockToUTC(date, '00:00', tz) : new Date(date + 'T00:00:00');
      const dayEnd   = tz ? wallClockToUTC(date, '23:59', tz) : new Date(date + 'T23:59:59');
      const dayCount = event.restaurantReservations.filter(r =>
        (r.status === 'confirmed' || r.status === 'pending') &&
        new Date(r.dateTime) >= dayStart && new Date(r.dateTime) <= dayEnd
      ).length;
      if (dayCount >= maxPerDay) return res.status(409).json({ error: 'Sorry, this day is now fully booked.' });
    }

    // Generate tokens
    const resId      = `res_${Date.now().toString(36)}_${crypto.randomBytes(4).toString('hex')}`;
    const qrToken    = crypto.randomBytes(24).toString('hex');
    const cancelToken= crypto.randomBytes(24).toString('hex');

    const tss = event.tableServiceSettings || {};
    const qrExpiryMin = tss.reservationQrExpiryMinutes || 45;
    const qrExpiresAt = new Date(dateTime.getTime() + qrExpiryMin * 60000);

    const status = (rps.confirmationMode === 'manual') ? 'pending' : 'confirmed';

    const reservation = {
      id:              resId,
      partyName:       partyName.trim(),
      partySize:       sz,
      phone:           phone?.trim() || '',
      email:           email?.trim() || '',
      dateTime,
      tableId:         null,
      qrToken,
      qrExpiresAt,
      cancelToken,
      status,
      source:          'public',
      occasion:        occasion || '',
      specialRequests: specialRequests?.trim() || '',
      dietaryNeeds:    dietaryNeeds?.trim() || '',
      notes:           '',
      createdAt:       new Date(),
    };

    // Use findOneAndUpdate + $push to avoid Mongoose 8 partial-select validation errors
    // (event was fetched with .select() so required fields like title/subdomain are absent
    //  from the in-memory doc — calling event.save() throws ValidationError on those paths)
    await Event.findOneAndUpdate(
      { subdomain: req.params.subdomain },
      { $push: { restaurantReservations: reservation }, $set: { keepForever: true } },
      { runValidators: false }
    );

    // Fire confirmation email non-blocking
    if (rps.sendConfirmationEmail !== false && email?.trim()) {
      try {
        const { sendReservationConfirmation } = require('../services/emailService');
        sendReservationConfirmation(event, reservation).catch(() => {});
      } catch (_) {}
    }

    const cancelUrl = `${process.env.FRONTEND_URL || 'https://planit.events'}/reserve/cancel/${cancelToken}`;

    res.status(201).json({
      reservationId: resId,
      status,
      partyName:     reservation.partyName,
      partySize:     reservation.partySize,
      dateTime:      reservation.dateTime,
      qrToken,
      qrExpiresAt,
      cancelToken,   // frontend redirects to /reservation/:cancelToken ticket page
      cancelUrl,
      confirmationMessage: rps.confirmationMessage || '',
      depositRequired:     rps.depositRequired || false,
      depositAmount:       rps.depositAmount || 0,
      depositNote:         rps.depositNote || '',
      isPending: status === 'pending',
    });
  } catch (err) { next(err); }
});


// ── GET /public/reserve/confirmation/:cancelToken ────────────────────────────
// Returns reservation details for the guest confirmation/ticket page.
// Uses cancelToken (sent in POST response) — safe to expose publicly.
router.get('/public/reserve/confirmation/:cancelToken', availabilityLimiter, async (req, res, next) => {
  try {
    const { cancelToken } = req.params;
    if (!cancelToken || cancelToken.length < 10) return res.status(400).json({ error: 'Invalid token' });

    const event = await Event.findOne({
      isTableServiceMode: true,
      'restaurantReservations.cancelToken': cancelToken,
    }).select('title subdomain restaurantReservations reservationPageSettings');

    if (!event) return res.status(404).json({ error: 'Reservation not found.' });

    const r = event.restaurantReservations.find(x => x.cancelToken === cancelToken);
    if (!r) return res.status(404).json({ error: 'Reservation not found.' });

    const rps = event.reservationPageSettings || {};

    res.json({
      restaurantName: event.title,
      subdomain: event.subdomain,
      accentColor: rps.accentColor || '#f97316',
      logoUrl: rps.logoUrl || '',
      address: rps.address || '',
      phone: rps.phone || '',
      reservation: {
        id: r.id,
        partyName: r.partyName,
        partySize: r.partySize,
        dateTime: r.dateTime,
        status: r.status,
        qrToken: r.qrToken,
        qrExpiresAt: r.qrExpiresAt,
        occasion: r.occasion || '',
        specialRequests: r.specialRequests || '',
        dietaryNeeds: r.dietaryNeeds || '',
      },
      cancelUrl: `${process.env.FRONTEND_URL || 'https://planit.events'}/reservation/${cancelToken}`,
      confirmationMessage: rps.confirmationMessage || '',
      cancelCutoffHours: rps.cancelCutoffHours || 2,
    });
  } catch (err) { next(err); }
});

// ── DELETE /public/reserve/cancel/:cancelToken ────────────────────────────────
// Self-service cancellation via the token in the confirmation email.
router.delete('/public/reserve/cancel/:cancelToken', reservationLimiter, async (req, res, next) => {
  try {
    const { cancelToken } = req.params;
    if (!cancelToken || cancelToken.length < 10) return res.status(400).json({ error: 'Invalid cancel token' });

    // Search across all table-service events for this token
    const event = await Event.findOne({
      isTableServiceMode: true,
      'restaurantReservations.cancelToken': cancelToken,
    });
    if (!event) return res.status(404).json({ error: 'Reservation not found or already cancelled.' });

    const res_ = event.restaurantReservations.find(r => r.cancelToken === cancelToken);
    if (!res_) return res.status(404).json({ error: 'Reservation not found.' });
    if (res_.status === 'cancelled') return res.status(400).json({ error: 'This reservation is already cancelled.' });
    if (res_.status === 'seated') return res.status(400).json({ error: 'This reservation cannot be cancelled — the party is already seated.' });

    const rps = event.reservationPageSettings || {};
    const cutoffMs = (rps.cancelCutoffHours || 2) * 3600000;
    if (new Date(res_.dateTime).getTime() - Date.now() < cutoffMs) {
      return res.status(403).json({
        error: `Reservations can only be cancelled at least ${rps.cancelCutoffHours || 2} hour(s) before the booking time. Please call us directly.`,
        phone: rps.phone || '',
      });
    }

    res_.status = 'cancelled';
    await event.save();

    // Notify organizer
    if (rps.notifyOrganizerOnCancel && rps.notifyOrganizerEmail) {
      try {
        const { sendReservationCancellation } = require('../services/emailService');
        sendReservationCancellation(event, res_).catch(() => {});
      } catch (_) {}
    }

    res.json({ success: true, message: 'Your reservation has been cancelled.' });
  } catch (err) { next(err); }
});

// ─── End public routes ──────────────────────────────────────────────────────

router.get('/:eventId', verifyEventAccess, async (req, res, next) => {
  try {
    const event = req.event;
    res.json({
      event: {
        id: event._id, subdomain: event.subdomain, title: event.title,
        description: event.description, date: event.date, location: event.location,
        organizerName: event.organizerName, settings: event.settings,
        participants: event.participants, maxParticipants: event.maxParticipants,
        status: event.status, isPasswordProtected: event.isPasswordProtected,
        isEnterpriseMode: event.isEnterpriseMode,
        isTableServiceMode: !!event.isTableServiceMode,
        eventType: event.eventType || 'standard',
        isClone: !!event.clonedFrom,
        seatingMap: { enabled: !!event.seatingMap?.enabled, tableCount: (event.seatingMap?.objects || []).length },
        rsvps: event.rsvps, rsvpSummary: event.getRsvpSummary(),
        agenda: event.agenda ? [...event.agenda].sort((a, b) => a.order - b.order) : [],
        createdAt: event.createdAt
      }
    });
  } catch (error) { next(error); }
});

// ── RSVP ──────────────────────────────────────────────────────────────────
router.post('/:eventId/rsvp',
  verifyEventAccess,
  [
    body('username').trim().isLength({ min: 1, max: 100 }).withMessage('Username required'),
    body('status').isIn(['yes', 'maybe', 'no']).withMessage('Status must be yes, maybe, or no'),
    validate
  ],
  async (req, res, next) => {
    try {
      const event = req.event;

      // ── RSVP deadline enforcement ──────────────────────────────────────────
      if (event.settings?.rsvpEnabled === false) {
        return res.status(403).json({ error: 'RSVPs are not enabled for this event.' });
      }
      if (event.settings?.rsvpDeadline && new Date() > new Date(event.settings.rsvpDeadline)) {
        return res.status(403).json({
          error: 'The RSVP deadline has passed.',
          deadline: event.settings.rsvpDeadline,
        });
      }
      if (req.body.status === 'maybe' && event.settings?.rsvpAllowMaybe === false) {
        return res.status(400).json({ error: 'Maybe responses are not allowed for this event.' });
      }
      // ──────────────────────────────────────────────────────────────────────

      await event.setRsvp(req.body.username, req.body.status);

      const io = req.app.get('io');
      if (io) {
        io.to(`event_${req.params.eventId}`).emit('rsvp_updated', {
          username: req.body.username,
          status:   req.body.status,
          rsvps:    event.rsvps,
          summary:  event.getRsvpSummary()
        });
      }

      // Fire webhooks non-blocking
      fireWebhooks(req.params.eventId, 'rsvp_updated', { username: req.body.username, rsvp: req.body.status }).catch(() => {});

      res.json({ message: 'RSVP recorded', rsvpSummary: event.getRsvpSummary() });
    } catch (error) { next(error); }
  }
);

// ── RSVP settings (organizer only) ────────────────────────────────────────
router.patch('/:eventId/rsvp-settings',
  verifyOrganizer,
  async (req, res, next) => {
    try {
      const event = req.event;
      const { rsvpEnabled, rsvpDeadline, rsvpAllowMaybe, rsvpShowCount, rsvpMessage } = req.body;

      if (rsvpEnabled      !== undefined) event.settings.rsvpEnabled      = rsvpEnabled;
      if (rsvpDeadline     !== undefined) event.settings.rsvpDeadline     = rsvpDeadline ? new Date(rsvpDeadline) : null;
      if (rsvpAllowMaybe   !== undefined) event.settings.rsvpAllowMaybe   = rsvpAllowMaybe;
      if (rsvpShowCount    !== undefined) event.settings.rsvpShowCount    = rsvpShowCount;
      if (rsvpMessage      !== undefined) event.settings.rsvpMessage      = rsvpMessage.slice(0, 500);

      await event.save();

      const io = req.app.get('io');
      if (io) {
        io.to(`event_${req.params.eventId}`).emit('event_settings_updated', {
          settings: event.settings,
        });
      }

      res.json({ message: 'RSVP settings updated', settings: event.settings });
    } catch (error) { next(error); }
  }
);

// ── RSVP summary — public, no auth needed ─────────────────────────────────
// Used by the guest invite page to show counts without requiring login
router.get('/:eventId/rsvp-summary', async (req, res, next) => {
  try {
    const Event = require('../models/Event');
    const event = await Event.findById(req.params.eventId).select('rsvps settings title date').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });

    const summary = { yes: 0, maybe: 0, no: 0 };
    event.rsvps.forEach(r => { if (summary[r.status] !== undefined) summary[r.status]++; });

    res.json({
      summary,
      total:        event.rsvps.length,
      deadline:     event.settings?.rsvpDeadline || null,
      deadlinePast: event.settings?.rsvpDeadline ? new Date() > new Date(event.settings.rsvpDeadline) : false,
      showCount:    event.settings?.rsvpShowCount !== false,
      message:      event.settings?.rsvpMessage || '',
    });
  } catch (error) { next(error); }
});

// ── TASKS ─────────────────────────────────────────────────────────────────
// Get tasks
router.get('/:eventId/tasks', verifyEventAccess, async (req, res, next) => {
  try {
    const tasks = req.event.tasks.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({ tasks, stats: req.event.getTaskStats() });
  } catch (error) { next(error); }
});

// Create task
router.post('/:eventId/tasks', verifyEventAccess,
  [
    body('title').trim().isLength({ min: 1, max: 200 }),
    body('description').optional().trim().isLength({ max: 500 }),
    body('assignedTo').optional().trim().isLength({ max: 100 }),
    body('dueDate').optional().isISO8601(),
    body('priority').optional().isIn(['low', 'medium', 'high']),
    validate
  ],
  async (req, res, next) => {
    try {
      const { title, description, assignedTo, dueDate, priority } = req.body;
      const task = {
        id: uuidv4(),
        title, description: description || '', assignedTo, dueDate,
        priority: priority || 'medium',
        createdBy: req.eventAccess.username,
        completed: false
      };
      req.event.tasks.push(task);
      await req.event.save();

      const io = req.app.get('io');
      if (io) io.to(`event_${req.params.eventId}`).emit('tasks_updated', { tasks: req.event.tasks });

      res.status(201).json({ message: 'Task created', task });
    } catch (error) { next(error); }
  }
);

// Toggle task completion
router.patch('/:eventId/tasks/:taskId/toggle', verifyEventAccess, async (req, res, next) => {
  try {
    const task = req.event.tasks.find(t => t.id === req.params.taskId);
    if (!task) return res.status(404).json({ error: 'Task not found' });

    task.completed = !task.completed;
    if (task.completed) {
      task.completedBy = req.eventAccess.username;
      task.completedAt = new Date();
    } else {
      task.completedBy = undefined;
      task.completedAt = undefined;
    }
    await req.event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('tasks_updated', { tasks: req.event.tasks });

    res.json({ message: 'Task updated', task });
  } catch (error) { next(error); }
});

// Delete task
router.delete('/:eventId/tasks/:taskId', verifyEventAccess, async (req, res, next) => {
  try {
    req.event.tasks = req.event.tasks.filter(t => t.id !== req.params.taskId);
    await req.event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('tasks_updated', { tasks: req.event.tasks });

    res.json({ message: 'Task deleted' });
  } catch (error) { next(error); }
});

// ── ANNOUNCEMENTS ─────────────────────────────────────────────────────────
// Get announcements
router.get('/:eventId/announcements', verifyEventAccess, async (req, res, next) => {
  try {
    const announcements = [...req.event.announcements].sort((a, b) => 
      new Date(b.createdAt) - new Date(a.createdAt)
    );
    res.json({ announcements });
  } catch (error) { next(error); }
});

// Create announcement (organizer only)
router.post('/:eventId/announcements', verifyEventAccess,
  [
    body('title').trim().isLength({ min: 1, max: 200 }),
    body('content').trim().isLength({ min: 1, max: 2000 }),
    body('important').optional().isBoolean(),
    validate
  ],
  async (req, res, next) => {
    try {
      const isOrg = req.event.participants.some(p => 
        p.username === req.eventAccess.username && p.role === 'organizer'
      );
      if (!isOrg) return res.status(403).json({ error: 'Only organizers can create announcements' });

      const announcement = {
        id: uuidv4(),
        title: req.body.title,
        content: req.body.content,
        important: req.body.important || false,
        author: req.eventAccess.username,
        createdAt: new Date()
      };
      req.event.announcements.push(announcement);
      await req.event.save();

      const io = req.app.get('io');
      if (io) io.to(`event_${req.params.eventId}`).emit('announcement_created', { announcement });

      res.status(201).json({ message: 'Announcement created', announcement });
    } catch (error) { next(error); }
  }
);

// Delete announcement (organizer only)
router.delete('/:eventId/announcements/:announcementId', verifyEventAccess, async (req, res, next) => {
  try {
    const isOrg = req.event.participants.some(p => 
      p.username === req.eventAccess.username && p.role === 'organizer'
    );
    if (!isOrg) return res.status(403).json({ error: 'Only organizers can delete announcements' });

    req.event.announcements = req.event.announcements.filter(a => a.id !== req.params.announcementId);
    await req.event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('announcements_updated', { announcements: req.event.announcements });

    res.json({ message: 'Announcement deleted' });
  } catch (error) { next(error); }
});

// ── EXPENSES ──────────────────────────────────────────────────────────────
// Get expenses
router.get('/:eventId/expenses', verifyEventAccess, async (req, res, next) => {
  try {
    const expenses = [...req.event.expenses].sort((a, b) => new Date(b.date) - new Date(a.date));
    res.json({ expenses, summary: req.event.getExpenseSummary(), budget: req.event.budget });
  } catch (error) { next(error); }
});

// Add expense
router.post('/:eventId/expenses', verifyEventAccess,
  [
    body('title').trim().isLength({ min: 1, max: 200 }),
    body('amount').isFloat({ min: 0 }),
    body('category').optional().trim().isLength({ max: 100 }),
    body('paidBy').optional().trim().isLength({ max: 100 }),
    body('notes').optional().trim().isLength({ max: 500 }),
    validate
  ],
  async (req, res, next) => {
    try {
      const { title, amount, category, paidBy, notes } = req.body;
      const expense = {
        id: uuidv4(),
        title, amount, category, paidBy, notes,
        createdBy: req.eventAccess.username,
        date: new Date()
      };
      req.event.expenses.push(expense);
      await req.event.save();

      const io = req.app.get('io');
      if (io) io.to(`event_${req.params.eventId}`).emit('expenses_updated', { 
        expenses: req.event.expenses,
        summary: req.event.getExpenseSummary()
      });

      res.status(201).json({ message: 'Expense added', expense });
    } catch (error) { next(error); }
  }
);

// Update budget (organizer only)
router.patch('/:eventId/budget', verifyEventAccess,
  [body('budget').isFloat({ min: 0 }), validate],
  async (req, res, next) => {
    try {
      const isOrg = req.event.participants.some(p => 
        p.username === req.eventAccess.username && p.role === 'organizer'
      );
      if (!isOrg) return res.status(403).json({ error: 'Only organizers can set budget' });

      req.event.budget = req.body.budget;
      await req.event.save();

      res.json({ message: 'Budget updated', budget: req.event.budget });
    } catch (error) { next(error); }
  }
);

// Delete expense
router.delete('/:eventId/expenses/:expenseId', verifyEventAccess, async (req, res, next) => {
  try {
    req.event.expenses = req.event.expenses.filter(e => e.id !== req.params.expenseId);
    await req.event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('expenses_updated', { 
      expenses: req.event.expenses,
      summary: req.event.getExpenseSummary()
    });

    res.json({ message: 'Expense deleted' });
  } catch (error) { next(error); }
});

// ── NOTES ─────────────────────────────────────────────────────────────────
// Get notes
router.get('/:eventId/notes', verifyEventAccess, async (req, res, next) => {
  try {
    const notes = [...req.event.notes].sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt));
    res.json({ notes });
  } catch (error) { next(error); }
});

// Create note
router.post('/:eventId/notes', verifyEventAccess,
  [
    body('title').trim().isLength({ min: 1, max: 200 }),
    body('content').trim().isLength({ min: 1, max: 5000 }),
    body('color').optional().matches(/^#[0-9A-Fa-f]{6}$/),
    validate
  ],
  async (req, res, next) => {
    try {
      const { title, content, color } = req.body;
      const note = {
        id: uuidv4(),
        title, content,
        color: color || '#fef3c7',
        author: req.eventAccess.username,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      req.event.notes.push(note);
      await req.event.save();

      const io = req.app.get('io');
      if (io) io.to(`event_${req.params.eventId}`).emit('notes_updated', { notes: req.event.notes });

      res.status(201).json({ message: 'Note created', note });
    } catch (error) { next(error); }
  }
);

// Update note
router.put('/:eventId/notes/:noteId', verifyEventAccess,
  [
    body('title').optional().trim().isLength({ min: 1, max: 200 }),
    body('content').optional().trim().isLength({ min: 1, max: 5000 }),
    body('color').optional().matches(/^#[0-9A-Fa-f]{6}$/),
    validate
  ],
  async (req, res, next) => {
    try {
      const note = req.event.notes.find(n => n.id === req.params.noteId);
      if (!note) return res.status(404).json({ error: 'Note not found' });

      if (req.body.title) note.title = req.body.title;
      if (req.body.content) note.content = req.body.content;
      if (req.body.color) note.color = req.body.color;
      note.updatedAt = new Date();
      
      await req.event.save();

      const io = req.app.get('io');
      if (io) io.to(`event_${req.params.eventId}`).emit('notes_updated', { notes: req.event.notes });

      res.json({ message: 'Note updated', note });
    } catch (error) { next(error); }
  }
);

// Delete note
router.delete('/:eventId/notes/:noteId', verifyEventAccess, async (req, res, next) => {
  try {
    req.event.notes = req.event.notes.filter(n => n.id !== req.params.noteId);
    await req.event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('notes_updated', { notes: req.event.notes });

    res.json({ message: 'Note deleted' });
  } catch (error) { next(error); }
});

// ── ANALYTICS ─────────────────────────────────────────────────────────────
// Get analytics (organizer only) - UPDATED WITH CHECK-IN STATS
router.get('/:eventId/analytics', verifyEventAccess, async (req, res, next) => {
  try {
    const username = req.eventAccess?.username;
    if (!username) return res.status(403).json({ error: 'Only organizers can view analytics' });
    const isOrg = req.event.participants.some(p =>
      p.username === username && p.role === 'organizer'
    );
    if (!isOrg) return res.status(403).json({ error: 'Only organizers can view analytics' });

    const Message = require('../models/Message');
    const Poll = require('../models/Poll');
    const File = require('../models/File');
    const Invite = require('../models/Invite');

    const promises = [
      Message.countDocuments({ eventId: req.params.eventId }).catch(() => 0),
      Poll.countDocuments({ eventId: req.params.eventId }).catch(() => 0),
      File.countDocuments({ eventId: req.params.eventId }).catch(() => 0)
    ];

    if (req.event.isEnterpriseMode) {
      promises.push(Invite.find({ eventId: req.params.eventId }).catch(() => []));
    }

    const results = await Promise.all(promises);
    const [messageCount, pollCount, fileCount, invites] = results;

    const baseAnalytics = req.event.getAnalytics ? req.event.getAnalytics() : {
      views: req.event.metadata?.views || 0,
      participants: req.event.participants?.length || 0,
      rsvps: req.event.getRsvpSummary ? req.event.getRsvpSummary() : { yes: 0, maybe: 0, no: 0 },
      tasks: req.event.getTaskStats ? req.event.getTaskStats() : { total: 0, completed: 0, pending: 0 },
      expenses: req.event.getExpenseSummary ? req.event.getExpenseSummary() : { total: 0, count: 0, byCategory: {} },
      lastActivity: req.event.metadata?.lastActivity || new Date()
    };

    const analytics = { ...baseAnalytics, messages: messageCount, polls: pollCount, files: fileCount };

    if (req.event.isEnterpriseMode && invites) {
      const checkedInInvites = invites.filter(i => i.checkedIn);
      const totalInvites = invites.length;
      const totalExpectedGuests = invites.reduce((sum, i) => sum + (i.adults || 1) + (i.children || 0), 0);
      const totalCheckedIn = checkedInInvites.reduce((sum, i) => sum + (i.actualAttendees || (i.adults || 1) + (i.children || 0)), 0);
      analytics.checkins = {
        totalInvites,
        checkedInInvites: checkedInInvites.length,
        pendingInvites: totalInvites - checkedInInvites.length,
        totalExpectedGuests,
        totalCheckedIn,
        checkInRate: totalInvites > 0 ? Math.round((checkedInInvites.length / totalInvites) * 100) : 0,
        attendanceRate: totalExpectedGuests > 0 ? Math.round((totalCheckedIn / totalExpectedGuests) * 100) : 0
      };
    }

    res.json({ analytics });
  } catch (error) {
    console.error('Analytics error:', error);
    next(error);
  }
});
// ═══════════════════════════════════════════════════════════════════════════
// PUBLIC LIVE WAIT BOARD API  (/api/events/public/wait/...)
// No auth required. Rate-limited. For walk-in / waitlist-only restaurants.
// ═══════════════════════════════════════════════════════════════════════════

// ─────────────────────────────────────────────────────────────────────────────
// SMART WAIT TIME PREDICTION ENGINE
//
// Factors accounted for:
//  1. Per-party-size dining duration overrides (tss.sizeOverrides)
//  2. Table status: available (0 wait), cleaning (buffer only), occupied
//     (remaining dining time + buffer), reserved (full reservation duration
//     + buffer), unavailable (excluded entirely)
//  3. Missing occupiedAt fallback (uses full avg dining time as conservative est.)
//  4. Waitlist queue simulation — parties already in queue "consume" the
//     soonest tables before a new arrival gets seated; each party is greedily
//     assigned to their earliest valid table and that table's free-at time
//     is advanced by their dining duration + buffer.
//  5. Returns scalar minutes AND rich breakdown per party-size bracket so
//     the frontend can display table-level detail and confidence context.
// ─────────────────────────────────────────────────────────────────────────────
function calcWaitTimes(objects, states, tss, waitlist = []) {
  const now    = Date.now();
  const avgDining = tss.avgDiningMinutes || 75;
  const buffer    = tss.cleaningBufferMinutes || 10;
  const resvDuration = tss.reservationDurationMinutes || 90;

  // ── 1. Per-party-size dining time lookup (respects sizeOverrides) ──────────
  const getDiningMins = (partySize) => {
    const overrides = tss.sizeOverrides || [];
    const match = overrides.find(o =>
      (!o.minParty || partySize >= o.minParty) &&
      (!o.maxParty || partySize <= o.maxParty)
    );
    return (match && match.avgMinutes) ? match.avgMinutes : avgDining;
  };

  // ── 2. Build per-table availability timeline ───────────────────────────────
  // First try seating map objects (rich data: labels, capacity, type).
  // If the floor plan hasn't been drawn yet, fall back to tableStates so the
  // wait board still reflects reality even without a visual seating map.
  let tableTimeline;

  const mapObjects = (objects || []).filter(o => o.type !== 'zone' && (o.capacity || 0) > 0);

  if (mapObjects.length > 0) {
    // ─── Full floor-plan path ───────────────────────────────────────────────
    tableTimeline = mapObjects.map(t => {
      const s = (states || []).find(st => st.tableId === t.id);
      const status = s ? s.status : 'available';
      let minsUntilFree = 0;

      switch (status) {
        case 'available':
          minsUntilFree = 0;
          break;
        case 'cleaning':
          minsUntilFree = buffer;
          break;
        case 'occupied': {
          const diningMins = getDiningMins(s.partySize || 2);
          if (s.occupiedAt) {
            const seatedMs  = now - new Date(s.occupiedAt).getTime();
            const remaining = Math.max(0, Math.round((diningMins * 60000 - seatedMs) / 60000));
            minsUntilFree = remaining + buffer;
          } else {
            minsUntilFree = diningMins + buffer;
          }
          break;
        }
        case 'reserved':
          minsUntilFree = resvDuration + buffer;
          break;
        case 'unavailable':
        default:
          minsUntilFree = Infinity;
          break;
      }

      return {
        id:            t.id,
        label:         t.label || '',
        capacity:      t.capacity || 0,
        status,
        minsUntilFree,
        partySize:     s ? (s.partySize || 0) : 0,
      };
    });
  } else if ((states || []).length > 0) {
    // ─── tableStates-only fallback (no floor plan drawn yet) ───────────────
    // Derive a synthetic timeline from the live table states.
    // We don't have capacity from states alone, so assume 4 per table.
    tableTimeline = (states || [])
      .filter(s => s.status !== 'unavailable')
      .map((s, idx) => {
        const status = s.status || 'available';
        const capacity = 4; // conservative default
        let minsUntilFree = 0;

        switch (status) {
          case 'available':
            minsUntilFree = 0;
            break;
          case 'cleaning':
            minsUntilFree = buffer;
            break;
          case 'occupied': {
            const diningMins = getDiningMins(s.partySize || 2);
            if (s.occupiedAt) {
              const seatedMs  = now - new Date(s.occupiedAt).getTime();
              const remaining = Math.max(0, Math.round((diningMins * 60000 - seatedMs) / 60000));
              minsUntilFree = remaining + buffer;
            } else {
              minsUntilFree = diningMins + buffer;
            }
            break;
          }
          case 'reserved':
            minsUntilFree = resvDuration + buffer;
            break;
          default:
            minsUntilFree = Infinity;
            break;
        }

        return {
          id:            s.tableId || `t${idx}`,
          label:         s.tableId ? `Table ${idx + 1}` : `Table ${idx + 1}`,
          capacity,
          status,
          minsUntilFree,
          partySize:     s.partySize || 0,
        };
      });
  } else {
    // ─── No data at all — open / walk right in ─────────────────────────────
    tableTimeline = [];
  }

  // ── 3. Active waitlist queue (waiting + notified), chronological ───────────
  const activeQueue = (waitlist || [])
    .filter(w => w.status === 'waiting' || w.status === 'notified')
    .slice()
    .sort((a, b) => new Date(a.addedAt || 0) - new Date(b.addedAt || 0));

  // ── 4. Queue simulation for a target party size ────────────────────────────
  const simulateForSize = (targetSz) => {
    const timeline = tableTimeline.map(t => ({ ...t }));

    for (const party of activeQueue) {
      const sz = party.partySize || 1;
      const eligible = timeline
        .filter(t => t.capacity >= sz && t.minsUntilFree !== Infinity)
        .sort((a, b) => a.minsUntilFree - b.minsUntilFree);
      if (!eligible.length) continue;
      const tbl = eligible[0];
      tbl.minsUntilFree += getDiningMins(sz) + buffer;
    }

    const candidates = timeline
      .filter(t => t.capacity >= targetSz && t.minsUntilFree !== Infinity)
      .sort((a, b) => a.minsUntilFree - b.minsUntilFree);

    if (!candidates.length) {
      // If there are tables in the timeline but none fit this size, the restaurant
      // is either full or doesn't have large-enough tables — return a reasonable wait
      if (tableTimeline.length > 0) {
        const anyFree = tableTimeline.some(t => t.minsUntilFree === 0 && t.minsUntilFree !== Infinity);
        return anyFree ? { minutes: 0, tableId: null, tableLabel: '', fromStatus: 'available' } : null;
      }
      // No tables at all — assume available
      return { minutes: 0, tableId: null, tableLabel: '', fromStatus: 'available' };
    }
    const best = candidates[0];
    return {
      minutes:    best.minsUntilFree,
      tableId:    best.id,
      tableLabel: best.label,
      fromStatus: best.status,
    };
  };

  // ── 5. Assemble results per bracket ───────────────────────────────────────
  const brackets = [
    { key: 'forTwo',   sz: 2  },
    { key: 'forFour',  sz: 4  },
    { key: 'forEight', sz: 8  },
  ];

  const result = {
    queueDepth:     activeQueue.length,
    tableBreakdown: tableTimeline
      .filter(t => t.minsUntilFree !== Infinity)
      .map(t => ({
        id:           t.id,
        label:        t.label,
        capacity:     t.capacity,
        status:       t.status,
        minsUntilFree: t.minsUntilFree,
      })),
  };

  for (const { key, sz } of brackets) {
    const sim = simulateForSize(sz);
    result[key] = sim ? sim.minutes : null;
    result[`${key}Detail`] = sim
      ? { tableId: sim.tableId, label: sim.tableLabel, fromStatus: sim.fromStatus, queueDepth: activeQueue.length }
      : null;
  }

  return result;
}

// ── Helper: find event by subdomain OR eventId ─────────────────────────────
const mongoose = require('mongoose');
// Generate ICS calendar file
router.get('/:eventId/calendar.ics', verifyEventAccess, async (req, res, next) => {
  try {
    const event = req.event;
    const startDate = new Date(event.date);
    const endDate = new Date(startDate.getTime() + 2 * 60 * 60 * 1000); // +2 hours default

    const formatDate = (date) => {
      return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    };

    const ics = `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//PlanIt//Event//EN
CALSCALE:GREGORIAN
METHOD:PUBLISH
BEGIN:VEVENT
UID:${event._id}@planit.app
DTSTAMP:${formatDate(new Date())}
DTSTART:${formatDate(startDate)}
DTEND:${formatDate(endDate)}
SUMMARY:${event.title}
DESCRIPTION:${event.description || ''}
LOCATION:${event.location || ''}
ORGANIZER;CN=${event.organizerName}:mailto:${event.organizerEmail}
URL:${req.protocol}://${req.get('host')}/e/${event.subdomain}
STATUS:CONFIRMED
END:VEVENT
END:VCALENDAR`;

    res.setHeader('Content-Type', 'text/calendar');
    res.setHeader('Content-Disposition', `attachment; filename="${event.subdomain}.ics"`);
    res.send(ics);
  } catch (error) { next(error); }
});

// Export participants as CSV
router.get('/:eventId/participants.csv', verifyEventAccess, async (req, res, next) => {
  try {
    const isOrg = req.event.participants.some(p => 
      p.username === req.eventAccess.username && p.role === 'organizer'
    );
    if (!isOrg) return res.status(403).json({ error: 'Only organizers can export participants' });

    let csv = 'Username,Role,Joined At,RSVP Status\n';
    req.event.participants.forEach(p => {
      const rsvp = req.event.rsvps.find(r => r.username === p.username);
      csv += `"${p.username}","${p.role}","${p.joinedAt.toISOString()}","${rsvp ? rsvp.status : 'no response'}"\n`;
    });

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${req.event.subdomain}-participants.csv"`);
    res.send(csv);
  } catch (error) { next(error); }
});

// ── Agenda ────────────────────────────────────────────────────────────────
// Get agenda
router.get('/:eventId/agenda', verifyEventAccess, async (req, res, next) => {
  try {
    const event = req.event;
    const sorted = event.agenda ? [...event.agenda].sort((a, b) => a.order - b.order) : [];
    res.json({ agenda: sorted });
  } catch (error) { next(error); }
});

// Add agenda item (organizer only)
router.post('/:eventId/agenda',
  verifyEventAccess,
  [
    body('title').trim().isLength({ min: 1, max: 200 }).withMessage('Title required'),
    body('time').optional().trim().isLength({ max: 20 }),
    body('description').optional().trim().isLength({ max: 500 }),
    body('duration').optional().isInt({ min: 0 }),
    validate
  ],
  async (req, res, next) => {
    try {
      const event = req.event;
      const username = req.eventAccess?.username;
      if (!canEditAgenda(event, username)) return res.status(403).json({ error: 'You do not have permission to manage the agenda' });

      const { title, time, description, duration } = req.body;
      const item = {
        id: uuidv4(),
        title, time: time || '', description: description || '',
        duration: duration || 0,
        order: event.agenda.length
      };

      event.agenda.push(item);
      await event.save();

      const io = req.app.get('io');
      if (io) io.to(`event_${req.params.eventId}`).emit('agenda_updated', { agenda: event.agenda });

      res.status(201).json({ message: 'Agenda item added', item });
    } catch (error) { next(error); }
  }
);

// Delete agenda item (organizer only)
router.delete('/:eventId/agenda/:itemId',
  verifyEventAccess,
  async (req, res, next) => {
    try {
      const event = req.event;
      const username = req.eventAccess?.username;
      if (!canEditAgenda(event, username)) return res.status(403).json({ error: 'You do not have permission to manage the agenda' });

      event.agenda = event.agenda.filter(a => a.id !== req.params.itemId);
      await event.save();

      const io = req.app.get('io');
      if (io) io.to(`event_${req.params.eventId}`).emit('agenda_updated', { agenda: event.agenda });

      res.json({ message: 'Agenda item removed' });
    } catch (error) { next(error); }
  }
);

// Promote or demote a participant (organizer only)
router.patch('/:eventId/participants/:username/role',
  verifyOrganizer,
  [
    body('role').isIn(['organizer', 'participant']).withMessage('Role must be "organizer" or "participant"'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const event = req.event;
      const { username } = req.params;
      const { role } = req.body;
      const callerUsername = req.eventAccess?.username;

      // Prevent the last organizer from demoting themselves
      if (role === 'participant' && callerUsername === username) {
        const organizerCount = event.participants.filter(p => p.role === 'organizer').length;
        if (organizerCount <= 1) {
          return res.status(400).json({ error: 'Cannot demote yourself — you are the only organizer.' });
        }
      }

      const target = event.participants.find(p => p.username === username);
      if (!target) return res.status(404).json({ error: 'Participant not found in this event.' });

      await Event.updateOne(
        { _id: event._id, 'participants.username': username },
        { $set: { 'participants.$.role': role } }
      );

      await EventParticipant.updateOne(
        { eventId: event._id.toString(), username },
        { $set: { role } }
      );

      const io = req.app.get('io');
      if (io) {
        io.to(`event_${req.params.eventId}`).emit('participant_role_changed', { username, role, changedBy: callerUsername });
      }

      res.json({ message: `${username} is now ${role === 'organizer' ? 'an organizer' : 'a participant'}.`, username, role });
    } catch (error) { next(error); }
  }
);

// Update event (organizer only)
router.put('/:eventId', verifyOrganizer,
  [
    body('title').optional().trim().isLength({ min: 1, max: 200 }),
    body('description').optional().trim().isLength({ max: 2000 }),
    body('date').optional().isISO8601(),
    body('location').optional().trim().isLength({ max: 500 }),
    validate
  ],
  async (req, res, next) => {
    try {
      const { title, description, date, location, settings, maxParticipants, status, coverImage, themeColor, tags } = req.body;
      const event = req.event;
      if (title) event.title = title;
      if (description !== undefined) event.description = description;
      if (date) event.date = date;
      if (location !== undefined) event.location = location;
      if (settings) {
        event.settings = { ...event.settings, ...settings };
        event.markModified('settings'); // required for Mongoose to detect nested object changes
      }
      if (maxParticipants) event.maxParticipants = maxParticipants;
      if (status && ['active', 'completed', 'cancelled'].includes(status)) event.status = status;
      if (coverImage !== undefined) event.coverImage = coverImage;
      if (themeColor !== undefined) event.themeColor = themeColor;
      if (tags !== undefined) event.tags = Array.isArray(tags) ? tags.slice(0, 5) : [];
      await event.save();

      const io = req.app.get('io');
      if (io) {
        io.to(`event_${req.params.eventId}`).emit('event_settings_updated', {
          settings: event.settings,
          status:   event.status,
          title:    event.title,
          maxParticipants: event.maxParticipants,
        });
      }

      res.json({ message: 'Event updated', event });
    } catch (error) { next(error); }
  }
);

// Upload cover image for event (organizer only)
router.post('/:eventId/cover', verifyOrganizer, async (req, res, next) => {
  const multer     = require('multer');
  const cloudinary = require('cloudinary').v2;
  const fs         = require('fs');
  const os         = require('os');
  const path       = require('path');

  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key:    process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
    secure:     true,
  });

  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (_, file, cb) => {
      ['image/jpeg','image/png','image/webp','image/gif'].includes(file.mimetype)
        ? cb(null, true)
        : cb(new Error('Only images are allowed for cover photos'));
    },
  }).single('cover');

  upload(req, res, async (err) => {
    if (err) return res.status(400).json({ error: err.message });
    if (!req.file) return res.status(400).json({ error: 'No image uploaded' });

    if (!process.env.CLOUDINARY_CLOUD_NAME) {
      return res.status(503).json({ error: 'Image storage is not configured' });
    }

    const safeName = `cover-${req.params.eventId}`;
    const tmpPath  = path.join(os.tmpdir(), `planit-cover-${Date.now()}`);
    fs.writeFileSync(tmpPath, req.file.buffer);

    try {
      const result = await cloudinary.uploader.upload(tmpPath, {
        folder:        'planit-covers',
        resource_type: 'image',
        public_id:     safeName,
        overwrite:     true,
        transformation: [{ width: 1200, height: 400, crop: 'fill', quality: 'auto' }],
        secure:        true,
      });

      req.event.coverImage = result.secure_url;
      await req.event.save();

      res.json({ coverImage: result.secure_url });
    } catch (uploadErr) {
      next(uploadErr);
    } finally {
      try { fs.unlinkSync(tmpPath); } catch (_) {}
    }
  });
});

// Delete event (organizer only)
router.delete('/:eventId', verifyOrganizer, async (req, res, next) => {
  try {
    await Event.findByIdAndDelete(req.params.eventId);
    res.json({ message: 'Event deleted successfully' });
  } catch (error) { next(error); }
});

// Enterprise Mode: Create personalized invites
router.post('/:eventId/invites', verifyOrganizer, 
  [
    body('guests').isArray().withMessage('Guests must be an array'),
    body('guests.*.guestName').trim().isLength({ min: 1, max: 100 }),
    body('guests.*.guestEmail').optional().isEmail(),
    body('guests.*.groupSize').optional().isInt({ min: 1 }),
    body('guests.*.adults').optional().isInt({ min: 0 }),
    body('guests.*.children').optional().isInt({ min: 0 }),
    validate
  ],
  async (req, res, next) => {
    try {
      const Invite = require('../models/Invite');
      const { guests } = req.body;
      
      const invites = [];
      for (const guest of guests) {
        const inviteCode = generateInviteCode();
        
        // Calculate adults and children with proper defaults
        const adults = parseInt(guest.adults) >= 0 ? parseInt(guest.adults) : 1;
        const children = parseInt(guest.children) >= 0 ? parseInt(guest.children) : 0;
        const calculatedGroupSize = adults + children;
        
        const invite = await Invite.create({
          eventId: req.params.eventId,
          inviteCode,
          guestName: guest.guestName,
          guestEmail: guest.guestEmail || '',
          guestPhone: guest.guestPhone || '',
          adults: adults,
          children: children,
          groupSize: guest.groupSize || calculatedGroupSize,
          plusOnes: parseInt(guest.plusOnes) || 0,
          securityPin: guest.securityPin || '',
          notes: guest.notes || ''
        });
        invites.push(invite);

        // Guest invite confirmation emails disabled (free email tier)
      }
      
      res.status(201).json({ message: 'Invites created', invites });
    } catch (error) { next(error); }
  }
);

// ── Bulk CSV import ──────────────────────────────────────────────────────────
// POST /:eventId/invites/import-csv
// Body: { csv: string }  — raw CSV text including header row
// Returns: { imported, skipped, errors: [{ row, guestName, reason }] }
router.post('/:eventId/invites/import-csv', verifyOrganizer, async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const { csv } = req.body;

    if (!csv || typeof csv !== 'string' || !csv.trim()) {
      return res.status(400).json({ error: 'csv field is required' });
    }

    // ── Parse CSV ────────────────────────────────────────────────────────────
    // Split on newlines, skip blank lines
    const lines = csv.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    if (lines.length < 2) {
      return res.status(400).json({ error: 'CSV must have a header row and at least one data row' });
    }

    // Parse a single CSV line respecting double-quoted fields
    const parseLine = (line) => {
      const fields = [];
      let field = '';
      let inQuotes = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
          if (inQuotes && line[i + 1] === '"') { field += '"'; i++; }
          else { inQuotes = !inQuotes; }
        } else if (ch === ',' && !inQuotes) {
          fields.push(field.trim());
          field = '';
        } else {
          field += ch;
        }
      }
      fields.push(field.trim());
      return fields;
    };

    // Map header names to column indices (case-insensitive, strip BOM)
    const rawHeader = lines[0].replace(/^\uFEFF/, '');
    const headers = parseLine(rawHeader).map(h => h.toLowerCase().replace(/\s+/g, ''));
    const col = (name) => headers.indexOf(name);

    const iName     = col('guestname');
    const iEmail    = col('guestemail');
    const iRole     = col('guestrole');
    const iAdults   = col('adults');
    const iChildren = col('children');
    const iPin      = col('securitypin');
    const iNotes    = col('notes');

    if (iName === -1) {
      return res.status(400).json({ error: 'CSV is missing required column: guestName' });
    }
    if (iEmail === -1) {
      return res.status(400).json({ error: 'CSV is missing required column: guestEmail' });
    }

    // Pre-load existing emails for this event to detect duplicates
    const existing = await Invite.find({ eventId: req.params.eventId }).select('guestEmail').lean();
    const existingEmails = new Set(existing.map(i => (i.guestEmail || '').toLowerCase().trim()));

    // Track emails added in this batch to catch in-batch duplicates
    const batchEmails = new Set();

    const VALID_ROLES = new Set(['GUEST', 'VIP', 'SPEAKER']);
    const EMAIL_RE    = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    let imported = 0;
    let skipped  = 0;
    const errors = [];

    for (let i = 1; i < lines.length; i++) {
      const rowNum = i + 1; // 1-based, header = row 1
      const cells  = parseLine(lines[i]);

      const guestName  = (cells[iName]  || '').trim();
      const guestEmail = (cells[iEmail] || '').trim();
      const roleRaw    = (cells[iRole]  || '').trim().toUpperCase();
      const guestRole  = VALID_ROLES.has(roleRaw) ? roleRaw : 'GUEST';
      const adults     = Math.max(0, parseInt(cells[iAdults],   10) || 0) || 1; // default 1
      const children   = Math.max(0, parseInt(cells[iChildren], 10) || 0);
      const securityPin = iPin   !== -1 ? (cells[iPin]   || '').trim().slice(0, 6) : '';
      const notes       = iNotes !== -1 ? (cells[iNotes] || '').trim().slice(0, 500) : '';

      // ── Validation ────────────────────────────────────────────────────────
      if (!guestName) {
        errors.push({ row: rowNum, guestName: guestName || '(empty)', reason: 'guestName is required' });
        skipped++;
        continue;
      }
      if (guestName.length > 100) {
        errors.push({ row: rowNum, guestName, reason: 'guestName exceeds 100 characters' });
        skipped++;
        continue;
      }
      if (!guestEmail) {
        errors.push({ row: rowNum, guestName, reason: 'guestEmail is required' });
        skipped++;
        continue;
      }
      if (!EMAIL_RE.test(guestEmail)) {
        errors.push({ row: rowNum, guestName, reason: `Invalid email address: ${guestEmail}` });
        skipped++;
        continue;
      }

      const emailKey = guestEmail.toLowerCase();

      if (existingEmails.has(emailKey)) {
        errors.push({ row: rowNum, guestName, reason: `${guestEmail} already has an invite for this event` });
        skipped++;
        continue;
      }
      if (batchEmails.has(emailKey)) {
        errors.push({ row: rowNum, guestName, reason: `Duplicate email in this import: ${guestEmail}` });
        skipped++;
        continue;
      }

      // ── Create invite ─────────────────────────────────────────────────────
      const inviteCode = generateInviteCode();
      await Invite.create({
        eventId:     req.params.eventId,
        inviteCode,
        guestName,
        guestEmail,
        guestPhone:  '',
        guestRole,
        adults,
        children,
        groupSize:   adults + children,
        plusOnes:    0,
        securityPin,
        notes,
      });

      existingEmails.add(emailKey);
      batchEmails.add(emailKey);
      imported++;
    }

    res.status(201).json({ imported, skipped, errors });
  } catch (error) {
    next(error);
  }
});

// Get all invites for event
router.get('/:eventId/invites', verifyCheckinAccess, async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const invites = await Invite.find({ eventId: req.params.eventId }).sort({ createdAt: -1 });
    res.json({ invites });
  } catch (error) { next(error); }
});

router.post('/:eventId/invites/:inviteCode/rsvp', async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const { status } = req.body;

    // ── Normalise and validate the incoming status ─────────────────────────
    // GuestInvite.jsx sends 'yes'/'maybe'/'no'; the model stores
    // 'confirmed'/'maybe'/'declined'.  Accept both conventions.
    const normalise = { yes: 'confirmed', confirmed: 'confirmed',
                        no: 'declined',   declined:  'declined',
                        maybe: 'maybe' };
    const normalisedStatus = normalise[status];
    if (!normalisedStatus) {
      return res.status(400).json({ error: 'Invalid RSVP response. Choose "Going", "Maybe", or "Can\'t make it".' });
    }

    // ── Load invite ────────────────────────────────────────────────────────
    const invite = await Invite.findOne({
      eventId:    req.params.eventId,
      inviteCode: req.params.inviteCode,
    });
    if (!invite) return res.status(404).json({ error: 'Invite not found' });

    // ── Load event settings ────────────────────────────────────────────────
    const event = await Event.findById(req.params.eventId).select('settings').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const settings = event.settings || {};

    // ── Enforce rsvpEnabled ────────────────────────────────────────────────
    if (settings.rsvpEnabled === false) {
      return res.status(403).json({ error: 'RSVPs are not enabled for this event.' });
    }

    // ── Enforce rsvpDeadline ───────────────────────────────────────────────
    if (settings.rsvpDeadline && new Date() > new Date(settings.rsvpDeadline)) {
      const fmt = new Date(settings.rsvpDeadline).toLocaleDateString('en-US', {
        month: 'long', day: 'numeric', year: 'numeric',
      });
      return res.status(403).json({
        error: `The RSVP deadline passed on ${fmt}. No further changes can be made.`,
        deadline: settings.rsvpDeadline,
        deadlinePast: true,
      });
    }

    // ── Enforce rsvpAllowMaybe ─────────────────────────────────────────────
    if (normalisedStatus === 'maybe' && settings.rsvpAllowMaybe === false) {
      return res.status(400).json({ error: '"Maybe" responses are not allowed for this event. Please choose Going or Can\'t make it.' });
    }

    invite.status = normalisedStatus;
    await invite.save();

    res.json({ message: 'RSVP updated', invite });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════
// SECURE CHECK-IN SYSTEM
// ═══════════════════════════════════════════════════════════════════════════

// STEP 1: Scan / lookup — returns full guest profile WITHOUT committing check-in
// Used by scanner UI to show the "boarding pass" before staff taps Admit
const {
  detectDuplicates,
  preventReentrancy,
  detectSuspiciousPatterns,
  enforceBlocks,
  enforceTimeWindow,
  enforceCapacity,
  auditLog,
} = require('../middleware/antifraud');

router.get('/:eventId/verify-scan/:inviteCode', 
  verifyEventAccess,
  enforceBlocks,           // ✅ Check emergency lockdown, blocks, trust scores
  detectDuplicates,        // ✅ Check for duplicate guests
  detectSuspiciousPatterns, // ✅ Check for rapid scans, multiple devices
  enforceCapacity,         // ✅ Check max attendees limit
  enforceTimeWindow,       // ✅ Check time restrictions
  auditLog,                // ✅ Log all scan attempts
  async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const { eventId, inviteCode } = req.params;
    const ip = realIp(req);
    const staffUser = req.eventAccess?.username || 'staff';

    // ── Cross-event security: invite must belong to THIS event ──
    const invite = await Invite.findOne({ inviteCode: inviteCode.toUpperCase().trim() });

    if (!invite) {
      return res.status(404).json({
        valid: false,
        reason: 'not_found',
        message: 'QR code not recognised. Deny entry.',
      });
    }

    if (invite.eventId.toString() !== eventId) {
      // Log the cross-event attempt on the invite it actually belongs to
      invite.scanAttempts.push({ reason: 'wrong_event', attemptedBy: staffUser, ipAddress: ip });
      await invite.save();
      return res.status(403).json({
        valid: false,
        reason: 'wrong_event',
        message: 'This ticket belongs to a DIFFERENT event. Deny entry.',
      });
    }

    if (invite.checkedIn) {
      invite.scanAttempts.push({ reason: 'already_checked_in', attemptedBy: staffUser, ipAddress: ip });
      await invite.save();

      // Check if this event allows manual override for already-used tickets
      const eventForOverride = await Event.findById(eventId).select('checkinSettings').lean();
      const allowOverride = eventForOverride?.checkinSettings?.allowManualOverride || false;

      return res.status(400).json({
        valid: false,
        reason: 'already_checked_in',
        severity: 'high',
        message: 'This ticket has already been used.',
        displayMessage: 'TICKET ALREADY USED',
        blockedReason: 'already_checked_in',
        inviteCode: invite.inviteCode,
        guestName: invite.guestName,
        groupSize: invite.groupSize,
        checkedInAt: invite.checkedInAt,
        checkedInBy: invite.checkedInBy,
        requiresOverride: allowOverride,
      });
    }

    // Get event checkin settings
    const event = await Event.findById(eventId).select('checkinSettings title').lean();
    const settings = event?.checkinSettings || {};

    // ── Collect security warnings from middleware ──
    const warnings = req.securityWarnings || [];
    const flags = invite.securityFlags || [];
    
    // Calculate trust score
    const trustScore = invite.calculateTrustScore();

    // ── Return the full guest profile for staff to review ──
    res.json({
      valid: true,
      requiresPin: settings.requirePin && !!invite.securityPin,
      guest: {
        id:          invite._id,
        inviteCode:  invite.inviteCode,
        guestName:   invite.guestName,
        guestEmail:  invite.guestEmail,
        guestPhone:  invite.guestPhone,
        adults:      invite.adults,
        children:    invite.children,
        groupSize:   invite.groupSize,
        plusOnes:    invite.plusOnes,
        status:      invite.status,
        notes:       invite.notes,
        tableId:     invite.tableId   || null,
        tableLabel:  invite.tableLabel || null,
        seatNumber:  invite.seatNumber || null,
        tableType:   invite.tableType  || null,
        guestRole:   invite.guestRole  || 'GUEST',
        // Only expose PIN hint — never the actual PIN value over the wire
        hasPin:      !!(invite.securityPin),
      },
      security: {
        trustScore:  trustScore,
        warnings:    warnings,
        flags:       flags,
      },
      event: { title: event?.title },
      staffNote: settings.staffNote || '',
    });
  } catch (error) { next(error); }
});

// STEP 2: Verify PIN (called if requiresPin === true, before committing admission)
router.post('/:eventId/verify-pin/:inviteCode', verifyEventAccess, async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const { eventId, inviteCode } = req.params;
    const { pin } = req.body;
    const ip = realIp(req);
    const staffUser = req.eventAccess?.username || 'staff';

    const invite = await Invite.findOne({ inviteCode: inviteCode.toUpperCase().trim(), eventId });
    if (!invite) return res.status(404).json({ valid: false, message: 'Invite not found.' });

    if (!invite.securityPin || invite.securityPin.trim() === '') {
      return res.json({ valid: true, message: 'No PIN required.' });
    }

    if (!pin || pin.trim() !== invite.securityPin.trim()) {
      invite.scanAttempts.push({ reason: 'wrong_pin', attemptedBy: staffUser, ipAddress: ip });
      await invite.save();

      const event = await Event.findById(eventId).select('checkinSettings').lean();
      const maxAttempts = event?.checkinSettings?.maxFailedAttempts || 3;
      const pinAttempts = invite.scanAttempts.filter(a => a.reason === 'wrong_pin').length;
      const remaining = Math.max(0, maxAttempts - pinAttempts);

      return res.status(401).json({
        valid: false,
        message: remaining > 0
          ? `Incorrect PIN. ${remaining} attempt${remaining !== 1 ? 's' : ''} remaining.`
          : 'PIN locked — too many failed attempts. Escalate to organizer.',
        locked: remaining === 0,
      });
    }

    res.json({ valid: true, message: 'PIN verified.' });
  } catch (error) { next(error); }
});

// STEP 3: Commit check-in — only called after staff reviews profile (and PIN if required)
router.post('/:eventId/checkin/:inviteCode', 
  verifyEventAccess,
  preventReentrancy,  // ✅ Prevent simultaneous check-ins
  async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const { eventId, inviteCode } = req.params;
    const { actualAttendees, pinVerified } = req.body;
    const ip = realIp(req);
    const staffUser = req.eventAccess?.username || 'staff';

    // Re-verify event ownership on commit (belt-and-suspenders)
    const invite = await Invite.findOne({ inviteCode: inviteCode.toUpperCase().trim() });
    if (!invite) return res.status(404).json({ error: 'Invite not found' });

    if (invite.eventId.toString() !== eventId) {
      invite.scanAttempts.push({ reason: 'wrong_event', attemptedBy: staffUser, ipAddress: ip });
      await invite.save();
      return res.status(403).json({ error: 'Cross-event ticket — access denied.' });
    }

    if (invite.checkedIn) {
      return res.status(400).json({
        error: 'Already checked in',
        checkedInAt: invite.checkedInAt,
        checkedInBy: invite.checkedInBy,
      });
    }

    const event = await Event.findById(eventId).select('checkinSettings').lean();
    const settings = event?.checkinSettings || {};

    // If PIN is required and wasn't verified, block commit
    if (settings.requirePin && invite.securityPin && !pinVerified) {
      return res.status(403).json({ error: 'PIN verification required before check-in.' });
    }

    // ✅ FINAL CAPACITY CHECK before committing
    if (settings.enableCapacityLimits && settings.maxTotalAttendees) {
      const checkedInInvites = await Invite.find({ eventId, checkedIn: true });
      const currentAttendees = checkedInInvites.reduce((sum, inv) => sum + (inv.actualAttendees || 0), 0);
      const newTotal = currentAttendees + (actualAttendees || invite.groupSize);
      
      if (newTotal > settings.maxTotalAttendees) {
        return res.status(403).json({
          error: 'Capacity limit reached',
          message: 'Cannot check in - venue at maximum capacity',
          currentCapacity: currentAttendees,
          maxCapacity: settings.maxTotalAttendees
        });
      }
    }

    invite.checkedIn    = true;
    invite.checkedInAt  = new Date();
    invite.checkedInBy  = staffUser;
    invite.status       = 'checked-in';
    invite.actualAttendees = (actualAttendees !== undefined && actualAttendees !== null)
      ? parseInt(actualAttendees)
      : (invite.adults + invite.children) || invite.groupSize;
    
    // Add to check-in history
    invite.checkInHistory.push({
      checkedInAt: new Date(),
      checkedInBy: staffUser,
      actualAttendees: invite.actualAttendees,
    });

    await invite.save();

    // Release reentrancy lock
    if (req.checkInInvite) {
      await req.checkInInvite.releaseCheckInLock();
    }

    const io = req.app.get('io');
    if (io) {
      io.to(`event_${eventId}`).emit('guest_checked_in', {
        inviteCode:       invite.inviteCode,
        guestName:        invite.guestName,
        adults:           invite.adults,
        children:         invite.children,
        actualAttendees:  invite.actualAttendees,
        checkedInAt:      invite.checkedInAt,
      });
    }

    // Fire webhooks non-blocking
    fireWebhooks(eventId, 'checkin', {
      username:       invite.guestName,
      guestName:      invite.guestName,
      inviteCode:     invite.inviteCode,
      actualCount:    invite.actualAttendees,
    }).catch(() => {});

    res.json({
      message: 'Guest checked in successfully',
      invite: {
        id:              invite._id,
        inviteCode:      invite.inviteCode,
        guestName:       invite.guestName,
        adults:          invite.adults,
        children:        invite.children,
        groupSize:       invite.groupSize,
        actualAttendees: invite.actualAttendees,
        checkedInAt:     invite.checkedInAt,
        checkedInBy:     invite.checkedInBy,
        notes:           invite.notes,
      },
    });
  } catch (error) { next(error); }
});

// Get check-in analytics
router.get('/:eventId/checkin-stats', verifyCheckinAccess, async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    const invites = await Invite.find({ eventId: req.params.eventId });

    const total       = invites.length;
    const checkedIn   = invites.filter(i => i.checkedIn).length;
    const pending     = invites.filter(i => i.status === 'pending').length;
    const confirmed   = invites.filter(i => i.status === 'confirmed').length;
    const declined    = invites.filter(i => i.status === 'declined').length;

    const totalExpectedAdults    = invites.reduce((s, i) => s + (i.adults   || 0), 0);
    const totalExpectedChildren  = invites.reduce((s, i) => s + (i.children || 0), 0);
    const totalExpectedAttendees = invites.reduce((s, i) => s + i.groupSize, 0);
    const totalActualAttendees   = invites.reduce((s, i) => s + i.actualAttendees, 0);
    const totalFailedScans       = invites.reduce((s, i) => s + i.scanAttempts.length, 0);

    res.json({
      stats: {
        total, checkedIn, pending, confirmed, declined,
        noShow: Math.max(0, confirmed - checkedIn),
        totalExpectedAdults,
        totalExpectedChildren,
        totalExpectedAttendees,
        totalActualAttendees,
        totalFailedScans,
      }
    });
  } catch (error) { next(error); }
});

// Get / update checkin security settings (organizer only)
router.get('/:eventId/checkin-settings', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId).select('checkinSettings').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    res.json({ settings: event.checkinSettings || {} });
  } catch (error) { next(error); }
});

router.patch('/:eventId/checkin-settings', verifyOrganizer, async (req, res, next) => {
  try {
    // ══════════════════════════════════════════════════════════════════
    // COMPREHENSIVE SECURITY SETTINGS - CORRECT MIDDLEWARE NAMES
    // ══════════════════════════════════════════════════════════════════
    const allowed = [
      // General Security
      'requirePin',
      'requireCodeConfirm',
      'blockCrossEvent',
      'maxFailedAttempts',
      'lockoutMinutes',
      'allowManualOverride',
      'staffNote',
      
      // Duplicate Prevention - ✅ CORRECT NAMES
      'enableDuplicateDetection',
      'duplicateDetectionMode',
      'autoBlockDuplicates',
      'allowMultipleTickets',
      
      // Pattern Detection - ✅ CORRECT NAMES
      'enablePatternDetection',
      'rapidScanThreshold',
      'rapidScanWindowSeconds',
      'multiDeviceThreshold',
      
      // Trust Scoring - ✅ CORRECT NAMES
      'enableTrustScore',
      'minimumTrustScore',
      'autoBlockLowTrust',
      
      // Reentrancy Protection
      'enableReentrancyProtection',
      
      // Time Restrictions
      'enableTimeRestrictions',
      'checkInWindowStart',
      'checkInWindowEnd',
      'allowLateCheckIn',
      
      // Advanced Settings
      'detailedAuditLogging',
      'logIPAddresses',
      'logDeviceInfo',
      'enableCapacityLimits',
      'maxTotalAttendees',
      
      // Emergency Controls
      'emergencyLockdown',
      'emergencyLockdownReason',
      'emergencyLockdownAt',
    ];
    
    console.log('[SETTINGS] Incoming request body:', req.body);
    
    const updates = {};
    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        updates[`checkinSettings.${key}`] = req.body[key];
      }
    }
    
    console.log('[SETTINGS] Updates to apply:', updates);
    
    const event = await Event.findByIdAndUpdate(
      req.params.eventId, 
      { $set: updates }, 
      { new: true, runValidators: false }
    ).select('checkinSettings');
    
    if (!event) return res.status(404).json({ error: 'Event not found' });
    
    console.log('[SETTINGS] Saved settings:', event.checkinSettings);
    
    res.json({ settings: event.checkinSettings });
  } catch (error) { 
    console.error('[SETTINGS] Error saving:', error);
    next(error); 
  }
});

router.put('/:eventId/invites/:inviteId', verifyOrganizer, 
  [
    body('guestName').optional().trim().isLength({ min: 1, max: 100 }),
    body('guestEmail').optional().isEmail(),
    body('guestPhone').optional().trim(),
    body('guestRole').optional().isIn(['GUEST', 'VIP', 'SPEAKER']),
    body('adults').optional().isInt({ min: 0 }),
    body('children').optional().isInt({ min: 0 }),
    body('groupSize').optional().isInt({ min: 1 }),
    body('plusOnes').optional().isInt({ min: 0 }),
    body('securityPin').optional().trim().isLength({ max: 6 }),
    body('notes').optional().trim(),
    body('seatNumber').optional({ nullable: true }).isString().isLength({ max: 20 }),
    validate
  ],
  async (req, res, next) => {
    try {
      const Invite = require('../models/Invite');
      const { inviteId, eventId } = req.params;
      
      // Verify invite belongs to this event
      const invite = await Invite.findById(inviteId);
      if (!invite) {
        return res.status(404).json({ error: 'Invite not found' });
      }
      
      if (invite.eventId.toString() !== eventId) {
        return res.status(403).json({ error: 'Invite does not belong to this event' });
      }
      
      // Don't allow updating checked-in invites
      if (invite.checkedIn) {
        return res.status(400).json({ error: 'Cannot update checked-in invite' });
      }
      
      // Update fields — guestRole IS included so VIP/SPEAKER assignments save correctly
      const allowedFields = ['guestName', 'guestEmail', 'guestPhone', 'guestRole', 'adults', 'children', 'groupSize', 'plusOnes', 'securityPin', 'notes', 'seatNumber'];
      const updates = {};
      
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          updates[field] = req.body[field];
        }
      }
      
      // Recalculate groupSize if adults or children changed
      if (updates.adults !== undefined || updates.children !== undefined) {
        const adults = updates.adults !== undefined ? parseInt(updates.adults) : invite.adults;
        const children = updates.children !== undefined ? parseInt(updates.children) : invite.children;
        updates.groupSize = adults + children;
      }
      
      Object.assign(invite, updates);
      await invite.save();
      
      res.json({ 
        message: 'Invite updated successfully', 
        invite 
      });
    } catch (error) { 
      next(error); 
    }
  }
);





// Delete invite
router.delete('/:eventId/invites/:inviteId', verifyOrganizer, async (req, res, next) => {
  try {
    const Invite = require('../models/Invite');
    await Invite.findByIdAndDelete(req.params.inviteId);
    res.json({ message: 'Invite deleted' });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════
// STAFF CHECK-IN ACCOUNTS
// Organizers create staff accounts with PINs; staff use them to log into
// the check-in page without getting full organizer privileges.
// ═══════════════════════════════════════════════════════════════════════════

// POST /:eventId/staff-login  — public, no auth, used on check-in login screen
router.post('/:eventId/staff-login', authLimiter, async (req, res, next) => {
  try {
    const { eventId } = req.params;
    const { username, pin } = req.body;

    if (!username || !pin) {
      return res.status(400).json({ error: 'Username and PIN are required' });
    }

    const staff = await EventParticipant
      .findOne({ eventId, username: username.trim(), role: 'staff' })
      .select('+password');

    if (!staff || !staff.password) {
      return res.status(401).json({ error: 'Invalid username or PIN' });
    }

    const valid = await bcrypt.compare(String(pin), staff.password);
    if (!valid) {
      console.log(`[STAFF-LOGIN] Failed attempt: ${username} for event ${eventId}`);
      return res.status(401).json({ error: 'Invalid username or PIN' });
    }

    await EventParticipant.updateOne({ _id: staff._id }, { $set: { lastSeenAt: new Date() } });

    const token = jwt.sign(
      { eventId: eventId.toString(), username: staff.username, role: 'staff' },
      secrets.jwt,
      { expiresIn: '12h' }
    );

    console.log(`[STAFF-LOGIN] Success: ${username} for event ${eventId}`);
    res.json({ success: true, token, username: staff.username, role: 'staff' });

  } catch (error) {
    next(error);
  }
});

// GET /:eventId/staff — list all staff accounts (organizer only)
router.get('/:eventId/staff', verifyOrganizer, async (req, res, next) => {
  try {
    const staff = await EventParticipant
      .find({ eventId: req.params.eventId, role: 'staff' })
      .select('username hasPassword createdAt lastSeenAt')
      .sort({ createdAt: -1 });

    res.json({ staff });
  } catch (error) { next(error); }
});

// POST /:eventId/staff — create a staff account (organizer only)
router.post('/:eventId/staff', verifyOrganizer, async (req, res, next) => {
  try {
    const { eventId } = req.params;
    const { username, pin } = req.body;

    if (!username || !username.trim()) {
      return res.status(400).json({ error: 'Username is required' });
    }
    if (!pin || String(pin).length < 4 || String(pin).length > 8) {
      return res.status(400).json({ error: 'PIN must be 4–8 digits' });
    }
    if (!/^\d+$/.test(String(pin))) {
      return res.status(400).json({ error: 'PIN must contain only numbers' });
    }

    // Prevent duplicate username within this event (any role)
    const existing = await EventParticipant.findOne({ eventId, username: username.trim(), role: 'staff' });
    if (existing) {
      return res.status(409).json({ error: 'A staff account with that username already exists for this event' });
    }

    const hashed = await bcrypt.hash(String(pin), 10);
    const staff = await EventParticipant.create({
      eventId,
      username: username.trim(),
      password: hashed,
      hasPassword: true,
      role: 'staff',
    });

    console.log(`[STAFF] Created staff account: ${username} for event ${eventId}`);
    res.status(201).json({
      success: true,
      staff: { username: staff.username, createdAt: staff.createdAt }
    });

  } catch (error) {
    next(error);
  }
});

// DELETE /:eventId/staff/:username — remove a staff account (organizer only)
router.delete('/:eventId/staff/:staffUsername', verifyOrganizer, async (req, res, next) => {
  try {
    const { eventId, staffUsername } = req.params;
    const deleted = await EventParticipant.findOneAndDelete({ eventId, username: staffUsername, role: 'staff' });
    if (!deleted) {
      return res.status(404).json({ error: 'Staff account not found' });
    }
    res.json({ success: true, message: 'Staff account removed' });
  } catch (error) { next(error); }
});

// PATCH /:eventId/staff/:username/pin — update staff PIN (organizer only)
router.patch('/:eventId/staff/:staffUsername/pin', verifyOrganizer, async (req, res, next) => {
  try {
    const { eventId, staffUsername } = req.params;
    const { pin } = req.body;

    if (!pin || String(pin).length < 4 || String(pin).length > 8 || !/^\d+$/.test(String(pin))) {
      return res.status(400).json({ error: 'PIN must be 4–8 digits' });
    }

    const staff = await EventParticipant.findOne({ eventId, username: staffUsername, role: 'staff' });
    if (!staff) {
      return res.status(404).json({ error: 'Staff account not found' });
    }

    staff.password = await bcrypt.hash(String(pin), 10);
    staff.hasPassword = true;
    await staff.save();

    res.json({ success: true, message: 'PIN updated' });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════
// BRANDED QR CODE
// ═══════════════════════════════════════════════════════════════════════════

// GET /:eventId/qr.svg — no auth required, encodes the public join URL
router.get('/:eventId/qr.svg', async (req, res, next) => {
  try {
    const QRCode = require('qrcode');
    const event = await Event.findById(req.params.eventId).select('title subdomain').lean();
    if (!event) return res.status(404).send('Event not found');

    const protocol = process.env.NODE_ENV === 'production' ? 'https' : req.protocol;
    const host = process.env.BASE_DOMAIN || req.get('host');
    const joinUrl = `${protocol}://${host}/event/${req.params.eventId}`;

    // Clean QR — NO overlay on the QR modules. BarcodeDetector (used by
    // html5-qrcode) rejects any QR with pixels painted over it, including
    // the previously used centre logo. PLANIT branding goes BELOW the QR.
    // Using level M (15%) is sufficient; H was only needed for the overlay.
    const dataUrl = await QRCode.toDataURL(joinUrl, {
      width: 260,
      margin: 2,
      color: { dark: '#000000', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    });

    const safeTitle = event.title.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').slice(0, 32);

    // Card dimensions — same proportions as the invite QR card
    const W = 300, H = 400;
    const QX = 20, QY = 20, QS = 260;

    const svg = `<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
  <defs>
    <filter id="glow" x="-5%" y="-5%" width="110%" height="110%">
      <feDropShadow dx="0" dy="4" stdDeviation="10" flood-color="#000" flood-opacity="0.55"/>
    </filter>
    <clipPath id="qrclip">
      <rect x="${QX}" y="${QY}" width="${QS}" height="${QS}" rx="10"/>
    </clipPath>
  </defs>

  <!-- Dark card -->
  <rect width="${W}" height="${H}" rx="20" fill="#0a0a0a" filter="url(#glow)"/>

  <!-- White QR backing (no overlay on top of QR modules) -->
  <rect x="${QX - 4}" y="${QY - 4}" width="${QS + 8}" height="${QS + 8}" rx="14" fill="#ffffff"/>

  <!-- Clean QR — nothing painted on top -->
  <image x="${QX}" y="${QY}" width="${QS}" height="${QS}"
         href="${dataUrl}" clip-path="url(#qrclip)"/>

  <!-- Divider -->
  <line x1="20" y1="${QY + QS + 18}" x2="${W - 20}" y2="${QY + QS + 18}"
        stroke="#1f1f1f" stroke-width="1"/>

  <!-- PLANIT brand -->
  <text x="${W / 2}" y="${QY + QS + 40}" text-anchor="middle"
        fill="#ffffff"
        font-family="system-ui,-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"
        font-size="13" font-weight="800" letter-spacing="5">PLANIT</text>

  <!-- Event title -->
  <text x="${W / 2}" y="${QY + QS + 62}" text-anchor="middle"
        fill="#e5e5e5"
        font-family="system-ui,-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"
        font-size="12" font-weight="600">${safeTitle}</text>

  <!-- Sub-label -->
  <text x="${W / 2}" y="${QY + QS + 82}" text-anchor="middle"
        fill="#555555"
        font-family="system-ui,-apple-system,'Segoe UI',Helvetica,Arial,sans-serif"
        font-size="10" letter-spacing="1.5">SCAN TO JOIN</text>
</svg>`;

    res.setHeader('Content-Type', 'image/svg+xml');
    res.setHeader('Cache-Control', 'public, max-age=3600');
    res.send(svg);
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════
// WAITLIST
// ═══════════════════════════════════════════════════════════════════════════

// POST /:eventId/waitlist — join the waitlist when event is full
router.post('/:eventId/waitlist',
  [body('username').trim().isLength({ min: 1, max: 100 }), body('email').optional().isEmail(), validate],
  async (req, res, next) => {
    try {
      const event = await Event.findById(req.params.eventId);
      if (!event) return res.status(404).json({ error: 'Event not found' });

      // Only allow if event is actually full
      if (event.participants.length < event.maxParticipants) {
        return res.status(400).json({ error: 'Event is not full — join directly instead' });
      }

      const { username, email } = req.body;
      const alreadyOn = event.waitlist.some(w => w.username.toLowerCase() === username.toLowerCase());
      if (alreadyOn) return res.status(409).json({ error: 'Already on the waitlist' });

      const alreadyIn = event.participants.some(p => p.username.toLowerCase() === username.toLowerCase());
      if (alreadyIn) return res.status(400).json({ error: 'Already a participant' });

      event.waitlist.push({ username, email: email || '' });
      await event.save();

      res.status(201).json({
        message: 'Added to waitlist',
        position: event.waitlist.length,
      });
    } catch (error) { next(error); }
  }
);

// GET /:eventId/waitlist — organizer only
router.get('/:eventId/waitlist', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId).select('waitlist').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    res.json({ waitlist: event.waitlist || [], count: (event.waitlist || []).length });
  } catch (error) { next(error); }
});

// DELETE /:eventId/waitlist/:username — leave the waitlist
router.delete('/:eventId/waitlist/:username', async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    event.waitlist = event.waitlist.filter(w => w.username !== req.params.username);
    await event.save();
    res.json({ message: 'Removed from waitlist' });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════
// CLONE EVENT — copy an event's setup to new dates + slugs
//
//   • Works for standard, enterprise and RSVP-only events. Table service is refused.
//   • Each source event gets EVENT_CLONE_LIMIT clone uses in total (default 2).
//     One use = one new event, so a single request may create up to the number
//     of uses still remaining.
//   • The organizer picks the date and the slug for every clone.
//   • Copies setup only (settings, agenda, checklist, seating map, check-in
//     rules, RSVP page + builder layout, theme). It never copies guests, RSVPs,
//     invites, chat, files, polls, expenses, notes, webhooks or OAuth tokens.
// ═══════════════════════════════════════════════════════════════════════════

const CLONE_LIMIT = Math.max(1, parseInt(process.env.EVENT_CLONE_LIMIT || '2', 10) || 2);

// Failed attempts (bad slug, taken slug) don't count against the hourly cap.
const cloneLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  keyGenerator: realIp,
  skipFailedRequests: true,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many clones, please try again later.' },
});

const stripIds = (arr) => (Array.isArray(arr) ? arr : []).map((row) => {
  const { _id, ...rest } = row || {};
  return rest;
});

// How many clone uses are left for this event.
router.get('/:eventId/clone-info', verifyOrganizer, async (req, res, next) => {
  try {
    const src = await Event.findById(req.params.eventId).select('cloneCount isTableServiceMode clonedFrom').lean();
    if (!src) return res.status(404).json({ error: 'Event not found' });
    const isClone = !!src.clonedFrom;
    const canClone = !src.isTableServiceMode && !isClone;
    const used = Math.min(src.cloneCount || 0, CLONE_LIMIT);
    res.json({
      allowed:   canClone,
      isClone,
      used,
      limit:     CLONE_LIMIT,
      remaining: canClone ? Math.max(0, CLONE_LIMIT - used) : 0,
    });
  } catch (error) { next(error); }
});

router.post('/:eventId/clone', verifyOrganizer, cloneLimiter, async (req, res, next) => {
  let reserved = 0; // uses taken from the source event's quota
  let sourceId = null;
  try {
    const source = await Event.findById(req.params.eventId)
      .select('+password +rsvpPage.rsvpPassword').lean();
    if (!source) return res.status(404).json({ error: 'Event not found' });
    sourceId = source._id;

    // A cloned event can't be cloned again — only the original event can make clones.
    if (source.clonedFrom) {
      return res.status(403).json({ error: 'This event is itself a clone, so it can\'t be cloned again. Clone the original event instead.' });
    }

    if (source.isTableServiceMode) {
      return res.status(400).json({ error: 'Table service events can\'t be cloned.' });
    }

    // ── Organizer login for the new event(s) ─────────────────────────────────
    const cloneUsername = String(req.body.username || '').trim();
    const clonePassword = String(req.body.accountPassword || '');
    if (!cloneUsername || cloneUsername.length > 100) {
      return res.status(400).json({ error: 'Enter a username for the new event.' });
    }
    if (clonePassword.length < 4) {
      return res.status(400).json({ error: 'Password must be at least 4 characters.' });
    }
    const nameBanned = await Blocklist.findOne({
      type: 'name',
      value: { $regex: new RegExp(`^${cloneUsername.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, 'i') },
      $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }],
    }).lean();
    if (nameBanned) return res.status(403).json({ error: 'This username is not allowed.' });

    // ── Read + validate the requested clones ─────────────────────────────────
    let requested = Array.isArray(req.body.clones) ? req.body.clones : null;
    if (!requested && req.body.date) {
      // Legacy single-clone body: { date, title } — slug is generated.
      requested = [{ date: req.body.date, title: req.body.title, subdomain: null }];
    }
    if (!requested || requested.length === 0) {
      return res.status(400).json({ error: 'Add at least one date and slug.' });
    }
    if (requested.length > CLONE_LIMIT) {
      return res.status(400).json({ error: `You can create at most ${CLONE_LIMIT} clones of an event.` });
    }

    const now = Date.now();
    const seen = new Set();
    const clean = [];
    for (let i = 0; i < requested.length; i++) {
      const r = requested[i] || {};
      const label = requested.length > 1 ? ` (clone ${i + 1})` : '';

      const when = new Date(r.date);
      if (!r.date || Number.isNaN(when.getTime())) {
        return res.status(400).json({ error: `Enter a valid date${label}.` });
      }
      if (when.getTime() < now - 60 * 60 * 1000) {
        return res.status(400).json({ error: `Pick a date in the future${label}.` });
      }

      let slug = r.subdomain == null ? null : String(r.subdomain).trim().toLowerCase();
      if (slug === null) {
        slug = `${source.subdomain.replace(/-\d+$/, '')}-${Date.now().toString(36)}${i}`.slice(0, 50);
      }
      if (!/^[a-z0-9-]+$/.test(slug) || slug.length < 3 || slug.length > 50) {
        return res.status(400).json({ error: `Slug must be 3–50 characters: lowercase letters, numbers and dashes${label}.` });
      }
      if (seen.has(slug)) {
        return res.status(400).json({ error: `Each clone needs its own slug ("${slug}" is used twice).` });
      }
      seen.add(slug);

      const title = String(r.title || '').trim().slice(0, 200);
      clean.push({ slug, when, title });
    }

    // Slugs must be free and not banned.
    const slugs = clean.map((c) => c.slug);
    const [taken, banned] = await Promise.all([
      Event.find({ subdomain: { $in: slugs } }).select('subdomain').lean(),
      Blocklist.find({
        type: 'event', value: { $in: slugs },
        $or: [{ expiresAt: null }, { expiresAt: { $gt: new Date() } }],
      }).select('value').lean(),
    ]);
    if (taken.length) {
      return res.status(409).json({ error: `The slug "${taken[0].subdomain}" is already taken.`, field: 'subdomain', slug: taken[0].subdomain });
    }
    if (banned.length) {
      return res.status(403).json({ error: `The slug "${banned[0].value}" isn't available.`, field: 'subdomain', slug: banned[0].value });
    }

    // ── Reserve quota atomically (two tabs can't both use the last slot) ──────
    const n = clean.length;
    const held = await Event.findOneAndUpdate(
      { _id: source._id, cloneCount: { $not: { $gt: CLONE_LIMIT - n } } },
      { $inc: { cloneCount: n } },
      { new: true }
    ).select('cloneCount').lean();
    if (!held) {
      const cur = await Event.findById(source._id).select('cloneCount').lean();
      const used = Math.min(cur?.cloneCount || 0, CLONE_LIMIT);
      return res.status(403).json({
        error: used >= CLONE_LIMIT
          ? `This event has used all ${CLONE_LIMIT} of its clones.`
          : `Only ${CLONE_LIMIT - used} clone${CLONE_LIMIT - used === 1 ? '' : 's'} left for this event.`,
        used, limit: CLONE_LIMIT, remaining: Math.max(0, CLONE_LIMIT - used),
      });
    }
    reserved = n;

    // ── Build the clones ─────────────────────────────────────────────────────
    // One fresh organizer login (the username + password the person just typed),
    // shared by every clone made in this request. Hashed once here.
    const accountHash  = await bcrypt.hash(clonePassword, 10);
    const recoveryCode = Array.from({ length: 5 }, () => crypto.randomBytes(2).toString('hex').toUpperCase()).join('-');
    const recoveryHash = await bcrypt.hash(recoveryCode.replace(/-/g, '').toLowerCase(), 10);

    const ip = realIp(req);
    const ua = (req.headers['user-agent'] || '').slice(0, 500);
    const fingerprint = crypto.createHash('sha256').update(`${ip}::${ua}`).digest('hex').slice(0, 32);

    const created = [];
    const failed  = [];

    for (const c of clean) {
      try {
        // Keep relative deadlines (RSVP deadline, task due dates) the same distance from the event.
        const delta = source.date ? c.when.getTime() - new Date(source.date).getTime() : null;
        const shift = (d) => (d && delta !== null ? new Date(new Date(d).getTime() + delta) : null);

        const rsvpPage = source.rsvpPage ? { ...source.rsvpPage } : undefined;
        if (rsvpPage) {
          delete rsvpPage.gmailAuth;            // OAuth tokens never travel
          rsvpPage.deadline  = shift(rsvpPage.deadline);
          rsvpPage.updatedAt = null;
          rsvpPage.updatedBy = null;
        }
        const rsvpPageConfig = source.rsvpPageConfig
          ? { ...source.rsvpPageConfig, updatedAt: null, updatedBy: null }
          : undefined;

        const checkinSettings = { ...(source.checkinSettings || {}) };
        checkinSettings.emergencyLockdown = false;
        delete checkinSettings.emergencyLockdownReason;
        delete checkinSettings.emergencyLockdownBy;
        delete checkinSettings.emergencyLockdownAt;

        const clone = new Event({
          subdomain:           c.slug,
          title:               c.title || source.title,
          description:         source.description,
          date:                c.when,
          timezone:            source.timezone,
          location:            source.location,
          organizerName:       cloneUsername,
          organizerEmail:      source.organizerEmail,
          wlDomain:            source.wlDomain || null,
          password:            source.password,
          isPasswordProtected: source.isPasswordProtected,
          maxParticipants:     source.maxParticipants,
          isEnterpriseMode:    !!source.isEnterpriseMode,
          isTableServiceMode:  false,
          eventType:           source.eventType || 'standard',
          checkinSettings,
          seatingMap: source.seatingMap
            ? { ...source.seatingMap, updatedAt: null, updatedBy: null }
            : undefined,
          settings: { ...(source.settings || {}), rsvpDeadline: shift(source.settings?.rsvpDeadline) },
          agenda:   stripIds(source.agenda),
          tasks:    stripIds(source.tasks).map((t) => ({
            ...t, completed: false, completedBy: undefined, completedAt: undefined,
            dueDate: shift(t.dueDate) || undefined, createdAt: new Date(),
          })),
          budget:          source.budget || 0,
          coverImage:      source.coverImage || null,
          themeColor:      source.themeColor || null,
          tags:            source.tags || [],
          dataRetentionDays: source.dataRetentionDays,
          ...(rsvpPage ? { rsvpPage } : {}),
          ...(rsvpPageConfig ? { rsvpPageConfig } : {}),
          status:       'active',
          clonedFrom:   source._id,
          participants: [{ username: cloneUsername, role: 'organizer' }],
          creatorIp: ip, creatorUserAgent: ua, creatorFingerprint: fingerprint,
        });
        await clone.save();

        // Organizer login for the clone: the username + password entered in the clone form.
        await EventParticipant.create({
          eventId:  clone._id,
          username: cloneUsername,
          role:     'organizer',
          password: accountHash,
          hasPassword: true,
          recoveryCodeHash: recoveryHash,
          recoveryCodeGeneratedAt: new Date(),
        });

        created.push({
          id: clone._id, subdomain: clone.subdomain, title: clone.title,
          date: clone.date, eventType: clone.eventType, isEnterpriseMode: clone.isEnterpriseMode,
        });
      } catch (err) {
        failed.push({ subdomain: c.slug, error: err?.code === 11000 ? 'Slug already taken.' : 'Could not create this clone.' });
        console.error('[clone] failed for', c.slug, err?.message || err);
      }
    }

    // Give back the uses for clones that never got created.
    if (failed.length) {
      await Event.updateOne({ _id: source._id }, { $inc: { cloneCount: -failed.length } }).catch(() => {});
      reserved -= failed.length;
    }
    if (!created.length) {
      return res.status(409).json({ error: failed[0]?.error || 'Clone failed.', failed });
    }

    const used = Math.min((held.cloneCount || 0) - failed.length, CLONE_LIMIT);
    res.status(201).json({
      message: created.length > 1 ? 'Events cloned successfully' : 'Event cloned successfully',
      events:  created,
      event:   created[0],
      failed,
      recoveryCode,   // shown once; only the hash is stored
      clone:   { used, limit: CLONE_LIMIT, remaining: Math.max(0, CLONE_LIMIT - used) },
    });
  } catch (error) {
    // Unexpected error before/while creating: return anything still held.
    if (reserved > 0 && sourceId) {
      await Event.updateOne({ _id: sourceId }, { $inc: { cloneCount: -reserved } }).catch(() => {});
    }
    next(error);
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// WEBHOOKS
// ═══════════════════════════════════════════════════════════════════════════

// Utility: fire all active webhooks for a given event + event type
async function fireWebhooks(eventId, eventType, payload) {
  try {
    const crypto = require('crypto');
    const event = await Event.findById(eventId)
      .select('webhooks title subdomain organizerName date location status maxParticipants participants settings')
      .lean();
    if (!event || !event.webhooks?.length) return;

    const active = event.webhooks.filter(wh => wh.active && wh.events.includes(eventType));
    if (!active.length) return;

    const body = JSON.stringify({
      event:     eventType,
      eventId:   eventId.toString(),
      eventName: event.title,
      subdomain: event.subdomain,
      timestamp: new Date().toISOString(),
      data:      payload,
    });

    const isDiscordUrl = (url) => url.toLowerCase().includes('discord.com/api/webhooks/');
    const isSlackUrl   = (url) => url.toLowerCase().includes('hooks.slack.com');

    const titleMap = {
      participant_joined: 'New participant joined',
      rsvp_updated:       'RSVP updated',
      checkin:            'Guest checked in',
      message_sent:       'New message',
    };

    // Build a Discord embed. ALL field values must be non-empty strings — Discord
    // rejects the entire embed with 400 if any field is missing its value.
    const safeStr = (v, fallback = 'N/A') => (v !== undefined && v !== null && String(v).trim() !== '') ? String(v) : fallback;

    // BUG FIX: builders now return a plain JS object, NOT a JSON string.
    // Previously they returned JSON.stringify(...) which axios then serialised
    // again, producing double-encoded JSON. Discord received a string literal
    // instead of an object and showed an empty message body.
    const buildDiscordPayload = (evType, planItPayload, eventName) => {
      const parsed = JSON.parse(planItPayload);
      const colorMap = {
        participant_joined: 0x10b981,
        rsvp_updated:       0x3b82f6,
        checkin:            0x6366f1,
        message_sent:       0x8b5cf6,
      };

      const d = parsed.data || {};
      let description = '';
      if (evType === 'message_sent' && d.message) {
        description = `**${safeStr(d.username, 'Someone')}:** ${String(d.message).slice(0, 500)}`;
      } else if (evType === 'participant_joined' && d.username) {
        description = `**${d.username}** joined the event.`;
      } else if (evType === 'rsvp_updated' && d.username) {
        description = `**${d.username}** responded: **${safeStr(d.rsvp)}**`;
      } else if (evType === 'checkin' && d.guestName) {
        description = `**${d.guestName}** checked in.`;
      }

      const fields = [];
      if (parsed.data?.username)                    fields.push({ name: 'Participant', value: safeStr(parsed.data.username),                inline: true });
      if (parsed.data?.rsvp)                        fields.push({ name: 'RSVP',        value: safeStr(parsed.data.rsvp),                   inline: true });
      if (parsed.data?.message)                     fields.push({ name: 'Message',     value: safeStr(parsed.data.message).slice(0, 1024), inline: false });
      if (parsed.data?.actualCount !== undefined)   fields.push({ name: 'Attendees',   value: safeStr(parsed.data.actualCount, '0'),        inline: true });
      if (parsed.data?.guestName && parsed.data.guestName !== parsed.data.username)
                                                    fields.push({ name: 'Guest',       value: safeStr(parsed.data.guestName),              inline: true });
      if (parsed.data?.inviteCode)                  fields.push({ name: 'Invite',      value: safeStr(parsed.data.inviteCode),             inline: true });
      fields.push({ name: 'Event', value: safeStr(eventName, 'PlanIt Event'), inline: true });
      fields.push({ name: 'Time',  value: new Date(parsed.timestamp).toLocaleString(), inline: true });

      const embed = {
        title:     titleMap[evType] || evType,
        color:     colorMap[evType] || 0x6366f1,
        fields,
        footer:    { text: 'PlanIt' },
        timestamp: parsed.timestamp,
      };
      if (description) embed.description = description;

      // Top-level `content` is the plain text Discord shows as the message body.
      // Without it the notification preview and message body appear completely blank —
      // the embed description alone is hidden until the user clicks to expand it.
      let topContent = '';
      if (evType === 'message_sent' && d.username && d.message) {
        topContent = `**${safeStr(d.username)}:** ${String(d.message).slice(0, 500)}`;
      } else if (evType === 'participant_joined' && d.username) {
        topContent = `${safeStr(d.username)} joined ${safeStr(eventName)}`;
      } else if (evType === 'rsvp_updated' && d.username) {
        topContent = `${safeStr(d.username)} updated their RSVP: ${safeStr(d.rsvp)}`;
      } else if (evType === 'checkin' && d.guestName) {
        topContent = `${safeStr(d.guestName)} checked in to ${safeStr(eventName)}`;
      }

      // Return plain object — axios handles serialisation
      const out = { embeds: [embed] };
      if (topContent) out.content = topContent;
      return out;
    };

    // Slack incoming webhooks require {"text":"..."} — anything else is silently dropped.
    const buildSlackPayload = (evType, planItPayload, eventName) => {
      const parsed = JSON.parse(planItPayload);
      const d      = parsed.data || {};
      const evLabel = titleMap[evType] || evType;
      let text = `*${evLabel}* — ${eventName}`;
      if (d.username)                  text += `
*Who:* ${d.username}`;
      if (d.rsvp)                      text += `
*RSVP:* ${d.rsvp}`;
      if (d.message)                   text += `
*Message:* ${String(d.message).slice(0, 200)}`;
      if (d.actualCount !== undefined) text += `
*Attendees:* ${d.actualCount}`;
      text += `
_${new Date(parsed.timestamp).toLocaleString()}_`;
      return { text }; // plain object — axios serialises, don't stringify
    };

    for (const wh of active) {
      try {
        const urlLower = wh.url.toLowerCase();
        const discord  = isDiscordUrl(urlLower);
        const slack    = isSlackUrl(urlLower);

        // All three builders now return plain objects — axios serialises them.
        // Generic webhooks receive the raw PlanIt payload parsed back to object.
        const outBody = discord ? buildDiscordPayload(eventType, body, event.title)
                      : slack   ? buildSlackPayload(eventType, body, event.title)
                      : JSON.parse(body);

        const headers = { 'Content-Type': 'application/json' };
        if (!discord && !slack) {
          headers['X-PlanIt-Event']   = eventType;
          headers['X-PlanIt-EventId'] = eventId.toString();
        }
        if (wh.secret && !discord && !slack) {
          const sig = crypto.createHmac('sha256', wh.secret).update(body).digest('hex');
          headers['X-PlanIt-Signature'] = 'sha256=' + sig;
        }
        await axios.post(wh.url, outBody, { headers, timeout: 5000 });
        console.log(`[webhook] Fired ${eventType} → ${discord ? 'discord' : slack ? 'slack' : 'generic'} (${wh._id})`);
      } catch (whErr) {
        const status = whErr.response?.status;
        const detail = whErr.response?.data ? JSON.stringify(whErr.response.data).slice(0, 200) : whErr.message;
        console.error(`[webhook] FAILED ${eventType} → ${wh._id}: HTTP ${status || 'network'} — ${detail}`);
      }
    }
  } catch (_) {}
}

// GET /:eventId/webhooks — list webhooks (organizer only)
router.get('/:eventId/webhooks', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId).select('webhooks').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    // Never expose the secret in list view
    const safe = (event.webhooks || []).map(({ _id, url, events, active, createdAt }) => ({ _id, url, events, active, createdAt }));
    res.json({ webhooks: safe });
  } catch (error) { next(error); }
});

// POST /:eventId/webhooks — create webhook (organizer only)
router.post('/:eventId/webhooks', verifyOrganizer,
  [
    body('url').isURL({ require_protocol: true }).withMessage('Valid URL required'),
    body('events').isArray({ min: 1 }).withMessage('At least one event type required'),
    body('secret').optional().isLength({ max: 200 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const event = await Event.findById(req.params.eventId);
      if (!event) return res.status(404).json({ error: 'Event not found' });

      if ((event.webhooks || []).length >= 5) {
        return res.status(400).json({ error: 'Maximum 5 webhooks per event' });
      }

      const VALID_EVENTS = ['participant_joined', 'rsvp_updated', 'checkin', 'message_sent'];
      const filteredEvents = (req.body.events || []).filter(e => VALID_EVENTS.includes(e));

      event.webhooks.push({
        url:    req.body.url.trim(),
        events: filteredEvents,
        secret: req.body.secret?.trim() || '',
        active: true,
      });

      await event.save();
      const wh = event.webhooks[event.webhooks.length - 1];

      // Send a config confirmation message to the webhook immediately
      try {
        const isDiscord = wh.url.toLowerCase().includes('discord.com/api/webhooks/');
        const isSlack   = wh.url.toLowerCase().includes('hooks.slack.com');
        const triggerLabels = {
          participant_joined: 'Participant joined',
          rsvp_updated: 'RSVP updated',
          checkin: 'Guest checked in',
          message_sent: 'New message sent',
        };
        const triggersText = wh.events.map(e => triggerLabels[e] || e).join(', ');
        const eventDate = event.date ? new Date(event.date).toLocaleString('en-GB', { dateStyle: 'full', timeStyle: 'short', timeZoneName: 'short', timeZone: isValidTimezone(event.timezone) ? event.timezone : 'UTC' }) : 'Not set';
        const participantCount = (event.participants || []).length;
        const maxP = event.maxParticipants || 'Unlimited';

        if (isDiscord) {
          const configPayload = {
            embeds: [{
              title: 'PlanIt Webhook Connected',
              description: 'This channel will now receive live notifications from your PlanIt event.',
              color: 0x10b981,
              fields: [
                { name: 'Event', value: event.title, inline: true },
                { name: 'Subdomain', value: event.subdomain || 'N/A', inline: true },
                { name: 'Status', value: event.status || 'active', inline: true },
                { name: 'Date', value: eventDate, inline: false },
                { name: 'Location', value: event.location || 'Not set', inline: true },
                { name: 'Participants', value: `${participantCount} / ${maxP}`, inline: true },
                { name: 'Organizer', value: event.organizerName, inline: true },
                { name: 'Triggers', value: triggersText, inline: false },
                { name: 'Chat', value: event.settings?.allowChat !== false ? 'Enabled' : 'Disabled', inline: true },
                { name: 'Polls', value: event.settings?.allowPolls !== false ? 'Enabled' : 'Disabled', inline: true },
                { name: 'File Sharing', value: event.settings?.allowFileSharing !== false ? 'Enabled' : 'Disabled', inline: true },
                { name: 'RSVP', value: event.settings?.rsvpEnabled !== false ? 'Enabled' : 'Disabled', inline: true },
                { name: 'Public Event', value: event.settings?.isPublic ? 'Yes' : 'No', inline: true },
                { name: 'Require Approval', value: event.settings?.requireApproval ? 'Yes' : 'No', inline: true },
                { name: 'Webhook ID', value: wh._id.toString(), inline: false },
                { name: 'Signing Secret', value: wh.secret ? 'Configured' : 'None', inline: true },
              ],
              footer: { text: 'PlanIt — You will receive a notification for each selected trigger.' },
              timestamp: new Date().toISOString(),
            }]
          };
          await axios.post(wh.url, configPayload, { headers: { 'Content-Type': 'application/json' }, timeout: 5000 });
        } else if (isSlack) {
          // Slack requires { text: "..." } — plain object, NOT a pre-stringified string
          const slackPayload = {
            text: `*PlanIt Webhook Connected* — ${event.title}\nTriggers: ${triggersText}\nParticipants: ${participantCount} / ${maxP}\nDate: ${eventDate}`,
          };
          await axios.post(wh.url, slackPayload, { headers: { 'Content-Type': 'application/json' }, timeout: 5000 });
        } else {
          const configPayload = {
            event: 'webhook_configured',
            eventId: event._id.toString(),
            eventName: event.title,
            subdomain: event.subdomain,
            timestamp: new Date().toISOString(),
            webhook: {
              id: wh._id.toString(),
              triggers: wh.events,
              triggerLabels: triggersText,
              hasSecret: !!wh.secret,
            },
            eventDetails: {
              date: event.date,
              location: event.location || null,
              organizer: event.organizerName,
              status: event.status,
              participants: participantCount,
              maxParticipants: maxP,
              settings: {
                allowChat: event.settings?.allowChat !== false,
                allowPolls: event.settings?.allowPolls !== false,
                allowFileSharing: event.settings?.allowFileSharing !== false,
                rsvpEnabled: event.settings?.rsvpEnabled !== false,
                isPublic: event.settings?.isPublic === true,
                requireApproval: event.settings?.requireApproval === true,
              },
            },
          };
          await axios.post(wh.url, configPayload, {
            headers: { 'Content-Type': 'application/json', 'X-PlanIt-Event': 'webhook_configured', 'X-PlanIt-EventId': event._id.toString() },
            timeout: 5000,
          });
        }
      } catch (cfgErr) {
        // Config ping is best-effort — don't block webhook creation, but DO log so we can debug.
        const cfgStatus = cfgErr.response?.status;
        const cfgDetail = cfgErr.response?.data ? JSON.stringify(cfgErr.response.data).slice(0, 300) : cfgErr.message;
        console.error(`[webhook] Config ping FAILED for ${wh._id}: HTTP ${cfgStatus || 'network'} — ${cfgDetail}`);
      }

      res.status(201).json({ webhook: { _id: wh._id, url: wh.url, events: wh.events, active: wh.active, createdAt: wh.createdAt } });
    } catch (error) { next(error); }
  }
);

// PATCH /:eventId/webhooks/:webhookId — toggle active (organizer only)
router.patch('/:eventId/webhooks/:webhookId', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const wh = event.webhooks.id(req.params.webhookId);
    if (!wh) return res.status(404).json({ error: 'Webhook not found' });
    if (req.body.active !== undefined) wh.active = req.body.active;
    await event.save();
    res.json({ webhook: { _id: wh._id, url: wh.url, events: wh.events, active: wh.active } });
  } catch (error) { next(error); }
});

// DELETE /:eventId/webhooks/:webhookId — delete webhook (organizer only)
router.delete('/:eventId/webhooks/:webhookId', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    event.webhooks = event.webhooks.filter(w => w._id.toString() !== req.params.webhookId);
    await event.save();
    res.json({ message: 'Webhook deleted' });
  } catch (error) { next(error); }
});

// ═══════════════════════════════════════════════════════════════════════════
// APPROVAL QUEUE — organizer approve/reject pending join requests
// ═══════════════════════════════════════════════════════════════════════════

// GET  /:eventId/approval-status — polling endpoint for pending users
// SECURITY FIX: now requires a poll token issued at queue-join time.
// This prevents unauthenticated callers from supplying any username in the
// event's participants array (e.g. the organiser) and receiving a real JWT.
router.get('/:eventId/approval-status', async (req, res, next) => {
  try {
    const { eventId } = req.params;
    const username = (req.query.username || '').trim();
    if (!username) return res.status(400).json({ error: 'username query param required' });

    // ── Require the poll token issued at queue-join time ───────────────────────
    const rawPollToken =
      req.headers['x-poll-token'] ||
      req.query.pollToken ||
      req.query.poll_token;

    if (!rawPollToken) {
      return res.status(401).json({ error: 'Poll token required. Please rejoin the event to obtain one.' });
    }

    let pollDecoded;
    try {
      pollDecoded = jwt.verify(rawPollToken, secrets.jwt);
    } catch (e) {
      return res.status(401).json({ error: 'Invalid or expired poll token.' });
    }

    // Token must be the right type AND scoped to this event AND this username
    if (
      pollDecoded.type !== 'approval_poll' ||
      pollDecoded.eventId !== eventId.toString() ||
      pollDecoded.username !== username
    ) {
      return res.status(403).json({ error: 'Poll token is not valid for this request.' });
    }
    // ── End poll token check ───────────────────────────────────────────────────

    const event = await Event.findById(eventId).select('approvalQueue participants settings title');
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    if (!event.settings?.requireApproval) return res.status(400).json({ error: 'This event does not require approval.' });

    const inQueue      = event.approvalQueue?.some(q => q.username === username);
    const isParticipant = event.participants?.some(p => p.username === username);

    if (isParticipant) {
      // They've been approved — ensure their participant record exists and issue a token
      await EventParticipant.findOneAndUpdate(
        { eventId, username },
        { role: 'participant', lastSeenAt: new Date() },
        { upsert: true, new: true }
      );
      const token = jwt.sign(
        { eventId: eventId.toString(), username, role: 'participant' },
        secrets.jwt, { expiresIn: '7d' }
      );
      return res.json({ approved: true, token, event: { id: event._id, title: event.title } });
    }

    if (inQueue) {
      return res.json({ pending: true, message: 'Your request is still pending organizer approval.' });
    }

    // Not in queue and not a participant — they haven't requested yet or were rejected
    return res.json({ notRequested: true });
  } catch (err) { next(err); }
});

// GET  /:eventId/approval-queue  — list pending requests (organizer only)
router.get('/:eventId/approval-queue', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId).select('approvalQueue');
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    res.json({ queue: event.approvalQueue || [] });
  } catch (err) { next(err); }
});

// POST /:eventId/approval-queue/:username/approve
router.post('/:eventId/approval-queue/:username/approve', verifyOrganizer, async (req, res, next) => {
  try {
    const { eventId, username } = req.params;
    const event = await Event.findById(eventId).select('+password');
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const inQueue = event.approvalQueue?.some(q => q.username === username);
    if (!inQueue) return res.status(404).json({ error: 'No pending request for that username.' });

    // Remove from queue
    await Event.findByIdAndUpdate(eventId, { $pull: { approvalQueue: { username } } });

    // Create participant record and add to event
    await EventParticipant.findOneAndUpdate(
      { eventId, username },
      { role: 'participant', lastSeenAt: new Date() },
      { upsert: true, new: true }
    );
    await event.addParticipant(username);

    // Issue a token for them to use
    const token = jwt.sign(
      { eventId: eventId.toString(), username, role: 'participant' },
      secrets.jwt, { expiresIn: '7d' }
    );

    const io = req.app.get('io');
    if (io) {
      io.to(`event_${eventId}`).emit('approval_approved', { username, token });
    }
    res.json({ message: `${username} approved.`, token });
  } catch (err) { next(err); }
});

// POST /:eventId/approval-queue/:username/reject
router.post('/:eventId/approval-queue/:username/reject', verifyOrganizer, async (req, res, next) => {
  try {
    const { eventId, username } = req.params;
    await Event.findByIdAndUpdate(eventId, { $pull: { approvalQueue: { username } } });
    const io = req.app.get('io');
    if (io) {
      io.to(`event_${eventId}`).emit('approval_rejected', { username });
    }
    res.json({ message: `${username} rejected.` });
  } catch (err) { next(err); }
});


// ─── GET /:eventId/checkin-cache ─────────────────────────────────────────────
// Returns a lightweight snapshot of all invites for offline PWA check-in.
// Staff/organizer devices call this on page load and store it in IndexedDB.
// When offline, the device checks invites against this cache and queues scans.
// Excludes sensitive fields (actual PIN value is never sent — only hasPin flag).
router.get('/:eventId/checkin-cache', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { eventId } = req.params;

    const event = await Event.findById(eventId).select('title checkinSettings').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });

    const Invite = require('../models/Invite');
    const invites = await Invite.find({ eventId })
      .select('inviteCode guestName guestEmail groupSize adults children checkedIn securityPin isBlocked status notes tableId tableLabel')
      .lean();

    const snapshot = invites.map(inv => ({
      code:       inv.inviteCode,
      name:       inv.guestName,
      email:      inv.guestEmail       || '',
      groupSize:  inv.groupSize        || 1,
      adults:     inv.adults           || 1,
      children:   inv.children         || 0,
      checkedIn:  !!inv.checkedIn,
      hasPin:     !!(inv.securityPin),
      isBlocked:  !!(inv.isBlocked),
      status:     inv.status           || 'active',
      notes:      inv.notes            || '',
      tableId:    inv.tableId          || null,
      tableLabel: inv.tableLabel       || null,
    }));

    res.json({
      snapshot,
      total:    snapshot.length,
      builtAt:  new Date().toISOString(),
      event:    { title: event.title },
    });
  } catch (err) { next(err); }
});

module.exports = router;
module.exports.fireWebhooks = fireWebhooks;

// ═══════════════════════════════════════════════════════════════════════════
// TABLE SERVICE MODE — Restaurant & Venue Floor Management Routes
// Data is NEVER auto-wiped (keepForever enforced in settings PATCH).
// ═══════════════════════════════════════════════════════════════════════════

// GET  /:eventId/table-service/floor  — full floor state
// Strictly table-service events only. Enterprise events use /checkin for seating.
router.get('/:eventId/table-service/floor', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId)
      .select('title tableServiceSettings reservationPageSettings tableStates restaurantReservations tableServiceWaitlist seatingMap isTableServiceMode isEnterpriseMode')
      .lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    if (!event.isTableServiceMode) {
      return res.status(403).json({
        error: 'Floor plan is not available for this event.',
        isEnterpriseMode: !!event.isEnterpriseMode,
        eventTitle: event.title,
      });
    }
    res.json({
      seatingMap:              event.seatingMap || { enabled: false, objects: [] },
      tableStates:             event.tableStates || [],
      settings:                event.tableServiceSettings || {},
      reservations:            (event.restaurantReservations || []).filter(r => r.status !== 'cancelled'),
      waitlist:                (event.tableServiceWaitlist || []).filter(w => w.status === 'waiting' || w.status === 'notified'),
      restaurantName:          event.tableServiceSettings?.restaurantName || event.title,
      reservationPageSettings: event.reservationPageSettings || {},
      isTableServiceMode:      true,
      isEnterpriseMode:        false,
    });
  } catch (err) { next(err); }
});

// PATCH /:eventId/table-service/table/:tableId  — update a single table state
router.patch('/:eventId/table-service/table/:tableId', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { eventId, tableId } = req.params;
    const {
      status, partyName, partySize, serverName, notes, reservationId,
      // server-controlled guest tablet fields
      guestScreen, billSubtotal, billTax, billPaid, guestAlert,
    } = req.body;
    const ALLOWED_STATUSES = ['available', 'occupied', 'reserved', 'cleaning', 'unavailable'];
    const ALLOWED_SCREENS  = ['idle', 'dining', 'bill', 'rating'];
    if (status && !ALLOWED_STATUSES.includes(status)) {
      return res.status(400).json({ error: `Invalid status. Must be: ${ALLOWED_STATUSES.join(', ')}` });
    }
    if (guestScreen !== undefined && !ALLOWED_SCREENS.includes(guestScreen)) {
      return res.status(400).json({ error: `Invalid guestScreen. Must be: ${ALLOWED_SCREENS.join(', ')}` });
    }
    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });

    let existing = event.tableStates.find(s => s.tableId === tableId);
    if (!existing) { event.tableStates.push({ tableId, status: 'available' }); existing = event.tableStates[event.tableStates.length - 1]; }

    const prevStatus = existing.status;
    if (status !== undefined)        existing.status        = status;
    if (partyName !== undefined)     existing.partyName     = partyName;
    if (partySize !== undefined)     existing.partySize     = partySize;
    if (serverName !== undefined)    existing.serverName    = serverName;
    if (notes !== undefined)         existing.notes         = notes;
    if (reservationId !== undefined) existing.reservationId = reservationId;
    if (status === 'occupied' && prevStatus !== 'occupied') existing.occupiedAt = new Date();
    if (status === 'available' || status === 'cleaning') {
      existing.occupiedAt = null; existing.partyName = partyName || ''; existing.partySize = partySize || 0; existing.reservationId = null;
    }
    // Server-controlled guest tablet fields
    if (guestScreen !== undefined) existing.guestScreen = guestScreen;
    if (guestAlert !== undefined)  existing.guestAlert  = guestAlert;
    if (billSubtotal !== undefined) existing.billSubtotal = typeof billSubtotal === 'number' ? billSubtotal : null;
    if (billTax !== undefined)      existing.billTax      = typeof billTax === 'number' ? billTax : null;
    if (billPaid !== undefined)     existing.billPaid     = !!billPaid;
    // When server resets to idle, clear guest-written fields
    if (guestScreen === 'idle') {
      existing.guestAlert = null;
      existing.guestDietary = [];
      existing.guestDietaryNotes = '';
    }
    existing.updatedAt = new Date();
    await event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${eventId}`).emit('table_state_update', { tableId, ...existing.toObject() });
    res.json({ success: true, tableState: existing });
  } catch (err) { next(err); }
});

// ── Public guest tablet routes (no auth required) ─────────────────────────────
// Guests can only read their own table and write a strict whitelist of fields.

// GET /:eventId/table-service/guest/:tableId — guest polls their table state
router.get('/:eventId/table-service/guest/:tableId', availabilityLimiter, async (req, res, next) => {
  try {
    const { eventId, tableId } = req.params;
    if (!eventId || eventId.length > 64 || !tableId || tableId.length > 128) {
      return res.status(400).json({ error: 'Invalid request.' });
    }
    const event = await Event.findById(eventId)
      .select('title tableServiceSettings reservationPageSettings seatingMap tableStates isTableServiceMode')
      .lean();
    if (!event || !event.isTableServiceMode) return res.status(404).json({ error: 'Not found.' });

    const objects = event.seatingMap?.objects || [];
    const tableObj = objects.find(o => o.id === tableId);
    if (!tableObj) return res.status(404).json({ error: 'Table not found.' });

    const state = (event.tableStates || []).find(s => s.tableId === tableId) || { tableId, guestScreen: 'idle' };
    const rps   = event.reservationPageSettings || {};

    // Only return what the guest needs — never expose other tables or party data
    res.json({
      venueName:         event.tableServiceSettings?.restaurantName || event.title || '',
      table:             { id: tableObj.id, label: tableObj.label, capacity: tableObj.capacity, type: tableObj.type },
      guestScreen:       state.guestScreen || 'idle',
      guestAlert:        state.guestAlert  || null,
      guestDietary:      state.guestDietary || [],
      guestDietaryNotes: state.guestDietaryNotes || '',
      billSubtotal:      state.billSubtotal ?? null,
      billTax:           state.billTax ?? null,
      billPaid:          state.billPaid || false,
      tipPct:            state.tipPct ?? null,
      hasRating:         !!(state.guestRating?.food),
      accentColor:       rps.accentColor || '#f97316',
      menus:             rps.menus || [],
      // Active orders for this table (read-only for guest — shows what server placed)
      orders: (state.orders || []).filter(o => o.status !== 'cancelled').map(o => ({
        id:         o.id,
        itemId:     o.itemId,
        itemName:   o.itemName,
        priceCents: o.priceCents,
        qty:        o.qty,
        status:     o.status,
      })),
    });
  } catch (err) { next(err); }
});

// PATCH /:eventId/table-service/guest/:tableId — guest writes allowed fields only
const GUEST_ALLOWED_DIETARY = [
  'Vegetarian','Vegan','Gluten-Free','Nut Allergy','Dairy-Free',
  'Shellfish','Soy','Kosher','Halal','Low-Sodium',
  'Pescatarian','Egg-Free','Diabetic-Friendly','Raw/Organic',
];
const GUEST_ALLOWED_ALERTS = ['call', 'order', 'quick:water', 'quick:napkins', 'quick:menu', 'quick:dessert', null];
router.patch('/:eventId/table-service/guest/:tableId', availabilityLimiter, async (req, res, next) => {
  try {
    const { eventId, tableId } = req.params;
    if (!eventId || eventId.length > 64 || !tableId || tableId.length > 128) {
      return res.status(400).json({ error: 'Invalid request.' });
    }
    const { guestAlert, guestDietary, guestDietaryNotes, tipPct, guestRating, guestScreen, partySize } = req.body;

    if (guestAlert !== undefined && !GUEST_ALLOWED_ALERTS.includes(guestAlert)) {
      return res.status(400).json({ error: 'Invalid alert type.' });
    }
    if (guestDietary !== undefined) {
      if (!Array.isArray(guestDietary) || guestDietary.length > GUEST_ALLOWED_DIETARY.length ||
          !guestDietary.every(d => GUEST_ALLOWED_DIETARY.includes(d))) {
        return res.status(400).json({ error: 'Invalid dietary data.' });
      }
    }
    if (guestDietaryNotes !== undefined && (typeof guestDietaryNotes !== 'string' || guestDietaryNotes.length > 300)) {
      return res.status(400).json({ error: 'Notes too long.' });
    }
    if (tipPct !== undefined && (typeof tipPct !== 'number' || tipPct < 0 || tipPct > 100)) {
      return res.status(400).json({ error: 'Invalid tip.' });
    }
    if (partySize !== undefined) {
      const ps = parseInt(partySize);
      if (!Number.isInteger(ps) || ps < 1 || ps > 50) {
        return res.status(400).json({ error: 'Invalid party size.' });
      }
    }
    // Guests may only transition themselves to 'dining' (tap to begin)
    if (guestScreen !== undefined && guestScreen !== 'dining') {
      return res.status(400).json({ error: 'Invalid screen.' });
    }
    if (guestRating !== undefined) {
      const { food, service, atmosphere, comment } = guestRating;
      if (![food, service, atmosphere].every(v => Number.isInteger(v) && v >= 1 && v <= 5)) {
        return res.status(400).json({ error: 'Invalid rating values.' });
      }
      if (comment !== undefined && (typeof comment !== 'string' || comment.length > 300)) {
        return res.status(400).json({ error: 'Comment too long.' });
      }
    }

    const event = await Event.findById(eventId).select('isTableServiceMode seatingMap tableStates');
    if (!event || !event.isTableServiceMode) return res.status(404).json({ error: 'Not found.' });

    const tableExists = (event.seatingMap?.objects || []).some(o => o.id === tableId);
    if (!tableExists) return res.status(404).json({ error: 'Table not found.' });

    let existing = event.tableStates.find(s => s.tableId === tableId);
    if (!existing) { event.tableStates.push({ tableId }); existing = event.tableStates[event.tableStates.length - 1]; }

    if (guestAlert !== undefined)        existing.guestAlert        = guestAlert;
    if (guestDietary !== undefined)      existing.guestDietary      = guestDietary;
    if (guestDietaryNotes !== undefined) existing.guestDietaryNotes = guestDietaryNotes.trim().slice(0, 300);
    if (tipPct !== undefined)            existing.tipPct            = tipPct;
    if (guestScreen !== undefined)       existing.guestScreen       = guestScreen;
    if (partySize !== undefined)         existing.partySize         = parseInt(partySize);
    if (guestRating !== undefined) {
      existing.guestRating = {
        food:        guestRating.food,
        service:     guestRating.service,
        atmosphere:  guestRating.atmosphere,
        comment:     (guestRating.comment || '').trim().slice(0, 300),
        submittedAt: new Date(),
      };
      existing.guestScreen = 'idle'; // auto-reset after rating
    }
    existing.updatedAt = new Date();
    await event.save();

    const io = req.app.get('io');
    if (io) io.to(`event_${eventId}`).emit('table_state_update', { tableId, ...existing.toObject() });

    res.json({
      success:           true,
      guestScreen:       existing.guestScreen,
      guestAlert:        existing.guestAlert,
      guestDietary:      existing.guestDietary,
      guestDietaryNotes: existing.guestDietaryNotes,
      billSubtotal:      existing.billSubtotal,
      billTax:           existing.billTax,
      billPaid:          existing.billPaid,
      tipPct:            existing.tipPct,
      hasRating:         !!(existing.guestRating?.food),
    });
  } catch (err) { next(err); }
});

// POST /:eventId/table-service/waitlist
router.post('/:eventId/table-service/waitlist', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { partyName, partySize, phone, notes } = req.body;
    if (!partyName?.trim()) return res.status(400).json({ error: 'Party name is required' });
    if (!partySize || partySize < 1) return res.status(400).json({ error: 'Party size must be at least 1' });
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const entry = { id: require('crypto').randomUUID(), partyName: partyName.trim(), partySize: parseInt(partySize), phone: phone?.trim() || '', notes: notes?.trim() || '', addedAt: new Date(), status: 'waiting' };
    event.tableServiceWaitlist.push(entry);
    await event.save();
    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('waitlist_update', { action: 'add', entry });
    res.status(201).json({ success: true, entry });
  } catch (err) { next(err); }
});

// PATCH /:eventId/table-service/waitlist/:partyId
router.patch('/:eventId/table-service/waitlist/:partyId', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { status } = req.body;
    if (!['waiting','notified','seated','left'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const entry = event.tableServiceWaitlist.find(w => w.id === req.params.partyId);
    if (!entry) return res.status(404).json({ error: 'Not found' });
    entry.status = status;
    if (status === 'notified') entry.notifiedAt = new Date();
    await event.save();
    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('waitlist_update', { action: 'update', entry });
    res.json({ success: true, entry });
  } catch (err) { next(err); }
});

// DELETE /:eventId/table-service/waitlist/:partyId
router.delete('/:eventId/table-service/waitlist/:partyId', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    event.tableServiceWaitlist = event.tableServiceWaitlist.filter(w => w.id !== req.params.partyId);
    await event.save();
    res.json({ success: true });
  } catch (err) { next(err); }
});

// POST /:eventId/table-service/reservations
router.post('/:eventId/table-service/reservations', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { partyName, partySize, phone, email, dateTime, tableId, notes } = req.body;
    if (!partyName?.trim()) return res.status(400).json({ error: 'Party name is required' });
    if (!partySize || partySize < 1) return res.status(400).json({ error: 'Party size must be at least 1' });
    if (!dateTime) return res.status(400).json({ error: 'Date/time is required' });
    const event = await Event.findById(req.params.eventId).select('restaurantReservations tableServiceSettings title');
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const id = require('crypto').randomUUID();
    const expiryMins = event.tableServiceSettings?.reservationQrExpiryMinutes || 45;
    const resDateTime = new Date(dateTime);
    const qrExpiresAt = new Date(resDateTime.getTime() + expiryMins * 60000);
    const secsUntilExpiry = Math.max(3600, Math.ceil((qrExpiresAt.getTime() - Date.now()) / 1000));
    const qrToken = jwt.sign(
      { type: 'table_reservation', reservationId: id, eventId: req.params.eventId, partyName: partyName.trim(), partySize: parseInt(partySize) },
      secrets.jwt, { expiresIn: `${secsUntilExpiry}s` }
    );
    const reservation = { id, partyName: partyName.trim(), partySize: parseInt(partySize), phone: phone?.trim() || '', email: email?.trim() || '', dateTime: resDateTime, tableId: tableId || null, qrToken, qrExpiresAt, status: 'confirmed', notes: notes?.trim() || '', createdAt: new Date() };
    event.restaurantReservations.push(reservation);
    await event.save();
    res.status(201).json({ success: true, reservation });
  } catch (err) { next(err); }
});

// PATCH /:eventId/table-service/reservations/:reservationId
router.patch('/:eventId/table-service/reservations/:reservationId', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { status, tableId, notes } = req.body;
    if (status && !['confirmed','seated','cancelled','no_show'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const r = event.restaurantReservations.find(r => r.id === req.params.reservationId);
    if (!r) return res.status(404).json({ error: 'Reservation not found' });
    if (status !== undefined)  r.status  = status;
    if (tableId !== undefined) r.tableId = tableId;
    if (notes !== undefined)   r.notes   = notes;
    await event.save();
    res.json({ success: true, reservation: r });
  } catch (err) { next(err); }
});

// GET /:eventId/table-service/reservations/verify/:token  — QR scan verification
// Handles two token formats:
//   1. JWT  — staff-created reservations (signed with secrets.jwt)
//   2. Hex  — public online bookings (crypto.randomBytes(24).toString('hex') stored on reservation)
router.get('/:eventId/table-service/reservations/verify/:token', verifyCheckinAccess, async (req, res, next) => {
  try {
    const token = req.params.token;
    const event = await Event.findById(req.params.eventId).select('restaurantReservations tableServiceSettings');
    if (!event) return res.status(404).json({ valid: false, error: 'Event not found.' });

    // Path A: hex token (public online reservation — 48 hex chars)
    if (/^[0-9a-f]{48}$/i.test(token)) {
      const reservation = event.restaurantReservations?.find(r => r.qrToken === token);
      if (!reservation) return res.status(404).json({ valid: false, error: 'Reservation not found.' });
      if (reservation.status === 'cancelled') return res.status(400).json({ valid: false, error: 'This reservation was cancelled.' });
      if (reservation.status === 'seated')    return res.status(400).json({ valid: false, error: 'This party is already seated.' });
      if (reservation.qrExpiresAt && new Date() > new Date(reservation.qrExpiresAt)) {
        return res.status(401).json({ valid: false, error: 'This QR code has expired.' });
      }
      return res.json({ valid: true, reservation });
    }

    // Path B: JWT token (staff-created reservation)
    let decoded;
    try { decoded = jwt.verify(token, secrets.jwt); } catch (e) {
      return res.status(401).json({ valid: false, error: e.name === 'TokenExpiredError' ? 'This QR code has expired.' : 'Invalid QR code.' });
    }
    if (decoded.type !== 'table_reservation' || decoded.eventId !== req.params.eventId) {
      return res.status(400).json({ valid: false, error: 'QR code is not for this venue.' });
    }
    const reservation = event.restaurantReservations?.find(r => r.id === decoded.reservationId);
    if (!reservation) return res.status(404).json({ valid: false, error: 'Reservation not found.' });
    if (reservation.status === 'cancelled') return res.status(400).json({ valid: false, error: 'This reservation was cancelled.' });
    if (reservation.status === 'seated')    return res.status(400).json({ valid: false, error: 'This party is already seated.' });
    return res.json({ valid: true, reservation });
  } catch (err) { next(err); }
});

// PATCH /:eventId/table-service/settings
router.patch('/:eventId/table-service/settings', verifyOrganizer, async (req, res, next) => {
  try {
    const ALLOWED = ['restaurantName','avgDiningMinutes','cleaningBufferMinutes','reservationDurationMinutes','reservationQrExpiryMinutes','maxPartySizeWalkIn','operatingHoursOpen','operatingHoursClose','currency','welcomeMessage','sizeOverrides','servers'];
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    ALLOWED.forEach(k => { if (req.body[k] !== undefined) event.tableServiceSettings[k] = req.body[k]; });
    event.keepForever = true; // Table Service data is never auto-wiped
    await event.save();
    res.json({ success: true, settings: event.tableServiceSettings });
  } catch (err) { next(err); }
});

// ── PATCH /:eventId/table-service/reservation-page-settings ──────────────────
router.patch('/:eventId/table-service/reservation-page-settings', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    if (!event.isTableServiceMode) return res.status(403).json({ error: 'Not a table service event' });

    const ALLOWED_KEYS = [
      'acceptingReservations','confirmationMode','heroImageUrl','logoUrl','accentColor',
      'backgroundStyle','fontStyle','headerTagline','showPoweredBy','hidePlanitBranding',
      'announcementBanner','announcementBannerColor','announcementBannerEnabled',
      'publicDescription','cuisine','priceRange','dressCode','parkingInfo','accessibilityInfo',
      'address','phone','websiteUrl','instagramHandle','facebookUrl','googleMapsUrl',
      'operatingDays','blackoutDates',
      'slotIntervalMinutes','maxAdvanceDays','minAdvanceHours','cancelCutoffHours',
      'maxPartySizePublic','minPartySizePublic','maxReservationsPerDay','maxReservationsPerSlot',
      'lastBookingBeforeCloseMinutes',
      'requirePhone','requireEmail','allowSpecialRequests','allowDietaryNeeds',
      'allowOccasionSelect','occasionOptions',
      'showLiveWaitTime','showAvailabilityStatus','showTableCount','showPartySizeWaitTimes',
      'availabilityDisplayMode',
      'confirmationMessage','confirmationEmailSubject','sendConfirmationEmail',
      'sendReminderEmail','reminderHoursBefore','sendCancellationEmail',
      'notifyOrganizerOnBooking','notifyOrganizerOnCancel','notifyOrganizerEmail',
      'cancellationPolicy','depositRequired','depositAmount','depositNote',
      'termsUrl','privacyUrl','faqItems','menus',
      'metaTitle','metaDescription',
      'walkInOnlyMode','publicWaitBoardEnabled','waitBoardMessage','waitBoardTitle',
    ];

    if (!event.reservationPageSettings) event.reservationPageSettings = {};
    ALLOWED_KEYS.forEach(k => {
      if (req.body[k] !== undefined) event.reservationPageSettings[k] = req.body[k];
    });
    event.keepForever = true;
    event.markModified('reservationPageSettings');
    await event.save();

    res.json({ success: true, settings: event.reservationPageSettings, reservationPageSettings: event.reservationPageSettings });
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════
// PUBLIC RESERVATION API  (/api/events/public/reserve/...)
// No auth required. Aggressively rate-limited.
// ═══════════════════════════════════════════════════════════════════════════

// ── Availability helpers (module-scope) ──────────────────────────────────────
// These were previously only defined inside the analytics handler scope.
// Hoisted here so computeAvailability and all public-reserve route handlers
// can reference them regardless of call order.

function wallClockToUTC(dateStr, timeStr, tz) {
  if (!tz) return new Date(`${dateStr}T${timeStr}:00`);
  try {
    const [Y, M, D] = dateStr.split('-').map(Number);
    const [h, m]    = timeStr.split(':').map(Number);
    const target = Date.UTC(Y, M - 1, D, h, m, 0);
    const fmt = new Intl.DateTimeFormat('en-CA', {
      timeZone: tz,
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      hour12: false,
    });
    let utcMs = target;
    for (let i = 0; i < 3; i++) {
      const parts = Object.fromEntries(
        fmt.formatToParts(new Date(utcMs)).map(p => [p.type, p.value])
      );
      const localMs = Date.UTC(
        +parts.year, +parts.month - 1, +parts.day,
        +parts.hour === 24 ? 0 : +parts.hour,
        +parts.minute, +parts.second
      );
      const diff = target - localMs;
      if (diff === 0) break;
      utcMs += diff;
    }
    return new Date(utcMs);
  } catch (_) {
    return new Date(`${dateStr}T${timeStr}:00`);
  }
}

function buildSlots(dateStr, openTime, closeTime, intervalMin, lastBookingBuffer, tz) {
  const slots = [];
  const [oh, om] = openTime.split(':').map(Number);
  const [ch, cm] = closeTime.split(':').map(Number);
  let cur = oh * 60 + om;
  const end = ch * 60 + cm - (lastBookingBuffer || 0);
  while (cur <= end) {
    const h = Math.floor(cur / 60);
    const m = cur % 60;
    const timeStr = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    const dt = wallClockToUTC(dateStr, timeStr, tz);
    slots.push({ time: timeStr, datetime: dt });
    cur += intervalMin;
  }
  return slots;
}

function getDayKey(date) {
  const days = ['sun','mon','tue','wed','thu','fri','sat'];
  return days[new Date(date).getDay()];
}

function computeAvailability(dateStr, partySize, event, tz) {
  const rps = event.reservationPageSettings || {};
  const tss = event.tableServiceSettings || {};

  // Check if this day is open
  const dayKey = getDayKey(dateStr + 'T12:00:00');
  const dayConfig = rps.operatingDays?.[dayKey];
  if (dayConfig && dayConfig.open === false) return [];

  // Blackout check
  if ((rps.blackoutDates || []).some(b => b.date === dateStr)) return [];

  const openTime  = dayConfig?.openTime  || tss.operatingHoursOpen  || '11:00';
  const closeTime = dayConfig?.closeTime || tss.operatingHoursClose || '22:00';
  const interval  = rps.slotIntervalMinutes || 30;
  const duration  = tss.reservationDurationMinutes || 90;
  const buffer    = rps.lastBookingBeforeCloseMinutes || 30;
  const maxPerSlot = rps.maxReservationsPerSlot || 0;

  const slots = buildSlots(dateStr, openTime, closeTime, interval, buffer, tz);

  // Tables that can seat this party
  const tables = (event.seatingMap?.objects || []).filter(t =>
    t.type !== 'zone' && t.capacity >= partySize
  );

  // Reservations for this day — use UTC day window covering the full local day
  const dayStart = tz ? wallClockToUTC(dateStr, '00:00', tz) : new Date(dateStr + 'T00:00:00');
  const dayEnd   = tz ? wallClockToUTC(dateStr, '23:59', tz) : new Date(dateStr + 'T23:59:59');
  const dayRes   = (event.restaurantReservations || []).filter(r =>
    (r.status === 'confirmed' || r.status === 'pending') &&
    new Date(r.dateTime) >= dayStart &&
    new Date(r.dateTime) <= dayEnd
  );

  // Min advance enforcement
  const minAdvanceMs = (rps.minAdvanceHours ?? 1) * 3600000;
  const now = Date.now();

  return slots.map(slot => {
    // Past or too soon?
    if (slot.datetime.getTime() - now < minAdvanceMs) {
      return { time: slot.time, status: 'unavailable', reason: 'past' };
    }

    const slotEnd = new Date(slot.datetime.getTime() + duration * 60000);

    // Which of our suitable tables already have a reservation overlapping this window?
    const bookedTableIds = new Set();
    dayRes.forEach(res => {
      if (!res.tableId) return;
      const rStart = new Date(res.dateTime);
      const rEnd   = new Date(rStart.getTime() + duration * 60000);
      if (rStart < slotEnd && rEnd > slot.datetime) {
        bookedTableIds.add(res.tableId);
      }
    });
    const freeTables = tables.filter(t => !bookedTableIds.has(t.id));

    // Per-slot cap check (counts all reservations starting within ±interval/2)
    let slotCount = 0;
    if (maxPerSlot > 0) {
      slotCount = dayRes.filter(r => {
        const diff = Math.abs(new Date(r.dateTime).getTime() - slot.datetime.getTime());
        return diff < (interval * 60000) / 2;
      }).length;
    }

    let status = 'available';
    if (tables.length > 0) {
      if (freeTables.length === 0) status = 'full';
      else if (freeTables.length === 1) status = 'limited';
    } else {
      // No floor map yet — fall back to slot cap only
      if (maxPerSlot > 0 && slotCount >= maxPerSlot) status = 'full';
      else if (maxPerSlot > 0 && slotCount >= maxPerSlot * 0.7) status = 'limited';
    }

    if (maxPerSlot > 0 && slotCount >= maxPerSlot) status = 'full';

    return {
      time: slot.time,
      status,
      freeCount: freeTables.length,
    };
  });
}


const Message = require('../models/Message');
const Poll = require('../models/Poll');
const File = require('../models/File');

/**
 * GET /api/events/:eventId/backup
 * 
 * Download complete backup of event data
 * Returns JSON file with all event information
 * Users should download this before their event date
 */
router.get('/:eventId/backup', verifyOrganizer, async (req, res, next) => {
  try {
    const { eventId } = req.params;

    // Get the event
    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }

    // Gather all event data
    const [messages, polls, files, participants, invites] = await Promise.all([
      Message.find({ eventId, isDeleted: false })
        .select('-__v')
        .lean(),
      Poll.find({ eventId })
        .select('-__v')
        .lean(),
      File.find({ eventId, isDeleted: false })
        .select('-__v')
        .lean(),
      EventParticipant.find({ eventId })
        .select('-password -__v')
        .lean(),
      (() => {
        try {
          const Invite = require('../models/Invite');
          return Invite.find({ eventId }).select('-__v').lean();
        } catch {
          return Promise.resolve([]);
        }
      })()
    ]);

    // Create comprehensive backup object
    const backup = {
      metadata: {
        exportDate: new Date().toISOString(),
        eventId: event._id,
        planItVersion: '1.0.0',
        format: 'JSON'
      },
      event: {
        id: event._id,
        title: event.title,
        description: event.description,
        date: event.date,
        location: event.location,
        organizerName: event.organizerName,
        organizerEmail: event.organizerEmail,
        isEnterpriseMode: event.isEnterpriseMode,
        subdomain: event.subdomain,
        status: event.status,
        createdAt: event.createdAt,
        tasks: event.tasks || [],
        announcements: event.announcements || [],
        expenses: event.expenses || [],
        budget: event.budget || 0,
        notes: event.notes || [],
        agenda: event.agenda || [],
        rsvps: event.rsvps || []
      },
      statistics: {
        totalParticipants: participants.length,
        totalMessages: messages.length,
        totalPolls: polls.length,
        totalFiles: files.length,
        totalInvites: invites.length,
        totalExpenses: event.expenses?.length || 0,
        totalTasks: event.tasks?.length || 0,
        totalBudget: event.budget || 0
      },
      participants: participants.map(p => ({
        username: p.username,
        role: p.role,
        joinedAt: p.joinedAt,
        hasPassword: p.hasPassword,
        rsvp: event.rsvps?.find(r => r.username === p.username)
      })),
      messages: messages.map(m => ({
        id: m._id,
        username: m.username,
        content: m.content,
        createdAt: m.createdAt,
        editedAt: m.editedAt,
        reactions: m.reactions || []
      })),
      polls: polls.map(p => ({
        id: p._id,
        question: p.question,
        options: p.options || [],
        createdBy: p.createdBy,
        createdAt: p.createdAt,
        closedAt: p.closedAt,
        allowMultiple: p.allowMultiple
      })),
      files: files.map(f => ({
        id: f._id,
        filename: f.filename,
        originalName: f.originalName,
        size: f.size,
        mimetype: f.mimetype,
        url: f.cloudinaryUrl || f.url, // Support both old and new file systems
        uploadedBy: f.uploadedBy,
        uploadedAt: f.uploadedAt
      })),
      invites: invites.map(i => ({
        guestName: i.guestName,
        guestEmail: i.guestEmail,
        inviteCode: i.inviteCode,
        groupSize: i.groupSize,
        plusOnes: i.plusOnes,
        status: i.status,
        checkedIn: i.checkedIn,
        checkedInAt: i.checkedInAt,
        actualAttendees: i.actualAttendees
      })),
      importantNotice: {
        dataRetention: 'This event will be automatically deleted 7 days after the event date to save storage space.',
        fileAccess: 'File URLs in this backup will remain accessible as they are hosted externally (Cloudinary).',
        privacy: 'Keep this backup file secure as it contains all event data including participant information.',
        howToUse: 'This is a complete backup in JSON format. You can view it in any text editor or JSON viewer.'
      }
    };

    // Set headers for file download
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="planit-backup-${event.subdomain}-${Date.now()}.json"`);
    
    res.json(backup);

  } catch (error) {
    console.error('Backup error:', error);
    next(error);
  }
});

/**
 * GET /api/events/:eventId/backup-info
 * 
 * Get information about when the event will be deleted
 * Shows countdown and backup status
 */
router.get('/:eventId/backup-info', verifyEventAccess, async (req, res, next) => {
  try {
    const { eventId } = req.params;

    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({ error: 'Event not found' });
    }

    const eventDate = new Date(event.date);
    const deletionDate = new Date(eventDate);
    deletionDate.setDate(deletionDate.getDate() + 7);

    const now = new Date();
    const daysUntilDeletion = Math.ceil((deletionDate - now) / (1000 * 60 * 60 * 24));
    const hasOccurred = now > eventDate;
    const willBeDeleted = daysUntilDeletion <= 7 && hasOccurred;

    res.json({
      eventDate: eventDate,
      deletionDate: deletionDate,
      daysUntilDeletion: daysUntilDeletion,
      hasOccurred: hasOccurred,
      willBeDeleted: willBeDeleted,
      warningLevel: daysUntilDeletion <= 3 && hasOccurred ? 'critical' :
                    daysUntilDeletion <= 5 && hasOccurred ? 'warning' : 'normal',
      message: willBeDeleted 
        ? `This event will be automatically deleted in ${daysUntilDeletion} day(s). Download a backup now.`
        : hasOccurred
        ? 'This event has occurred. It will be deleted 7 days after the event date.'
        : 'Your event data is safe. Automatic deletion happens 7 days after the event date.'
    });

  } catch (error) {
    next(error);
  }
});
// ═══════════════════════════════════════════════════════════════════════════
// RESTAURANT MENU ROUTES
// ═══════════════════════════════════════════════════════════════════════════

// GET /:eventId/table-service/menu — all roles can read
router.get('/:eventId/table-service/menu', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId)
      .select('restaurantMenu isTableServiceMode').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    if (!event.isTableServiceMode) return res.status(403).json({ error: 'Not a table service event' });
    res.json({ menu: event.restaurantMenu || { categories: [] } });
  } catch (err) { next(err); }
});

// PUT /:eventId/table-service/menu — organizer/manager only
router.put('/:eventId/table-service/menu', verifyOrganizer, async (req, res, next) => {
  try {
    const { categories } = req.body;
    if (!Array.isArray(categories)) return res.status(400).json({ error: 'categories must be an array' });
    const crypto = require('crypto');
    // Sanitise + ensure IDs
    const safeCategories = categories.slice(0, 30).map((cat, ci) => ({
      id:   cat.id || crypto.randomUUID(),
      name: String(cat.name || '').trim().slice(0, 60),
      ord:  Number(cat.ord) || ci,
      items: (Array.isArray(cat.items) ? cat.items : []).slice(0, 100).map((item, ii) => ({
        id:            item.id || crypto.randomUUID(),
        name:          String(item.name || '').trim().slice(0, 100),
        desc:          String(item.desc || '').trim().slice(0, 300),
        priceCents:    Math.max(0, Math.round(Number(item.priceCents) || 0)),
        dietary:       (Array.isArray(item.dietary) ? item.dietary : []).slice(0, 10).map(d => String(d).slice(0, 20)),
        available:     item.available !== false,
        ord:           Number(item.ord) || ii,
        courseType:    ['appetizer','main','side','dessert','drink','other'].includes(item.courseType) ? item.courseType : 'main',
      })),
    }));
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    event.restaurantMenu = { categories: safeCategories, updatedAt: new Date() };
    await event.save();
    res.json({ success: true, menu: event.restaurantMenu });
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════
// ORDER ROUTES — server places/updates orders per table
// ═══════════════════════════════════════════════════════════════════════════

// POST /:eventId/table-service/table/:tableId/orders — server places order items
router.post('/:eventId/table-service/table/:tableId/orders', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { items, serverName } = req.body; // items: [{itemId, qty, specialRequest}]
    if (!Array.isArray(items) || items.length === 0)
      return res.status(400).json({ error: 'items array required' });
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const crypto = require('crypto');
    // Build lookup map for menu items
    const menuMap = {};
    for (const cat of (event.restaurantMenu?.categories || [])) {
      for (const item of (cat.items || [])) menuMap[item.id] = item;
    }
    // Find or create tableState
    let ts = event.tableStates.find(s => s.tableId === req.params.tableId);
    if (!ts) {
      event.tableStates.push({ tableId: req.params.tableId, status: 'available', orders: [] });
      ts = event.tableStates[event.tableStates.length - 1];
    }
    if (!ts.orders) ts.orders = [];
    const placed = [];
    for (const req_item of items.slice(0, 50)) {
      const menuItem = menuMap[req_item.itemId];
      if (!menuItem) continue;
      const order = {
        id:             crypto.randomUUID(),
        itemId:         menuItem.id,
        itemName:       menuItem.name,
        priceCents:     menuItem.priceCents,
        qty:            Math.max(1, Math.min(99, parseInt(req_item.qty) || 1)),
        courseType:     menuItem.courseType || 'main',
        dietary:        menuItem.dietary || [],
        specialRequest: String(req_item.specialRequest || '').trim().slice(0, 200),
        serverName:     String(serverName || '').trim().slice(0, 60),
        status:         'pending',
        placedAt:       new Date(),
        updatedAt:      new Date(),
      };
      ts.orders.push(order);
      placed.push(order);
    }
    await event.save();
    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('kitchen_update', { tableId: req.params.tableId });
    res.status(201).json({ success: true, placed, tableId: req.params.tableId });
  } catch (err) { next(err); }
});

// PATCH /:eventId/table-service/table/:tableId/orders/:orderId — update order item status
router.patch('/:eventId/table-service/table/:tableId/orders/:orderId', verifyCheckinAccess, async (req, res, next) => {
  try {
    const { status } = req.body;
    const validStatuses = ['pending','acknowledged','preparing','ready','delivered','cancelled'];
    if (!validStatuses.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const ts = event.tableStates.find(s => s.tableId === req.params.tableId);
    if (!ts) return res.status(404).json({ error: 'Table not found' });
    const order = (ts.orders || []).find(o => o.id === req.params.orderId);
    if (!order) return res.status(404).json({ error: 'Order item not found' });
    order.status = status;
    order.updatedAt = new Date();
    await event.save();
    const io = req.app.get('io');
    if (io) io.to(`event_${req.params.eventId}`).emit('kitchen_update', { tableId: req.params.tableId, orderId: req.params.orderId, status });
    res.json({ success: true, order });
  } catch (err) { next(err); }
});

// DELETE /:eventId/table-service/table/:tableId/orders — clear delivered/cancelled orders
router.delete('/:eventId/table-service/table/:tableId/orders', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const ts = event.tableStates.find(s => s.tableId === req.params.tableId);
    if (ts) ts.orders = [];
    await event.save();
    res.json({ success: true });
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════
// KITCHEN VIEW — all active orders across all tables
// ═══════════════════════════════════════════════════════════════════════════

router.get('/:eventId/table-service/kitchen', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId)
      .select('isTableServiceMode seatingMap tableStates tableServiceSettings restaurantName title')
      .lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    if (!event.isTableServiceMode) return res.status(403).json({ error: 'Not a table service event' });
    const objects = (event.seatingMap?.objects || []);
    const objMap  = {};
    for (const o of objects) objMap[o.id] = o;
    // Build kitchen tickets: only tables with active (non-delivered, non-cancelled) orders
    const tickets = [];
    for (const ts of (event.tableStates || [])) {
      const activeOrders = (ts.orders || []).filter(o =>
        !['delivered','cancelled'].includes(o.status)
      );
      if (activeOrders.length === 0) continue;
      const tableObj = objMap[ts.tableId] || {};
      // Flag if any order has dietary restrictions or special requests
      const hasDietary = activeOrders.some(o => o.dietary?.length > 0);
      const hasSpecial = activeOrders.some(o => o.specialRequest?.trim());
      const guestDietary = ts.guestDietary || [];
      const guestDietaryNotes = ts.guestDietaryNotes || '';
      tickets.push({
        tableId:          ts.tableId,
        tableLabel:       tableObj.label || ts.tableId,
        partyName:        ts.partyName || '',
        partySize:        ts.partySize || 0,
        serverName:       ts.serverName || '',
        guestDietary,
        guestDietaryNotes,
        hasDietary:       hasDietary || guestDietary.length > 0,
        hasSpecial,
        orders:           activeOrders,
        earliestPlacedAt: activeOrders.reduce((min, o) =>
          o.placedAt < min ? o.placedAt : min, activeOrders[0].placedAt
        ),
      });
    }
    // Sort: oldest ticket first (FIFO kitchen queue)
    tickets.sort((a, b) => new Date(a.earliestPlacedAt) - new Date(b.earliestPlacedAt));
    res.json({
      restaurantName: event.restaurantName || event.title || '',
      tickets,
      settings: {
        avgDiningMinutes: event.tableServiceSettings?.avgDiningMinutes || 75,
      },
    });
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════
// AUTO BILL CALCULATION
// Computes subtotal from active orders, applies tax + auto-gratuity, sends
// to guest tablet in one call. Returns breakdown for Clover / any POS.
// ═══════════════════════════════════════════════════════════════════════════

router.post('/:eventId/table-service/table/:tableId/bill/calculate', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const tss = event.tableServiceSettings || {};
    const ts  = event.tableStates.find(s => s.tableId === req.params.tableId);
    if (!ts) return res.status(404).json({ error: 'Table state not found' });

    // Sum all non-cancelled order items (include delivered)
    const billableOrders = (ts.orders || []).filter(o => o.status !== 'cancelled');
    const subtotalCents  = billableOrders.reduce((sum, o) => sum + (o.priceCents * o.qty), 0);

    const taxRate     = Number(tss.taxRate ?? 8.875) / 100;
    const gratuityPct = Number(tss.autoGratuityPct ?? 18) / 100;
    const gratuityMin = Number(tss.autoGratuityMinParty ?? 6);
    const partySize   = ts.partySize || 0;

    const taxCents       = Math.round(subtotalCents * taxRate);
    const applyGratuity  = partySize >= gratuityMin;
    const gratuityCents  = applyGratuity ? Math.round(subtotalCents * gratuityPct) : 0;
    const totalCents     = subtotalCents + taxCents + gratuityCents;

    const fmt = cents => (cents / 100).toFixed(2);

    // Build per-item line items for POS entry
    const lineItems = billableOrders.map(o => ({
      name:       o.itemName,
      qty:        o.qty,
      unitPrice:  fmt(o.priceCents),
      lineTotal:  fmt(o.priceCents * o.qty),
      courseType: o.courseType,
    }));

    // Send bill screen to guest tablet
    const subtotalDollars = subtotalCents / 100;
    const taxDollars      = (taxCents + gratuityCents) / 100; // roll gratuity into "tax" line for guest simplicity
    ts.guestScreen   = 'bill';
    ts.billSubtotal  = subtotalDollars;
    ts.billTax       = taxDollars;
    ts.billPaid      = false;

    await event.save();

    res.json({
      success: true,
      breakdown: {
        lineItems,
        subtotal:       fmt(subtotalCents),
        taxRate:        `${tss.taxRate ?? 8.875}%`,
        taxAmount:      fmt(taxCents),
        autoGratuity:   applyGratuity ? { pct: `${tss.autoGratuityPct ?? 18}%`, amount: fmt(gratuityCents) } : null,
        total:          fmt(totalCents),
        partySize,
        paymentNote:    tss.paymentNote || '',
        orderCount:     billableOrders.length,
      },
      // Sent to guest tablet
      billSubtotal: subtotalDollars,
      billTax:      taxDollars,
    });
  } catch (err) { next(err); }
});

// ═══════════════════════════════════════════════════════════════════════════
// SMART QUEUE FORECAST — per-party-in-line wait time estimation
// Returns expected seat time for each waiting party + auto-seat suggestion
// ═══════════════════════════════════════════════════════════════════════════

router.get('/:eventId/table-service/queue-forecast', verifyCheckinAccess, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId)
      .select('isTableServiceMode seatingMap tableStates tableServiceWaitlist tableServiceSettings').lean();
    if (!event) return res.status(404).json({ error: 'Event not found' });
    const tss     = event.tableServiceSettings || {};
    const objects = (event.seatingMap?.objects || []).filter(o => o.type !== 'zone' && (o.capacity || 0) > 0);
    const states  = event.tableStates || [];
    const queue   = (event.tableServiceWaitlist || [])
      .filter(w => w.status === 'waiting' || w.status === 'notified')
      .sort((a, b) => new Date(a.addedAt) - new Date(b.addedAt));

    const now       = Date.now();
    const avgDining = tss.avgDiningMinutes || 75;
    const buffer    = tss.cleaningBufferMinutes || 10;
    const getDining = (sz) => {
      const ov = (tss.sizeOverrides || []).find(o =>
        (!o.minParty || sz >= o.minParty) && (!o.maxParty || sz <= o.maxParty)
      );
      return ov?.avgMinutes || avgDining;
    };

    // Build mutable timeline of tables
    let timeline = objects.map(t => {
      const s = states.find(st => st.tableId === t.id);
      const status = s?.status || 'available';
      let minsUntilFree = 0;
      switch (status) {
        case 'available':   minsUntilFree = 0; break;
        case 'cleaning':    minsUntilFree = buffer; break;
        case 'occupied': {
          const dm = getDining(s?.partySize || 2);
          const seated = s?.occupiedAt ? now - new Date(s.occupiedAt).getTime() : 0;
          minsUntilFree = Math.max(0, Math.round((dm * 60000 - seated) / 60000)) + buffer;
          break;
        }
        case 'reserved':    minsUntilFree = (tss.reservationDurationMinutes || 90) + buffer; break;
        default:            minsUntilFree = Infinity;
      }
      return { id: t.id, label: t.label || '', capacity: t.capacity, minsUntilFree };
    });

    // Simulate queue: assign each party to the soonest available fitting table
    const assignments = [];
    const simTimeline = timeline.map(t => ({ ...t }));

    for (const party of queue) {
      const sz = party.partySize || 1;
      const eligible = simTimeline
        .filter(t => t.capacity >= sz && t.minsUntilFree !== Infinity)
        .sort((a, b) => a.minsUntilFree - b.minsUntilFree);

      if (!eligible.length) {
        assignments.push({ partyId: party.id, partyName: party.partyName, partySize: sz,
          minsWait: null, tableId: null, tableLabel: null, canSeatNow: false });
        continue;
      }
      const best = eligible[0];
      const minsWait = best.minsUntilFree;
      assignments.push({
        partyId:    party.id,
        partyName:  party.partyName,
        partySize:  sz,
        minsWait,
        tableId:    best.id,
        tableLabel: best.label,
        canSeatNow: minsWait === 0,
      });
      // Advance this table's availability by this party's dining time
      best.minsUntilFree = minsWait + getDining(sz) + buffer;
    }

    // autoSeat suggestion: the first party that can be seated RIGHT NOW
    const autoSeatSuggestion = assignments.find(a => a.canSeatNow) || null;

    res.json({ assignments, autoSeatSuggestion });
  } catch (err) { next(err); }
});
