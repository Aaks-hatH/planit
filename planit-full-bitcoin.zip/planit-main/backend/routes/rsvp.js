'use strict';

// ─────────────────────────────────────────────────────────────────────────────
// RSVP Routes  —  /api/rsvp
//
// Public endpoints (no auth required):
//   GET  /api/rsvp/:eventIdOrSlug/page          — public event info for the RSVP page
//   POST /api/rsvp/:eventIdOrSlug/track-view     — records one deduplicated page "open"
//   POST /api/rsvp/:eventIdOrSlug/submit         — submit an RSVP
//   GET  /api/rsvp/submission/:editToken         — guest views their own RSVP
//   PATCH /api/rsvp/submission/:editToken        — guest edits their own RSVP
//
// Organizer-only endpoints:
//   GET    /api/rsvp/:eventId/submissions        — list all submissions
//   PATCH  /api/rsvp/:eventId/submissions/:id    — update a submission
//   DELETE /api/rsvp/:eventId/submissions/:id    — delete a submission
//   POST   /api/rsvp/:eventId/submissions/:id/checkin  — check in a guest
//   GET    /api/rsvp/:eventId/export.csv         — CSV export
//   PATCH  /api/rsvp/:eventId/settings           — update RSVP page settings
//   GET    /api/rsvp/:eventId/stats              — submission stats
//   GET    /api/rsvp/:eventId/analytics          — opens vs. submissions (Analytics tab)
// ─────────────────────────────────────────────────────────────────────────────

const express  = require('express');
const router   = express.Router();
const crypto   = require('crypto');
const Event    = require('../models/Event');
const RSVPSubmission = require('../models/RSVPSubmission');
const { recordGuestIdentity } = require('../services/identityService');
const RSVPPageView = require('../models/RSVPPageView');
const WhiteLabel = require('../models/WhiteLabel');
const File     = require('../models/File');
const { verifyOrganizer } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');
const { meshPost } = require('../middleware/mesh');
const sanitizeHtml = require('sanitize-html');
const { migrateFlatConfigToSections } = require('../utils/rsvpPageMigration');
const { validateSections } = require('../utils/rsvpBlockSchema');
const { generateCover, TEMPLATES: COVER_TEMPLATES } = require('../services/coverGenerator');

// Allowed markup inside a richText block's content.html. This is authored
// through the builder's own rich-text editor, not pasted raw HTML from
// anywhere else, but it's sanitized here regardless before it's ever
// persisted — this is the only place that HTML reaches storage, and
// RSVPPageRenderer's RichTextBlock trusts that this has already happened.
const RICH_TEXT_ALLOWED_TAGS = ['p', 'b', 'strong', 'i', 'em', 'u', 'a', 'ul', 'ol', 'li', 'br', 'h1', 'h2', 'h3', 'blockquote'];
const RICH_TEXT_ALLOWED_ATTRS = { a: ['href', 'target', 'rel'] };
function sanitizeSectionsRichText(sections) {
  return sections.map((s) => {
    if (s.type !== 'richText' || !s.content?.html) return s;
    return {
      ...s,
      content: {
        ...s.content,
        html: sanitizeHtml(s.content.html, { allowedTags: RICH_TEXT_ALLOWED_TAGS, allowedAttributes: RICH_TEXT_ALLOWED_ATTRS }),
      },
    };
  });
}
const { sendRsvpGuestConfirmation, sendRsvpOrganizerNotification, buildRsvpGuestConfirmation } = require('../services/emailService');
const { analyzeRsvp } = require('../services/spamDetector');
const { verifyTurnstile } = require('../services/captchaService');
const { sendAntiAbuse } = require('../services/antiAbuseResponses');

const CALLER     = process.env.BACKEND_LABEL || 'Backend';
const ROUTER_URL = () => process.env.ROUTER_URL || '';

// Sends the guest's RSVP confirmation email. If the organizer has connected
// Gmail (used today only for their own "New RSVP" notifications), the guest
// confirmation goes out from that same real inbox instead of the no-reply
// relay — matching what the Notifications settings copy already promises
// ("...guest confirmations send from a real inbox instead of a no-reply
// address"). Falls back to the no-reply relay if Gmail isn't connected, or
// if the Gmail send fails for any reason.
async function sendGuestConfirmation(event, opts) {
  const gmailAuth = event.rsvpPage?.gmailAuth;
  const routerUrl = ROUTER_URL();
  if (routerUrl && gmailAuth?.connected && gmailAuth.refreshToken && opts.guestEmail) {
    const { subject, html } = buildRsvpGuestConfirmation(opts);
    const result = await meshPost(CALLER, `${routerUrl}/mesh/gmail-send`, {
      eventId:      String(event._id),
      to:           opts.guestEmail,
      fromEmail:    gmailAuth.email,
      accessToken:  gmailAuth.accessToken,
      refreshToken: gmailAuth.refreshToken,
      expiresAt:    gmailAuth.expiresAt,
      subject,
      html,
    }, { timeout: 15000 }).catch(() => ({ ok: false }));
    if (result.ok) return true;
    // Gmail send failed (expired grant, API error, etc.) — still get the
    // confirmation to the guest via the no-reply relay rather than dropping it.
  }
  return sendRsvpGuestConfirmation(opts);
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

// Resolve event by MongoDB ObjectId OR subdomain slug
async function resolveEvent(idOrSlug, selectExtra = '') {
  const isId = /^[0-9a-f]{24}$/i.test(idOrSlug);
  const query = isId
    ? Event.findById(idOrSlug)
    : Event.findOne({ subdomain: idOrSlug.toLowerCase() });
  if (selectExtra) query.select(selectExtra);
  return query.lean();
}

// Resolve whether the seating chart should be offered at checkout for this
// event. This is the single server-side source of truth — never trust a
// client-supplied flag. Mirrors the client-side gating pattern used for
// showGuestList/showWaitlist/showSocialShare (!isWL || flag), except the
// chart defaults OFF and is pro+-tier-gated, matching its WhiteLabel schema
// default and the tier check already enforced in wl-portal.js's
// PATCH /features route.
async function resolveSeatingChart(event) {
  const hasMap = !!(event.seatingMap?.enabled && (event.seatingMap.objects || []).length);
  if (!hasMap) return { enabled: false, objects: [], canvasW: 1000, canvasH: 700 };

  if (!event.wlDomain) {
    // Non-white-label event — organizer's own seatingMap.enabled is the gate.
    return {
      enabled: true,
      objects: event.seatingMap.objects,
      canvasW: event.seatingMap.canvasW || 1000,
      canvasH: event.seatingMap.canvasH || 700,
    };
  }

  const wl = await WhiteLabel.findOne({ domain: event.wlDomain }).select('tier features').lean();
  const allowed = !!wl && wl.tier !== 'basic' && wl.features?.showSeatingChart === true;
  return {
    enabled: allowed,
    objects: allowed ? event.seatingMap.objects : [],
    canvasW: event.seatingMap.canvasW || 1000,
    canvasH: event.seatingMap.canvasH || 700,
  };
}

// Safe IP extraction
function getClientIp(req) {
  return (
    req.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
    req.headers['x-real-ip'] ||
    req.connection?.remoteAddress ||
    ''
  );
}

// Salted, one-way, per-day hash used to deduplicate RSVP page "opens" (see
// RSVPPageView.js) — the same visitor reloading the page repeatedly in one
// day collapses to a single counted open, without ever persisting their
// raw IP. Falls back to a fixed key (still salted) if AUDIT_ENCRYPTION_KEY
// isn't set, so this never crashes the request — it just dedupes slightly
// less securely in that case.
const VIEW_SALT = process.env.AUDIT_ENCRYPTION_KEY || 'planit-rsvp-view-fallback-salt';
function buildViewSessionHash(req) {
  const day = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  const raw = `${getClientIp(req)}|${req.headers['user-agent'] || ''}|${day}|${VIEW_SALT}`;
  return crypto.createHash('sha256').update(raw).digest('hex');
}

// Generate a secure edit token
function generateEditToken() {
  return crypto.randomBytes(32).toString('hex');
}

// ─── Per-IP-per-event rate limiter ────────────────────────────────────────────
// Tracks submission timestamps keyed on `${eventId}:${ip}`.
// Entries older than RATE_WINDOW_MS are pruned every PRUNE_INTERVAL_MS.
const RATE_WINDOW_MS    = 60 * 60 * 1000; // 1 hour
const PRUNE_INTERVAL_MS =  5 * 60 * 1000; // 5 minutes
const _rateLimitMap = new Map(); // key → number[] (timestamps)

function checkRateLimit(eventId, ip, maxPerWindow) {
  const key  = `${eventId}:${ip}`;
  const now  = Date.now();
  const hits = (_rateLimitMap.get(key) || []).filter(t => now - t < RATE_WINDOW_MS);
  if (hits.length >= maxPerWindow) return false;
  hits.push(now);
  _rateLimitMap.set(key, hits);
  return true;
}

setInterval(() => {
  const now = Date.now();
  for (const [key, hits] of _rateLimitMap) {
    const fresh = hits.filter(t => now - t < RATE_WINDOW_MS);
    if (fresh.length === 0) _rateLimitMap.delete(key);
    else _rateLimitMap.set(key, fresh);
  }
}, PRUNE_INTERVAL_MS).unref();

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/:eventIdOrSlug/page
// Public — returns all info needed to render the RSVP page
// ─────────────────────────────────────────────────────────────────────────────
/**
 * Returns event.rsvpPageConfig, migrating it from the legacy flat rsvpPage
 * on first read if it hasn't happened yet. `event` here is often a `.lean()`
 * plain object (this route is public/high-traffic and reads leanly by
 * default), so on the rare cold-start path (migratedAt not set) this does
 * one extra full-document fetch + save — after that one-time write, every
 * subsequent request for this event takes the cheap read-only path.
 */
async function getOrMigratePageConfig(event) {
  if (event.rsvpPageConfig?.migratedAt) return event.rsvpPageConfig;

  const fullDoc = await Event.findById(event._id);
  if (!fullDoc) return event.rsvpPageConfig || { accentColor: '#6366f1', sections: [] };
  if (fullDoc.rsvpPageConfig?.migratedAt) return fullDoc.rsvpPageConfig; // migrated concurrently by another request

  const migrated = migrateFlatConfigToSections(fullDoc);
  fullDoc.rsvpPageConfig = { ...migrated, migratedAt: new Date(), updatedAt: new Date(), updatedBy: 'system:lazy-migration' };
  fullDoc.markModified('rsvpPageConfig');
  await fullDoc.save();
  return fullDoc.rsvpPageConfig;
}

/** Scans hero sections for a coverImageId and resolves it to a Cloudinary URL via the File model. */
async function resolveCoverUrls(sections) {
  const ids = (sections || [])
    .filter((s) => s.type === 'hero' && s.content?.coverImageId)
    .map((s) => s.content.coverImageId);
  if (!ids.length) return {};
  const files = await File.find({ _id: { $in: ids }, isDeleted: false }).select('_id cloudinaryUrl');
  return Object.fromEntries(files.map((f) => [String(f._id), f.cloudinaryUrl]));
}

/**
 * The first hero section's cover image, for social-share metadata.
 *
 * There are two ways a hero cover ends up on a section, and until now only
 * one of them was ever surfaced to callers outside RSVPPageRenderer:
 *   - content.coverImageId  -> a tracked File doc, resolved via coverUrlsById
 *   - content.coverImageUrl -> set DIRECTLY by BlockContentEditor's normal
 *                              "Upload Cover" flow (see frontend/src/
 *                              components/rsvpBlocks/BlockContentEditor.jsx),
 *                              which is how most organizers actually set a
 *                              cover today.
 * RSVPPageRenderer.jsx already prefers the direct URL over the File lookup
 * when rendering the page for real visitors — this mirrors that same
 * precedence so link-preview crawlers see the same cover a visitor does,
 * instead of silently falling back to the generic PlanIt image.
 */
function resolveHeroCoverUrl(sections, coverUrlsById) {
  const hero = (sections || []).find((s) => s.type === 'hero');
  if (!hero) return null;
  return hero.content?.coverImageUrl || coverUrlsById[hero.content?.coverImageId] || null;
}

router.get('/:eventIdOrSlug/page', async (req, res, next) => {
  // Dynamic, guest-facing, and reflects live state (counts, spotsLeft,
  // isFull, deadlinePast). Must never be conditionally cached — Express's
  // default ETag turns an unchanged byte-for-byte response into a 304,
  // which axios's default validateStatus (200-299) rejects as an error,
  // surfacing as a false "RSVP not found" on the guest page.
  res.set('Cache-Control', 'no-store');
  try {
    const event = await resolveEvent(req.params.eventIdOrSlug);
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const rsvpPage = event.rsvpPage || {};

    // Build submission counts for display
    const submissionCounts = await RSVPSubmission.aggregate([
      { $match: { eventId: event._id, deletedAt: null, status: { $in: ['confirmed', 'pending'] } } },
      { $group: { _id: '$response', count: { $sum: 1 }, totalAttendees: { $sum: { $add: ['$plusOnes', 1] } } } },
    ]);

    const counts = { yes: 0, maybe: 0, no: 0, totalAttendees: 0 };
    submissionCounts.forEach(({ _id, count, totalAttendees }) => {
      counts[_id] = count;
      if (_id === 'yes') counts.totalAttendees = totalAttendees;
    });

    // Determine capacity status
    const capacityLimit = rsvpPage.capacityLimit || 0;
    const yesCount = counts.yes;
    const isFull = capacityLimit > 0 && yesCount >= capacityLimit;
    const spotsLeft = capacityLimit > 0 ? Math.max(0, capacityLimit - yesCount) : null;

    // Determine deadline status
    const deadlinePast = rsvpPage.deadline ? new Date() > new Date(rsvpPage.deadline) : false;

    // Seating chart — server-resolved, tier/flag-checked (see resolveSeatingChart)
    const seatingChart = await resolveSeatingChart(event);
    let tableOccupancy = {};
    if (seatingChart.enabled) {
      const occRows = await RSVPSubmission.aggregate([
        { $match: { eventId: event._id, deletedAt: null, status: { $in: ['confirmed', 'pending'] }, selectedTableId: { $ne: null } } },
        { $group: { _id: '$selectedTableId', occupied: { $sum: { $add: ['$plusOnes', 1] } } } },
      ]);
      occRows.forEach(r => { tableOccupancy[r._id] = r.occupied; });
    }

    // If closed, return minimal info
    if (rsvpPage.accessMode === 'closed') {
      return res.json({
        eventId:     event._id,
        subdomain:   event.subdomain,
        title:       event.title,
        rsvpPage:    { enabled: false, accessMode: 'closed' },
        rsvpPageConfig: event.rsvpPageConfig || { accentColor: '#6366f1', sections: [] },
        coverUrlsById: {},
        closed:      true,
      });
    }

    // Return public-safe event info + RSVP page config
    // Never return credentials or organizer-private fields from this public
    // endpoint. gmailAuth's accessToken/refreshToken are select:false at the
    // schema level now (so they can't come back even by accident), but strip
    // the whole object anyway — connected/email/expiresAt are still nobody
    // else's business, and a denylist here is exactly what let gmailAuth
    // leak in the first place once, so keep this list deliberately explicit.
    const { rsvpPassword: _pw, gmailAuth: _gmailAuth, organizerNotifyEmail: _orgNotifyEmail, ...safePage } = rsvpPage;

    const rsvpPageConfig = await getOrMigratePageConfig(event);
    const coverUrlsById = await resolveCoverUrls(rsvpPageConfig.sections);

    res.json({
      eventId:       event._id,
      subdomain:     event.subdomain,
      title:         rsvpPage.welcomeTitle || event.title,
      rawTitle:      event.title,
      description:   event.description,
      date:          event.date,
      timezone:      event.timezone,
      location:      event.location,
      organizerName: event.organizerName,
      isEnterpriseMode: event.isEnterpriseMode,
      rsvpPage:      safePage,
      rsvpPageConfig,
      coverUrlsById,
      heroCoverUrl:  resolveHeroCoverUrl(rsvpPageConfig.sections, coverUrlsById),
      counts:        rsvpPage.showGuestCount !== false ? counts : null,
      spotsLeft,
      isFull,
      deadlinePast,
      requiresPassword: rsvpPage.accessMode === 'password',
      seatingChartEnabled: seatingChart.enabled,
      seatingMap: seatingChart.enabled
        ? { objects: seatingChart.objects, canvasW: seatingChart.canvasW, canvasH: seatingChart.canvasH }
        : null,
      tableOccupancy,
    });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/rsvp/:eventIdOrSlug/track-view
// Public — records one deduplicated "open" of the RSVP page (see
// RSVPPageView.js). Called fire-and-forget from RSVPPage.jsx after the page
// data has loaded — never from the bot-preview path in server.js, since
// that path never runs client JS, so link-preview crawlers (WhatsApp,
// Facebook, etc.) never inflate this count.
// Always responds 204 and never throws to the client — a tracking failure
// must never be visible to a guest or block them from RSVPing.
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:eventIdOrSlug/track-view', async (req, res) => {
  try {
    const event = await resolveEvent(req.params.eventIdOrSlug, '_id');
    if (!event) return res.status(204).end();

    await RSVPPageView.create({
      eventId:     event._id,
      sessionHash: buildViewSessionHash(req),
    });
  } catch (err) {
    // E11000 duplicate key = this visitor already counted today; anything
    // else is logged but still never surfaced to the guest.
    if (err?.code !== 11000) console.warn('[rsvp track-view]', err.message);
  }
  res.status(204).end();
});


router.post('/:eventIdOrSlug/submit', async (req, res, next) => {
  try {
    const event = await resolveEvent(
      req.params.eventIdOrSlug,
      '+rsvpPage.rsvpPassword +rsvpPage.gmailAuth.accessToken +rsvpPage.gmailAuth.refreshToken'
    );
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const rsvpPage = event.rsvpPage || {};

    if (!rsvpPage.enabled) {
      return res.status(403).json({ error: 'RSVP is not enabled for this event.' });
    }
    if (rsvpPage.accessMode === 'closed') {
      return res.status(403).json({ error: 'This event is no longer accepting RSVPs.' });
    }

    // Password check
    if (rsvpPage.accessMode === 'password') {
      const { pagePassword } = req.body;
      if (!pagePassword || pagePassword !== rsvpPage.rsvpPassword) {
        return res.status(403).json({ error: 'Incorrect password.', requiresPassword: true });
      }
    }

    // Deadline check
    if (rsvpPage.deadline && new Date() > new Date(rsvpPage.deadline)) {
      return res.status(403).json({ error: rsvpPage.deadlineMessage || 'The RSVP deadline has passed.' });
    }

    // Honeypot check (bot trap field must be empty)
    if (rsvpPage.enableHoneypot !== false && req.body._hp) {
      // Silently accept but do not store
      return res.json({ success: true, editToken: generateEditToken() });
    }

    // Per-IP rate limit
    const ip         = getClientIp(req);
    const maxPerHour = rsvpPage.rateLimitPerIp ?? 5;
    if (maxPerHour > 0 && !checkRateLimit(event._id.toString(), ip, maxPerHour)) {
      return res.status(429).json({ error: 'Too many RSVP submissions from your network. Please try again later.' });
    }

    const {
      response,
      firstName,
      lastName,
      email,
      phone,
      plusOnes,
      plusOneDetails,
      dietaryRestrictions,
      accessibilityNeeds,
      customAnswers,
      guestNote,
      selectedTableId,
    } = req.body;

    // Validate response
    const allowed = [];
    if (rsvpPage.allowYes !== false) allowed.push('yes');
    if (rsvpPage.allowMaybe !== false) allowed.push('maybe');
    if (rsvpPage.allowNo !== false) allowed.push('no');
    if (!allowed.includes(response)) {
      return res.status(400).json({ error: 'Invalid RSVP response.' });
    }

    // Required field validation
    if (!firstName?.trim()) {
      return res.status(400).json({ error: 'First name is required.' });
    }
    if (rsvpPage.requireLastName && !lastName?.trim()) {
      return res.status(400).json({ error: 'Last name is required.' });
    }
    if (rsvpPage.requireEmail && !email?.trim()) {
      return res.status(400).json({ error: 'Email address is required.' });
    }
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: 'Please provide a valid email address.' });
    }
    if (rsvpPage.requirePhone && !phone?.trim()) {
      return res.status(400).json({ error: 'Phone number is required.' });
    }

    // Capacity check (only for 'yes' responses)
    if (response === 'yes') {
      const capacityLimit = rsvpPage.capacityLimit || 0;
      if (capacityLimit > 0) {
        const yesCount = await RSVPSubmission.countDocuments({
          eventId:  event._id,
          response: 'yes',
          status:   { $in: ['confirmed', 'pending'] },
          deletedAt: null,
        });
        if (yesCount >= capacityLimit) {
          if (rsvpPage.enableWaitlist !== false) {
            // Put on waitlist
            const editToken = generateEditToken();
            const submission = await RSVPSubmission.create({
              eventId:   event._id,
              response,
              firstName: firstName.trim(),
              lastName:  lastName?.trim() || '',
              email:     email?.trim().toLowerCase() || '',
              phone:     phone?.trim() || '',
              plusOnes:  Number(plusOnes) || 0,
              plusOneDetails: Array.isArray(plusOneDetails) ? plusOneDetails.slice(0, rsvpPage.maxPlusOnes || 5) : [],
              dietaryRestrictions: dietaryRestrictions?.trim() || '',
              accessibilityNeeds:  accessibilityNeeds?.trim() || '',
              customAnswers:       Array.isArray(customAnswers) ? customAnswers : [],
              guestNote:           guestNote?.trim() || '',
              status:    'waitlisted',
              editToken,
              ipAddress: getClientIp(req),
              userAgent: req.headers['user-agent'] || '',
            });
            // Fire-and-forget: send waitlist confirmation to guest. (This used to
            // sit after the `return` below and could never actually run.)
            if (rsvpPage.sendGuestConfirmation && email?.trim()) {
              sendGuestConfirmation(event, {
                guestEmail:      email.trim().toLowerCase(),
                guestFirstName:  firstName.trim(),
                guestName:       `${firstName.trim()}${lastName?.trim() ? ' ' + lastName.trim() : ''}`,
                eventTitle:      event.title,
                eventDate:       event.date || null,
                eventTimezone:       event.timezone || 'UTC',
                eventLocation:   event.location || null,
                response,
                status:          'waitlisted',
                plusOnes:        Number(plusOnes) || 0,
                editToken,
                customSubject:   rsvpPage.confirmationEmailSubject || null,
                customBody:      rsvpPage.confirmationEmailBody    || null,
                organizerEmail:  rsvpPage.organizerNotifyEmail?.trim() || event.organizerEmail || null,
              }).then((sent) => {
                if (sent) {
                  RSVPSubmission.updateOne(
                    { _id: submission._id },
                    { confirmationEmailSent: true, confirmationEmailSentAt: new Date() }
                  ).catch(() => {});
                }
              }).catch(() => {});
            }
            recordGuestIdentity(req, { event, firstName, lastName, email, phone, rsvpStatus: 'waitlist' });
            return res.json({
              success:   true,
              waitlisted: true,
              message:   rsvpPage.waitlistMessage || 'You have been added to the waitlist.',
              editToken,
              submissionId: submission._id,
            });
          }
          return res.status(409).json({ error: 'This event has reached capacity.' });
        }
      }
    }

    // Seating chart selection (checkout) — re-resolve server-side, never trust
    // the client's boolean. Only meaningful for confirmed 'yes' attendance;
    // waitlisted guests are handled above and never reach here.
    let selectedTableLabel = '';
    let validatedTableId = null;
    if (selectedTableId) {
      const seatingChart = await resolveSeatingChart(event);
      if (!seatingChart.enabled) {
        return res.status(403).json({ error: 'Seating selection is not available for this event.' });
      }
      const table = seatingChart.objects.find(o => o.id === selectedTableId);
      if (!table) {
        return res.status(400).json({ error: 'Selected table no longer exists.' });
      }
      if (table.type === 'zone' || table.type === 'stage') {
        return res.status(400).json({ error: 'That is not a seatable table.' });
      }
      const requestedSeats = 1 + (Number(plusOnes) || 0);
      const [occRow] = await RSVPSubmission.aggregate([
        { $match: { eventId: event._id, deletedAt: null, status: { $in: ['confirmed', 'pending'] }, selectedTableId } },
        { $group: { _id: null, occupied: { $sum: { $add: ['$plusOnes', 1] } } } },
      ]);
      const occupied = occRow?.occupied || 0;
      if (table.capacity > 0 && occupied + requestedSeats > table.capacity) {
        return res.status(409).json({ error: 'That table no longer has enough open seats.' });
      }
      validatedTableId = table.id;
      selectedTableLabel = table.label || '';
    }

    // Duplicate email check
    let isDuplicateSubmission = false;
    if (email && rsvpPage.duplicateEmailPolicy !== 'allow') {
      const existing = await RSVPSubmission.findOne({
        eventId: event._id,
        email:   email.trim().toLowerCase(),
        deletedAt: null,
      }).lean();
      if (existing) {
        if (rsvpPage.duplicateEmailPolicy === 'block') {
          return res.status(409).json({
            error: 'An RSVP from this email address already exists.',
            existingToken: existing.editToken,
          });
        }
        // warn_organizer — continue but flag the submission as a duplicate
        isDuplicateSubmission = true;
      }
    }

    // Determine initial status
    // Accept both legacy 'approval' and current UI value 'manual_approval'
    const requiresApproval = rsvpPage.confirmationMode === 'approval' || rsvpPage.confirmationMode === 'manual_approval';

    // ── Spam analysis ───────────────────────────────────────────────────────
    // Run before saving so we can block outright (score >= 60) or force-pending
    // (score 30–59) without creating a submission at all if it's a hard block.
    const submitterIp = getClientIp(req);
    const spamResult = await analyzeRsvp({
      eventId:   String(event._id),
      firstName: firstName?.trim() || '',
      lastName:  lastName?.trim()  || '',
      email:     email?.trim()     || '',
      phone:     phone?.trim()     || '',
      guestNote: guestNote?.trim() || '',
      plusOnes:  Number(plusOnes)  || 0,
      ip:        submitterIp,
      userAgent: req.headers['user-agent'] || '',
      honeypot:  req.body._hp || '',
      browserMeta: req.body.browserMeta || {},
      behavior: req.body.behavior || {},
    }).catch(() => ({ score: 0, flags: [], verdict: 'clean', shouldBlock: false }));

    // Hard block: generic response only; do not disclose which internal control fired.
    if (spamResult.shouldBlock) {
      return sendAntiAbuse(res, 'tryAgainLater');
    }

    // Moderate risk requires CAPTCHA verification.
    // IMPORTANT: if a token is present, verify it BEFORE checking verdict again.
    // Do NOT re-evaluate the spam score after a valid CAPTCHA solve — the velocity
    // counters increment on every request, so a resubmission would score higher
    // than the first attempt and could block a user who just passed the challenge.
    let captchaCleared = false;
    if (spamResult.verdict === 'review') {
      if (!req.body.turnstileToken) {
        return sendAntiAbuse(res, 'verificationRequired', { requiresVerification: true });
      }
      const tsResult = await verifyTurnstile(req.body.turnstileToken, submitterIp, { failOpen: false, context: 'rsvp-submit' });
      if (!tsResult.ok) {
        return sendAntiAbuse(res, 'invalidVerification', { requiresVerification: true });
      }
      // Token verified — CAPTCHA passed, treat submission as cleared
      captchaCleared = true;
    }

    // Soft flag: force to pending review — but not if CAPTCHA was passed
    const isSpamSuspect = spamResult.verdict === 'review' && !captchaCleared;
    const status = (requiresApproval || isSpamSuspect) ? 'pending' : 'confirmed';

    const editToken = generateEditToken();
    const submission = await RSVPSubmission.create({
      eventId:   event._id,
      response,
      firstName: firstName.trim(),
      lastName:  lastName?.trim() || '',
      email:     email?.trim().toLowerCase() || '',
      phone:     phone?.trim() || '',
      plusOnes:  Number(plusOnes) || 0,
      plusOneDetails: Array.isArray(plusOneDetails) ? plusOneDetails.slice(0, rsvpPage.maxPlusOnes || 5) : [],
      dietaryRestrictions: dietaryRestrictions?.trim() || '',
      accessibilityNeeds:  accessibilityNeeds?.trim() || '',
      customAnswers:       Array.isArray(customAnswers) ? customAnswers : [],
      guestNote:           guestNote?.trim() || '',
      selectedTableId:     validatedTableId,
      selectedTableLabel,
      status,
      editToken,
      duplicateFlag: isDuplicateSubmission,
      ipAddress: submitterIp,
      userAgent: req.headers['user-agent'] || '',
      // Keep organizer-facing notes generic so internal anti-abuse details are not exposed.
      ...(isSpamSuspect ? { organizerNotes: 'Additional review was requested before confirmation.' } : {}),
    });

    recordGuestIdentity(req, { event, firstName, lastName, email, phone, rsvpStatus: ['yes', 'maybe', 'no'].includes(response) ? response : null });

    res.status(201).json({
      success:     true,
      submissionId: submission._id,
      editToken,
      status,
      isPending:   status === 'pending',
      message:     status === 'pending'
        ? 'Your RSVP has been submitted and is awaiting approval.'
        : (rsvpPage.confirmationMessage || 'Your RSVP has been confirmed.'),
    });

    // Fire-and-forget: send confirmation email to the guest
    if (rsvpPage.sendGuestConfirmation && email?.trim()) {
      sendGuestConfirmation(event, {
        guestEmail:     email.trim().toLowerCase(),
        guestFirstName: firstName.trim(),
        guestName:      `${firstName.trim()}${lastName?.trim() ? ' ' + lastName.trim() : ''}`,
        eventTitle:     event.title,
        eventDate:      event.date || null,
        eventTimezone:      event.timezone || 'UTC',
        eventLocation:  event.location || null,
        response,
        status,
        plusOnes:       Number(plusOnes) || 0,
        editToken,
        customSubject:  rsvpPage.confirmationEmailSubject || null,
        customBody:     rsvpPage.confirmationEmailBody    || null,
        // Used as Reply-To when the send falls back to the no-reply relay,
        // so guests replying to their confirmation reach the organizer.
        organizerEmail: rsvpPage.organizerNotifyEmail?.trim() || event.organizerEmail || null,
      }).then((sent) => {
        if (sent) {
          RSVPSubmission.updateOne(
            { _id: submission._id },
            { confirmationEmailSent: true, confirmationEmailSentAt: new Date() }
          ).catch(() => {});
        }
      }).catch(() => {});
    }

    // Fire-and-forget: send Gmail RSVP notification to organizer if connected,
    // otherwise fall back to the no-reply relay sent as the organizer's own
    // address, so the organizer is always notified either way.
    if (rsvpPage.notifyOrganizerOnRsvp !== false) {
      const routerUrl = ROUTER_URL();
      const gmailAuth = event.rsvpPage?.gmailAuth;
      const notifyTo = rsvpPage.organizerNotifyEmail?.trim() || event.organizerEmail || '';
      if (notifyTo) {
        if (routerUrl && gmailAuth?.connected && gmailAuth.refreshToken) {
          meshPost(CALLER, `${routerUrl}/mesh/gmail-send`, {
            eventId:      String(event._id),
            to:           notifyTo,
            fromEmail:    gmailAuth.email,
            accessToken:  gmailAuth.accessToken,
            refreshToken: gmailAuth.refreshToken,
            expiresAt:    gmailAuth.expiresAt,
            guestName:    `${firstName.trim()}${lastName?.trim() ? ' ' + lastName.trim() : ''}`,
            guestEmail:   email?.trim() || '',
            guestPhone:   phone?.trim() || '',
            response:     submission.response,
            status:       submission.status,
            plusOnes:     Number(plusOnes) || 0,
            eventTitle:   event.title,
            eventDate:    event.date || null,
            eventTimezone:    event.timezone || 'UTC',
          }, { timeout: 15000 }).catch(() => {
            // Gmail send failed — still get the notification out via the relay.
            sendRsvpOrganizerNotification({
              organizerEmail: notifyTo,
              guestName:      `${firstName.trim()}${lastName?.trim() ? ' ' + lastName.trim() : ''}`,
              guestEmail:     email?.trim() || '',
              guestPhone:     phone?.trim() || '',
              response:       submission.response,
              status:         submission.status,
              plusOnes:       Number(plusOnes) || 0,
              eventTitle:     event.title,
              eventDate:      event.date || null,
              eventTimezone:      event.timezone || 'UTC',
            }).catch(() => {});
          });
        } else {
          sendRsvpOrganizerNotification({
            organizerEmail: notifyTo,
            guestName:      `${firstName.trim()}${lastName?.trim() ? ' ' + lastName.trim() : ''}`,
            guestEmail:     email?.trim() || '',
            guestPhone:     phone?.trim() || '',
            response:       submission.response,
            status:         submission.status,
            plusOnes:       Number(plusOnes) || 0,
            eventTitle:     event.title,
            eventDate:      event.date || null,
            eventTimezone:      event.timezone || 'UTC',
          }).catch(() => {});
        }
      }
    }
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/submission/:editToken
// Public — guest views their own RSVP
// ─────────────────────────────────────────────────────────────────────────────
router.get('/submission/:editToken', async (req, res, next) => {
  try {
    const submission = await RSVPSubmission.findOne({
      editToken: req.params.editToken,
      deletedAt: null,
    }).lean();
    if (!submission) return res.status(404).json({ error: 'RSVP not found.' });

    const event = await Event.findById(submission.eventId)
      .select('title date timezone location rsvpPage')
      .lean();

    res.json({ submission, event });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// PATCH /api/rsvp/submission/:editToken
// Public — guest edits their own RSVP
// ─────────────────────────────────────────────────────────────────────────────
router.patch('/submission/:editToken', async (req, res, next) => {
  try {
    const submission = await RSVPSubmission.findOne({
      editToken: req.params.editToken,
      deletedAt: null,
    });
    if (!submission) return res.status(404).json({ error: 'RSVP not found.' });

    // Check edit cutoff
    const event = await Event.findById(submission.eventId).select('rsvpPage').lean();
    const rsvpPage = event?.rsvpPage || {};
    const cutoffHours = rsvpPage.editCutoffHours ?? 24;
    if (rsvpPage.allowGuestEdit === false) {
      return res.status(403).json({ error: 'Editing RSVPs is not allowed for this event.' });
    }
    if (event?.date && cutoffHours > 0) {
      const cutoff = new Date(event.date);
      cutoff.setHours(cutoff.getHours() - cutoffHours);
      if (new Date() > cutoff) {
        return res.status(403).json({ error: 'The edit window for this RSVP has closed.' });
      }
    }

    const allowed = [];
    if (rsvpPage.allowYes !== false) allowed.push('yes');
    if (rsvpPage.allowMaybe !== false) allowed.push('maybe');
    if (rsvpPage.allowNo !== false) allowed.push('no');

    const {
      response, firstName, lastName, email, phone,
      plusOnes, plusOneDetails, dietaryRestrictions,
      accessibilityNeeds, customAnswers, guestNote,
    } = req.body;

    if (response && !allowed.includes(response)) {
      return res.status(400).json({ error: 'Invalid RSVP response.' });
    }
    if (response) submission.response = response;
    if (firstName !== undefined) submission.firstName = firstName.trim();
    if (lastName  !== undefined) submission.lastName  = lastName.trim();
    if (email     !== undefined) submission.email     = email.trim().toLowerCase();
    if (phone     !== undefined) submission.phone     = phone.trim();
    if (plusOnes  !== undefined) submission.plusOnes  = Number(plusOnes) || 0;
    if (Array.isArray(plusOneDetails)) submission.plusOneDetails = plusOneDetails.slice(0, rsvpPage.maxPlusOnes || 5);
    if (dietaryRestrictions !== undefined) submission.dietaryRestrictions = dietaryRestrictions.trim();
    if (accessibilityNeeds  !== undefined) submission.accessibilityNeeds  = accessibilityNeeds.trim();
    if (Array.isArray(customAnswers))      submission.customAnswers        = customAnswers;
    if (guestNote !== undefined)           submission.guestNote            = guestNote.trim();
    submission.updatedAt = new Date();

    await submission.save();
    res.json({ success: true, submission });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/rsvp/:eventId/verify-password
// Public — verify RSVP page password
// FIX: Added authLimiter — this route was unprotected, allowing unlimited brute-force
// attempts against RSVP page passwords.
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:eventId/verify-password', authLimiter, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId)
      .select('+rsvpPage.rsvpPassword rsvpPage.accessMode')
      .lean();
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const { password } = req.body;
    const stored = event.rsvpPage?.rsvpPassword;

    if (!stored || password === stored) {
      return res.json({ success: true });
    }
    res.status(403).json({ error: 'Incorrect password.' });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// ─── ORGANIZER-ONLY ROUTES ────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/:eventId/settings
// Organizer — get current RSVP page settings (with password)
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:eventId/settings', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId)
      .select('rsvpPage subdomain title wlDomain')
      .lean();
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    // Surface whether this event's seating chart is WL-tier/feature-gated so
    // the RSVP Page Builder can explain *why* it may not appear to guests,
    // mirroring the same tier/feature check resolveSeatingChart() enforces
    // server-side at RSVP time. Non-white-label events get seatingWlGate: null
    // (their seatingMap.enabled is the only gate — see resolveSeatingChart above).
    let seatingWlGate = null;
    if (event.wlDomain) {
      const wl = await WhiteLabel.findOne({ domain: event.wlDomain }).select('tier features').lean();
      seatingWlGate = {
        isWhiteLabel:            true,
        tier:                    wl?.tier || null,
        showSeatingChartAllowed: !!wl && wl.tier !== 'basic' && wl.features?.showSeatingChart === true,
      };
    }

    res.json({
      rsvpPage:  event.rsvpPage || {},
      subdomain: event.subdomain,
      title:     event.title,
      seatingWlGate,
    });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// PATCH /api/rsvp/:eventId/settings
// Organizer — update RSVP page settings
// ─────────────────────────────────────────────────────────────────────────────
router.patch('/:eventId/settings', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const ALLOWED = [
      'enabled', 'accessMode', 'rsvpPassword', 'confirmationMode',
      'coverImageUrl', 'logoUrl', 'backgroundImageUrl', 'accentColor', 'backgroundStyle', 'fontStyle',
      'bannerText', 'bannerColor', 'bannerEnabled', 'hideBranding',
      'heroTagline', 'welcomeTitle', 'welcomeMessage',
      'deadline', 'deadlineMessage', 'capacityLimit', 'enableWaitlist', 'waitlistMessage',
      'allowYes', 'allowMaybe', 'allowNo', 'yesButtonLabel', 'maybeButtonLabel', 'noButtonLabel',
      'requireFirstName', 'requireLastName',
      'collectEmail', 'requireEmail', 'collectPhone', 'requirePhone',
      'allowPlusOnes', 'maxPlusOnes', 'requirePlusOneNames', 'collectPlusOneDietary',
      'collectDietary', 'dietaryLabel', 'collectAccessibility', 'accessibilityLabel',
      'allowGuestNote', 'guestNoteLabel', 'guestNotePlaceholder',
      'customQuestions',
      'confirmationTitle', 'confirmationMessage', 'confirmationImageUrl',
      'showEventSpaceButton', 'eventSpaceButtonLabel', 'showAddToCalendar', 'showShareButton',
      'sendGuestConfirmation', 'confirmationEmailSubject', 'confirmationEmailBody',
      'notifyOrganizerOnRsvp', 'organizerNotifyEmail',
      'showGuestCount', 'showEventDate', 'showEventLocation', 'showEventDescription',
      'showHostName', 'showCountdown', 'allowGuestEdit', 'editCutoffHours',
      'rateLimitPerIp', 'duplicateEmailPolicy', 'enableHoneypot',
    ];

    if (!event.rsvpPage) event.rsvpPage = {};

    ALLOWED.forEach(key => {
      if (req.body[key] !== undefined) {
        event.rsvpPage[key] = req.body[key];
      }
    });

    // Coerce deadline
    if (req.body.deadline !== undefined) {
      event.rsvpPage.deadline = req.body.deadline ? new Date(req.body.deadline) : null;
    }

    event.rsvpPage.updatedAt = new Date();
    event.rsvpPage.updatedBy = req.eventAccess?.username || '';
    event.markModified('rsvpPage');
    await event.save();

    const { rsvpPassword: _pw, ...safePage } = event.rsvpPage.toObject
      ? event.rsvpPage.toObject()
      : event.rsvpPage;

    res.json({ success: true, rsvpPage: safePage });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/:eventId/page-config
// Organizer — fetch the section-based builder config (Part 2/4).
// Lazily migrates from the legacy flat `rsvpPage` the first time this is
// requested for a given event (rsvpPageConfig.migratedAt is null), so
// every event gets a valid sections array without needing a separate
// blocking backfill step. Safe to call repeatedly: once migratedAt is set,
// this is a plain read.
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:eventId/page-config', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    if (!event.rsvpPageConfig?.migratedAt) {
      const migrated = migrateFlatConfigToSections(event);
      event.rsvpPageConfig = { ...migrated, migratedAt: new Date(), updatedAt: new Date(), updatedBy: req.eventAccess?.username || '' };
      event.markModified('rsvpPageConfig');
      await event.save();
    }

    const { rsvpPassword: _pw, ...safeFlatSettings } = (event.rsvpPage?.toObject ? event.rsvpPage.toObject() : event.rsvpPage) || {};

    res.json({
      rsvpPageConfig: event.rsvpPageConfig,
      flatSettings: safeFlatSettings, // read-only context the rsvpForm block needs (field toggles, custom questions, etc.)
      seatingMapEnabled: !!event.seatingMap?.enabled,
      eventType: event.eventType,
      coverTemplates: COVER_TEMPLATES,
      subdomain: event.subdomain,
      title: event.title,
    });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// PATCH /api/rsvp/:eventId/page-config
// Organizer — persist section reordering/edits from the drag-and-drop builder.
// Validated server-side (see rsvpBlockSchema.js) independent of whatever the
// builder UI already enforces client-side, since this endpoint can be hit
// directly. Rejects the whole payload on the first problem rather than
// partially applying it.
// ─────────────────────────────────────────────────────────────────────────────
router.patch('/:eventId/page-config', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const { accentColor, sections } = req.body;

    let validated;
    try {
      validated = validateSections(sections);
    } catch (validationErr) {
      return res.status(validationErr.statusCode || 400).json({ error: validationErr.message });
    }
    const cleanSections = sanitizeSectionsRichText(validated);

    if (accentColor !== undefined && !/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(accentColor)) {
      return res.status(400).json({ error: 'accentColor must be a hex color.' });
    }

    event.rsvpPageConfig = {
      accentColor: accentColor || event.rsvpPageConfig?.accentColor || '#6366f1',
      sections: cleanSections,
      migratedAt: event.rsvpPageConfig?.migratedAt || new Date(),
      updatedAt: new Date(),
      updatedBy: req.eventAccess?.username || '',
    };
    event.markModified('rsvpPageConfig');
    await event.save();

    res.json({ success: true, rsvpPageConfig: event.rsvpPageConfig });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/rsvp/:eventId/cover
// Organizer — (re)generate the hero cover graphic (Part 5). Body:
// { template, accentColor, hostPhotoUrl?, logoUrl? }. Regenerates only when
// called — the builder should only call this when the organizer changes the
// template/accent/photo, not on every render (see coverGenerator.js caching).
// Returns the coverImageId (a Files _id) the hero block's content.coverImageId
// should be set to.
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:eventId/cover', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId).select('title date timezone organizerName');
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const { template, accentColor, hostPhotoUrl, logoUrl } = req.body;
    if (!COVER_TEMPLATES.includes(template)) {
      return res.status(400).json({ error: `template must be one of: ${COVER_TEMPLATES.join(', ')}` });
    }

    const cover = await generateCover(event, { template, accentColor, hostPhotoUrl, logoUrl });
    res.json({ success: true, ...cover });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/:eventId/submissions
// Organizer — list all submissions with filtering + pagination
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:eventId/submissions', verifyOrganizer, async (req, res, next) => {
  try {
    const {
      status, response, search, starred,
      page = 1, limit = 50, sort = '-submittedAt',
    } = req.query;

    const filter = {
      eventId:   req.params.eventId,
      deletedAt: null,
    };

    if (status)   filter.status   = status;
    if (response) filter.response = response;
    if (starred === 'true') filter.starred = true;

    if (search) {
      const re = new RegExp(search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      filter.$or = [
        { firstName: re },
        { lastName:  re },
        { email:     re },
        { phone:     re },
      ];
    }

    const total = await RSVPSubmission.countDocuments(filter);
    const submissions = await RSVPSubmission
      .find(filter)
      .sort(sort)
      .skip((Number(page) - 1) * Number(limit))
      .limit(Number(limit))
      .lean();

    // Aggregate stats
    const stats = await RSVPSubmission.aggregate([
      { $match: { eventId: require('mongoose').Types.ObjectId.createFromHexString
          ? require('mongoose').Types.ObjectId.createFromHexString(req.params.eventId)
          : new (require('mongoose').Types.ObjectId)(req.params.eventId),
        deletedAt: null } },
      { $group: {
          _id: null,
          totalYes:   { $sum: { $cond: [{ $eq: ['$response', 'yes'] }, 1, 0] } },
          totalMaybe: { $sum: { $cond: [{ $eq: ['$response', 'maybe'] }, 1, 0] } },
          totalNo:    { $sum: { $cond: [{ $eq: ['$response', 'no'] }, 1, 0] } },
          totalAttendees: { $sum: { $cond: [{ $eq: ['$response', 'yes'] }, { $add: ['$plusOnes', 1] }, 0] } },
          pending:    { $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] } },
          waitlisted: { $sum: { $cond: [{ $eq: ['$status', 'waitlisted'] }, 1, 0] } },
          checkedIn:  { $sum: { $cond: ['$checkedIn', 1, 0] } },
      }},
    ]);

    res.json({
      submissions,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      stats: stats[0] || { totalYes: 0, totalMaybe: 0, totalNo: 0, totalAttendees: 0, pending: 0, waitlisted: 0, checkedIn: 0 },
    });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// PATCH /api/rsvp/:eventId/submissions/:submissionId
// Organizer — update a submission (status, notes, tags, starred)
// ─────────────────────────────────────────────────────────────────────────────
router.patch('/:eventId/submissions/:submissionId', verifyOrganizer, async (req, res, next) => {
  try {
    const submission = await RSVPSubmission.findOne({
      _id:     req.params.submissionId,
      eventId: req.params.eventId,
    });
    if (!submission) return res.status(404).json({ error: 'Submission not found.' });

    const EDITABLE = [
      'status', 'response', 'organizerNotes', 'tags', 'starred',
      'firstName', 'lastName', 'email', 'phone',
      'plusOnes', 'plusOneDetails', 'dietaryRestrictions',
      'accessibilityNeeds', 'guestNote',
    ];

    EDITABLE.forEach(key => {
      if (req.body[key] !== undefined) submission[key] = req.body[key];
    });
    submission.updatedAt = new Date();
    await submission.save();

    res.json({ success: true, submission });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// DELETE /api/rsvp/:eventId/submissions/:submissionId
// Organizer — soft-delete a submission
// ─────────────────────────────────────────────────────────────────────────────
router.delete('/:eventId/submissions/:submissionId', verifyOrganizer, async (req, res, next) => {
  try {
    const submission = await RSVPSubmission.findOne({
      _id:     req.params.submissionId,
      eventId: req.params.eventId,
    });
    if (!submission) return res.status(404).json({ error: 'Submission not found.' });

    submission.deletedAt = new Date();
    await submission.save();
    res.json({ success: true });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/rsvp/:eventId/submissions/:submissionId/checkin
// Organizer — mark a guest as checked in
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:eventId/submissions/:submissionId/checkin', verifyOrganizer, async (req, res, next) => {
  try {
    const submission = await RSVPSubmission.findOne({
      _id:     req.params.submissionId,
      eventId: req.params.eventId,
    });
    if (!submission) return res.status(404).json({ error: 'Submission not found.' });

    submission.checkedIn   = true;
    submission.checkedInAt = new Date();
    await submission.save();

    res.json({ success: true, submission });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/rsvp/:eventId/submissions/:submissionId/undo-checkin
// Organizer — undo check-in
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:eventId/submissions/:submissionId/undo-checkin', verifyOrganizer, async (req, res, next) => {
  try {
    const submission = await RSVPSubmission.findOne({
      _id:     req.params.submissionId,
      eventId: req.params.eventId,
    });
    if (!submission) return res.status(404).json({ error: 'Submission not found.' });

    submission.checkedIn   = false;
    submission.checkedInAt = null;
    await submission.save();

    res.json({ success: true, submission });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/rsvp/:eventId/submissions/bulk-approve
// Organizer — approve multiple pending submissions at once
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:eventId/submissions/bulk-approve', verifyOrganizer, async (req, res, next) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'No submission IDs provided.' });
    }
    await RSVPSubmission.updateMany(
      { _id: { $in: ids }, eventId: req.params.eventId, status: 'pending' },
      { $set: { status: 'confirmed', updatedAt: new Date() } }
    );
    res.json({ success: true });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/rsvp/:eventId/submissions/bulk-decline
// Organizer — decline multiple submissions at once
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:eventId/submissions/bulk-decline', verifyOrganizer, async (req, res, next) => {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'No submission IDs provided.' });
    }
    await RSVPSubmission.updateMany(
      { _id: { $in: ids }, eventId: req.params.eventId },
      { $set: { status: 'declined', updatedAt: new Date() } }
    );
    res.json({ success: true });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/:eventId/export.csv
// Organizer — export all submissions as CSV
// Auth: accepts token via Authorization header OR ?token= query param
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:eventId/export.csv', async (req, res, next) => {
  try {
    // Allow token in query string for download links
    const jwt   = require('jsonwebtoken');
    const { secrets } = require('../keys');
    const token = req.headers.authorization?.split(' ')[1] ||
                  req.headers['x-event-token'] ||
                  req.query.token;
    if (!token) return res.status(401).json({ error: 'Unauthorized.' });

    let decoded;
    try { decoded = jwt.verify(token, secrets.jwt); }
    catch { return res.status(401).json({ error: 'Invalid or expired token.' }); }

    const eventId = req.params.eventId;
    // Full admin sessions (adminToken) are treated like event-scoped admin access.
    if (decoded.isAdmin === true && !decoded.restricted && !decoded.isDemo) decoded.isAdminAccess = true;
    if (!decoded.isAdminAccess && decoded.eventId !== eventId && decoded.eventId !== eventId?.toString()) {
      return res.status(403).json({ error: 'Token does not match this event.' });
    }
    if (decoded.role !== 'organizer' && !decoded.isAdminAccess) {
      // Check participant role in event
      const Event = require('../models/Event');
      const ev = await Event.findById(eventId).select('participants').lean();
      if (!ev) return res.status(404).json({ error: 'Event not found.' });
      const part = ev.participants.find(p => p.username === decoded.username);
      if (!part || part.role !== 'organizer') {
        return res.status(403).json({ error: 'Only organizers can export RSVPs.' });
      }
    }
    const event = await Event.findById(req.params.eventId).select('title rsvpPage').lean();
    if (!event) return res.status(404).json({ error: 'Event not found.' });

    const submissions = await RSVPSubmission.find({
      eventId:   req.params.eventId,
      deletedAt: null,
    }).sort('-submittedAt').lean();

    const customQuestions = (event.rsvpPage?.customQuestions || []);

    const escape = (v) => {
      if (v === null || v === undefined) return '';
      const s = String(v);
      if (s.includes(',') || s.includes('"') || s.includes('\n')) {
        return `"${s.replace(/"/g, '""')}"`;
      }
      return s;
    };

    const headers = [
      'First Name', 'Last Name', 'Email', 'Phone',
      'Response', 'Status', 'Plus Ones', 'Total Attendees',
      'Dietary', 'Accessibility', 'Guest Note',
      'Starred', 'Tags', 'Organizer Notes',
      'Checked In', 'Checked In At', 'Submitted At',
      ...customQuestions.map(q => q.label || q.question || `Q${q.id}`),
    ];

    const rows = submissions.map(s => {
      const customCols = customQuestions.map(q => {
        const ans = (s.customAnswers || []).find(a => a.questionId === q.id);
        if (!ans) return '';
        return Array.isArray(ans.answer) ? ans.answer.join('; ') : String(ans.answer || '');
      });
      return [
        s.firstName, s.lastName, s.email, s.phone,
        s.response, s.status,
        s.plusOnes, 1 + (s.plusOnes || 0),
        s.dietaryRestrictions, s.accessibilityNeeds, s.guestNote,
        s.starred ? 'Yes' : 'No',
        (s.tags || []).join('; '),
        s.organizerNotes,
        s.checkedIn ? 'Yes' : 'No',
        s.checkedInAt ? new Date(s.checkedInAt).toISOString() : '',
        new Date(s.submittedAt).toISOString(),
        ...customCols,
      ].map(escape).join(',');
    });

    const csv = [headers.map(escape).join(','), ...rows].join('\r\n');
    const filename = `rsvps-${event.title.replace(/[^a-z0-9]/gi, '-').toLowerCase()}-${Date.now()}.csv`;

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send('\uFEFF' + csv); // BOM for Excel compatibility
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/:eventId/stats
// Organizer — detailed statistics
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:eventId/stats', verifyOrganizer, async (req, res, next) => {
  try {
    const mongoose = require('mongoose');
    const eventObjectId = mongoose.Types.ObjectId.createFromHexString
      ? mongoose.Types.ObjectId.createFromHexString(req.params.eventId)
      : new mongoose.Types.ObjectId(req.params.eventId);

    const [summary, byDay, byTag] = await Promise.all([
      RSVPSubmission.aggregate([
        { $match: { eventId: eventObjectId, deletedAt: null } },
        { $group: {
          _id: null,
          totalYes:      { $sum: { $cond: [{ $eq: ['$response', 'yes']   }, 1, 0] } },
          totalMaybe:    { $sum: { $cond: [{ $eq: ['$response', 'maybe'] }, 1, 0] } },
          totalNo:       { $sum: { $cond: [{ $eq: ['$response', 'no']    }, 1, 0] } },
          totalAttendees:{ $sum: { $cond: [{ $eq: ['$response', 'yes']   }, { $add: ['$plusOnes', 1] }, 0] } },
          pending:       { $sum: { $cond: [{ $eq: ['$status', 'pending']    }, 1, 0] } },
          waitlisted:    { $sum: { $cond: [{ $eq: ['$status', 'waitlisted'] }, 1, 0] } },
          declined:      { $sum: { $cond: [{ $eq: ['$status', 'declined']   }, 1, 0] } },
          checkedIn:     { $sum: { $cond: ['$checkedIn', 1, 0] } },
          withEmail:     { $sum: { $cond: [{ $gt: [{ $strLenCP: { $ifNull: ['$email', ''] } }, 0] }, 1, 0] } },
          withPhone:     { $sum: { $cond: [{ $gt: [{ $strLenCP: { $ifNull: ['$phone', ''] } }, 0] }, 1, 0] } },
          hasDietary:    { $sum: { $cond: [{ $gt: [{ $strLenCP: { $ifNull: ['$dietaryRestrictions', ''] } }, 0] }, 1, 0] } },
          starred:       { $sum: { $cond: ['$starred', 1, 0] } },
        }},
      ]),
      RSVPSubmission.aggregate([
        { $match: { eventId: eventObjectId, deletedAt: null } },
        { $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$submittedAt' } },
          count: { $sum: 1 },
        }},
        { $sort: { _id: 1 } },
        { $limit: 90 },
      ]),
      RSVPSubmission.aggregate([
        { $match: { eventId: eventObjectId, deletedAt: null } },
        { $unwind: { path: '$tags', preserveNullAndEmptyArrays: false } },
        { $group: { _id: '$tags', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 20 },
      ]),
    ]);

    res.json({
      summary: summary[0] || {},
      byDay:   byDay.map(d => ({ date: d._id, count: d.count })),
      byTag:   byTag.map(t => ({ tag: t._id, count: t.count })),
    });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// GET /api/rsvp/:eventId/analytics
// Organizer — the Analytics tab in RSVPEventDashboard.jsx. Deliberately just
// two numbers (opens, submissions) rather than the full standard-event
// Analytics.jsx (tasks/budget/chat don't exist in rsvpOnly mode — see that
// dashboard's file header). RSVPSubmission.deletedAt filter mirrors /stats
// above so "submitted" here means the same thing it means everywhere else
// in this file.
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:eventId/analytics', verifyOrganizer, async (req, res, next) => {
  try {
    const mongoose = require('mongoose');
    const eventObjectId = mongoose.Types.ObjectId.createFromHexString
      ? mongoose.Types.ObjectId.createFromHexString(req.params.eventId)
      : new mongoose.Types.ObjectId(req.params.eventId);

    const [opens, submissions] = await Promise.all([
      RSVPPageView.countDocuments({ eventId: eventObjectId }),
      RSVPSubmission.countDocuments({ eventId: eventObjectId, deletedAt: null }),
    ]);

    res.json({ opens, submissions });
  } catch (err) { next(err); }
});


// Organizer — returns whether Gmail is connected for this event's RSVP notifications
// ─────────────────────────────────────────────────────────────────────────────
router.get('/:eventId/gmail/status', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId).select('rsvpPage.gmailAuth').lean();
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    const g = event.rsvpPage?.gmailAuth || {};
    res.json({ connected: g.connected === true, email: g.connected ? g.email : '' });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// DELETE /api/rsvp/:eventId/gmail/disconnect
// Organizer — removes stored Gmail OAuth tokens for this event
// ─────────────────────────────────────────────────────────────────────────────
router.delete('/:eventId/gmail/disconnect', verifyOrganizer, async (req, res, next) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    if (!event.rsvpPage) event.rsvpPage = {};
    event.rsvpPage.gmailAuth = { connected: false, email: '', accessToken: '', refreshToken: '', expiresAt: 0 };
    event.markModified('rsvpPage');
    await event.save();
    res.json({ success: true });
  } catch (err) { next(err); }
});

// ─────────────────────────────────────────────────────────────────────────────
// POST /api/mesh/rsvp-gmail-save
// Mesh-only — called by the router after Gmail OAuth callback to persist tokens
// ─────────────────────────────────────────────────────────────────────────────
router.post('/mesh/gmail-save', require('../middleware/mesh').meshAuth(process.env.BACKEND_LABEL || 'Backend'), async (req, res, next) => {
  try {
    const { eventId, email, accessToken, refreshToken, expiresAt } = req.body;
    if (!eventId || !refreshToken) return res.status(400).json({ error: 'Missing required fields.' });
    const event = await Event.findById(eventId);
    if (!event) return res.status(404).json({ error: 'Event not found.' });
    if (!event.rsvpPage) event.rsvpPage = {};
    event.rsvpPage.gmailAuth = { connected: true, email: email || '', accessToken, refreshToken, expiresAt: expiresAt || 0 };
    event.markModified('rsvpPage');
    await event.save();
    console.log(`[rsvp-gmail] Saved OAuth tokens for event ${eventId} (${email})`);
    res.json({ success: true });
  } catch (err) { next(err); }
});

module.exports = router;
module.exports.sendGuestConfirmation = sendGuestConfirmation;
